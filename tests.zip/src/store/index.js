import Vue from 'vue'
import Vuex from 'vuex'
import store from 'store'

Vue.use(Vuex, store)

export default new Vuex.Store({
    state: {
        active: false,
        dialog: false,
        dialog2: true,
        tipoFuncionario: '',
        id_funcionario: 0,
        fechas: {
        },
        yearInformeJurisdiccional: 0,
        codCorteIGJ: 0,
        codTribunalIGJ: 0,
        nombreTribunalIGJ: '',
        validaEnvioICA: 1,
        incluirExhortoJurisdiccional: true,
        meses: [
            'Enero',
            'Febrero',
            'Marzo',
            'Abril',
            'Mayo',
            'Junio',
            'Julio',
            'Agosto',
            'Septiembre',
            'Octubre',
            'Noviembre',
            'Diciembre'
        ],
        tribunal: {
            Object,
            default: () => { }
        },
        competencias: [ //------dim_competencias------
            {id: 1, competencia: 'Civil', src:'/civil_icon.png'},
            {id: 2, competencia: 'Cobranza', src:'/cobranza_icon.png'},
            {id: 3, competencia: 'Familia', src:'/familia_icon.png'},
            {id: 4, competencia: 'Penal', src:'/penal_icon.png'},
            {id: 5, competencia: 'Laboral', src:'/laboral_icon.png'},
        ]
    },
    getters: {
        tipoFuncionario(state) {
            return state.tipoFuncionario;
        },
        id_funcionario(state) {
            return state.id_funcionario;
        },
        getValidaEnvioICA(state) {
            return state.validaEnvioICA;
        }
    },
    mutations: {
        setActive(state, active) {
            state.active = !active
            setInterval(() => {
                window.dispatchEvent(new Event('resize'));
            }, 10);
        },
        setModal(state, dialog) {
            state.dialog = dialog
        },
        setFechas(state, obj,) {
            state.fechas = obj
        },
        setTipoFuncionario(state, tipoFuncionario) {
            state.tipoFuncionario = tipoFuncionario
        },
        setId_funcionario(state, id_funcionario) {
            state.id_funcionario = id_funcionario
        },
        setTribunal(state, tribunal) {
            state.tribunal = tribunal
        },
        setYearInformeJurisdiccional(state, year) {
            state.yearInformeJurisdiccional = year
        },
        setExhortosJurisdiccional(state, exhortos) {
            state.incluirExhortoJurisdiccional = exhortos
        },
        setValidaEnvioICA(state, envio) {
            state.validaEnvioICA = envio
        },
        setcodCorteIGJ(state, cod_corte) {
            state.codCorteIGJ = cod_corte
        },
        setcodTribunalIGJ(state, cod_tribunal) {
            state.codTribunalIGJ = cod_tribunal
        },
        setnombreTribunalIGJ(state, gls_tribunal) {
            state.nombreTribunalIGJ = gls_tribunal
        },
        
    },
    actions: {

    }
})