import Vue from 'vue'
import VueRouter from 'vue-router'
import store from 'store'

Vue.use(VueRouter)

const routes = new VueRouter({
	mode: 'history',
	base: process.env.BASE_URL,
	routes: [
		{
			path: '/',
			component: () => import('../AppAccess.vue'),
			children: [
				{
					path: '/',
					redirect: 'Login',
				},
				{
					path: '/Home', // Vista de las competencias.
					name: 'Home',
					component: () => import(/* webpackChunkName: "about" */ '../views/Home.vue')
				},
				{
					path: '/CambiarContrasena',
					name: 'CambiarContrasena',
					component: () => import(/* webpackChunkName: "about" */ '../views/CambiarContrasena.vue')
				},
				{
					path: '/Permisos',
					name: 'Permisos',
					component: () => import(/* webpackChunkName: "about" */ '../views/configuraciones/Permisos.vue')
				},
				{
					path: '/Usuarios',
					name: 'Usuarios',
					component: () => import(/* webpackChunkName: "about" */ '../views/configuraciones/Usuarios.vue')
				},
				//INI-CARTILLA DE VISITA MINISTRO
				{
					path: '/CartillaVisitaMinistro',
					name: 'CartillaVisitaMinistro',
					component: () => import(/* webpackChunkName: "about" */ '../views/cartilla/CartillaVisitaMinistro.vue')
				},
				{
					path: '/CartillaVisitaMinTop',
					name: 'CartillaVisitaMinTop',
					component: () => import(/* webpackChunkName: "about" */ '../views/cartilla/CartillaVisitaMinTop.vue')
				},
				{
					path: '/CartillaVisitaMinistroFamilia',
					name: 'CartillaVisitaMinistroFamilia',
					component: () => import(/* webpackChunkName: "about" */ '../views/cartilla/CartillaVisitaMinistroFamilia.vue')
				},
				//INI-JURISDICCIONAL
				{
					path: '/Jurisdiccional',
					name: 'Jurisdiccional',
					component: () => import(/* webpackChunkName: "about" */ '../views/jurisdiccional/Inicio.vue')
				},
				{
					path: '/JurisdiccionalCortes',
					name: 'JurisdiccionalCortes',
					component: () =>
						import(
							'../views/jurisdiccional/Cortes/JurisdiccionalCortes.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalGenerales',
					name: 'JurisdiccionalGenerales',
					component: () =>
						import(
							'../views/jurisdiccional/Antecedentes/Generales.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalIngresos',
					name: 'JurisdiccionalIngresos',
					component: () =>
						import(
							'../views/jurisdiccional/GestionJurisdiccional/Ingresos/Ingresos.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalAudiencias',
					name: 'JurisdiccionalAudiencias',
					component: () =>
						import(
							'../views/jurisdiccional/GestionJurisdiccional/Audiencias/Audiencias.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalResoluciones',
					name: 'JurisdiccionalResoluciones',
					component: () =>
						import(
							'../views/jurisdiccional/GestionJurisdiccional/Resoluciones/Resoluciones.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalTerminos',
					name: 'JurisdiccionalTerminos',
					component: () =>
						import(
							'../views/jurisdiccional/GestionJurisdiccional/Terminos/Terminos.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalDotacion',
					name: 'JurisdiccionalDotacion',
					component: () =>
						import(
							'../views/jurisdiccional/Dotacion/Dotacion.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalConcursos',
					name: 'JurisdiccionalConcursos',
					component: () =>
						import(
							'../views/jurisdiccional/Dotacion/Concursos.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalPresentacion',
					name: 'JurisdiccionalPresentacion',
					component: () =>
						import(
							'../views/jurisdiccional/Antecedentes/Presentacion.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalAdministrativa',
					name: 'JurisdiccionalAdministrativa',
					component: () =>
						import(
							'../views/jurisdiccional/Gestion/Administrativa.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalPresupuestaria',
					name: 'JurisdiccionalPresupuestaria',
					component: () =>
						import(
							'../views/jurisdiccional/Gestion/Presupuestaria.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalAcademia',
					name: 'JurisdiccionalAcademia',
					component: () =>
						import(
							'../views/jurisdiccional/Gestion/Academia.vue'
						),
					props: true,
				},
				{
					path: '/Jurisdiccional/JurisdiccionalSoporte',
					name: 'JurisdiccionalSoporte',
					component: () =>
						import(
							'../views/jurisdiccional/Soporte.vue'
						),
					props: true,
				},
				
				//FIN-JURISDICCIONAL				
				{
					path: '/Home/Civil',
					name: 'Civil',
					component: () => import('../components/competencias/civil/Civil.vue'),
				},
				{
					path: '/Home/Civil/RebajaCausas/',
					name: 'CivilRebaja',
					component: () => import('../views/civil/rebajaCausas/TableroRebajas')
				},
				{
					path: '/Home/Civil/Indicadores/:cod_corte', // Vista de los indicadores de los Tribunales.
					name: 'CivilIndicadores',
					component: () => import('../views/civil/Indicadores/Indicadores.vue'),
					props: {
						header: true,
						content: true
					}
				},
				{
					path: '/Home/Civil/CivilTablero/',
					name: 'CivilTablero',
					component: () => import('../views/civil/Tablero')
				},
				{
					path: '/Home/Civil/Tablero/CivilIngresos/',
					name: 'CivilIngresos',
					component: () => import('../views/civil/Ingresos/IngresosMain')
				},
				{
					path: '/Home/Civil/Tablero/CivilTerminos/',
					name: 'CivilTerminos',
					component: () => import('../views/civil/Terminos/TerminosMain')
				},
				{
					path: '/Home/Civil/Tablero/CivilResoluciones/',
					name: 'CivilResoluciones',
					component: () => import('../views/civil/Resoluciones/ResolucionesMain')
				},
				{
					path: '/Home/Civil/Tablero/CivilFallos/',
					name: 'CivilFallos',
					component: () => import('../views/civil/Fallos/FallosMain')
				},
				{
					path: '/Home/Civil/Tablero/CivilEscritosMain',
					name: 'CivilEscritosMain',
					component: () => import('../views/civil/Escritos/ModalEscritosMain')
				},
				{
					path: '/Home/Cobranza',
					name: 'Cobranza',
					component: () => import('../components/competencias/cobranza/Cobranza.vue'),
				},
				{
					path: '/Home/Cobranza/RebajaCausas/',
					name: 'CobranzaRebaja',
					component: () => import('../views/cobranza/rebajaCausas/TableroRebajas')
				},
				{
					path: '/Home/Corte', // Vista de las cortes.
					name: 'Corte',
					component: () => import('../components/competencias/apelaciones/Apelaciones.vue'),
				},
				{
					path: '/Home/Corte/Indicadores/:cod_corte', // Vista de los indicadores de los Tribunales.
					name: 'ApelacionesIndicadores',
					component: () => import('../views/apelaciones/Indicadores/Indicadores.vue'),
					props: {
						header: true,
						content: true
					}
				},
				{
					path: '/Home/Corte/ApelacionesRecursos', // Vista de los indicadores de las cortes.
					name: 'ApelacionesRecursos',
					component: () => import('../views/apelaciones/Recursos/ApelacionesRecursos.vue'),
					props: true
				},
				{
					path: '/Home/Corte/ApelacionesFallos', // Vista de los indicadores de las cortes.
					name: 'ApelacionesFallos',
					component: () => import('../views/apelaciones/Fallos/ApelacionesFallos.vue'),
					props: true
				},
				{
					path: '/Home/Corte/ApelacionesEscritos', // Vista de los indicadores de las cortes.
					name: 'ApelacionesEscritos',
					component: () => import('../views/apelaciones/Escritos/ApelacionesEscritos.vue'),
					props: true
				},
				/* Antes el indicador de resoluciones */
				{
					path: '/Home/Corte/ApelacionesInventarios', // Vista de los indicadores de las cortes.
					name: 'ApelacionesInventarios',
					component: () => import('../views/apelaciones/Inventarios/ApelacionesInventarios.vue'),
					props: true
				},
				{
					path: '/Home/Familia', // Vista de las cortes.
					name: 'Familia',
					component: () => import('../components/competencias/familia/Familia.vue'),
				},
				{
					path: '/Home/Familia/Indicadores/:cod_corte', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaIndicadores',
					component: () => import('../views/familia/Indicadores/Indicadores.vue'),
					props: {
						header: true,
						content: true
					}
				},
				{
					path: '/Home/Familia/FamiliaIngresos', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaIngresos',
					component: () => import('../views/familia/Ingresos/FamiliaIngresos.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaTerminos', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaTerminos',
					component: () => import('../views/familia/Terminos/FamiliaTerminos.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaAudiencias', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaAudiencias',
					component: () => import('../views/familia/Audiencias/FamiliaAudiencias.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaResoluciones', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaResoluciones',
					component: () => import('../views/familia/Resoluciones/FamiliaResoluciones.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaEscritos', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaEscritos',
					component: () => import('../views/familia/Escritos/FamiliaEscritos.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaActuaciones', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaActuaciones',
					component: () => import('../views/familia/Actuaciones/FamiliaActuaciones.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaEscritos', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaEscritos',
					component: () => import('../views/familia/Escritos/FamiliaEscritos.vue'),
					props: true
				},
				{
					path: '/Home/Familia/FamiliaRebaja', // Vista de los indicadores de los Tribunales.
					name: 'FamiliaRebaja',
					component: () => import('../views/familia/rebajaCausas/TableroRebajas.vue'),
					props: true
				},
				// INI - LABORAL
				{
					path: '/Home/Laboral/Indicadores/:cod_corte', // Vista de los indicadores de los Tribunales.
					name: 'LaboralIndicadores',
					component: () => import('../views/laboral/Indicadores/Indicadores.vue'),
					props: {
						header: true,
						content: true
					}
				},
				{
					path: '/Home/Laboral',
					name: 'Laboral',
					component: () => import('../components/competencias/laboral/Laboral.vue'),
				},
				{
					path: '/Home/Laboral/RebajaCausas/',
					name: 'LaboralRebaja',
					component: () => import('../views/laboral/rebajaCausas/TableroRebajas')
				},
				{
					path: '/Home/LaboralIngresos',
					name: 'LaboralIngresos',
					component: () => import('../views/laboral/Ingresos/IngresosMain'),
				},
				{
					path: '/Home/LaboralTerminos',
					name: 'LaboralTerminos',
					component: () => import('../views/laboral/Terminos/TerminosMain'),
				},
				{
					path: '/Home/LaboralAudiencias',
					name: 'LaboralAudiencias',
					component: () => import('../views/laboral/Audiencias/AudienciasMain'),
				},
				{
					path: '/Home/LaboralActuaciones',
					name: 'LaboralActuaciones',
					component: () => import('../views/laboral/Actuaciones/ActuacionesMain'),
				},
				{
					path: '/Home/LaboralEscritos',
					name: 'LaboralEscritos',
					component: () => import('../views/laboral/Escritos/EscritosMain'),
				},
				{
					path: '/Home/LaboralResoluciones',
					name: 'LaboralResoluciones',
					component: () => import('../views/laboral/Resoluciones/ResolucionesMain'),
				},
				{
					path: '/Home/LaboralTablero',
					name: 'LaboralTablero',
					component: () => import('../views/laboral/Tablero/TableroMain'),
				},
				{
					path: '/Home/LaboralResolucionesNomenclaturas',
					name: 'LaboralResolucionesNomenclaturas',
					component: () => import('../views/laboral/Resoluciones/ResolucionesNomenclaturas'),
				},
				// FIN - LABORAL
				{
					path: '/Home/Penal',
					name: 'Penal',
					component: () => import('../components/competencias/penal/Penal.vue'),
				},
				{
					path: '/Home/Penal/PenalIngresos', 
					name: 'PenalIngresos',
					component: () => import('../views/penal/Ingresos/PenalIngresos.vue'),
					props: true
				},
				{
					path: '/Home/Penal/PenalTerminos', 
					name: 'PenalTerminos',
					component: () => import('../views/penal/Terminos/TerminosCausasMain.vue'),
					props: true
				},
				{
					path: '/Home/Penal/PenalTerminosRelaciones', 
					name: 'PenalTerminosRelaciones',
					component: () => import('../views/penal/Terminos/TerminosRelacionesMain.vue'),
					props: true
				},
				{
					path: '/Home/Penal/PenalAudiencias', 
					name: 'PenalAudiencias',
					component: () => import('../views/penal/Audiencias/PenalAudiencias.vue'),
					props: true
				},
				{
					path: '/Home/Penal/PenalResoluciones', 
					name: 'PenalResoluciones',
					component: () => import('../views/penal/Resoluciones/PenalResoluciones.vue'),
					props: true
				},
				{
					path: '/Home/Penal/PenalEscritos', 
					name: 'PenalEscritos',
					component: () => import('../views/penal/Escritos/PenalEscritos.vue'),
					props: true
				},
				{
					path: '/Home/Penal/RebajaCausas/',
					name: 'PenalRebaja',
					component: () => import('../views/penal/rebajaCausas/TableroRebajas')
				},
				{
					path: '/Home/Penal/Indicadores/:cod_corte', // Vista de los indicadores de los Tribunales.
					name: 'PenalIndicadores',
					component: () => import('../views/penal/Indicadores/Indicadores.vue'),
					props: {
						header: true,
						content: true
					}
				},
				{
					path: '/Home/Penal/PenalActuaciones', 
					name: 'PenalActuaciones',
					component: () => import('../views/penal/Actuaciones/PenalActuaciones.vue'),
					props: true
				},

				//INI-COBRANZA
				{
					path: '/Home/Cobranza/Indicadores/:cod_corte', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaIndicadores',
					component: () => import('../views/cobranza/Indicadores/Indicadores.vue'),
					props: {
						header: true,
						content: true
					}
				},
				{
					path: '/Home/Cobranza/CobranzaIngresos', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaIngresos',
					component: () => import('../views/cobranza/Ingresos/CobranzaIngresos.vue'),
					props: true
				},
				{
					path: '/Home/Cobranza/CobranzaTerminos', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaTerminos',
					component: () => import('../views/cobranza/Terminos/TerminosCausasMain.vue'),
					props: true
				},
				{
					path: '/Home/Cobranza/CobranzaActuaciones', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaActuaciones',
					component: () => import('../views/cobranza/Actuaciones/ActuacionesMain.vue'),
					props: true
				},
				{
					path: '/Home/Cobranza/CobranzaResoluciones', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaResoluciones',
					component: () => import('../views/cobranza/Resoluciones/ResolucionesMain.vue'),
					props: true
				},
				{
					path: '/Home/Cobranza/CobranzaEscritos', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaEscritos',
					component: () => import('../views/cobranza/Escritos/EscritosMain.vue'),
					props: true
				},
				{
					path: '/Home/Cobranza/CobranzaNotificaciones', // Vista de los indicadores de los Tribunales.
					name: 'CobranzaNotificaciones',
					component: () => import('../views/cobranza/Notificaciones/NotificacionesMain.vue'),
					props: true
				},
				//FIN-COBRANZA


			]
		},
		{
			path: '/Login',
			name: 'Login',
			component: () => import(/* webpackChunkName: "about" */'../views/Login.vue')
		},
		{
			path: '/RecuperarContrasena',
			name: 'RecuperarContrasena',
			component: () => import(/* webpackChunkName: "about" */ '../views/RecuperarContrasena.vue')
		}
	]
})

routes.beforeEach((to, from, next) => {
	const user = store.get('usuario')
	const token = store.get('token')
	if (user && token) {
	  next()
	} else if (to.name !== 'Login') {
	  next('Login')
	} else {
	  next()
	}
  })
export default routes
