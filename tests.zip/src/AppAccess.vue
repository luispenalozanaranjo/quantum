<template>
  <v-container fluid>
    <MenuHeader :path="path"/>
    <router-view/>
  </v-container>
</template>

<script>
import MenuHeader from './components/MenuHeader'
export default {
name: 'AppAccess',
	data: () => ({
		path: []
	}),
	created() {
	},
	mounted(){
		this.path = this.$route.path
	},
	updated() {
		this.path = this.$route.path
	},  
	components: {
		MenuHeader
	}  
};
</script>
