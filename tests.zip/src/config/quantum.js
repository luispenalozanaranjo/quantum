const quantum = process.env.NODE_ENV === 'development' ? 'http://10.13.142.195:8081/' : 'http://www.quantum.pjud/'
export {
  quantum
}
