const jwt = process.env.NODE_ENV === 'development' ? 'http://vmetlbi.cadm.pjud:3005' : 'http://vmetlbi.cadm.pjud:3005'
export {
  jwt
}
