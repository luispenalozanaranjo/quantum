const url = process.env.NODE_ENV === 'development' ? 'https://loginquantum.pjud.cl/apiconfig' : 'https://quantum.pjud.cl/apiconfig'
export {
  url
}