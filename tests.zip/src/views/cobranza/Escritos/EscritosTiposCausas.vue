<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Escritos_TiposCausas'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleIngresos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Escritos_TiposCausasDet'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleIngresos"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </v-toolbar>
                    <v-row dense>
                        <v-col cols="11" xs11>
                            <Piechart id="apexchartspieGrafico" :labels="pieLabel" :series="pieSeries" :tribunal="nombretribunal" />                   
                        </v-col>
                        <v-col cols="12" xs12>
                            <v-simple-table 
                                dense
                                class="pr-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            Tipos Causas
                                        </th>
                                        <th class="white--text text-center">
                                            CANTIDAD
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
import Piechart from '../../../components/elementos/grafico/PieChart.vue'
export default {
    name: 'CobranzaEscritosTiposCausas',
    props: {
    tribunal: { type: String, default: () => '' }
  },
	data: () => ({
        dialog: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        nombretribunal: '',
        tables: [], // Inicio de variables para el grafico.
        pieSeries: [] ,
        pieLabel: [] ,
        pieValues: [],
        pieChartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGrafico',
                type: 'donut'
            },
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                       
        }, // Inicio de variables para el descargable de excel.
        excelHead : [
            {
                label: "Tipos Causas",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleIngresos: [],
        excelHeadDetalles : [
            {
                label: "ID CAUSA",
                field: "crr_causa",
            },            
            {
                label: "RIT",
                field: "rit",
            },
            {
                label: "RUC",
                field: "ruc",
            },
            {
                label: "TIPO CAUSA",
                field: "gls_tipo_causa",
            },
            {
                label: "FEC. SOLICITUD",
                field: "fec_solicitud",
            },
            {
                label: "FEC. RESOLUCIÓN",
                field: "fec_resolucion",
            },
            {
                label: "DÍAS DURACIÓN",
                field: "dias_duracion",
            },
        ],        
        search: '',
        headers: [
            { text: 'ID CAUSA', align: 'center', value: 'crr_causa', class : 'pjud white--text' },            
            { text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text' },
            { text: 'RUC', align: 'center', value: 'ruc', class : 'pjud white--text' },
            { text: 'TIPO CAUSA', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text' },
            { text: 'FEC. SOLICITUD', align: 'center', value: 'fec_solicitud', class : 'pjud white--text' },
            { text: 'FEC. RESOLUCIÓN', align: 'center', value: 'fec_resolucion', class : 'pjud white--text' },
            { text: 'DÍAS DURACIÓN', align: 'center', value: 'dias_duracion', class : 'pjud white--text' },
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false       
	}),
    watch: {
        tribunal: 'getAll',
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('cobranza_escritos_tiposcausas', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];

            let response = await this.getEscritosTiposCausas(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.


            response.recordset.map((object) => {
                dataLabels.push(object.gls_tipo_causa)
                dataSeries.push(object.cantidad)
                dataTables.push({ name: object.gls_tipo_causa, value:object.cantidad})
            });

            this.pieLabel = []
            this.pieLabel = dataLabels;
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            this.nombretribunal = '';
            this.nombretribunal = this.tribunal;

            this.detalleIngresos = []
         
        },
        async getEscritosTiposCausas (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/cobranza/getEscritosTiposCausas',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getEscritosTiposCausasDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/cobranza/getEscritosTiposCausasDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })

                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left' } },
                        { content: object.value, styles: { halign: 'center' } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE ESCRITOS POR TIPOS CAUSAS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                theme: 'grid',
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Tipo Causa', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartspieGrafico')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                doc.save('Informe Escritos.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getEscritosTiposCausasDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleIngresos = response.recordset
            this.loading = !this.loading
        }
    },
    components:{
        countTo, Piechart
    }
} 
</script>