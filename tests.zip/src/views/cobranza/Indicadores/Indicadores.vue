<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-card>
                    <v-card-title>
                        <v-toolbar flat class="pjud">
                            <v-toolbar-title >
                                <h2 class="white--text">{{corte_descripcion}}</h2>
                            </v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                        </v-toolbar>
                    </v-card-title>
                    <v-card-subtitle>
                        <FiltrosCompetencias/>
                    </v-card-subtitle>
                    <v-card-text>
                        <v-simple-table
                            dense
                        >
                            <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            TRIBUNAL
                                        </th>
                                        <th class="white--text text-center">
                                            INGRESOS
                                        </th>
                                        <th class="white--text text-center">
                                            TÉRMINOS
                                        </th>
                                        <th class="white--text text-center">
                                            ACTUACIONES
                                        </th>                                        
                                        <th class="white--text text-center">
                                            RESOLUCIONES
                                        </th>
                                        <th class="white--text text-center">
                                            ESCRITOS
                                        </th>   
                                        <th class="white--text text-center">
                                            NOTIFICACIONES
                                        </th>                                                                                                                              
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tribunales"
                                        :key="item.cod_tribunal"
                                        >
                                        <td>
                                            {{item.tribunal_descripcion}}
                                            <!-- <router-link style="text-decoration: none;" :to="{ name: 'PenalTablero' }"> 
                                                {{item.tribunal_descripcion}}
                                            </router-link>                                             -->
                                        </td>
                                        <!-- <{{item.enero}}    -->
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('CobranzaIngresos', item.cod_corte, item.cod_tribunal, item.tribunal_descripcion)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.ingresos" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('CobranzaTerminos', item.cod_corte, item.cod_tribunal, item.tribunal_descripcion)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.terminos" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                            
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('CobranzaActuaciones', item.cod_corte, item.cod_tribunal, item.tribunal_descripcion)"> 
                                                     <countTo class="count" :startVal="0" :endVal="item.actuaciones" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                            
                                           
                                        </td>                                        
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('CobranzaResoluciones', item.cod_corte, item.cod_tribunal, item.tribunal_descripcion)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.resoluciones" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                            
                                            
                                        </td>       
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('CobranzaEscritos', item.cod_corte, item.cod_tribunal, item.tribunal_descripcion)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.escritos" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                              
                                            
                                        </td> 
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('CobranzaNotificaciones', item.cod_corte, item.cod_tribunal, item.tribunal_descripcion)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.notificaciones" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                             
                                        </td>                                                                                                                                                          
                                    </tr>
                                </tbody>
                                <tfoot class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            Totales
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('ingresos')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('terminos')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('actuaciones')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('resoluciones')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('escritos')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('notificaciones')" separator="." :duration="1000"></countTo>
                                        </th>
                                    </tr>
                                </tfoot>
                            </template>
                        </v-simple-table>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import { urlApi } from '../../../config/api'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias.vue'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
export default {
	name: 'CobranzaIndicadores',   
	data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte')
        },
        cod_corte: 0,
        corte_descripcion: '',
        cod_tribunal: 0,
        tribunales:[]        
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },      
    methods: {
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            this.cod_corte = this.$route.params.cod_corte
            let objects  = []
            let datos    = [] // Arreglo para obtener los datos de los tribunales. 

            let response =  await this.getUserCompetenciasCortesTribunales(this.usuario.usuario, 'Cobranza', this.cod_corte)

            this.corte_descripcion = response[0].corte_descripcion // Nombre de la Corte.

            response.map(function (object){
                objects.push(object.cod_tribunal) // Recorro el objeto para obtener todos los tribunales asociados al usuario.
            })

            let responseTwo = await this.getResumenesTribunales(
                this.cod_corte, 
                objects, 
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito toda los indicadores de los tribunales.

            responseTwo.recordset.map(function (objects){ // Recorro el objeto para obtener todos los indicadores asociados a los tribunales.
                let position = response.findIndex(element => element.cod_tribunal === objects.cod_tribunal)
                datos.push({ 
                    cod_corte: objects.cod_corte,
                    cod_tribunal: objects.cod_tribunal,
                    corte_descripcion: response[position].corte_descripcion,
                    tribunal_descripcion: response[position].tribunal_descripcion,
                    ingresos: objects.ingresos,
                    terminos: objects.terminos,
                    resoluciones: objects.resoluciones,
                    escritos: objects.escritos,
                    actuaciones: objects.actuaciones,
                    notificaciones: objects.notificaciones                                           
                })
            })
            this.tribunales = datos // Lleno el arreglo de tribunales con los indicadores            
        },
        async getUserCompetenciasCortesTribunales (usuario, competencia, cod_corte) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/user/getUserCompetenciasCortesTribunales',
                        headers: {},
                        params:{
                            usuario: usuario,
							competencia: competencia,
                            cod_corte: cod_corte
                        }
                    })

                    resolve(response.data.competenciasCortesTribunales)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResumenesTribunales (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) { // Faltan los parametros de ano, mes, tipo de busqueda y exhortos.
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/cobranza/getResumenesTribunales',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto                            
                        }
                    })

                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        goDetallesIndicadores(paramRoute, paramCod_corte, paramCod_tribunal, tribunal_descripcion){
            try {

                store.set('cod_tribunal', paramCod_tribunal)
                store.set('cod_corte', paramCod_corte)
                store.set('tipo_tribunal', (tribunal_descripcion.includes("Oral")) ? 2 : 1)

                this.$router.push({ name: paramRoute });

            } catch (error) {
                console.log(error.message);
            }
        },
        formatNumber(number) {
            if (number != 0){
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            } else {
                return '-'
            }
        },
        calcularTotal(propiedad) {
            return this.tribunales.reduce((total, item) => total + item[propiedad], 0);
        }
    },   
    components:{
        FiltrosCompetencias,
        countTo
    }
}
</script>     