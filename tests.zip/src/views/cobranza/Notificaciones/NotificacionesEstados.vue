<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Notificaciones_Estados'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleIngresos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'NotificacionesEstados_Detalle'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleIngresos"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </v-toolbar>
                    <v-row dense>
                        <v-col cols="6" xs6>
                            <apexchart type="donut" class="pr-4 mt-4" height="450" :options="pieChartOptions" :series="pieSeries" id="graficoEstadoNotificacion"></apexchart>
                        </v-col>
                        <v-col cols="6" xs6>
                            <v-simple-table 
                                dense
                                class="pr-4 mt-4"
                                height="480px"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            ESTADOS
                                        </th>
                                        <th class="white--text text-center">
                                            CANTIDAD
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'CobranzaNotificacionesEstados',
	data: () => ({
        dialog: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [], // Inicio de variables para el grafico.
        pieSeries: [] ,
        pieLabel: [] ,
        pieChartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGrafico',
                type: 'donut'
            },
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                       
        }, // Inicio de variables para el descargable de excel.
        excelHead : [
            {
                label: "Estados",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleIngresos: [],
        excelHeadDetalles : [
            {
                label: "ID CAUSA",
                field: "crr_causa",
            },            
            {
                label: "RIT",
                field: "rit",
            },
            {
                label: "ID NOTIFICACIÓN",
                field: "crr_idnotificalitigante",
            },
            {
                label: "TIPO NOTIFICACIÓN",
                field: "gls_tipnotificacion",
            },
            {
                label: "ESTADO",
                field: "gls_estnotificacion",
            },
            {
                label: "PARTE",
                field: "gls_parte",
            },
            {
                label: "FEC. FIRMA",
                field: "fec_firma",
            },
        ],        
        search: '',
        headers: [
            { text: 'ID CAUSA', align: 'center', value: 'crr_causa', class : 'pjud white--text' },
            { text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text' },
            { text: 'ID NOTIFICACIÓN', align: 'center', value: 'crr_idnotificalitigante', class : 'pjud white--text' },
            { text: 'TIPO NOTIFICACIÓN', align: 'center', value: 'gls_tipnotificacion', class : 'pjud white--text' },
            { text: 'ESTADO', align: 'center', value: 'gls_estnotificacion', class : 'pjud white--text' },
            { text: 'PARTE', align: 'center', value: 'gls_parte', class : 'pjud white--text' },
            { text: 'FEC. FIRMA', align: 'center', value: 'fec_firma', class : 'pjud white--text' },
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('cobranza_notificaciones_estados', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];

            let response = await this.getNotificacionesEstados(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.


            response.recordset.map((object) => {
                dataLabels.push(object.gls_estnotificacion)
                dataSeries.push(object.cantidad)
                dataTables.push({ name: object.gls_estnotificacion, value:object.cantidad})
            });
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            this.pieChartOptions = {
                labels: dataLabels,
            };

            this.detalleIngresos = []
         
        },
        async getNotificacionesEstados (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/cobranza/getNotificacionesEstados',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getNotificacionesTiposDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/cobranza/getNotificacionesTiposDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })

                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left' } },
                        { content: object.value, styles: { halign: 'center' } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE NOTIFICACIONES ESTADO' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                theme: 'grid',
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Estado', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#graficoEstadoNotificacion')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                doc.save('Informe Notificaciones Estados.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getNotificacionesTiposDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleIngresos = response.recordset
            this.loading = !this.loading
        }
    },
    components:{
        countTo
    }
} 
</script>