<template>
    
</template>
<script>
export default {
    name: 'Terminos',
    data(){
        return{

        }
    }
}
</script>