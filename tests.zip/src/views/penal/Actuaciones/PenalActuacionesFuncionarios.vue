<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Actuaciones'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"                                          
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on" 
                                    @click="downloadPDF()"                                     
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleActuaciones"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'ActuacionesDetalle'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleActuaciones"
                                        :search="search"
                                        :items-per-page="causasItemsPerPage"
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"   
                                        disable-sort                                                                                
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                    La información contemplada en este indicador considera lo siguiente:<br/>
                                <ul>
                                    <li>• Causas cuyo estado no se encuentren invalidadas</li>
                                    <li>• No se consideran las causas administrativas</li>
                                    <li>• El estado de la actuación debe estar firmada</li>
                                </ul>
                        </v-tooltip>
                    </v-toolbar>
                    <v-row dense>
                        <v-col 
                            cols="6"
                            xs12
                            style="max-height: 500px"
                            class="overflow-y-auto mt-3"
                        >
                            <apexchart type="bar" height="450" :options="chartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                        <v-col cols="6" xs6>
                            <v-simple-table 
                                fixed-header
                                dense
                                class="mt-2"
                                height="500px"
                            >
                                <template v-slot:default>
                                    <thead class="pjud">
                                        <tr>
                                            <th class="pjud white--text text-center subtitle-2">
                                                Funcionario
                                            </th>
                                            <th class="pjud white--text text-center subtitle-2">
                                                Cantidad
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr
                                            v-for="item in tables"
                                            :key="item.name"
                                            >
                                            <td class="text-left">{{ item.name }}</td>
                                            <td class="text-center">
                                                <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                            </td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr class="pjud white--text">
                                            <th class="text-center  subtitle-2">Total</th>
                                            <th class="text-center  subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                                        </tr>
                                    </tfoot>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json"
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'PenalActuacionesFuncionarios',
	data: () => ({
        dialog: false,   
        total: 0,       
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        chartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: "barFuncionarios",
                type: 'bar',
                height: 450,
                toolbar: {
                    show: false
                }
            },
            colors: ["#775DD0"],
            noData: {
                text: 'Visualizando'
            },              
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true, 
                    columnWidth: '70%',
                    barHeight: '70%',
                    dataLabels: {
                        hideOverflowingLabels: true,
                        orientation: 'horizontal'
                    }                    
                },
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opt) {
                    return val.toString().replace('.',',')
                }  
            },
            xaxis: {
                categories: [],             
            },
            yaxis:{
                forceNiceScale: true,
                labels: {
                    show: true,
                    align: 'left',
                    minWidth: 0,
                    maxWidth: 500,
                }
            },
            animations: { 
                enabled: true, 
                easing: "linear", 
                speed: 1500,
                animateGradually: { 
                    enabled: true, 
                    delay: 1500 
                },
                dynamicAnimation: { 
                    enabled: true, 
                    speed: 1500 
                }
            } 
        },
        excelHead : [
            {
                label: "Funcionario",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleActuaciones: [],
        excelHeadDetalles : [{label: "Tribunal Origen", field: "gls_tribunal_origen"},            
                            {label: "Tipo Causa",       field: "gls_tipcausaref"},
                            {label: "Tipo Ingreso",     field: "gls_tipo_ingreso",},
                            {label: "Forma Inicio",     field: "gls_formainicio"},
                            {label: "Estado Procesal",  field: "gls_estrelacion"},
                            {label: "Rit",              field: "rit"},  
                            {label: "Ruc",              field: "ruc"},             
                            {label: "Fec. Ingreso",     field: "fec_ingreso"},
                            {label: "Fec. Actuación",   field: "fec_evento"},
                            {label: "Observación",      field: "gls_observacion_evento"},
                            {label: "Fec. Firma",       field: "fec_firma"},
                            {label: "Funcionario",      field: "gls_funcionario"}                        
        ],        
        search: '',
        headers: [
            { text: 'Tribunal Origen', align: 'center', value: 'gls_tribunal_origen', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipcausaref', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Ingreso', align: 'center', value: 'gls_tipo_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Forma Inicio', align: 'center', value: 'gls_formainicio', class : 'pjud white--text subtitle-2' },
            { text: 'Estado Procesal', align: 'center', value: 'gls_estrelacion', class : 'pjud white--text subtitle-2' },          
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2' },
            { text: 'Ruc', align: 'center', value: 'ruc', class : 'pjud white--text subtitle-2' },
            { text: 'Fec. Ingreso', align: 'center', value: 'fec_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Fec. Actuación', align: 'center', value: 'fec_evento', class : 'pjud white--text subtitle-2' },
            { text: 'Observación', align: 'center', value: 'gls_observacion_evento', class : 'pjud white--text subtitle-2' },
            { text: 'Fec. Firma', align: 'center', value: 'fec_firma', class : 'pjud white--text subtitle-2' },
            { text: 'Funcionario', align: 'center', value: 'gls_funcionario', class : 'pjud white--text subtitle-2' }
            
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false,
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll();
        }
    },
    async created () {
        this.$gtag.event('penal_actuaciones_funcionarios', { method: 'Google' })
        this.getAll();
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];
            let contador = 0;
            let acumulador = 0;
            this.total = 0;

            let response = await this.getActuacionesFuncionarios(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            response.recordset.map((object) => {

                dataTables.push({ name: object.gls_funcionario, value:object.cantidad})
                this.total += object.cantidad;

                if(contador > 30) {
                    acumulador += object.cantidad;
                }else{
                    dataLabels.push(object.gls_funcionario)
                    dataSeries.push({ x:object.gls_funcionario, y:object.cantidad })
                }

                contador++;

            });

            if(acumulador > 0){
                dataLabels.push('OTROS')
                dataSeries.push({ x: 'OTROS', y: acumulador })
            }
            
            this.tables = []
            this.tables = dataTables;

            this.detalleActuaciones = []

            this.chartOptions = {...this.chartOptions, ...{     
                    chart: {
                        height: (dataSeries.length <= 15) ? 450 : (dataSeries.length * 25)
                    }
                }   
            }            

            ApexCharts.exec('barFuncionarios', 'updateSeries', [{
                data: dataSeries
            }], true, true);                    
         
        },
        async getActuacionesFuncionarios (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getActuacionesFuncionarios',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getActuacionesFuncionariosDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getActuacionesFuncionariosDetalle',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })

                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left', fontSize: 12 } },
                        { content: object.value, styles: { halign: 'center', fontSize: 12 } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 2) / 100 ), 'INFORME DE ACTUACIONES POR FUNCIONARIOS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                // tableLineColor: [189, 195, 199],
                // tableLineWidth: 0.5,
                // tableLineColor: [0, 0, 0],
                theme: 'grid',
                // bodyStyles: { lineColor: [0, 0, 0] },
                // styles: { padding:0 },
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Funcionario', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartsbarFuncionarios')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addPage();
                doc.addImage(img, 'png', 10, (( doc.internal.pageSize.height * 5) / 100 ),  width-20, height-50) // Grafica               
                doc.save('Informe Actuaciones.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getActuacionesFuncionariosDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleActuaciones = response.recordset
            this.loading = !this.loading
        },
    },
    components:{
        countTo
    }          
} 
</script>