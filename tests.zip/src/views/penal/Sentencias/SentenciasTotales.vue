<template>
        <v-card>
            <v-toolbar flat dense>
                <v-spacer></v-spacer>
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn icon v-bind="attrs" v-on="on" @click="getSentenciasDetalle(0,0)">
                                <v-icon
                                large
                                color="#5461a9"
                                >
                                mdi-clipboard-text-outline
                                </v-icon>
                        </v-btn>
                    </template>
                    <span>Detalle Sentencias Mensual</span>
                </v-tooltip>

                <vue-excel-xlsx class="btn text-center"
                    :data="tbody"
                    :columns="excelHead"
                    :filename="'Sentencias'"
                    :sheetname="'Hoja1'"
                >
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs" v-on="on"
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>
                            </v-btn>
                        </template>
                        <span>Exportar a excel</span>
                    </v-tooltip>
                </vue-excel-xlsx>


            </v-toolbar>
            <v-divider></v-divider>
            <v-card-text>
                <highcharts :options="chartOptions" :constructor-type="'chart'" />
                <v-simple-table dense class="mt-10">
                    <template>
                        <thead>
                            <tr>
                                <th class="pjud white--text text-center">Año</th>
                                <th class="pjud white--text text-center">Ene</th>
                                <th class="pjud white--text text-center">Febr</th>
                                <th class="pjud white--text text-center">Mar</th>
                                <th class="pjud white--text text-center">Abr</th>
                                <th class="pjud white--text text-center">May</th>
                                <th class="pjud white--text text-center">Jun</th>
                                <th class="pjud white--text text-center">Jul</th>
                                <th class="pjud white--text text-center">Ago</th>
                                <th class="pjud white--text text-center">Sep</th>
                                <th class="pjud white--text text-center">Oct</th>
                                <th class="pjud white--text text-center">Nov</th>
                                <th class="pjud white--text text-center">Dic</th>
                            </tr>                
                        </thead>
                        <tbody>
                            <tr v-for="item in arrSentenciasData" :key="item.ano">
                                <td style ="text-align: center">{{ item.ano }}</td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 1 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 1)" v-bind:class="[user.mes == 1 ? 'white--text' : '']">
                                        {{ item.enero }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 2 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 2)" v-bind:class="[user.mes == 2 ? 'white--text' : '']">
                                        {{ item.febrero }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 3 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 3)" v-bind:class="[user.mes == 3 ? 'white--text' : '']">
                                        {{ item.marzo }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 4 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 4)" v-bind:class="[user.mes == 4 ? 'white--text' : '']">
                                        {{ item.abril }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 5 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 5)" v-bind:class="[user.mes == 5 ? 'white--text' : '']">
                                        {{ item.mayo }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 6 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 6)" v-bind:class="[user.mes == 6 ? 'white--text' : '']">
                                        {{ item.junio }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 7 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 7)" v-bind:class="[user.mes == 7 ? 'white--text' : '']">
                                        {{ item.julio }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 8 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 8)" v-bind:class="[user.mes == 8 ? 'white--text' : '']">
                                        {{ item.agosto }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 9 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 9)" v-bind:class="[user.mes == 9 ? 'white--text' : '']">
                                        {{ item.septiembre }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 10 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 10)" v-bind:class="[user.mes == 10 ? 'white--text' : '']">
                                        {{ item.octubre }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 11 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 11)" v-bind:class="[user.mes == 11 ? 'white--text' : '']">
                                        {{ item.noviembre }}
                                    </v-btn>
                                </td>
                                <td style ="text-align: center" v-bind:class="[user.mes == 12 ? 'pjud' : '']">
                                    <v-btn text @click.stop="getSentenciasDetalle(item.ano, 12)" v-bind:class="[user.mes == 12 ? 'white--text' : '']">
                                        {{ item.diciembre }}
                                    </v-btn>
                                </td>
                            </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="pjud white--text text-center">Año</th>
                                    <th class="pjud white--text text-center">Ene</th>
                                    <th class="pjud white--text text-center">Febr</th>
                                    <th class="pjud white--text text-center">Mar</th>
                                    <th class="pjud white--text text-center">Abr</th>
                                    <th class="pjud white--text text-center">May</th>
                                    <th class="pjud white--text text-center">Jun</th>
                                    <th class="pjud white--text text-center">Jul</th>
                                    <th class="pjud white--text text-center">Ago</th>
                                    <th class="pjud white--text text-center">Sep</th>
                                    <th class="pjud white--text text-center">Oct</th>
                                    <th class="pjud white--text text-center">Nov</th>
                                    <th class="pjud white--text text-center">Dic</th>
                                </tr>                             
                            </tfoot>
                        </template>
                    </v-simple-table>
            </v-card-text>
            <v-dialog
                v-model="dialog"
                max-width="1200px"
            >
                <v-card>
                    <v-card-title class="headline">
                        <v-btn
                            class="pjud white--text"
                            @click="dialog = false"
                        > Cerrar
                        </v-btn>
                        <v-spacer></v-spacer>

                        <vue-excel-xlsx class="btn text-center"
                            :data="arrSentenciasDetalle"
                            :columns="excelDetalleHead"
                            :filename="'SentenciasDetalles'"
                            :sheetname="'Hoja1'"
                        >
                            <v-tooltip top>
                                <template v-slot:activator="{ on, attrs }">
                                    <v-btn
                                        class="mx-2"
                                        fab
                                        dark
                                        small
                                        color="success"
                                        v-bind="attrs" v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>
                                    </v-btn>
                                </template>
                                <span>Exportar a excel</span>
                            </v-tooltip>
                        </vue-excel-xlsx>


                    </v-card-title>                     
                    <v-card-text>      
                        <v-data-table
                            :headers="SentenciasDetalleHeader"
                            :items="arrSentenciasDetalle"
                            :items-per-page="10"
                            class="mt-5 elevation-1"
                        ></v-data-table>                   
                    </v-card-text>
                </v-card>
            </v-dialog>
        </v-card>
</template>

<script>
import { quantum } from '../../../config/quantum'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import { url } from '../../../config/api'
import store from 'store'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    data() {
        return{
            chartOptions: JSON.parse(JSON.stringify(Graph['lines'][0])),
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo:  (this.$route.params.tipo === undefined) ? store.get('tipo') : this.$route.params.tipo
            },
            arrSentenciasData: [],
            arrSentenciasDetalle: [],
            tbody: [],
            excelHead : [  {label: "Año",      field: "ano",},
                            {label: "Enero",    field: "enero",},
                            {label: "Febrero",  field: "febrero",},
                            {label: "Marzo",    field: "marzo",},
                            {label: "Abril",    field: "abril",},
                            {label: "Mayo",     field: "mayo",},
                            {label: "Junio",    field: "junio",},
                            {label: "Julio",    field: "julio",},
                            {label: "Agosto",   field: "agosto",},
                            {label: "Septiembre",field: "septiembre",},
                            {label: "Octubre",  field: "octubre",},
                            {label: "Noviembre",field: "noviembre",},
                            {label: "Diciembre",field: "diciembre",}                                                                                                                                                                                                
            ],

            SentenciasDetalleHeader: [{text: 'Tribunal', align: 'center', sortable: false, value: 'gls_tribunal', class: 'pjud white--text'},
                                        {text: 'Fecha Ingreso', align: 'center', sortable: false, value: 'fec_ingreso', class: 'pjud white--text'},
                                        {text: 'Rol', align: 'center', sortable: false, value: 'idf_rolinterno', class: 'pjud white--text'},
                                        {text: 'Año', align: 'center', sortable: false, value: 'ano', class: 'pjud white--text'},
                                        {text: 'Fecha Sentencia', align: 'center', sortable: false, value: 'fec_sentencia', class: 'pjud white--text'},
                                        {text: 'Juez', align: 'center', sortable: false, value: 'nombre', class: 'pjud white--text'},
            ],
            excelDetalleHead : [  {label: "Tribunal",      field: "gls_tribunal",},
                            {label: "Fecha Ingreso",    field: "fec_ingreso",},
                            {label: "Rol",  field: "idf_rolinterno",},
                            {label: "Año",    field: "ano",},
                            {label: "Fecha Sentencia",    field: "fec_sentencia",},
                            {label: "Juez",     field: "nombre",},                                                                                                                                                                                              
            ],
            dialog: false,                  
        }
    },
    created(){
        this.$gtag.event('penal_sentencias', { method: 'Google' })
        this.getSentencias()
    },
    methods:{
        async getSentencias(){
            try {
                const axios = require('axios')
                const req1 = url + '/penal/sentenciasTotales' 
                this.chartOptions.series = []
                this.chartOptions.legend.layout = 'horizontal'
                // this.chartOptions.legend.align = 'right'
                // this.chartOptions.legend.verticalAlign = 'middle'
                this.chartOptions.yAxis.title.text = 'Cant. Sentencias'

                this.chartOptions.title.text =  'Sentencias'
                this.chartOptions.subtitle.text =  'cantidad de sentencias mensuales'

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal,
                                    mes: this.user.mes,
                                    ano: this.user.ano,
                                    rango: this.user.rango,
                                    exhortos: this.user.exhorto
                            }
                                        
                        })
                        
                        const data = response.data
                        this.arrSentenciasData = []


                        Object.values(data.recordset).map((type) => {

                            this.chartOptions.series.push({
                                data: [type.enero, type.febrero, type.marzo, type.abril, type.mayo, type.junio, type.julio, type.agosto,
                                    type.septiembre, type.octubre, type.noviembre, type.diciembre
                                ],
                                name: type.ano
                            })

                            this.tbody.push({ ano: type.ano, 
                                          enero: this.$thousandSeparator(type.enero) ,
                                          febrero: this.$thousandSeparator(type.febrero) ,
                                          marzo: this.$thousandSeparator(type.marzo) ,
                                          abril: this.$thousandSeparator(type.abril) ,
                                          mayo: this.$thousandSeparator(type.mayo) ,
                                          junio: this.$thousandSeparator(type.junio) ,
                                          julio: this.$thousandSeparator(type.julio) ,
                                          agosto: this.$thousandSeparator(type.agosto) ,
                                          septiembre: this.$thousandSeparator(type.septiembre) ,
                                          octubre: this.$thousandSeparator(type.octubre) ,
                                          noviembre: this.$thousandSeparator(type.noviembre) ,
                                          diciembre: this.$thousandSeparator(type.diciembre)})

                            this.arrSentenciasData.push({
                                "ano": type.ano,
                                "enero": type.enero,
                                "febrero": type.febrero,
                                "marzo": type.marzo,
                                "abril": type.abril,
                                "mayo": type.mayo,
                                "junio": type.junio,
                                "julio": type.julio,
                                "agosto": type.agosto,
                                "septiembre": type.septiembre,
                                "octubre": type.octubre,
                                "noviembre": type.noviembre,
                                "diciembre": type.diciembre
                            })

                        })


                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

                
            } catch (error) {
                console.log(error)
            }
        },
        async getSentenciasDetalle(paramAno, paramMes){
            try {
                const axios = require('axios')
                 this.arrSentenciasDetalle = []

                let req1 = url + '/penal/sentenciasDetallesOrales' 
                
                if(this.user.tipo == 13){
                    req1 = url + '/penal/sentenciasDetallesGarantias' 
                }

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal,
                                    mes: (paramMes == 0) ? this.user.mes : paramMes,
                                    ano: (paramAno == 0) ? this.user.ano : paramAno,
                                    rango: this.user.rango,
                                    exhortos: this.user.exhorto
                            }
                                        
                        })
                        
                        const data = response.data

                        Object.values(data.recordset).map((type) => {
                            
                            this.arrSentenciasDetalle.push({"gls_tribunal": type.gls_tribunal, 
                                                            "fec_ingreso": type.fec_ingreso, 
                                                            "idf_rolinterno": type.idf_rolinterno, 
                                                            "ano": type.ano, 
                                                            "fec_sentencia": type.fec_sentencia, 
                                                            "nombre": type.nombre})
                        
                        })

                        // console.log(this.arrSentenciasDetalle[0])
                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)
                this.dialog = !this.dialog

                
            } catch (error) {
                console.log(error)
            }
        },
        prueba(mes, ano){
            console.log("probando holamundo");
            console.log(mes);
            console.log(ano);
        }
    },
    components:{
        highcharts: Chart,
    }
}
</script>

<style lang="css" scoped>

th {
    /* border: 1px solid rgb(190, 190, 190); */
    padding: 5px 10px;
    white-space: nowrap;
    border: 1px solid #ddd;
    position: sticky;
    top: 0;
}

.bordes{
    border: 1px solid #ddd;
    white-space: nowrap;
}

</style>