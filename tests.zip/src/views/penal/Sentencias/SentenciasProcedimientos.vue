<template>
        <v-card>
            <v-toolbar flat dense class="mb-0">
                <v-spacer></v-spacer>
                <v-tooltip top class="grey">
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn icon v-bind="attrs" v-on="on" @click="dialog = !dialog">
                            <v-icon
                                large
                                color="#5461a9"
                            >
                                mdi-clipboard-text-outline
                            </v-icon>
                        </v-btn>
                    </template>
                    <span>Detalle Sentencias Mensual</span>
                </v-tooltip>

                <vue-excel-xlsx class="btn text-center"
                    :data="arrSentenciasData"
                    :columns="excelHead"
                    :filename="'SentenciasProcedimientos'"
                    :sheetname="'Hoja1'"
                >
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs" v-on="on"
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>
                            </v-btn>
                        </template>
                        <span>Exportar a excel</span>
                    </v-tooltip>
                </vue-excel-xlsx>




            </v-toolbar>
            <v-divider></v-divider>
            <v-card-text>
                <highcharts :options="chartOptions" :constructor-type="'chart'" />
                    <v-simple-table dense class="mt-10">
                        <template>
                            <thead>
                                <tr>
                                    <th class="pjud white--text text-center">Año {{this.user.ano}}</th>
                                    <th class="pjud white--text text-center">Ene</th>
                                    <th class="pjud white--text text-center">Febr</th>
                                    <th class="pjud white--text text-center">Mar</th>
                                    <th class="pjud white--text text-center">Abr</th>
                                    <th class="pjud white--text text-center">May</th>
                                    <th class="pjud white--text text-center">Jun</th>
                                    <th class="pjud white--text text-center">Jul</th>
                                    <th class="pjud white--text text-center">Ago</th>
                                    <th class="pjud white--text text-center">Sep</th>
                                    <th class="pjud white--text text-center">Oct</th>
                                    <th class="pjud white--text text-center">Nov</th>
                                    <th class="pjud white--text text-center">Dic</th>
                                    <th class="pjud white--text text-center">Total</th>
                                </tr>                
                            </thead>
                            <tbody>
                                <tr v-for="item in arrSentenciasData" :key="item.ano">
                                    <td style ="text-align: center">{{ item.procedimiento }}</td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 1 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 1 ? 'white--text' : '']">
                                            {{ item.enero }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 2 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 2 ? 'white--text' : '']">
                                            {{ item.febrero }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 3 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 3 ? 'white--text' : '']">
                                            {{ item.marzo }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 4 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 4 ? 'white--text' : '']">
                                            {{ item.abril }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 5 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 5 ? 'white--text' : '']">
                                            {{ item.mayo }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 6 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 6 ? 'white--text' : '']">
                                            {{ item.junio }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 7 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 7 ? 'white--text' : '']">
                                            {{ item.julio }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 8 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 8 ? 'white--text' : '']">
                                            {{ item.agosto }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 9 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 9 ? 'white--text' : '']">
                                            {{ item.septiembre }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 10 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 10 ? 'white--text' : '']">
                                            {{ item.octubre }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 11 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 11 ? 'white--text' : '']">
                                            {{ item.noviembre }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center" v-bind:class="[user.mes == 12 ? 'pjud' : '']">
                                        <span v-bind:class="[user.mes == 12 ? 'white--text' : '']">
                                            {{ item.diciembre }}
                                        </span>
                                    </td>
                                    <td style ="text-align: center">{{ item.total }}</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="pjud white--text text-center">Año {{this.user.ano}}</th>
                                    <th class="pjud white--text text-center">Ene</th>
                                    <th class="pjud white--text text-center">Febr</th>
                                    <th class="pjud white--text text-center">Mar</th>
                                    <th class="pjud white--text text-center">Abr</th>
                                    <th class="pjud white--text text-center">May</th>
                                    <th class="pjud white--text text-center">Jun</th>
                                    <th class="pjud white--text text-center">Jul</th>
                                    <th class="pjud white--text text-center">Ago</th>
                                    <th class="pjud white--text text-center">Sep</th>
                                    <th class="pjud white--text text-center">Oct</th>
                                    <th class="pjud white--text text-center">Nov</th>
                                    <th class="pjud white--text text-center">Dic</th>
                                    <th class="pjud white--text text-center">{{totalSentencias}}</th>
                                </tr>                             
                                </tfoot>
                            </template>
                        </v-simple-table>
            </v-card-text>
            <v-dialog
                v-model="dialog"
                max-width="1200px"
            >
                <v-card>
                    <v-card-title class="headline">
                        <v-btn
                            class="pjud white--text"
                            @click="dialog = false"
                        > Cerrar
                        </v-btn>
                        <v-spacer></v-spacer>

                        <vue-excel-xlsx class="btn text-center"
                            :data="arrSentenciasDetalle"
                            :columns="excelDetalleHead"
                            :filename="'SentenciasDetalles'"
                            :sheetname="'Hoja1'"
                        >
                            <v-tooltip top>
                                <template v-slot:activator="{ on, attrs }">
                                    <v-btn
                                        class="mx-2"
                                        fab
                                        dark
                                        small
                                        color="success"
                                        v-bind="attrs" v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>
                                    </v-btn>
                                </template>
                                <span>Exportar a excel</span>
                            </v-tooltip>
                        </vue-excel-xlsx>


                    </v-card-title>                     
                    <v-card-text>      
                        <v-data-table
                            :headers="SentenciasDetalleHeader"
                            :items="arrSentenciasDetalle"
                            :items-per-page="10"
                            class="mt-5 elevation-1"
                        ></v-data-table>                   
                    </v-card-text>
                </v-card>
            </v-dialog>
        </v-card>
</template>

<script>
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import { url } from '../../../config/api'
import store from 'store'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'SentenciasProcedimientos',
    data() {
        return{
            chartOptions: JSON.parse(JSON.stringify(Graph['lines'][0])),
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo:  (this.$route.params.tipo === undefined) ? store.get('tipo') : this.$route.params.tipo
            },
            arrSentenciasData: [],
            totalSentencias: 0,
            dialog: false,
            tbody: [],
            arrSentenciasDetalle: [],
            excelHead : [  {label: "Procedimiento",      field: "procedimiento",},
                            {label: "Enero",    field: "enero",},
                            {label: "Febrero",  field: "febrero",},
                            {label: "Marzo",    field: "marzo",},
                            {label: "Abril",    field: "abril",},
                            {label: "Mayo",     field: "mayo",},
                            {label: "Junio",    field: "junio",},
                            {label: "Julio",    field: "julio",},
                            {label: "Agosto",   field: "agosto",},
                            {label: "Septiembre",field: "septiembre",},
                            {label: "Octubre",  field: "octubre",},
                            {label: "Noviembre",field: "noviembre",},
                            {label: "Diciembre",field: "diciembre",},
                            {label: "Total",field: "total",}                                                                                                                                                                                                
            ],
            excelDetalleHead : [  {label: "Tribunal",      field: "gls_tribunal",},
                            {label: "Fecha Ingreso",    field: "fec_ingreso",},
                            {label: "Rol",  field: "idf_rolinterno",},
                            {label: "Año",    field: "ano",},
                            {label: "Fecha Sentencia",    field: "fec_sentencia",},
                            {label: "Juez",     field: "nombre",},
                            {label: "Procedimiento",     field: "gls_procedimiento",},
            ],
            SentenciasDetalleHeader: [{text: 'Tribunal', align: 'center', sortable: false, value: 'gls_tribunal', class: 'pjud white--text'},
                                        {text: 'Fecha Ingreso', align: 'center', sortable: false, value: 'fec_ingreso', class: 'pjud white--text'},
                                        {text: 'Rol', align: 'center', sortable: false, value: 'idf_rolinterno', class: 'pjud white--text'},
                                        {text: 'Año', align: 'center', sortable: false, value: 'ano', class: 'pjud white--text'},
                                        {text: 'Fecha Sentencia', align: 'center', sortable: false, value: 'fec_sentencia', class: 'pjud white--text'},
                                        {text: 'Juez', align: 'center', sortable: false, value: 'nombre', class: 'pjud white--text'},
                                        {text: 'Procedimiento', align: 'center', sortable: false, value: 'gls_procedimiento', class: 'pjud white--text'},
            ],
            
        }
    },
    created(){
        this.$gtag.event('penal_sentencias', { method: 'Google' })
        this.getSentencias()
        this.getSentenciasDetalle()
        // console.log(this.user)
    },
    methods:{
        async getSentencias(){
            try {
                const axios = require('axios')
                const req1 = url + '/penal/sentenciasProcedimientos' 
                this.chartOptions.series = []
                this.chartOptions.legend.layout = 'horizontal'
                this.chartOptions.yAxis.title.text = 'Cant. Sentencias'

                this.chartOptions.title.text =  'Sentencias Procedimientos'
                this.chartOptions.subtitle.text =  'cantidad de sentencias mensuales por tipo de procedimiento '

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal,
                                    mes: this.user.mes,
                                    ano: this.user.ano,
                                    rango: this.user.rango,
                                    exhortos: this.user.exhorto
                            }
                                        
                        })
                        
                        const data = response.data
                        this.arrSentenciasData = []
                        this.totalSentencias = 0

                        Object.values(data.recordset).map((type) => {

                            this.chartOptions.series.push({
                                data: [type.enero, type.febrero, type.marzo, type.abril, type.mayo, type.junio, type.julio, type.agosto,
                                    type.septiembre, type.octubre, type.noviembre, type.diciembre
                                ],
                                name: type.gls_procedimiento
                            })

                            this.totalSentencias += type.cantidad

                            this.arrSentenciasData.push({
                                "procedimiento": type.gls_procedimiento,
                                "enero": type.enero,
                                "febrero": type.febrero,
                                "marzo": type.marzo,
                                "abril": type.abril,
                                "mayo": type.mayo,
                                "junio": type.junio,
                                "julio": type.julio,
                                "agosto": type.agosto,
                                "septiembre": type.septiembre,
                                "octubre": type.octubre,
                                "noviembre": type.noviembre,
                                "diciembre": type.diciembre,
                                "total": type.cantidad
                            })

                        })


                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

                
            } catch (error) {
                console.log(error)
            }
        },
        async getSentenciasDetalle(){
            try {
                const axios = require('axios')

                let req1 = url + '/penal/sentenciasDetallesOralesProcedimientos' 
                
                if(this.user.tipo == 13){
                    req1 = url + '/penal/sentenciasDetallesGarantiasProcedimientos' 
                }

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal,
                                    mes: this.user.mes,
                                    ano: this.user.ano,
                                    rango: this.user.rango,
                                    exhortos: this.user.exhorto
                            }
                                        
                        })
                        
                        const data = response.data
                        this.arrSentenciasDetalle = []

                        Object.values(data.recordset).map((type) => {
                            
                            this.arrSentenciasDetalle.push({"gls_tribunal": type.gls_tribunal, 
                                                            "fec_ingreso": type.fec_ingreso, 
                                                            "idf_rolinterno": type.idf_rolinterno, 
                                                            "ano": type.ano, 
                                                            "fec_sentencia": type.fec_sentencia, 
                                                            "nombre": type.nombre,
                                                            "gls_procedimiento": type.gls_procedimiento},)
                        
                        })

                        // console.log(this.arrSentenciasDetalle[0])
                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

                
            } catch (error) {
                console.log(error)
            }
        },
    },
    components:{
        highcharts: Chart,
    }
}
</script>

<style lang="css" scoped>

th {
    /* border: 1px solid rgb(190, 190, 190); */
    padding: 5px 10px;
    white-space: nowrap;
    border: 1px solid #ddd;
    position: sticky;
    top: 0;
}

.bordes{
    border: 1px solid #ddd;
    white-space: nowrap;
}

</style>