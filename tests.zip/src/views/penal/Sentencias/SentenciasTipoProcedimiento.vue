<template>
        <v-card>
            <v-card-text>
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn v-bind="attrs" v-on="on" @click="dialog = !dialog" class="pjud white--text ml-4">
                                Detalle Sentencias
                            </v-btn>
                        </template>
                        <span>Detalle Sentencias</span>
                    </v-tooltip>
                    <highcharts :options="chartOptions" :constructor-type="'chart'" />

                    <vue-excel-xlsx class="btn text-center"
                        :data="arrSentenciasData"
                        :columns="excelHead"
                        :filename="'SentenciasProcedimientos'"
                        :sheetname="'Hoja1'"
                    >
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                    class="mx-2"
                                    fab
                                    dark
                                    small
                                    color="success"
                                    v-bind="attrs" v-on="on"
                                >
                                    <v-icon >mdi-microsoft-excel</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar a excel</span>
                        </v-tooltip>
                    </vue-excel-xlsx>


                    <v-simple-table dense class="mt-2">
                        <template>
                            <thead>
                                <tr>
                                    <th class="pjud white--text text-center">#</th>
                                    <th class="pjud white--text text-center">Procedimiento</th>
                                    <th class="pjud white--text text-center">Cantidad</th>
                                </tr>                
                            </thead>
                            <tbody>
                                <tr v-for="item in arrSentenciasData" :key="item.contador">
                                    <td style ="text-align: center">{{ item.contador }}</td>
                                    <td style ="text-align: center">{{ item.gls_procedimiento }}</td>
                                    <td style ="text-align: center">{{ item.cantidad }} </td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="pjud white--text text-center">Total</th>
                                    <th class="pjud white--text text-center"></th>
                                    <th class="pjud white--text text-center">{{ totalSentencias }}</th>
                                </tr>                             
                                </tfoot>
                            </template>
                        </v-simple-table>
            </v-card-text>
            <v-dialog
                v-model="dialog"
                max-width="1200px"
            >
                <v-card>
                    <v-card-title class="headline">
                        <v-btn
                            class="pjud white--text"
                            @click="dialog = false"
                        > Cerrar
                        </v-btn>
                        <v-spacer></v-spacer>

                        <vue-excel-xlsx class="btn text-center"
                            :data="arrSentenciasDetalle"
                            :columns="excelDetalleHead"
                            :filename="'SentenciasDetalles'"
                            :sheetname="'Hoja1'"
                        >
                            <v-tooltip top>
                                <template v-slot:activator="{ on, attrs }">
                                    <v-btn
                                        class="mx-2"
                                        fab
                                        dark
                                        small
                                        color="success"
                                        v-bind="attrs" v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>
                                    </v-btn>
                                </template>
                                <span>Exportar a excel</span>
                            </v-tooltip>
                        </vue-excel-xlsx>


                    </v-card-title>                     
                    <v-card-text>      
                        <v-data-table
                            :headers="SentenciasDetalleHeader"
                            :items="arrSentenciasDetalle"
                            :items-per-page="10"
                            class="mt-5 elevation-1"
                        ></v-data-table>                   
                    </v-card-text>
                </v-card>
            </v-dialog>
        </v-card>
</template>

<script>
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import { url } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import store from 'store'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'SentenciasTiposProcedimientos',
    data() {
        return{
            chartOptions: JSON.parse(JSON.stringify(Graph['pie'][0])),
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo:  (this.$route.params.tipo === undefined) ? store.get('tipo') : this.$route.params.tipo
            },
            arrSentenciasData: [],
            totalSentencias: 0,
            dialog: false,
            tbody: [],
            arrSentenciasDetalle: [],
            excelHead : [  {label: "Contador",      field: "contador",},
                            {label: "Procedimiento",    field: "gls_procedimiento",},
                            {label: "Cantidad",  field: "cantidad",},                                                                                                                                                                                               
            ],
            excelDetalleHead : [  {label: "Tribunal",      field: "gls_tribunal",},
                            {label: "Fecha Ingreso",    field: "fec_ingreso",},
                            {label: "Rol",  field: "idf_rolinterno",},
                            {label: "Año",    field: "ano",},
                            {label: "Fecha Sentencia",    field: "fec_sentencia",},
                            {label: "Juez",     field: "nombre",},
                            {label: "Procedimiento",     field: "gls_procedimiento",},
            ],
            SentenciasDetalleHeader: [{text: 'Tribunal', align: 'center', sortable: false, value: 'gls_tribunal', class: 'pjud white--text'},
                                        {text: 'Fecha Ingreso', align: 'center', sortable: false, value: 'fec_ingreso', class: 'pjud white--text'},
                                        {text: 'Rol', align: 'center', sortable: false, value: 'idf_rolinterno', class: 'pjud white--text'},
                                        {text: 'Año', align: 'center', sortable: false, value: 'ano', class: 'pjud white--text'},
                                        {text: 'Fecha Sentencia', align: 'center', sortable: false, value: 'fec_sentencia', class: 'pjud white--text'},
                                        {text: 'Juez', align: 'center', sortable: false, value: 'nombre', class: 'pjud white--text'},
                                        {text: 'Procedimiento', align: 'center', sortable: false, value: 'gls_procedimiento', class: 'pjud white--text'},
            ],
            
        }
    },
    created(){
        this.getSentencias()
        this.getSentenciasDetalle()
    },
    methods:{
        async getSentencias(){
            try {
                const axios = require('axios')
                const req1 = url + '/penal/sentenciasProcedimientosTipos' 
                this.chartOptions.series = []

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte: this.user.cod_corte,
                                cod_tribunal: this.user.cod_tribunal,
                                anoInicio: this.fechas.anoInicio,
                                mesInicio: this.fechas.mesInicio,
                                anoFin: this.fechas.anoFin,
                                mesFin: this.fechas.mesFin,
                                flg_exhorto: this.fechas.exhorto
                            }
                        })
                        
                        const data = response.data
                        this.arrSentenciasData = []
                        this.totalSentencias = 0
                        let dataTable = []
                        let contador = 1
                        this.chartOptions.plotOptions.pie.dataLabels.format =  '<b>{point.name}</b>: {point.percentage:.1f} % ({point.y:.0f})';

                        Object.values(data.recordset).map((type) => {


                            this.arrSentenciasData.push({'contador': contador,
                                                        'gls_procedimiento': type.gls_procedimiento,
                                                        'cantidad': type.cantidad}
                            )

                            dataTable.push({name: type.gls_procedimiento,
                                            y: type.cantidad}
                            )

                            this.totalSentencias += type.cantidad
                            contador += 1

                        })

                        this.chartOptions.series.push({
                            data: dataTable,
                            name: 'Nro Sentencias',
                            colorByPoint: true
                        })
                        

                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

                
            } catch (error) {
                console.log(error)
            }
        },
        async getSentenciasDetalle(){
            try {
                const axios = require('axios')

                let req1 = url + '/penal/sentenciasDetalleProcedimientosTiposOrales' 
                
                if(this.user.tipo == 13){
                    req1 = url + '/penal/sentenciasDetalleProcedimientosTiposGarantias' 
                }

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte: this.user.cod_corte,
                                cod_tribunal: this.user.cod_tribunal,
                                anoInicio: this.fechas.anoInicio,
                                mesInicio: this.fechas.mesInicio,
                                anoFin: this.fechas.anoFin,
                                mesFin: this.fechas.mesFin,
                                flg_exhorto: this.fechas.exhorto
                            }
                                        
                        })
                        
                        const data = response.data
                        this.arrSentenciasDetalle = []

                        Object.values(data.recordset).map((type) => {
                            
                            this.arrSentenciasDetalle.push({"gls_tribunal": type.gls_tribunal, 
                                                            "fec_ingreso": type.fec_ingreso, 
                                                            "idf_rolinterno": type.idf_rolinterno, 
                                                            "ano": type.ano, 
                                                            "fec_sentencia": type.fec_sentencia, 
                                                            "nombre": type.nombre,
                                                            "gls_procedimiento": type.gls_procedimiento},)
                        
                        })

                        // console.log(this.arrSentenciasDetalle[0])
                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

                
            } catch (error) {
                console.log(error)
            }
        },
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.getSentencias()
            this.getSentenciasDetalle()
        }
    },
    components:{
        highcharts: Chart
    }
}
</script>

<style lang="css" scoped>

th {
    /* border: 1px solid rgb(190, 190, 190); */
    padding: 5px 10px;
    white-space: nowrap;
    border: 1px solid #ddd;
    position: sticky;
    top: 0;
}

.bordes{
    border: 1px solid #ddd;
    white-space: nowrap;
}

</style>