<template>
    <Layout>
        <v-card>
            <v-card flat>
                <v-card-title class="pjud white--text">
                    Filtros
                    <v-spacer></v-spacer>                
                </v-card-title>
                <v-card-text>
                    <FiltrosCompetencias v-on:buscar="submit" class="mt-4"/>
                </v-card-text>
            </v-card>
            <v-card-text>
            <v-tabs
                v-model="tab"
                flat
                centered
                center-active
                class="pjud"
            >
                <v-tab href="#tab-1">Sentencias Procedimientos</v-tab>
                <!-- <v-tab href="#tab-2" hidden>Sentencias</v-tab>
                <v-tab href="#tab-3" hidden>Sent Procedimientos</v-tab> -->
                <!-- <v-spacer></v-spacer>
                <v-tooltip right>
                    <template v-slot:activator="{ on, attrs }">
                        <font-awesome-icon icon="question-circle" size="2x" class="orange--text mt-2 mr-2" v-bind="attrs" v-on="on"/>
                    </template>
                    <span>
                        Los siguientes estados no son consideradas en el indicador de Ingresos: Invalidado
                    </span>
                </v-tooltip> -->
            </v-tabs>
            <v-tabs-items v-model="tab">
                <v-tab-item id="tab-1">
                    <SentenciasTiposProcedimientos  />
                </v-tab-item>
                <!-- <v-tab-item id="tab-2">
                    <SentenciasTotales  />
                </v-tab-item>
                <v-tab-item id="tab-3">
                    <SentenciasProcedimientos  />
                </v-tab-item> -->
            </v-tabs-items>
            </v-card-text>
        </v-card>
    </Layout>
</template>

<script>
import SentenciasTotales from '../Sentencias/SentenciasTotales'
import SentenciasProcedimientos from '../Sentencias/SentenciasProcedimientos'
import SentenciasTiposProcedimientos from '../Sentencias/SentenciasTipoProcedimiento'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'
import Layout from '../../../components/Layout'

export default {
    name: "SentenciasMain",
    data(){
        return{
            tab: null
        }
    },
    methods:{
        submit(){

        },
    },
    components:{
        SentenciasTotales,
        SentenciasProcedimientos,
        SentenciasTiposProcedimientos,
        FiltrosCompetencias,
        Layout
    }
}

</script>
