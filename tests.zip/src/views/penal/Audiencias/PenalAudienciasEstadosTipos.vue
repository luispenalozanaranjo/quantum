<template>
    <v-container fluid>
        <v-row dense>
            <v-col md="12">
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Audiencias Estados'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                <br/>
                                <ul>
                                    <li>• Se excluyen causas invalidadas o con rol interno "0"</li>
                                    <li>• Son consideradas audiencias realizadas toda audiencia que ocupe recursos del tribunal:
                                        <ul>
                                            <li>Audiencias efectivamente realizadas</li>
                                            <li>Suspendidas que figuren firmadas</li>
                                            <li>Reprogramadas que figuren firmadas</li>
                                        </ul>
                                    </li>
                                    <li>
                                        • Son consideradas audiencias NO realizadas:
                                        <ul>
                                            <li>Suspendidas que no figuren firmadas</li>
                                            <li>Reprogramadas que no figuren firmadas</li>
                                            <li>Sin efecto</li>
                                            <li>Reprogramada por Resolución</li>
                                        </ul>
                                    </li>
                                </ul>
                        </v-tooltip>
                        <v-spacer>
                        </v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadReprogramacionesDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>     
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tablesTwo"
                                    :columns="excelHeadTwo"
                                    :filename="'Audiencias Reprogramadas'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleIngresos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Detalle Audiencias Estados'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleIngresos"
                                        :search="search"
                                        :items-per-page="causasItemsPerPage"
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"
                                        disable-sort
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>
                    </v-toolbar>
                    <v-row dense>
                        <v-col sm="12" md="6">
                            <apexchart type="donut" ref="pieGrafico" class="pr-4 mt-4" height="300" :options="pieChartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                        <v-col sm="12" md="6">
                            <apexchart type="donut" ref="pieGraficoTwo" class="pr-4 mt-4" height="300" :options="pieChartOptionsTwo" :series="pieSeriesTwo"></apexchart>
                        </v-col>                                                
                    </v-row>
                    <v-row dense>
                        <v-col sm="12" md="6" xs6>
                            <v-simple-table 
                                dense
                                class="pr-4 pl-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center subtitle-2">
                                            #
                                        </th>                                         
                                        <th class="white--text text-center subtitle-2">
                                            Estado
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            Cantidad
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="(item, index) in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ index + 1 }}</td>                                        
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>
                        <v-col sm="12" md="6" xs6>
                            <v-simple-table 
                                dense
                                class="pr-4 pl-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center subtitle-2">
                                            #
                                        </th>                                        
                                        <th class="white--text text-center subtitle-2">
                                            Tipo
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            Cantidad
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="(item, index) in tablesTwo"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ index + 1 }}</td>
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>                        
                    </v-row>                                         
                 </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'PenalAudienciasEstadosTipos',
	data: () => ({
        dialog: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [], // Inicio de variables para el grafico.
        pieSeries: [] ,
        pieLabel: [] ,
        pieChartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGrafico',
                type: 'donut'
            },
            title: {
                text: 'Porcentaje de audiencias por estado',
                align: 'left'
            },            
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                       
        },
        tablesTwo: [], // Inicio de variables para el grafico.
        pieSeriesTwo: [] ,
        pieLabelTwo: [] ,        
        pieChartOptionsTwo: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGraficoTwo',
                type: 'donut'
            },
            colors:['#F44336', '#674EA7', '#9C27B0'],
            title: {
                text: 'Porcentaje de reprogramacion segun tramite',
                align: 'left'
            },            
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                       
        }, // Inicio de variables para el descargable de excel.        
        excelHead : [
            {
                label: "Estado Audiencia",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        excelHeadTwo : [
            {
                label: "Tipo Reprogramación",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.        
        detalleIngresos: [],
        excelHeadDetalles : [
            {
                label: "TRIBUNAL ORIGEN",
                field: "gls_tribunal_origen",
            },            
            {
                label: "TIPO CAUSA",
                field: "gls_tipcausaref",
            },
            {
                label: "TIPO INGRESO",
                field: "gls_tipo_ingreso",
            },
            {
                label: "FORMA INICIO",
                field: "gls_formainicio",
            },
            {
                label: "ESTADO PROCESAL",
                field: "gls_estrelacion",
            },
            {
                label: "RIT",
                field: "rit",
            },
            {
                label: "FECHA INGRESO",
                field: "fec_ingreso",
            },
            {
                label: "FECHA AUDIENCIA",
                field: "fec_audiencia",
            },
            {
                label: "ESTADO AUDIENCIA",
                field: "gls_estado_audiencia",
            },
             {
                label: "PROGRAMACIÓN",
                field: "gls_programacion",
            },
            {
                label: "TIPO AUDIENCIA",
                field: "gls_hitoact",
            },
            {
                label: "MOTIVO SUSPENSIÓN",
                field: "gls_motsuspaud",
            },
            {
                label: "MOTIVO REPROGRAMACIÓN",
                field: "gls_motaudiencia",
            }                                                               
        ],
        search: '',
        headers: [
            { text: 'Tribunal Origen', align: 'center', value: 'gls_tribunal_origen', class : 'pjud white--text subtitle-2' },            
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipcausaref', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Ingreso', align: 'center', value: 'gls_tipo_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Forma Inicio', align: 'center', value: 'gls_formainicio', class : 'pjud white--text subtitle-2' },
            { text: 'Estado Procesal', align: 'center', value: 'gls_estrelacion', class : 'pjud white--text subtitle-2' },
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2' },
            { text: 'Fec Ingreso', align: 'center', value: 'fec_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Fec Audiencia', align: 'center', value: 'fec_audiencia', class : 'pjud white--text subtitle-2' },
            { text: 'Estado Audiencia', align: 'center', value: 'gls_estado_audiencia', class : 'pjud white--text subtitle-2' },
            { text: 'Programación', align: 'center', value: 'gls_programacion', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Audiencia', align: 'center', value: 'gls_hitoact', class : 'pjud white--text subtitle-2' },
            { text: 'Motivo Suspensión', align: 'center', value: 'gls_motsuspaud', class : 'pjud white--text subtitle-2' },
            { text: 'Motivo Reprogramación', align: 'center', value: 'gls_motaudiencia', class : 'pjud white--text subtitle-2' },
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false       
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('penal_audiencias_estados', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];

            let dataLabelsTwo = [];
            let dataSeriesTwo = [];
            let dataTablesTwo = [];            

            let response = await this.getAudienciasEstados(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            let responseTwo = await this.getAudienciasTiposReprogramaciones(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.            

            response.recordset.map((object) => {
                dataLabels.push(object.gls_estado_audiencia)
                dataSeries.push(object.cantidad)
                dataTables.push({ name: object.gls_estado_audiencia, value:object.cantidad})
            });


            responseTwo.recordset.map((object) => {
                dataLabelsTwo.push(object.gls_estaudiencia)
                dataSeriesTwo.push(object.cantidad)
                dataTablesTwo.push({ name: object.gls_estaudiencia, value:object.cantidad})
            });            
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            this.pieSeriesTwo = []
            this.pieSeriesTwo = dataSeriesTwo;

            this.tablesTwo = []
            this.tablesTwo = dataTablesTwo;            

            this.pieChartOptions = {
                labels: dataLabels,
            };

            this.pieChartOptionsTwo = {
                labels: dataLabelsTwo,
            };            

            this.detalleIngresos = []
         
        },
        async getAudienciasEstados (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getAudienciasEstados',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data.audienciasEstados)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getAudienciasTiposReprogramaciones (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getAudienciasTiposReprogramaciones',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data.audienciasReprogramaciones)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getAudienciasEstadosDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getAudienciasEstadosDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data.AudienciasEstadosDetalles)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getReprogramacionesDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getReprogramacionesDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    resolve(response.data.AudienciasReprogramacionesDetalles)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left' } },
                        { content: object.value, styles: { halign: 'center' } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE AUDIENCIAS ESTADOS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                theme: 'grid',
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Estado Audiencia', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartspieGrafico')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                doc.save('Informe Audiencias.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getAudienciasEstadosDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleIngresos = response.recordset
            this.loading = !this.loading
        },
        async downloadReprogramacionesDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getReprogramacionesDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleIngresos = response.recordset
            this.loading = !this.loading
        }        
    },
    components:{
        countTo
    }
} 
</script>