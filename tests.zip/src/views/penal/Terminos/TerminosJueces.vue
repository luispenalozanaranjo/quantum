<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'TerminosJueces'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"                                          
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on" 
                                    @click="downloadPDF()"                                     
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleResoluciones"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Terminos Jueces'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleResoluciones"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"    
                                        disable-sort                                                                               
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>
                        <v-spacer></v-spacer>
                        <v-dialog
                            v-model="dialogCriterios"
                            width="700"
                        >
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                icon
                                v-bind="attrs"
                                v-on="on"
                                >
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                >
                                    mdi-information-outline
                                </v-icon>
                                </v-btn>
                            </template>

                            <v-card>
                                <v-card-title class="pjud white--text">
                                    Criterios
                                </v-card-title>
                                <v-card-text>
                                    <ul class="body-1 black--text mt-2">
                                        <li>1.- Se cuentan las relaciones terminadas</li>
                                        <li>2.- Se omiten causas invalidadas o con rol interno en "0"</li>
                                        <li>3.- Se omiten los tipos de causas exhortos y administrativas</li>
                                        <li>
                                            4.- Se cuentan por los siguientes hitos de término:
                                            <ul>
                                                <li>367 Declara sobreseimiento definitivo</li>
                                                <li>455 Absolución o condena</li>
                                                <li>456 Sentencia</li>
                                                <li>462 No perseverar en el procedimiento</li>
                                                <li>469 Acumulación</li>
                                                <li>491 Declara incompetencia</li>
                                                <li>494 Aprobación no inicio investigación</li>
                                                <li>525 Abandono de la querella</li>
                                                <li>532 Desistimiento querella</li>
                                                <li>621 Declara inadmisibilidad de la querella</li>
                                                <li>642 Comunica y/o aplica decisión ppio. de oportunidad</li>
                                                <li>682 Certifica cumplimiento art. 468</li>
                                                <li>1052 Desistimiento querella y sobreseimiento art. 401</li>
                                                <li>1521 Declara incompetencia RPA</li>
                                            </ul>         
                                        </li>
                                        <li>
                                            5.- En el caso del cumplimiento 468, se omite la posible duplicación en caso que la sentencia haya sido dictada por el mismo tribunal (se cuentan sólo los casos en que la sentencia es TOP).
                                        </li>
                                        <li>
                                            6.- Las sentencias se cuentan independiente que estén ejecutoriadas o no
                                        </li>
                                        <li>7.- Si una relación es firmada por 3 jueces, esta se contará para los 3</li>
                                    </ul>
                                </v-card-text>
                                <v-divider></v-divider>
                                <v-card-actions>
                                <v-spacer></v-spacer>
                                <v-btn
                                    color="success"
                                    text
                                    @click="dialogCriterios = false"
                                >
                                    OK
                                </v-btn>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>     
                    </v-toolbar>
                    <v-row dense>
                        <v-col 
                            cols="6"
                            xs12
                            style="max-height: 500px"
                            class="overflow-y-auto mt-3"
                        >
                            <apexchart type="bar" class="pr-4 mt-4" height="450" :options="chartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                        <v-col cols="6" xs6>
                            <v-simple-table 
                                fixed-header
                                dense
                                class="mt-2"
                                height="500px"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="pjud white--text text-center subtitle-2">
                                            Juez
                                        </th>
                                        <th class="pjud white--text text-center subtitle-2">
                                            Cantidad
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-left">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr class="pjud white--text">
                                        <th class="text-center  subtitle-2">Total</th>
                                        <th class="text-center  subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                                    </tr>
                                </tfoot>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json"
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'PenalTerminosJueces',
	data: () => ({
        dialog: false,      
        total: 0,  
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes'),
            tipo_tribunal : store.get('tipo_tribunal')            
        },
        dialogCriterios: false,
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        chartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: "barJueces",
                type: 'bar',
                height: 450
            },
            colors: ["#775DD0"],
            noData: {
                text: 'Visualizando'
            },              
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true, 
                    columnWidth: '70%',
                    barHeight: '70%',
                    dataLabels: {
                        hideOverflowingLabels: true,
                        orientation: 'horizontal'
                    }                    
                },
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opt) {
                    return val.toString().replace('.',',')
                }
            },
            xaxis: {
                categories: [],             
            },
            yaxis:{
                forceNiceScale: true,
                labels: {
                    show: true,
                    align: 'left',
                    minWidth: 0,
                    maxWidth: 500
                }
            },
            animations: { 
                enabled: true, 
                easing: "linear", 
                speed: 1500,
                animateGradually: { 
                    enabled: true, 
                    delay: 1500 
                },
                dynamicAnimation: { 
                    enabled: true, 
                    speed: 1500 
                }
            } 
        },
        excelHead : [
            {
                label: "Juez",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleResoluciones: [],
        excelHeadDetalles : [
            {label: "Id Causa", field: "crr_idcausa"},            
            {label: "Id Evento",field: "crr_idevento"},
            {label: "Id Relación",field: "crr_idrelacion"},
            {label: "Rit",field: "rit"},
            {label: "Ruc",field: "ruc"},
            {label: "Tipo Causa",field: "gls_tipcausaref"},
            {label: "Estado Causa",field: "gls_estrelacion"},
            {label: "Mot. Término",field: "gls_mottermino"},           
            {label: "Juez",field: "juez"},
            {label: "Calidad",field: "gls_calidad"},
            {label: "Fecha Ingreso",field: "fec_ingreso"},                        
            {label: "Fecha Término",field: "fec_termino"},
            {label: "Duración",field: "duracion"},
        ],        
        search: '',
        headers: [
            { text: 'Id. Causa', align: 'center', value: 'crr_idcausa', class : 'pjud white--text subtitle-2' },
            { text: 'Id. Evento', align: 'center', value: 'crr_idevento', class : 'pjud white--text subtitle-2' },
            { text: 'Id. Relación', align: 'center', value: 'crr_idrelacion', class : 'pjud white--text subtitle-2' },
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2' },
            { text: 'Ruc', align: 'center', value: 'ruc', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipcausaref', class : 'pjud white--text subtitle-2' },
            { text: 'Estado Causa', align: 'center', value: 'gls_estrelacion', class : 'pjud white--text subtitle-2' },
            { text: 'Mot. Término', align: 'center', value: 'gls_mottermino', class : 'pjud white--text subtitle-2' },          
            { text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text subtitle-2' },    
            { text: 'Calidad', align: 'center', value: 'gls_calidad', class : 'pjud white--text subtitle-2' },    
            { text: 'Fecha Ingreso', align: 'center', value: 'fec_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Fecha Término', align: 'center', value: 'fec_termino', class : 'pjud white--text subtitle-2' },     
            { text: 'Duración', align: 'center', value: 'duracion', class : 'pjud white--text subtitle-2' },   
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        // this.$gtag.event('penal_terminos_jueces', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];
            this.total = 0;

            let response = await this.getTerminosJueces(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto,
                this.usuario.tipo_tribunal
            ) // Solicito informacion de los ingresos por tipos.

            
            response.forEach(terJuez => {
                dataLabels.push(terJuez.juez);
                dataSeries.push({ x:terJuez.juez, y:terJuez.cantidad });
                dataTables.push({ name: terJuez.juez, value:terJuez.cantidad});
                this.total += terJuez.cantidad;
            });
            
            this.tables = []
            this.tables = dataTables;

            this.detalleResoluciones = []

            this.chartOptions = {...this.chartOptions, ...{     
                    chart: {
                        height: (dataSeries.length <= 15) ? 450 : (dataSeries.length * 25)
                    }
                }   
            } 

            ApexCharts.exec('barJueces', 'updateSeries', [{
                data: dataSeries
            }], true, true);   
            
         
        },
        async getTerminosJueces (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto, tipo_tribunal) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getTerminosJueces',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto,
                            tipo_tribunal: tipo_tribunal
                        }
                    })

                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getTerminosJuecesDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto, tipo_tribunal) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getTerminosJuecesDetalle',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left', fontSize: 12 } },
                        { content: object.value, styles: { halign: 'center', fontSize: 12 } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 2) / 100 ), 'INFORME DE TÉRMINOS POR JUECES' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                theme: 'grid',
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Juez', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartsbarJueces')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addPage();
                doc.addImage(img, 'png', 10, (( doc.internal.pageSize.height * 5) / 100 ),  width-20, height-50) // Grafica               
                doc.save('Informe Terminos Jueces.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getTerminosJuecesDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto,
                this.usuario.tipo_tribunal
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleResoluciones = response
            this.loading = !this.loading
        }
    },
    components:{
        countTo
    }        
} 
</script>