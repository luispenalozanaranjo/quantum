<template>
    <v-container fluid>
        <v-row dense>
            <v-col md="12">
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Tipo Materia'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"                                          
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on" 
                                    @click="downloadPDF()"                                     
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleTerminosMaterias"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'detTerminos Materias'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleTerminosMaterias"
                                        :search="search"
                                        :items-per-page="causasItemsPerPage"
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"
                                        disable-sort                                                                                 
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>         
                        <v-spacer></v-spacer>
                        <v-dialog
                            v-model="dialogCriterios"
                            width="700"
                        >
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                icon
                                v-bind="attrs"
                                v-on="on"
                                >
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                >
                                    mdi-information-outline
                                </v-icon>
                                </v-btn>
                            </template>

                            <v-card>
                                <v-card-title class="pjud white--text">
                                    Criterios
                                </v-card-title>
                                <v-card-text>
                                    <ul class="body-1 black--text mt-2">
                                        <li>1.- Se cuentan las causas terminadas</li>
                                        <li>2.- Se omiten causas invalidadas o con rol interno en "0"</li>
                                        <li>3.- Se omiten los tipos de causas exhortos y administrativas</li>
                                        <li>
                                            4.- Se cuentan por los siguientes hitos de término:
                                            <ul>
                                                <li>367 Declara sobreseimiento definitivo</li>
                                                <li>455 Absolución o condena</li>
                                                <li>456 Sentencia</li>
                                                <li>462 No perseverar en el procedimiento</li>
                                                <li>469 Acumulación</li>
                                                <li>491 Declara incompetencia</li>
                                                <li>494 Aprobación no inicio investigación</li>
                                                <li>525 Abandono de la querella</li>
                                                <li>532 Desistimiento querella</li>
                                                <li>621 Declara inadmisibilidad de la querella</li>
                                                <li>642 Comunica y/o aplica decisión ppio. de oportunidad</li>
                                                <li>682 Certifica cumplimiento art. 468</li>
                                                <li>1052 Desistimiento querella y sobreseimiento art. 401</li>
                                                <li>1521 Declara incompetencia RPA</li>
                                            </ul>         
                                        </li>
                                        <li>
                                            5.- En el caso del cumplimiento 468, se omite la posible duplicación en caso que la sentencia haya sido dictada por el mismo tribunal (se cuentan sólo los casos en que la sentencia es TOP).
                                        </li>
                                        <li>
                                            6.- Las sentencias se cuentan independiente que estén ejecutoriadas o no
                                        </li>
                                    </ul>
                                </v-card-text>
                                <v-divider></v-divider>
                                <v-card-actions>
                                <v-spacer></v-spacer>
                                <v-btn
                                    color="success"
                                    text
                                    @click="dialogCriterios = false"
                                >
                                    OK
                                </v-btn>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>               
                    </v-toolbar>
                    <v-row dense>
                        <v-col 
                            sm="12"
                            md="6"
                            style="max-height: 500px"
                            class="overflow-y-auto mt-3"
                        >
                            <apexchart type="bar" height="1000" :options="chartOptions" :series="pieSeries" ref="barGrafico"></apexchart>
                        </v-col>
                        <v-col  
                            sm="12"
                            md="6"
                        >
                            <v-simple-table 
                                fixed-header
                                dense
                                class="mt-2"
                                height="500px"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="pjud white--text text-center subtitle-2">
                                            Materia
                                        </th>
                                        <th class="pjud white--text text-center subtitle-2">
                                            Cantidad
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-left">{{ item.name }}</td>
                                        <td class="text-center">{{ item.value }}</td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json"
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'PenalTerminosCausasMaterias',
	data: () => ({
        dialog: false,        
        dialogCriterios: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        chartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: "barGrafico",
                type: 'bar',
                height: 500
            },
            noData: {
                text: 'Visualizando'
            },              
            colors: ["#775DD0"],
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true, 
                    columnWidth: '70%',
                    barHeight: '70%',
                    dataLabels: {
                        hideOverflowingLabels: true,
                        orientation: 'horizontal'
                    }                    
                },
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opt) {
                    return val.toString().replace('.',',')
                }  
            },
            xaxis: {
                categories: [],             
            },
            yaxis:{
                forceNiceScale: true,
                labels: {
                    show: true,
                    align: 'left',
                    minWidth: 0,
                    maxWidth: 300,
                }
            },
            animations: { 
                enabled: true, 
                easing: "linear", 
                speed: 1500,
                animateGradually: { 
                    enabled: true, 
                    delay: 1500 
                },
                dynamicAnimation: { 
                    enabled: true, 
                    speed: 1500 
                }
            } 
        },
        excelHead : [
            {
                label: "Tipo Materia",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleTerminosMaterias: [],
        excelHeadDetalles : [
            {
                label: "Id Causa",
                field: "crr_idcausa",
            },
            {
                label: "Rit",
                field: "rit",
            },
            {
                label: "Tipo Causa",
                field: "gls_tipcausaref",
            },
            {
                label: "Estado Causa",
                field: "gls_estrelacion",
            },
            {
                label: "Mot. Término",
                field: "gls_mottermino",
            },
            {
                label: "Materia",
                field: "gls_materia",
            },
            {
                label: "Fec. Ingreso",
                field: "fec_ingreso",
            },
            {
                label: "Fec. Término",
                field: "fec_termino",
            },   
            {
                label: "Duración",
                field: "duracion",
            }       
        ],        
        search: '',
        headers: [
            { text: 'Id Causa', align: 'center', value: 'crr_idcausa', class : 'pjud white--text subtitle-2' },
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipcausaref', class : 'pjud white--text subtitle-2' },
            { text: 'Estado Causa', align: 'center', value: 'gls_estrelacion', class : 'pjud white--text subtitle-2' },
            { text: 'Mot. Término', align: 'center', value: 'gls_mottermino', class : 'pjud white--text subtitle-2' },
            { text: 'Materia', align: 'center', value: 'gls_materia', class : 'pjud white--text subtitle-2' },
            { text: 'Fec. Ingreso', align: 'center', value: 'fec_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Fec. Término', align: 'center', value: 'fec_termino', class : 'pjud white--text subtitle-2' },     
            { text: 'Duración', align: 'center', value: 'duracion', class : 'pjud white--text subtitle-2' },          
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('familia_terminos_materias', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];
            let contador = 0;
            let totalizador = 0;

            let response = await this.getTerminosMaterias(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            response.recordset.map((object) => {

                if(contador < 30){
                    dataLabels.push(object.gls_materia)
                    dataSeries.push({ x:object.gls_materia, y:object.cantidad })
                }else {
                    totalizador += object.cantidad;
                }

                dataTables.push({ name: object.gls_materia, value:object.cantidad})

                contador ++
            });

            if(totalizador > 0){
                dataLabels.push("Otros")
                dataSeries.push({ x:"Otros", y:totalizador })
            }
            
            this.tables = []
            this.tables = dataTables;

            this.detalleTerminosMaterias = []

            ApexCharts.exec('barGrafico', 'updateSeries', [{
                data: dataSeries
            }], true, true);                    
         
        },
        async getTerminosMaterias (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getTerminosMaterias',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getTerminosMateriasDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/penal/getTerminosMateriasDetalle',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left', fontSize: 12 } },
                        { content: object.value, styles: { halign: 'center', fontSize: 12 } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 2) / 100 ), 'INFORME DE TÉRMINOS POR TIPOS DE MATERIAS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                // tableLineColor: [189, 195, 199],
                // tableLineWidth: 0.5,
                // tableLineColor: [0, 0, 0],
                theme: 'grid',
                // bodyStyles: { lineColor: [0, 0, 0] },
                // styles: { padding:0 },
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Tipo Materia', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartsbarGrafico')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addPage();
                doc.addImage(img, 'png', 10, (( doc.internal.pageSize.height * 5) / 100 ),  width-20, height-50) // Grafica               
                doc.save('Informe Terminos.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getTerminosMateriasDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleTerminosMaterias = response.recordset
            this.loading = !this.loading
        }        
    },
    components:{
        countTo
    }        
} 
</script>