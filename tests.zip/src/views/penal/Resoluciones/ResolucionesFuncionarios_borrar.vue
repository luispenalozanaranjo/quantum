<template>
        <v-card>
            <v-card-title  style="color: #5461a9">
                <b>
                Detalle Resoluciones Funcionarios
                </b>
                <v-list-item-subtitle class="font-italic">{{fechaPeriodo}}</v-list-item-subtitle>
            </v-card-title>
            <v-card-text>
                <v-row>
                    <v-col md="12">
                        <apexchart type="bar"  height="550" :options="barChartOptions" :series="barSeriesfun" ref="barChart"></apexchart>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col md="12">
                        <br/>
                            <vue-excel-xlsx class="btn text-center"
                                    :data="arrResolucionesData"
                                    :columns="excelHead"
                                    :filename="'Resoluciones'"
                                    :sheetname="'Hoja1'"
                            >
                                <v-tooltip top>
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-btn
                                            class="mx-2"
                                            fab
                                            dark
                                            small
                                            color="success"
                                            v-bind="attrs" v-on="on"
                                        >
                                            <v-icon >mdi-microsoft-excel</v-icon>
                                        </v-btn>
                                    </template>
                                    <span>Exportar a excel</span>
                                </v-tooltip>
                            </vue-excel-xlsx>
                        <v-data-table
                            :headers="ResolucionesHeader"
                            :items="arrResolucionesData"
                            :items-per-page="10"
                            class="mt-5 elevation-1"
                        
                        >
                            <template  v-slot:[`body.append`]
                            >
                                <tr class="pjud">
                                    <td style="text-align: center; ">
                                        <b class="white--text">
                                            Total
                                        </b>
                                    </td>
                                    <td>
                                    </td>
                                    <td style="text-align: center; ">
                                        <v-btn text @click="goNomenclaturas()" class="white--text">
                                           {{totalResoluciones}}
                                        </v-btn>
                                    </td>
                                </tr>
                            </template>
                        </v-data-table>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col md="12">
                        <br/>
                        <h2 style="color: #5461a9">
                            Detalle de firma resoluciones según bloque horarios
                        </h2>
                        <apexchart type="heatmap" height="1100"  width= '100%' :options="heatChartOptionsfun" :series="heatSeriesfun"></apexchart>
                    </v-col>
                </v-row>
            </v-card-text>
        </v-card>
</template>

<script>
import { GChart } from 'vue-google-charts'
import { url } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import store from 'store'

export default {
    name: 'ResolucionesFuncionarios',
    data() {
        return{
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo:  (this.$route.params.tipo === undefined) ? store.get('tipo') : this.$route.params.tipo
            },
            fechaPeriodo: '',
            arrResolucionesData: [],
            totalResoluciones: 0,
            ResolucionesHeader: [{text: '#', align: 'center', sortable: false, value: 'contador', class: 'pjud white--text'},
                                {text: 'Nombre', align: 'center', sortable: false, value: 'nombre', class: 'pjud white--text'},
                                {text: 'Cantidad', align: 'center', sortable: true, value: 'cantidad', class: 'pjud white--text'},
            ],
            excelHead : [   {label: "#", field: "contador",},
                        {label: "Nombre", field: "nombre",},
                        {label: "Cantidad", field: "cantidad",},
            ],
            barSeriesfun: [{
                name: "",
                data: [],
            }],

            barChartOptions: {
                chart: {
                    type: 'bar',
                    height: 350,
                },
                colors: ["#775DD0"],
                plotOptions: {
                    bar: {
                        borderRadius: 2,
                        horizontal: true,
                    }
                },
                dataLabels: {
                    enabled: true
                },
                xaxis: {
                    categories: [],
                },
            },
            heatSeriesfun:[{
                name: "",
                data: [],
            }],
            heatChartOptionsfun: {
                chart: {
                    type: 'heatmap',
                },
                dataLabels: {
                    enabled: true,
                },
                xaxis: {
                    type: 'category',
                    categories: ['0H-3H', '4H-7H', '8H-11H', '12H-15H', '16H-19H', '20H-23H']
                },
                plotOptions: {
                    heatmap: {
                        shadeIntensity: 0.5,
                        radius: 0,
                        useFillColorAsStroke: true,
                        colorScale: {
                            ranges: [{
                                from: -50,
                                to: 0,
                                name: 'Bajo',
                                color: '#E5E5E5'
                                },
                                {
                                from: 1,
                                to: 100,
                                name: 'Medio',
                                color: '#FF9F33'
                                },
                                {
                                from: 101,
                                to: 1000,
                                name: 'Alto',
                                color: '#FF0000'
                            }]
                        }
                    }
                },
            }
            
    
        }
    },
    created(){
        this.fechaPeriodo = this.fechas.periodo;
        this.getResolucionesFuncionarios();
    },
    methods: {
        ...mapMutations(['setTipoFuncionario']),

        goNomenclaturas(){
            try {
                this.setTipoFuncionario('funcionario');
                this.$router.push({ name: 'PenalResolucionesNomenclaturas' });

            } catch (error) {
                console.log(error);
            }
        },
        async getResolucionesFuncionarios(){

            const axios = require('axios')
            const req1 = url + '/penal/resolucionesFuncionarios' 
            // this.chartOptions.series = []
            this.arrResolucionesData = []
            this.totalResoluciones = 0
            this.barChartOptions.xaxis.categories = []
            this.barSeriesfun[0].data = []
            this.heatSeriesfun = []

            try{

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte: this.user.cod_corte,
                                cod_tribunal: this.user.cod_tribunal,
                                anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                                mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                                anoFin: this.fechas.anoFin || this.$route.params.ano,
                                mesFin: this.fechas.mesFin || this.$route.params.mes,
                                exhortos: this.fechas.exhortos || 0,
                                tipo: this.user.tipo
                            }
                        })
                        
                        const data = response.data
                        
                        let cantidad = 0
                        let totalOtros = 0
                        this.barSeriesfun[0].name = "Nro Resoluciones"
                    
                        Object.values(data.recordset).map((type) => {
                            
                            //top 15 de jueces con mayores resoluciones
                            //carga de data utilizada en el grafico de barra
                            if(cantidad < 25){
                                this.barChartOptions.xaxis.categories.push(type.nombre)
                                this.barSeriesfun[0].data.push(type.cantidad)
                            } else {
                                //sumo los con menores resoluciones
                                totalOtros += type.cantidad
                            }

                            //Total de resoluciones
                            this.totalResoluciones += type.cantidad

                            //carga de data utilizada en el datatable
                            this.arrResolucionesData.push({
                                contador: cantidad,
                                nombre: type.nombre,
                                cantidad: type.cantidad
                            })

                            this.heatSeriesfun.unshift({
                                name: type.nombre,
                                data: [{x: '0H-3H', y: type.tres},
                                       {x: '4H-7H', y: type.siete},
                                       {x: '8H-11H', y: type.once},
                                       {x: '12H-15H', y:type.quince},
                                       {x: '16H-19H', y:type.diecinueve},
                                       {x: '19H-23H', y:type.veintitres}]
                            })

                            cantidad += 1

                        })

                        //agrego los con menores resoluciones
                        if(totalOtros > 0){
                            //carga de data utilizada en el grafico de barra
                            this.barChartOptions.xaxis.categories.push("OTROS")
                            this.barSeriesfun[0].data.push(totalOtros)

                        }
                        
                    } 
                    catch (error) {
                        console.log(error)
                    } finally{
                        this.updateSeriesBar();
                    }
                }

                get(req1)



            }catch(error){
                console.log(error)
            }

        },
        updateSeriesBar() {
            this.$refs.barChart.updateSeries([{
                data: this.barSeriesfun[0].data,
            }], false, true);
        },
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas() {
            this.fechaPeriodo = this.fechas.periodo;
            this.getResolucionesFuncionarios()
            this.$forceUpdate()
        }
    },
    components: {
        GChart,
    },
}

</script>