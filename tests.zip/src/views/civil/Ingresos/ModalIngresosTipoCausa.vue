<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Tipo Causa'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleIngresos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Tipo Causa'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleIngresos"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </v-toolbar>
                    <v-card-title >
                        <v-list-item-subtitle class="font-italic pjud--text">{{fechaPeriodo}}</v-list-item-subtitle>
                    </v-card-title>
                    <v-row dense>
                        <v-col cols="6" xs6>
                            <apexchart type="donut" class="pr-4 mt-4" height="450" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico"></apexchart>
                        </v-col>
                        <v-col cols="6" xs6>
                            <v-simple-table 
                                dense
                                class="pr-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            Ingreso
                                        </th>
                                        <th class="white--text text-center">
                                            Masiva
                                        </th>
                                        <th class="white--text text-center">
                                            No Masiva
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.valueB" separator="." :duration="1000"></countTo>
                                        </td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.valueA" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr class="pjud white--text">
                                        <th style ="text-align: center">Total</th>
                                        <th style="text-align: center; cursor:pointer" @click="downloadDetalles()"><countTo class="count" :startVal="0" :endVal="totalMasivo" separator="." :duration="1000"></countTo></th>
                                        <th style="text-align: center; cursor:pointer" @click="downloadDetalles()"><countTo class="count" :startVal="0" :endVal="totaNolMasivo" separator="." :duration="1000"></countTo></th>
                                    </tr>
                                </tfoot>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'CivilIngresosTipos',
	data: () => ({
        dialog: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        totalMasivo: 0,
        totaNolMasivo: 0,
        fechaPeriodo: '',
        tables: [], // Inicio de variables para el grafico.
        pieSeries: [] ,
        pieLabel: [] ,
        pieChartOptions: {
            chart: {
                redrawOnParentResize: true, 
                redrawOnWindowResize: true,
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGrafico',
                type: 'donut'
            },
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                       
        }, // Inicio de variables para el descargable de excel.
        excelHead : [
            { label: "Ingreso", field:  "name" },
            { label: "Masiva", field:  "valueB" },
            { label: "No Masiva", field:  "valueA" }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleIngresos: [],
        excelHeadDetalles : [
            { label: "#",field: "increment" },
            { label: "RIT",field: "rit" },
            { label: "Litigante",field: "litigante" },
            { label: "Litigante",field: "litigante2" },
            { label: "Procedimiento",field: "procedimiento" },
            { label: "Materia",field: "materia" },
            { label: "Fecha Ingreso",field: "fecha_ingreso" }
        ],        
        search: '',
        headers: [
            {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '4%'},
            {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '15%'},
            {text: 'Litigante', align: 'center', value: 'litigante', class : 'pjud white--text', width: '15%'},
            {text: 'Litigante', align: 'center', value: 'litigante2', class : 'pjud white--text', width: '15%'},
            {text: 'Procedimiento', align: 'center', value: 'procedimiento', class : 'pjud white--text', width: '15%'},
            {text: 'Materia', align: 'center', value: 'materia', class : 'pjud white--text', width: '15%'},
            {text: 'Fecha Ingreso', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '15%'}
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10 ,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('civil_ingresos_tipos', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];
            this.fechaPeriodo = this.fechas().periodo;

            let response = await this.getIngresosTipos(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            this.totalMasivo = 0
            this.totaNolMasivo = 0
            response.recordset.map((object) => {
                dataLabels.push(object.ingreso)
                dataSeries.push(object.nomasivo)
                this.totalMasivo = this.totalMasivo + object.masivo
                this.totaNolMasivo = this.totaNolMasivo + object.nomasivo
                dataTables.push({ name: object.ingreso, valueA:object.nomasivo, valueB:object.masivo})
            });
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            this.pieChartOptions = {
                labels: dataLabels,
            };

            this.detalleIngresos = []
         
        },
        async getIngresosTipos (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/resumen-ingresos-causa-anual-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto 
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getIngresosTiposDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/ingresos-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto 
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left' } },
                        { content: object.valueB, styles: { halign: 'center' } },
                        { content: object.valueA, styles: { halign: 'center' } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE INGRESOS POR TIPOS DE CAUSAS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                // tableLineColor: [189, 195, 199],
                // tableLineWidth: 0.5,
                // tableLineColor: [0, 0, 0],
                theme: 'grid',
                // bodyStyles: { lineColor: [0, 0, 0] },
                // styles: { padding:0 },
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Ingreso', styles: { halign: 'center' } },
                        { content: 'Masiva', styles: { halign: 'center' } },
                        { content: 'No Masiva', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartspieGrafico')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                doc.save('Informe Ingresos.pdf') 
            })

        },
        async downloadDetalles(){
            this.detalleIngresos = []
            this.dialog = !this.dialog
            this.loading = true
            let response = await this.getIngresosTiposDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            let objdetIngreso;
            let increment = 1

            Object.values(response.recordset).map((type) => {
                objdetIngreso = new Object();
                objdetIngreso.rit = type.tip_causa + '-' + type.rol_causa + '-' + type.era_causa
                objdetIngreso.litigante = type.litigante1
                objdetIngreso.litigante2 = type.litigante2
                objdetIngreso.procedimiento = type.gls_procedimiento
                objdetIngreso.materia = type.gls_materia
                objdetIngreso.fecha_ingreso = type.fecha_ingreso
                objdetIngreso.increment = increment

                this.detalleIngresos.push(objdetIngreso)
                increment ++
            })

            this.loading = false
        }
    },
    components:{
        countTo
    }
} 
</script>