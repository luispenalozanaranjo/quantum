<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Terminos Tipo'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleIngresos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Terminos Tipo'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleIngresos"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </v-toolbar>
                    <v-card-title >
                        <v-list-item-subtitle class="font-italic pjud--text">{{fechaPeriodo}}</v-list-item-subtitle>
                    </v-card-title>
                    <v-row dense>
                        <v-col cols="6" xs6>
                            <apexchart type="donut" class="pr-4 mt-4" height="450" :options="pieChartOptions" :series="pieSeries" ref="pieGraficoC"></apexchart>
                        </v-col>
                        <v-col cols="6" xs6>
                            <v-simple-table 
                                dense
                                class="pr-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            Tipo Términos
                                        </th>
                                        <th class="white--text text-center">
                                            Cantidad Términos
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr class="pjud white--text">
                                        <th style ="text-align: center">Total</th>
                                        <th style="text-align: center; cursor:pointer" @click="downloadDetalles()"><countTo class="count" :startVal="0" :endVal="totalCategoria" separator="." :duration="1000"></countTo></th>
                                    </tr>
                                </tfoot>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'CivilTerminosTipos',
	data: () => ({
        dialog: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        totalCategoria: 0,
        fechaPeriodo: '',
        tables: [], // Inicio de variables para el grafico.
        pieSeries: [] ,
        pieLabel: [] ,
        pieChartOptions: {
            chart: {
                redrawOnParentResize: true, 
                redrawOnWindowResize: true,
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGraficoC',
                type: 'donut'
            },
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                       
        }, // Inicio de variables para el descargable de excel.
        excelHead : [
            { label: "Tipo Términos", field:  "name" },
            { label: "Cantidad Términos", field:  "value" }                                                                                                                                                                      
        ], // Inicio de variables para el dataTables.
        detalleIngresos: [],
        excelHeadDetalles : [
            { label: "#",field: "increment" },
            { label: "RIT",field: "rit" },
            { label: "Demandante",field: "demandante" },
            { label: "Demandado",field: "demandado" },
            { label: "Categoria",field: "tipo_categoria" },
            { label: "Procedimiento",field: "procedimiento" },
            { label: "Juez",field: "juez" },
            { label: "Materia",field: "materia" },
            { label: "Tipo Término",field: "termino" },
            { label: "Fecha Ingreso",field: "fecha_ingreso" },
            { label: "Fecha Término",field: "fecha_termino" }
        ],        
        search: '',
        headers: [
            {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '3%'},
            {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '9%'},
            {text: 'Demandante', align: 'center', value: 'demandante', class : 'pjud white--text', width: '10%'},
            {text: 'Demandado', align: 'center', value: 'demandado', class : 'pjud white--text', width: '10%'},
            {text: 'Categoria', align: 'center', value: 'tipo_categoria', class : 'pjud white--text', width: '10%'},
            {text: 'Procedimiento', align: 'center', value: 'procedimiento', class : 'pjud white--text', width: '10%'},
            {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text', width: '10%'},
            {text: 'Materia', align: 'center', value: 'materia', class : 'pjud white--text', width: '9%'},
            {text: 'Tipo Término', align: 'center', value: 'termino', class : 'pjud white--text', width: '9%'},
            {text: 'Fecha Ingreso', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '10%'},
            {text: 'Fecha Término', align: 'center', value: 'fecha_termino', class : 'pjud white--text', width: '10%'}
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10 ,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('civil_terminos_tipos', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];
            this.fechaPeriodo = this.fechas().periodo;

            let response = await this.getTerminosTipos(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            this.totalCategoria = 0
            response.recordset.map((object) => {
                dataLabels.push(object.gls_termino)
                dataSeries.push(object.sum_terminos)
                this.totalCategoria = this.totalCategoria + object.sum_terminos
                dataTables.push({ name: object.gls_termino, value:object.sum_terminos })
            });
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            this.pieChartOptions = {
                labels: dataLabels,
            };

            this.detalleIngresos = []
         
        },
        async getTerminosTipos (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/resumen-terminos-tipo-anual-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto   
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getTerminosDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/terminos-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left' } },
                        { content: object.value, styles: { halign: 'center' } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE TÉRMINOS POR TIPO TÉRMINO' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                // tableLineColor: [189, 195, 199],
                // tableLineWidth: 0.5,
                // tableLineColor: [0, 0, 0],
                theme: 'grid',
                // bodyStyles: { lineColor: [0, 0, 0] },
                // styles: { padding:0 },
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Tipo Términos', styles: { halign: 'center' } },
                        { content: 'Cantidad Términos', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartspieGraficoC')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                doc.save('Informe Terminos.pdf') 
            })

        },
        async downloadDetalles(){
            this.detalleIngresos = []
            this.dialog = !this.dialog
            this.loading = true
            let response = await this.getTerminosDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            let objdetIngreso;
            let increment = 1

            Object.values(response.recordset).map((type) => {
                objdetIngreso = new Object();
                objdetIngreso.rit = type.rit
                objdetIngreso.demandante = type.demandante
                objdetIngreso.demandado = type.demandado
                objdetIngreso.tipo_categoria = type.tipo_categoria
                objdetIngreso.procedimiento = type.procedimiento_homologado
                objdetIngreso.juez = type.juez
                objdetIngreso.materia = type.gls_materia
                objdetIngreso.termino = type.gls_termino
                objdetIngreso.fecha_ingreso = type.fecha_ingreso
                objdetIngreso.fecha_termino = type.fecha_termino
                objdetIngreso.increment = increment

                this.detalleIngresos.push(objdetIngreso)
                increment ++
            })

            this.loading = false
        }
    },
    components:{
        countTo
    }
} 
</script>