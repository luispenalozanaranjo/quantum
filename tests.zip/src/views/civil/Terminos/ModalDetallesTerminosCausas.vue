<template>
    <v-card>
        <v-card-actions class="px-6">
            <v-row>
                <v-col offset="10">        
                    <vue-excel-xlsx class="mt-0 btn pjud white--text text-center"
                    :data="detalleTerminos"
                    :columns="excelHead"
                    :filename="'DetallesTerminosCausas'"
                    :sheetname="'Hoja1'"
                    >
                        <v-btn icon class="pjud"><v-icon  large class="white--text">mdi-microsoft-excel</v-icon></v-btn>
                    </vue-excel-xlsx>
                </v-col>
            </v-row>                             
        </v-card-actions>
            <v-card-text>
                <v-data-table 
                    :headers="headers"
                    :items="detalleTerminos"
                    :page.sync="page"
                    :items-per-page="itemsPerPage"
                    dense
                    hide-default-footer
                    @page-count="pageCount = $event"                                
                    class="mt-10">
                </v-data-table>
                <v-row justify="center"> 
                    <v-col cols="6">
                        <v-pagination v-model="page" :length="pageCount"></v-pagination>
                    </v-col>
                </v-row>
            </v-card-text>
            <ModalLoading/>     
    </v-card> 
</template>

<script>
import ModalLoading from '../../../components/elementos/ModalLoading'
import Vue from 'vue'
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState,mapMutations } from 'vuex'


export default {
        name: "detalleTerminosMateria",
        data: () => ({
            dialog: false
            ,detalleTerminos: []
            ,search: ''
            ,page: 1
            ,pageCount: 0
            ,itemsPerPage: 10
            ,headers: [
                {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '3%'},
                {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '9%'},
                {text: 'Demandante', align: 'center', value: 'demandante', class : 'pjud white--text', width: '10%'},
                {text: 'Demandado', align: 'center', value: 'demandado', class : 'pjud white--text', width: '10%'},
                {text: 'Categoria', align: 'center', value: 'tipo_categoria', class : 'pjud white--text', width: '10%'},
                {text: 'Procedimiento', align: 'center', value: 'procedimiento', class : 'pjud white--text', width: '10%'},
                {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text', width: '10%'},
                {text: 'Materia', align: 'center', value: 'materia', class : 'pjud white--text', width: '9%'},
                {text: 'Tipo Término', align: 'center', value: 'termino', class : 'pjud white--text', width: '9%'},
                {text: 'Fecha Ingreso', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '10%'},
                {text: 'Fecha Término', align: 'center', value: 'fecha_termino', class : 'pjud white--text', width: '10%'}
            ]
            ,user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }]
            ,excelHead :[
                 { label: "#",field: "increment" }
                ,{ label: "RIT",field: "rit" }
                ,{ label: "Demandante",field: "demandante" }
                ,{ label: "Demandado",field: "demandado" }
                ,{ label: "Categoria",field: "tipo_categoria" }
                ,{ label: "Procedimiento",field: "procedimiento" }
                ,{ label: "Juez",field: "juez" }
                ,{ label: "Materia",field: "materia" }
                ,{ label: "Tipo Término",field: "termino" }
                ,{ label: "Fecha Ingreso",field: "fecha_ingreso" }
                ,{ label: "Fecha Término",field: "fecha_termino" }
            ]
        }),
        components: {
            ModalLoading
        },
        created(){ 
            this.requestData()
        },
        methods:{
            ...mapMutations(['setModal']), // Mutations no Borrar
            requestData: function(){
    
                const axios = require('axios')
                const req1 = urlApi + '/civil/terminos-rango' 
                this.detalleTerminos = []
                this.setModal(true) // Para cargar la ventana Modal
                
                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objdetIngreso;
                    let increment = 1

                    Object.values(data1.recordset).map((type) => {

                        objdetIngreso = new Object();
                        objdetIngreso.rit = type.rit
                        objdetIngreso.demandante = type.demandante
                        objdetIngreso.demandado = type.demandado
                        objdetIngreso.tipo_categoria = type.tipo_categoria
                        objdetIngreso.procedimiento = type.procedimiento_homologado
                        objdetIngreso.juez = type.juez
                        objdetIngreso.materia = type.gls_materia
                        objdetIngreso.termino = type.gls_termino
                        objdetIngreso.fecha_ingreso = type.fecha_ingreso
                        objdetIngreso.fecha_termino = type.fecha_termino
                        objdetIngreso.increment = increment

                        this.detalleTerminos.push(objdetIngreso)
                        increment ++
                    })
                    this.setModal(false) // Aqui se apaga el Modal Loading


                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })

            }
        },
        watch: {
            fechas() {
                this.requestData()
            }
        },
        computed: {
            ...mapState(['fechas'])
        }
}
</script>

<style scoped>

</style>