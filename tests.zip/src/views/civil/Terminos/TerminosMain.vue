<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-card outlined>
                    <v-card-title class="pr-7 pl-7">
                        <v-toolbar flat class="pjud">
                            <v-toolbar-title >
                                <h2 class="white--text">{{tribunal_descripcion}}</h2>
                            </v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                        </v-toolbar>
                    </v-card-title>
                    <v-card-subtitle class="pr-7 pl-7">
                        <FiltrosCompetencias/>
                    </v-card-subtitle>
                    <v-card-text>
                        <v-tabs v-model="tab" background-color="accent-4" centered>
                            <v-tabs-slider></v-tabs-slider>
                            <v-tab href="#tab-3">Terminos Consolidados</v-tab>
                            <v-tab href="#tab-4">Términos por Procedimientos</v-tab>
                            <v-tab href="#tab-5">Términos por Jueces</v-tab>
                            <v-tab href="#tab-6">Términos por Tipo</v-tab>
                        </v-tabs>

                        <v-tabs-items v-model="tab">
                            <v-tab-item id="tab-3">
                                <TerminosConsolidado />
                            </v-tab-item>
                            <v-tab-item id="tab-4">
                                <TerminosProcedimientos />
                            </v-tab-item>
                            <v-tab-item id="tab-5">
                                <TerminosJueces />
                            </v-tab-item>
                            <v-tab-item id="tab-6">
                                <TerminosTipos />
                            </v-tab-item>
                        </v-tabs-items>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'
import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import TerminosProcedimientos from './ModalTerminosProcedimientos'
import TerminosConsolidado from './ModalTerminosConsolidado'
import TerminosJueces from './ModalTerminosJueces'
import TerminosTipos from './ModalTerminosTipos'
import { mapState, mapMutations } from 'vuex'
import { quantum } from '../../../config/quantum'
import Layout from '../../../components/layout/LayoutCivil'

export default {
    name: 'IngresosMain',
    data () {
        return {
            tab: null,
            usuario: {
                usuario: store.get('usuario'),
                nombre_completo: store.get('nombre_completo'),
                email: store.get('email'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')            
            },
            urlquauntum: quantum + '/civil_controller/totalesCorte/'+ store.get('cod_corte'),
            tribunal_descripcion: ''
        }
    },
    async created () {
        this.$gtag.event('civil_terminos', { method: 'Google' })
        this.getAll()
    },
    methods: {
        async getAll(){
            let response =  await this.getUserCompetenciasCortesTribunalesOne(this.usuario.usuario, 'Civil', this.usuario.cod_tribunal)
            this.tribunal_descripcion = response.descripcion // Nombre del Tribunal.       
        },
        async getUserCompetenciasCortesTribunalesOne (usuario, competencia, cod_tribunal) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/user/getUserCompetenciasCortesTribunalesOne',
                        headers: {},
                        params:{
                            usuario: usuario,
							competencia: competencia,
                            cod_tribunal: cod_tribunal
                        }
                    })
                    resolve(response.data.competenciasCortesTribunalesOne)
                } catch (err) {
                    reject(err)
                }
            })
        },                
    },
    components: {
        TerminosProcedimientos,
        TerminosConsolidado,
        TerminosJueces,
        TerminosTipos,
        FiltrosCompetencias,
        Layout
    }
} 
</script>