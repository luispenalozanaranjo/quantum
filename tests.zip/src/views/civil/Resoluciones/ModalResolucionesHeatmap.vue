<template>
    <v-card class="pdfi" id="pdfi">
        <v-card-title class="pjud white--text">
            Resoluciones por Jueces
        </v-card-title>
        <v-card-text>
            <v-row>
                <v-col sm="12">
                    <ModalDetalleResoluciones /> 
                    <v-spacer></v-spacer>
                </v-col> 
            </v-row>
            <v-row>
                <v-col sm="12">
                    <highcharts  :options="chartOptions" :constructor-type="'chart'" class="mt-2" />
                </v-col>
            </v-row>
        </v-card-text>   
    </v-card>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { url } from '../../../config/api'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
// import exporta from 'highcharts/modules/export-data'
import HighCharts from 'highcharts'
import hcHeatmap from "highcharts/modules/heatmap";
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import ModalDetalleResoluciones from './ModalDetallesResoluciones'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)
hcHeatmap(HighCharts)

export default {
    name: 'Ingresos',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            Query_Resoluciones: [],
            totalJueces: 0,       
            headers: [
                { text: 'N°',  align: 'center', value: 'increment', class : 'pjud white--text', width: '30%'},
                { text: 'Juez',  align: 'center', value: 'juez', class : 'pjud white--text', width: '40%' },
                { text: 'Cantidad Resoluciones', align: 'center', value: 'sum_jueces', class : 'pjud white--text', width: '30%' }
              ],
            excelHead : [
                {
                    label: "N°",
                    field: "increment",
                },
                {
                    label: "Juez",
                    field: "juez",
                },
                {
                    label: "Cantidad Resoluciones",
                    field: "sum_jueces",
                }                                                                                                                                                        
            ],
            total : 0 ,
            chartOptions: JSON.parse(JSON.stringify(Graph['heatmap'][0]))
        }
    },
    created(){
        this.consulta_ingreso();
    },
    components: {
        // FiltrosCompetencias,
        ModalLoading,
        highcharts: Chart,
        ModalDetalleResoluciones,
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
                
            html2canvas(document.querySelector('.pdfi')).then(canvas => {
                let image = canvas.toDataURL('image/png')
                
                let doc = new jsPDF('p', 'pt', 'a1');
                doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
                doc.save('DashboardIngresos.pdf')
            })    
            

            // html2canvas(document.querySelector('.pdfi'), {imageTimeout: 5000, useCORS: true}).then(canvas => {
            //     document.getElementById('pdfi').appendChild(canvas)

            //     let img = canvas.toDataURL('image/png')
            //     let pdf = new jsPDF('p', 'pt', 'a1');
            //     pdf.addImage(img, 'JPEG', 5, 5, 200, 287)
            //     pdf.save('relatorio-remoto.pdf')
            //     document.getElementById('pdf').innerHTML = ''

            // })
            

        },
 
        consulta_ingreso() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = url + '/civil/resumen-resoluciones-jueces-anual-rango'
            const req2 = url + '/civil/resumen-resoluciones-jueces-horario-rango'
            this.Query_Resoluciones = []
            let resultGrafico = []
            let filaFuncionario = []
            this.total = 0

            let params = {
                cod_corte: this.user[0].cod_corte,
                cod_tribunal: this.user[0].cod_tribunal,
                anoInicio: this.fechas.anoInicio,
                mesInicio: this.fechas.mesInicio,
                anoFin: this.fechas.anoFin,
                mesFin: this.fechas.mesFin,
                flg_exhorto: this.fechas().exhorto || this.$route.params.exhorto
            }

            axios.all([
                    axios.get(req1, {
                        params
                    }),
                    axios.get(req2, {
                        params
                    })
                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    const data2 = responses[1].data
                    let objIngreso;
                    let objGrafico;
                    let increment = 1
                    let incrementGrafico = 0
                    //this.chartOptions.series = []
                    //this.chartOptions.plotOptions.heatmap.dataLabels.format =  '<b>{point.name}</b>: {point.percentage:.1f} % ({point.y:.0f})';
                    let dataTable = []
                    let dataTableGrafico = []
                    let result = []
                    this.totalJueces =  0
                   
                    Object.values(data1.recordset).map((type) => {

                        objIngreso = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                        objIngreso.cod_corte = type.cod_corte
                        objIngreso.cod_tribunal = type.cod_tribunal
                        objIngreso.ano = type.ano
                        objIngreso.mes = type.mes
                        objIngreso.juez = type.juez
                        objIngreso.sum_jueces = type.sum_jueces
                        objIngreso.increment = increment
                        this.totalJueces = this.totalJueces + type.sum_jueces

                        result.push(objIngreso) // push para la tabla 
                        increment ++ 
                       
                    } )

                    Object.values(data2.recordset).map((type2) => {

                        objGrafico = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                        objGrafico.funcionario = type2.funcionario
                        objGrafico.bloque_0 = type2.bloque_0
                        objGrafico.bloque_1 = type2.bloque_1
                        objGrafico.bloque_2 = type2.bloque_2
                        objGrafico.bloque_3 = type2.bloque_3
                        objGrafico.bloque_4 = type2.bloque_4
                        objGrafico.bloque_5 = type2.bloque_5
                        objGrafico.bloque_6 = type2.bloque_6
                        objGrafico.bloque_7 = type2.bloque_7
                        objGrafico.incrementGrafico = incrementGrafico

                        resultGrafico.push(objGrafico) // push para la tabla 
                        incrementGrafico ++ 
                       
                    } )
                    
                    this.Query_Resoluciones = Object.values(
                                result.reduce((a, c) => (
                                    a[c.juez] = a[c.juez] ?
                                    (a[c.juez].sum_jueces += c.sum_jueces, a[c.juez]) :
                                    c, a), {}
                                )
                                );
                    
                    for(const [key, value] of Object.entries(this.Query_Resoluciones)){
                        dataTable.push({ name: value.juez, y: value.sum_jueces}) // Push para la grafica
                    }

                    let j = 0
                    for(const [key2, value2] of Object.entries(resultGrafico)){
                        filaFuncionario.push(value2.funcionario)
                        dataTableGrafico.push([0, j, value2.bloque_0])
                        dataTableGrafico.push([1, j, value2.bloque_1])
                        dataTableGrafico.push([2, j, value2.bloque_2])
                        dataTableGrafico.push([3, j, value2.bloque_3])
                        dataTableGrafico.push([4, j, value2.bloque_4])
                        dataTableGrafico.push([5, j, value2.bloque_5])
                        dataTableGrafico.push([6, j, value2.bloque_6])
                        dataTableGrafico.push([7, j, value2.bloque_7])
                        j++
                    }

                    this.chartOptions.yAxis.categories = filaFuncionario
                    this.chartOptions.series.push({
                        data: dataTableGrafico,
                        dataLabels: {
                            enabled: true,
                            color: "#000000"
                        }
                    })

                    this.setModal(false) // Aqui Manipulamos el modal                     

                })).catch(errors => {

            })
            
        }  
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.consulta_ingreso()
        }
    }
} 
</script>