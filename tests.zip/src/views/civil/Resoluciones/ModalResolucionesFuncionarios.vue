<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>                          
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Resoluciones Funcionarios'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleIngresos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Resoluciones Funcionarios'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleIngresos"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </v-toolbar>
                    <v-card-title >
                        <v-list-item-subtitle class="font-italic pjud--text">{{fechaPeriodo}}</v-list-item-subtitle>
                    </v-card-title>
                    <v-row dense>
                        <v-col cols="6" xs6>
                            <apexchart type="bar" class="pr-4 mt-4" height="450" :options="chartOptions" :series="pieSeries" ref="barGraficoA"></apexchart>
                        </v-col>
                        <v-col cols="6" xs6>
                            <v-simple-table 
                                dense
                                class="pr-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            Funcionario
                                        </th>
                                        <th class="white--text text-center">
                                            Cantidad Resoluciones
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr class="pjud white--text">
                                        <th style ="text-align: center">Total</th>
                                        <th style="text-align: center; cursor:pointer" @click="downloadDetalles()"><countTo class="count" :startVal="0" :endVal="totalCategoria" separator="." :duration="1000"></countTo></th>
                                    </tr>
                                </tfoot>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                    <v-col cols="12" xs12>
                        <highcharts  :options="chartOptionsGraf" :constructor-type="'chart'" class="mt-2" />
                    </v-col>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
import exporting from 'highcharts/modules/exporting'
// import exporta from 'highcharts/modules/export-data'
import HighCharts from 'highcharts'
import hcHeatmap from "highcharts/modules/heatmap";
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)
hcHeatmap(HighCharts)

export default {
    name: 'ResolucionesFuncionarios',
	data: () => ({
        dialog: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        totalCategoria: 0,
        rand: Math.random(),
        fechaPeriodo: '',
        tables: [], // Inicio de variables para el grafico.
        pieSeries: [] ,
        pieLabel: [] ,
        chartOptionsGraf: JSON.parse(JSON.stringify(Graph['heatmap'][0])),
        chartOptions: {
            chart: {
                redrawOnParentResize: true, 
                redrawOnWindowResize: true,
                locales: [es],
                defaultLocale: "es",                
                id: "barGraficoA",
                type: 'bar',
                height: 500
            },
            noData: {
                text: 'Visualizando'
            },              
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true, 
                    columnWidth: '70%',
                    barHeight: '70%',
                    dataLabels: {
                        hideOverflowingLabels: true,
                        orientation: 'horizontal'
                    }                    
                },
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opt) {
                    return val.toString().replace('.',',')
                }  
            },
            xaxis: {
                categories: [],             
            },
            yaxis:{
                forceNiceScale: true,
                labels: {
                    show: true,
                    align: 'left',
                    minWidth: 0,
                    maxWidth: 160,
                }
            },
            animations: { 
                enabled: true, 
                easing: "linear", 
                speed: 1500,
                animateGradually: { 
                    enabled: true, 
                    delay: 1500 
                },
                dynamicAnimation: { 
                    enabled: true, 
                    speed: 1500 
                }
            } 
        }, // Inicio de variables para el descargable de excel.
        excelHead : [
            { label: "Funcionario", field:  "name" },
            { label: "Cantidad Resoluciones", field:  "value" }                                                                                                                                                                      
        ], // Inicio de variables para el dataTables.
        detalleIngresos: [],
        excelHeadDetalles : [
            { label: "#",field: "increment" },
            { label: "RIT",field: "rit" },
            { label: "Juez",field: "juez" },
            { label: "Funcionario",field: "funcionario" },
            { label: "Cuaderno",field: "tipcuaderno" },
            { label: "Fecha Ingreso",field: "fecha_ingreso" },
            { label: "Fecha Firma",field: "fecha_firma" },
            { label: "Hora Firma",field: "hora_firma" },
            { label: "Nomenclaturas",field: "nomenclatura" }
        ],        
        search: '',
        headers: [
            {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '3%'},
            {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '9%'},
            {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text', width: '10%'},
            {text: 'Funcionario', align: 'center', value: 'funcionario', class : 'pjud white--text', width: '10%'},
            {text: 'Cuaderno', align: 'center', value: 'tipcuaderno', class : 'pjud white--text', width: '10%'},
            {text: 'Fecha Ingreso', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '10%'},
            {text: 'Fecha Firma', align: 'center', value: 'fecha_firma', class : 'pjud white--text', width: '10%'},
            {text: 'Hora Firma', align: 'center', value: 'hora_firma', class : 'pjud white--text', width: '10%'},
            {text: 'Nomenclaturas', align: 'center', value: 'nomenclatura', class : 'pjud white--text', width: '20%'}
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10 ,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('civil_resoluciones_funcionarios', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];
            let resultGrafico = [];
            let filaFuncionario = []
            this.chartOptionsGraf.series = []
            this.fechaPeriodo = this.fechas().periodo;

            let response = await this.getResolucionesFuncionarios(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            let response2 = await this.getResolucionesFuncionariosHorario(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            )

            this.totalCategoria = 0
            response.recordset.map((object) => {
                dataLabels.push(object.funcionario)
                dataSeries.push({ x:object.funcionario, y:object.sum_funcionarios })
                this.totalCategoria = this.totalCategoria + object.sum_funcionarios
                dataTables.push({ name: object.funcionario, value:object.sum_funcionarios })
            });

            let objGrafico;
            let incrementGrafico = 0
            response2.recordset.map((type2) => {
                objGrafico = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                objGrafico.funcionario = type2.funcionario
                objGrafico.bloque_0 = type2.bloque_0
                objGrafico.bloque_1 = type2.bloque_1
                objGrafico.bloque_2 = type2.bloque_2
                objGrafico.bloque_3 = type2.bloque_3
                objGrafico.bloque_4 = type2.bloque_4
                objGrafico.bloque_5 = type2.bloque_5
                objGrafico.bloque_6 = type2.bloque_6
                objGrafico.bloque_7 = type2.bloque_7
                objGrafico.incrementGrafico = incrementGrafico

                resultGrafico.push(objGrafico) // push para la tabla 
                incrementGrafico ++ 
            } )

            let dataTableGrafico = []
            let j = 0
            for(const [key2, value2] of Object.entries(resultGrafico)){
                filaFuncionario.push(value2.funcionario)
                dataTableGrafico.push([0, j, value2.bloque_0])
                dataTableGrafico.push([1, j, value2.bloque_1])
                dataTableGrafico.push([2, j, value2.bloque_2])
                dataTableGrafico.push([3, j, value2.bloque_3])
                dataTableGrafico.push([4, j, value2.bloque_4])
                dataTableGrafico.push([5, j, value2.bloque_5])
                dataTableGrafico.push([6, j, value2.bloque_6])
                dataTableGrafico.push([7, j, value2.bloque_7])
                j++
            }

            this.chartOptionsGraf.xAxis.categories = ['06:00 - 08:00', '08:00 - 10:00', '10:00 - 12:00', '12:00 - 14:00', '14:00 - 16:00', '16:00 - 18:00', '18:00 - 20:00', '20:00 - 22:00']
            this.chartOptionsGraf.yAxis.categories = filaFuncionario
            this.chartOptionsGraf.series.push({
                data: dataTableGrafico,
                dataLabels: {
                    enabled: true,
                    color: "#000000"
                }
            })
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            ApexCharts.exec('barGraficoA', 'updateSeries', [{
                data: dataSeries
            }], false, true); 
 
            this.detalleIngresos = []
         
        },
        async getResolucionesFuncionarios (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/resumen-resoluciones-funcionarios-anual-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResolucionesFuncionariosHorario (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/resumen-resoluciones-funcionarios-horario-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResolucionesFuncionariosDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/civil/resoluciones-unicos-rango',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto
                        }
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left' } },
                        { content: object.value, styles: { halign: 'center' } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE RESOLUCIONES POR FUNCIONARIO' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                // tableLineColor: [189, 195, 199],
                // tableLineWidth: 0.5,
                // tableLineColor: [0, 0, 0],
                theme: 'grid',
                // bodyStyles: { lineColor: [0, 0, 0] },
                // styles: { padding:0 },
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Funcionario', styles: { halign: 'center' } },
                        { content: 'Cantidad Resoluciones', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartsbarGraficoA')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                doc.save('Informe Resoluciones Funcionarios.pdf') 
            })

        },
        async downloadDetalles(){
            this.detalleIngresos = []
            this.dialog = !this.dialog
            this.loading = true
            let response = await this.getResolucionesFuncionariosDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            let objdetIngreso;
            let increment = 1

            Object.values(response.recordset).map((type) => {
                objdetIngreso = new Object();
                objdetIngreso.corte = type.gls_corte
                objdetIngreso.tribunal = type.gls_tribunal
                objdetIngreso.rit = type.rit
                objdetIngreso.fecha_ingreso = type.fecha_ingreso
                objdetIngreso.juez = type.juez
                objdetIngreso.tipcuaderno = type.gls_tipcuaderno
                objdetIngreso.fecha_firma = type.fec_cambioestfirma
                objdetIngreso.hora_firma = type.hora_firma
                objdetIngreso.funcionario = type.funcionario
                objdetIngreso.nomenclatura = type.nomenclatura
                objdetIngreso.increment = increment

                this.detalleIngresos.push(objdetIngreso)
                increment ++
            })

            this.loading = false
        }
    },
    components:{
        highcharts: Chart,
        countTo
    }
} 
</script>