<template>
      
            <v-card>
                <v-card-actions class="px-6">
                    <v-row>
                        <v-col offset="10">        
                            <vue-excel-xlsx class="mt-0 btn pjud white--text text-center"
                            :data="detalleResoluciones"
                            :columns="excelHead"
                            :filename="'DetallesResoluciones'"
                            :sheetname="'Hoja1'"
                            >
                                <v-btn icon class="pjud"><v-icon  large class="white--text">mdi-microsoft-excel</v-icon></v-btn>
                            </vue-excel-xlsx>
                        </v-col>
                    </v-row>                             
                </v-card-actions>
                    <v-card-text>
                        <v-data-table 
                            :headers="headers"
                            :items="detalleResoluciones"
                            :page.sync="page"
                            :items-per-page="itemsPerPage"
                            dense
                            hide-default-footer
                            @page-count="pageCount = $event"                                
                            class="mt-10">
                        </v-data-table>
                        <v-row justify="center"> 
                            <v-col cols="6">
                                <v-pagination v-model="page" :length="pageCount"></v-pagination>
                            </v-col>
                        </v-row>
                    </v-card-text>
                    <ModalLoading/>     
            </v-card> 

</template>

<script>
import ModalLoading from '../../../components/elementos/ModalLoading'
import Vue from 'vue'
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState,mapMutations } from 'vuex'


export default {
        name: "detalleResolucionesMateria",
        data: () => ({
            dialog: false
            ,detalleResoluciones: []
            ,search: ''
            ,page: 1
            ,pageCount: 0
            ,itemsPerPage: 10
            ,headers: [
                {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '3%'},
                {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '9%'},
                {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text', width: '10%'},
                {text: 'Funcionario', align: 'center', value: 'funcionario', class : 'pjud white--text', width: '10%'},
                {text: 'Cuaderno', align: 'center', value: 'tipcuaderno', class : 'pjud white--text', width: '10%'},
                {text: 'Fecha Ingreso', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '10%'},
                {text: 'Fecha Firma', align: 'center', value: 'fecha_firma', class : 'pjud white--text', width: '10%'},
                {text: 'Hora Firma', align: 'center', value: 'hora_firma', class : 'pjud white--text', width: '10%'},
                {text: 'Nomenclaturas', align: 'center', value: 'nomenclatura', class : 'pjud white--text', width: '20%'}
            ]
            ,user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }]
            ,excelHead :[
                 { label: "#",field: "increment" }
                ,{ label: "RIT",field: "rit" }
                ,{ label: "Juez",field: "juez" }
                ,{ label: "Funcionario",field: "funcionario" }
                ,{ label: "Cuaderno",field: "tipcuaderno" }
                ,{ label: "Fecha Ingreso",field: "fecha_ingreso" }
                ,{ label: "Fecha Firma",field: "fecha_firma" }
                ,{ label: "Hora Firma",field: "hora_firma" }
                ,{ label: "Nomenclaturas",field: "nomenclatura" }
            ]
        }),
        components: {
            ModalLoading
        },
        created(){ 
            this.requestData()
        },
        methods:{
            ...mapMutations(['setModal']), // Mutations no Borrar
            requestData: function(){
                const axios = require('axios')
                const req1 = urlApi + '/civil/resoluciones-unicos-rango' 
                this.detalleResoluciones = []
                this.setModal(true) // Para cargar la ventana Modal
                
                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objdetIngreso;
                    let increment = 1

                    Object.values(data1.recordset).map((type) => {

                        objdetIngreso = new Object();
                        objdetIngreso.corte = type.gls_corte
                        objdetIngreso.tribunal = type.gls_tribunal
                        objdetIngreso.rit = type.rit
                        objdetIngreso.fecha_ingreso = type.fecha_ingreso
                        objdetIngreso.juez = type.juez
                        objdetIngreso.tipcuaderno = type.gls_tipcuaderno
                        objdetIngreso.fecha_firma = type.fec_cambioestfirma
                        objdetIngreso.hora_firma = type.hora_firma
                        objdetIngreso.funcionario = type.funcionario
                        objdetIngreso.nomenclatura = type.nomenclatura
                        objdetIngreso.increment = increment

                        this.detalleResoluciones.push(objdetIngreso)
                        increment ++
                    })
                    this.setModal(false) // Aqui se apaga el Modal Loading


                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })

            }
        },
        watch: {
            fechas() {
                this.requestData()
            }
        },
        computed: {
            ...mapState(['fechas'])
        }
}
</script>

<style scoped>

</style>