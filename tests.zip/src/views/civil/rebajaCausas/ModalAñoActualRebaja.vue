<template>
<!-- eslint-disable vue/no-use-v-if-with-v-for,vue/no-confusing-v-for-v-if -->
    <v-card class="pdfi" id="pdfi">
        <v-card-text>
                <v-col sm="12">
                    <v-spacer></v-spacer>
                </v-col>
                <v-row class="px-8">
                    <v-col sm="12" class="py-0">
                        <vue-excel-xlsx class="btn text-center"
                            :data="Query_Ingreso"
                            :columns="headers"
                            :filename="'Inventario'"
                            :sheetname="'Hoja1'"
                        >
                            <v-tooltip top>
                                <template v-slot:activator="{ on, attrs }">
                                    <v-btn
                                        class="mx-2"
                                        fab
                                        dark
                                        small
                                        color="success"
                                        v-bind="attrs" v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>
                                    </v-btn>
                                </template>
                                <span>Exportar a excel</span>
                            </v-tooltip>
                        </vue-excel-xlsx>        
                    </v-col>
                </v-row>
            <v-row>

                <v-col sm="12">
                    <v-data-table 
                        :headers="headers"
                        :items="Query_Ingreso"
                        :sort-by="['nomasivo']"
                        :sort-desc="[true]"
                        hide-default-footer
                        dense
                        :page.sync="pageGeneral"
                        :items-per-page="itemsPerPageGeneral"
                        @page-count="pageCountGeneral = $event"
                        class="mt-5">
                        <template v-slot:[`body`]="{ items }">
                            <tbody>
                            <tr v-for="(item, index) in items " :key="index">
                                <td v-for="(i,k) in item" v-if="k <= 13" :key="k" style ="text-align: center" @click="detalle_inventario(item[0], item[2], headers[k].label, k)" >
                                    <router-link v-if="k > 3" style="text-decoration: none;" :to="{ }"> {{ i }} </router-link>
                                    <div v-else>{{ i }}</div>
                                </td>
                                <td style ="text-align: center" @click="detalle_inventario(item[0], item[2], 0, 99)">
                                    <router-link style="text-decoration: none;" :to="{ }"> {{ totalCorte[index] }} </router-link>
                                </td>
                            </tr>
                            </tbody>
                            <tfoot>
                                <tr class="pjud white--text">
                                    <td style ="text-align: left" colspan="14">Total</td>
                                    <td style="text-align: center; text-color: white;" @click="detalle_inventario(fechas.corte, fechas.tribunal, 0, 99)">
                                        <router-link class="white--text" style="text-color: white;" :to="{ }"> {{ totalCorte.reduce((a, b) => a + b, 0) }} </router-link>
                                    </td>
                                </tr>
                            </tfoot>
                        </template>
                    </v-data-table>
                    <v-row justify="center"> 
                        <v-col cols="6">
                            <v-pagination v-model="pageGeneral" :length="pageCountGeneral"></v-pagination>
                        </v-col>
                    </v-row>
                </v-col> 
            </v-row>
                
        </v-card-text>   
        <v-dialog v-model="dialog" max-width="95%">
            <v-card>
                <v-card-title class="pjud white--text">
                    Inventario Detalle
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialog = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>            
                    <v-card>
                        <v-card-actions class="px-6">
                            <v-row>
                                <v-col offset="10">
                                    <vue-excel-xlsx class="btn text-center"
                                        :data="detalleInventario"
                                        :columns="excelHeadDetalle"
                                        :filename="'DetallesCausas'"
                                        :sheetname="'Hoja1'"
                                    >
                                        <v-tooltip top>
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-btn
                                                    class="mx-2"
                                                    fab
                                                    dark
                                                    small
                                                    color="success"
                                                    v-bind="attrs" v-on="on"
                                                >
                                                    <v-icon >mdi-microsoft-excel</v-icon>
                                                </v-btn>
                                            </template>
                                            <span>Exportar a excel</span>
                                        </v-tooltip>
                                    </vue-excel-xlsx>
                                </v-col>
                            </v-row>                             
                        </v-card-actions>
                            <v-card-text>
                                <v-data-table 
                                    :headers="headersDetalle"
                                    :items="detalleInventario"
                                    :page.sync="page"
                                    :items-per-page="itemsPerPage"
                                    dense
                                    hide-default-footer
                                    @page-count="pageCount = $event"                                
                                    class="mt-10">
                                </v-data-table>
                                <v-row justify="center"> 
                                    <v-col cols="6">
                                        <v-pagination v-model="page" :length="pageCount"></v-pagination>
                                    </v-col>
                                </v-row>
                            </v-card-text>
                            <ModalLoading/>     
                    </v-card> 
                </v-card-text>
            </v-card>
        </v-dialog>
    <ModalLoading/>
    </v-card>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
// import exporta from 'highcharts/modules/export-data'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import ModalDetalleInventario from './ModalDetallesInventario'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'DetalleInventario',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            Query_Ingreso: [],
            dialog: false,
            totalCorte: [],       
            headers: [],
            total : 0 ,
            fechaPeriodo: '',
            chartOptions: JSON.parse(JSON.stringify(Graph['pie'][0])),
            detalleInventario: [],
            search: '',
            page: 1,
            pageCount: 0,
            itemsPerPage: 10,
            searchGeneral: '',
            pageGeneral: 1,
            pageCountGeneral: 0,
            itemsPerPageGeneral: 20,
            headersDetalle: [
                {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '2%'},
                {text: 'CÓD. CORTE', align: 'center', value: 'codigo_corte', class : 'pjud white--text', width: '4%'},
                {text: 'CORTE', align: 'center', value: 'corte', class : 'pjud white--text', width: '6%'},
                {text: 'CÓD. TRIBUNAL', align: 'center', value: 'codigo_tribunal', class : 'pjud white--text', width: '4%'},
                {text: 'TRIBUNAL', align: 'center', value: 'tribunal', class : 'pjud white--text', width: '6%'},
                {text: 'TIPO CAUSA', align: 'center', value: 'tipo_causa', class : 'pjud white--text', width: '8%'},
                {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '8%'},
                {text: 'AÑO', align: 'center', value: 'ano', class : 'pjud white--text', width: '8%'},
                {text: 'FECHA INGRESO', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '8%'},
                {text: 'CÓD. MATERIA', align: 'center', value: 'codigo_materia', class : 'pjud white--text', width: '8%'},
                {text: 'MATERIA', align: 'center', value: 'materia', class : 'pjud white--text', width: '8%'},
                {text: 'ETAPA CAUSA', align: 'center', value: 'etapa_causa', class : 'pjud white--text', width: '8%'},
                {text: 'ULT. DILIGENCIA', align: 'center', value: 'ult_diligencia', class : 'pjud white--text', width: '8%'},
                {text: 'FECHA ULT. DILIGENCIA', align: 'center', value: 'fecha_ult_diligencia', class : 'pjud white--text', width: '10%'},
                {text: 'CIRCULAR N°184/2017', align: 'center', value: 'circular', class : 'pjud white--text', width: '8%'}
            ],
            excelHeadDetalle :[
                 { label: "#",field: "increment" }
                ,{ label: "CÓD. CORTE",field: "codigo_corte" }
                ,{ label: "CORTE",field: "corte" }
                ,{ label: "CÓD. TRIBUNAL",field: "codigo_tribunal" }
                ,{ label: "TRIBUNAL",field: "tribunal" }
                ,{ label: "TIPO CAUSA",field: "tipo_causa" }
                ,{ label: "RIT",field: "rit" }
                ,{ label: "AÑO",field: "ano" }
                ,{ label: "CÓD. MATERIA",field: "codigo_materia" }
                ,{ label: "MATERIA",field: "materia" }
                ,{ label: "ETAPA CAUSA",field: "etapa_causa" }
                ,{ label: "ULT. DILIGENCIA",field: "ult_diligencia" }
                ,{ label: "FECHA ULT. DILIGENCIA",field: "fecha_ult_diligencia" }
                ,{ label: "CIRCULAR N°184/2017",field: "circular" }
            ]
        }
    },
    created(){
        this.consulta_ingreso();
    },
    components: {
        // FiltrosCompetencias,
        ModalLoading,
        highcharts: Chart,
        ModalDetalleInventario,
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        isItemInArray(array, item) {
            for (let i = 0; i < array.length; i++) {
                // This if statement depends on the format of your array
                if (array[i][0] == item[0] && array[i][1] == item[1]) {
                    return i;   // Found it
                }
            }
            return -1;   // Not found
        },
 
        consulta_ingreso() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = 'https://estadisticaservices.pjud.cl/civil/inventario/'+ this.fechas.corte +'/' + this.fechas.tribunal + '/'+ this.fechas.ano + '/' + this.fechas.mes
            this.Query_Ingreso = []
            this.headers = []
            this.totalCorte = []
            this.total = 0
            this.fechaPeriodo = this.fechas.periodo

            axios.all([
                    axios.get(req1, {
                    params: {
                        cod_corte: this.user[0].cod_corte,
                        cod_tribunal: this.user[0].cod_tribunal,
                        anoInicio: this.fechas.anoInicio,
                        mesInicio: this.fechas.mesInicio,
                        anoFin: this.fechas.anoFin,
                        mesFin: this.fechas.mesFin
                    }
                    })

                ]).then(axios.spread((...responses) => {

                    let data = responses[0].data
                    let tabla = []
                    let dataR = []
                    let tribunales = []
                    data = data.sort(function compare(a, b) {
                                if (a._id.CODIGO_CORTE > b._id.CODIGO_CORTE) return 1
                                else if (a._id.CODIGO_CORTE < b._id.CODIGO_CORTE) return -1
                                else {
                                    if(a._id.CODIGO_TRIBUNAL > b._id.CODIGO_TRIBUNAL) return 1
                                    else if (a._id.CODIGO_TRIBUNAL < b._id.CODIGO_TRIBUNAL) return -1
                                    return 0;
                                }
                                });
                    
                    Object.values(data).map((value, key) => {
                        tabla.push([].concat([data[key]._id.CODIGO_TRIBUNAL], [data[key]._id.CODIGO_CORTE]))
                    });
                    
                    tabla = tabla.filter((valorActual, indiceActual, arreglo) => {return arreglo.findIndex(valorDelArreglo => JSON.stringify(valorDelArreglo) === JSON.stringify(valorActual)) === indiceActual })
                    let hash = {};
                    dataR = data.filter(function(current) {
                        let exists = !hash[current._id.CODIGO_TRIBUNAL] || false
                        hash[current._id.CODIGO_TRIBUNAL] = true
                        return exists;
                    });
                    
                    Object.values(dataR).map((value, key) => {
                        tribunales.push([value._id.CODIGO_CORTE, value._id.GLOSA_CORTE, value._id.CODIGO_TRIBUNAL, value._id.GLOSA_TRIBUNAL])
                    });
                    
                    let anoA = this.fechas.ano - 1
                    let ano = this.fechas.ano
                    let d = new Date();
                    let años = [];
                    let diferencia = ano - (anoA - 8);
                    for (let i=diferencia; i >= 0; i--) { 
                        años[i] = ano-i;
                    }
                    let matriz = Array(tabla.length).fill(null).map(() => Array(años.length).fill('-'));

                    let totalCausasRebajas = 0;
                    let m =[];
                    let cuenta=[];
                    for (let key = 0; key < data.length; key++){
                        let t = this.isItemInArray(tabla, [data[key]._id.CODIGO_TRIBUNAL, data[key]._id.CODIGO_CORTE]);
                        let a = años.indexOf(data[key]._id.ANO);
                        if (a < 0 || a == 9) { a = 9; m.push(t); cuenta.push(data[key].count)}
                        matriz[t][a] = data[key].count;
                        totalCausasRebajas = totalCausasRebajas + data[key].count;
                    }
                                        
                    let ncuenta = [];
                    for (let i = 0; i < m.length; i++ ){
                        if (i > 0){
                            if (m[i] != m[i-1]){
                                matriz[m[i]][9] = cuenta[i];
                            }else{
                                matriz[m[i]][9] = matriz[m[i]][9] + cuenta[i];
                            }
                        }else{
                            matriz[m[i]][9] = cuenta[i];
                        }
                    }
                    for (let i = 0; i < matriz.length; i++ ){
                        matriz[i] = matriz[i].reverse();
                    }
                    años = años.reverse();
                    let objAños;
                    this.headers = [
                        { text: 'COD_CORTE', label: 'COD_CORTE',  align: 'center', class : 'pjud white--text', width: '5%', field: 0},
                        { text: 'CORTE', label: 'CORTE',  align: 'center', class : 'pjud white--text', width: '10%', field: 1 },
                        { text: 'COD_TRIBUNAL', label: 'COD_TRIBUNAL', align: 'center', class : 'pjud white--text', width: '5%', field: 2 },
                        { text: 'TRIBUNAL', label: 'TRIBUNAL', align: 'center', class : 'pjud white--text', width: '10%', field: 3 }
                    ]
                    Object.values(años).map((type, index) => {
                        objAños = new Object();
                        if (index == 0){
                            objAños.text = '≤ ' + type
                            objAños.label = type
                            objAños.align = 'center'
                            objAños.class = 'pjud white--text'
                            objAños.field = (index + 4)
                        } else {
                            objAños.text = type
                            objAños.label = type
                            objAños.align = 'center'
                            objAños.class = 'pjud white--text'
                            objAños.field = (index + 4)
                        }
                        this.headers.push(objAños)
                    })
                    this.headers.push({
                        text: 'TOTAL',
                        label: 'TOTAL',
                        align: 'center',
                        class: 'pjud white--text',
                        field: 14
                    })

                    let objdetIngreso = new Object();
                    for (let index = 0; index < matriz.length; index++) {
                        this.totalCorte[index] = 0
                        objdetIngreso = tribunales[index]
                        for (let j = 0; j < años.length; j++) {   
                            objdetIngreso.push(matriz[index][j])
                            this.totalCorte[index] += (isNaN(parseInt(matriz[index][j])))?0:parseInt(matriz[index][j]) 
                        }
                        objdetIngreso.push(this.totalCorte[index])
                        this.Query_Ingreso.push(objdetIngreso)
                    }
                    this.setModal(false) // Aqui Manipulamos el modal                     

                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
            })
            
        },
        detalle_inventario(corte, tribunal, anoConsulta, indice){
            if (indice > 3){
                this.dialog = true 
                this.setModal(true) // Para cargar la ventana Modal
                const axios = require('axios')
                const req1 = 'https://estadisticaservices.pjud.cl/civil/inventario_detalle/'+ corte +'/'+ tribunal +'/'+ this.fechas.ano +'/'+ this.fechas.mes +'/' + anoConsulta 
                this.detalleInventario = []

                axios.all([
                    axios.get(req1)
                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objdetIngreso;
                    let increment = 1

                    Object.values(data1).map((type) => {
                        let f_ult = new Date(type.FEC_ULT_DILIGENCIA+'T00:00:00.000-03:00');
                        let f_seis_m = new Date();
                        f_seis_m.setMonth(f_seis_m.getMonth() - 6);

                        objdetIngreso = new Object();
                        objdetIngreso.codigo_corte = type.CODIGO_CORTE
                        objdetIngreso.corte = type.GLOSA_CORTE
                        objdetIngreso.codigo_tribunal = type.CODIGO_TRIBUNAL
                        objdetIngreso.tribunal = type.GLOSA_TRIBUNAL
                        objdetIngreso.tipo_causa = type.TIPO_CAUSA
                        objdetIngreso.rit = type.RIT
                        objdetIngreso.ano = type.ANO
                        objdetIngreso.fecha_ingreso = type.FECHA_INGRESO
                        objdetIngreso.codigo_materia = type.CODIGO_MATERIA
                        objdetIngreso.materia = type.GLOSA_MATERIA
                        objdetIngreso.etapa_causa = type.ETAPA_CAUSA
                        objdetIngreso.ult_diligencia = type.ULT_DILIGENCIA
                        objdetIngreso.fecha_ult_diligencia = type.FEC_ULT_DILIGENCIA
                        objdetIngreso.flg_reservada = type.FLG_RESERVADA
                        if (type.ULT_DILIGENCIA.includes('Sin Tramitacion')){
                            objdetIngreso.circular = 'A'
                        }else if (f_ult < f_seis_m){
                            objdetIngreso.circular = 'B'
                        }else if (type.ULT_DILIGENCIA.includes('[101]')){
                            objdetIngreso.circular = 'C'
                        }else if (type.ULT_DILIGENCIA.includes('[193]')){
                            objdetIngreso.circular = 'D'
                        }else{
                            objdetIngreso.circular = ''
                        }
                        objdetIngreso.increment = increment

                        this.detalleInventario.push(objdetIngreso)
                        increment ++
                    })
                    this.setModal(false) // Aqui se apaga el Modal Loading


                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })
            }
        }
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.consulta_ingreso()
        }
    }
} 
</script>