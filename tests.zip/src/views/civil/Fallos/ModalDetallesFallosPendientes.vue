<template>
    <v-card>
        <v-card-actions class="px-6">
            <v-row>
                <v-col offset="10">        
                    <vue-excel-xlsx class="mt-0 btn pjud white--text text-center"
                    :data="detalleFallos"
                    :columns="excelHead"
                    :filename="'Causas MMS Pendientes'"
                    :sheetname="'Hoja1'"
                    >
                        <v-btn icon class="pjud"><v-icon  large class="white--text">mdi-microsoft-excel</v-icon></v-btn>
                    </vue-excel-xlsx>
                </v-col>
            </v-row>                             
        </v-card-actions>
            <v-card-text>
                <v-data-table 
                    :headers="headers"
                    :items="detalleFallos"
                    :page.sync="page"
                    :items-per-page="itemsPerPage"
                    dense
                    hide-default-footer
                    @page-count="pageCount = $event"                                
                    class="mt-10">
                </v-data-table>
                <v-row justify="center"> 
                    <v-col cols="6">
                        <v-pagination v-model="page" :length="pageCount"></v-pagination>
                    </v-col>
                </v-row>
            </v-card-text>
            <ModalLoading/>     
    </v-card> 
</template>
<script>
import ModalLoading from '../../../components/elementos/ModalLoading'
import Vue from 'vue'
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState,mapMutations } from 'vuex'


export default {
        name: "detalleFallosMateria",
        data: () => ({
            dialog: false
            ,detalleFallos: []
            ,search: ''
            ,page: 1
            ,pageCount: 0
            ,itemsPerPage: 10
            ,headers: [
                {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '3%'},
                {text: 'Estado', align: 'center', value: 'estado', class : 'pjud white--text', width: '9%'},
                {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '10%'},
                {text: 'Parte', align: 'center', value: 'caratulado', class : 'pjud white--text', width: '10%'},
                {text: 'Materia', align: 'center', value: 'materia', class : 'pjud white--text', width: '10%'},
                {text: 'Procedimiento', align: 'center', value: 'procedimiento', class : 'pjud white--text', width: '10%'},
                {text: 'Fecha de Ingreso', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '10%'},
                {text: 'Fecha MMR', align: 'center', value: 'fecha_mmr', class : 'pjud white--text', width: '10%'}
            ]
            ,user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }]
            ,excelHead :[
                 { label: "#",field: "increment" }
                ,{ label: "Estado",field: "estado" }
                ,{ label: "RIT",field: "rit" }
                ,{ label: "Parte",field: "caratulado" }
                ,{ label: "Materia",field: "materia" }
                ,{ label: "Procedimiento",field: "procedimiento" }
                ,{ label: "Fecha de Ingreso",field: "fecha_ingreso" }
                ,{ label: "Fecha MMR",field: "fecha_mmr" }
            ]
        }),
        components: {
            ModalLoading
        },
        created(){ 
            this.requestData()
        },
        methods:{
            ...mapMutations(['setModal']), // Mutations no Borrar
            requestData: function(){
    
                const axios = require('axios')
                const req1 = urlApi + '/civil/fallos-pendientes-rango' 
                this.detalleFallos = []
                this.setModal(true) // Para cargar la ventana Modal
                
                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objdetIngreso;
                    let increment = 1

                    Object.values(data1.recordset).map((type) => {

                        objdetIngreso = new Object();
                        objdetIngreso.estado = type.estado
                        objdetIngreso.rit = type.rit
                        objdetIngreso.caratulado = type.caratulado
                        objdetIngreso.materia = type.materia
                        objdetIngreso.procedimiento = type.procedimiento
                        objdetIngreso.fecha_ingreso = type.fecha_ingreso
                        objdetIngreso.fecha_mmr = type.fecha_mmr
                        objdetIngreso.increment = increment

                        this.detalleFallos.push(objdetIngreso)
                        increment ++
                    })
                    this.setModal(false) // Aqui se apaga el Modal Loading


                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })

            }
        },
        watch: {
            fechas() {
                this.requestData()
            }
        },
        computed: {
            ...mapState(['fechas'])
        }
}
</script>

<style scoped>

</style>