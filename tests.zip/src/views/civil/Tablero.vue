<template>
    <Layout>
        <v-card>
            <v-card-title class="pjud white--text">
                Filtros
                <v-spacer></v-spacer>
<!--                         <v-btn   small outlined color="white" @click="downloadPDF()" class="ml-16">PDF</v-btn>
                <v-btn  class="ml-16" small color="success" :href="this.urlquauntum"  style="text-decoration:none">Volver</v-btn> -->
            </v-card-title>
            <v-card-text>
                <FiltrosCompetencias v-on:buscar="submit" class="mt-4" />
            </v-card-text>
        </v-card>
        <v-card>
            <v-card-title >
                <v-list-item-subtitle class="font-italic pjud--text">{{fechaPeriodo}}</v-list-item-subtitle>
            </v-card-title>
            <v-card-text class="pdf">
                <v-row md="12" class="mt-0" dense>
                    <v-col md="5">
                        <highcharts :options="chartOptions" :constructor-type="'chart'" />
                    </v-col>
                    <v-col md="2" class="ml-0">
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogIngreso = true">
                                    <v-card-title class="white--text">Total Ingresos</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[0]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogTermino = true">
                                    <v-card-title class="white--text">Total Términos</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[1]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogFallos = true">
                                    <v-card-title class="white--text">Total Fallos</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[3]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                    </v-col>{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}
                    <v-col md="2" class="ml-0">
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card height="100" width="100%" color="pjud" class="cardAction">
                                    <v-card-title class="white--text">NCL.95</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[4]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card height="100" width="100%" color="pjud" class="cardAction">
                                    <v-card-title class="white--text">NCL.96</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[5]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogResoluciones = true" >
                                    <v-card-title class="white--text">Resoluciones</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[6]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                    </v-col>{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}{{'\xa0'}}
                    <v-col md="2" class="ml-0">
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogEscritoResuelto = true">
                                    <v-card-title class="white--text">Escritos Resueltos</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[7]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogEscritoPendiente = true">
                                    <v-card-title class="white--text">Escritos Pendientes</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[8]" separator="." :duration="3000"></countTo></h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                        <v-row class="py-2" justify="center">
                            <v-hover>
                                <v-card height="100" width="100%" color="pjud" class="cardAction">
                                    <v-card-title class="white--text">Cumplimiento</v-card-title>
                                    <v-card-text class="white--text text-center">
                                        <h1><countTo class="count" :startVal="startVal" :endVal="endVal[9]" separator="." :duration="3000" :decimals="2"></countTo> %</h1>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-row>
                    </v-col>
                </v-row>
                <v-row md="12" class="mt-0 py-2" dense>   
                    <v-col md="12">
                        <v-card class="mx-auto mt-0"
                            min-height="130"                                   
                        >
                            <v-card-title pjud-title class="pjud white--text">
                                <v-card-title class="white--text">Escritos por Plazos</v-card-title>
                                <v-spacer></v-spacer>
                                <!-- <v-btn small outlined color="white">Detalle</v-btn>                   -->
                            </v-card-title>
                            <ModalEscritos :fechasConsulta="this.fechas()" />
                        </v-card> 
                    </v-col>
                </v-row>      
            </v-card-text>        
        </v-card>
        
        <v-dialog v-model="dialogIngreso" max-width="1500">
            <v-card>
                <v-card-title class="pjud white--text">
                    Total Ingresos
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogIngreso = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                    <v-tabs v-model="tabIngresos" background-color="accent-4" centered>
                        <v-tabs-slider></v-tabs-slider>
                        <v-tab href="#tab-1">Tipo Causa</v-tab>
                        <v-tab href="#tab-2">Procedimientos</v-tab>
                    </v-tabs>
                    <v-tabs-items v-model="tabIngresos" class="py-1">
                        <v-tab-item id="tab-1">
                            <IngresosTipoCausa />
                        </v-tab-item>
                        <v-tab-item id="tab-2">
                            <IngresosProcedimientos />
                        </v-tab-item>
                    </v-tabs-items>
                </v-card-text>
            </v-card>
        </v-dialog>
        <v-dialog v-model="dialogTermino" max-width="1500">
            <v-card>
                <v-card-title class="pjud white--text">
                    Total Términos
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogTermino = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                    <v-tabs v-model="tabTerminos" background-color="accent-4" centered>
                        <v-tabs-slider></v-tabs-slider>
                        <v-tab href="#tab-3">Terminos Consolidados</v-tab>
                        <v-tab href="#tab-4">Términos por Procedimientos</v-tab>
                        <v-tab href="#tab-5">Términos por Jueces</v-tab>
                        <v-tab href="#tab-6">Términos por Tipo</v-tab>
                    </v-tabs>
                    <v-tabs-items v-model="tabTerminos" class="py-1">
                        <v-tab-item id="tab-3">
                            <TerminosConsolidado />
                        </v-tab-item>
                        <v-tab-item id="tab-4">
                            <TerminosProcedimientos />
                        </v-tab-item>
                        <v-tab-item id="tab-5">
                            <TerminosJueces />
                        </v-tab-item>
                        <v-tab-item id="tab-6">
                            <TerminosTipos />
                        </v-tab-item>
                    </v-tabs-items>
                </v-card-text>
            </v-card>
        </v-dialog>
        <v-dialog v-model="dialogEscritoResuelto">
            <v-card>
                <v-card-title class="pjud white--text">
                    Detalle de Escritos
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogEscritoResuelto = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>            
                    <ModalDetallesEscritosResueltos />
                </v-card-text>
            </v-card>
        </v-dialog>
        <v-dialog v-model="dialogEscritoPendiente">
            <v-card>
                <v-card-title class="pjud white--text">
                    Detalle de Escritos Pendientes
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogEscritoPendiente = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>            
                    <ModalDetallesEscritosPendientes />
                </v-card-text>
            </v-card>
        </v-dialog>
        <v-dialog v-model="dialogResoluciones" max-width="1500">
            <v-card>
                <v-card-title class="pjud white--text">
                    Total Resoluciones
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogResoluciones = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                    <v-tabs v-model="tabResoluciones" background-color="accent-4" centered>
                        <v-tabs-slider></v-tabs-slider>
                        <v-tab href="#tab-7">Resoluciones por Juez</v-tab>
                        <v-tab href="#tab-8">Resoluciones por Funcionario</v-tab>
                        <v-tab href="#tab-9">Resoluciones por Nomenclatura</v-tab>
                    </v-tabs>
                    <v-tabs-items v-model="tabResoluciones" class="py-1">
                        <v-tab-item id="tab-7">
                            <ModalResolucionesJueces />
                        </v-tab-item>
                        <v-tab-item id="tab-8">
                            <ModalResolucionesFuncionarios />
                        </v-tab-item>
                        <v-tab-item id="tab-9">
                            <ModalResolucionesNomenclatura />
                        </v-tab-item>
                    </v-tabs-items>
                </v-card-text>
            </v-card>
        </v-dialog>
        <v-dialog v-model="dialogFallos" max-width="1500">
            <v-card>
                <v-card-title class="pjud white--text">
                    Total Fallos
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogFallos = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                    <v-tabs v-model="tabFallos" background-color="accent-4" centered>
                        <v-tabs-slider></v-tabs-slider>
                        <v-tab href="#tab-10">Causas Falladas</v-tab>
                        <v-tab href="#tab-11">Causas para Fallo</v-tab>
                        <v-tab href="#tab-12">Causas con MMR Pendientes</v-tab>
                    </v-tabs>
                    <v-tabs-items v-model="tabFallos" class="py-1">
                        <v-tab-item id="tab-10">
                            <ModalFallosFalladas />
                        </v-tab-item>
                        <v-tab-item id="tab-11">
                            <ModalFallosParaFallo />
                        </v-tab-item>
                        <v-tab-item id="tab-12">
                            <ModalFallosPendientes />
                        </v-tab-item>
                    </v-tabs-items>
                </v-card-text>
            </v-card>
        </v-dialog>
        <ModalLoading />
    </Layout>
</template>
<script>
// Import Varios
import store from 'store'
import { urlApi } from '../../config/api'
import { quantum } from '../../config/quantum'
import { Graph } from '../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"

// Import Funcionalidades
import Layout from '../../components/layout/LayoutCivil'
import FiltrosCompetencias from '../../components/elementos/FiltrosCompetencias'
import ModalLoading from '../../components/elementos/ModalLoading'

// Import Ingresos 
import IngresosTipoCausa from '../civil/Ingresos/ModalIngresosTipoCausa'
import IngresosProcedimientos from '../civil/Ingresos/ModalIngresosProcedimientos'

// Import Fallos
import ModalFallosFalladas from '../civil/Fallos/ModalFallosFalladas'
import ModalFallosParaFallo from '../civil/Fallos/ModalFallosParaFallo'
import ModalFallosPendientes from '../civil/Fallos/ModalFallosPendientes'

// Import Resoluciones
import ModalResolucionesJueces from '../civil/Resoluciones/ModalResolucionesJueces'
import ModalResolucionesFuncionarios from '../civil/Resoluciones/ModalResolucionesFuncionarios'
import ModalResolucionesNomenclatura from '../civil/Resoluciones/ModalResolucionesNomenclatura'

// Import Escritos
import ModalEscritos from '../civil/Escritos/ModalEscritos'
import ModalDetallesEscritosResueltos from '../civil/Escritos/ModalDetallesEscritosResueltos'
import ModalDetallesEscritosPendientes from '../civil/Escritos/ModalDetallesEscritosPendientes'

// Import Terminos
import TerminosProcedimientos from '../civil/Terminos/ModalTerminosProcedimientos'
import TerminosConsolidado from '../civil/Terminos/ModalTerminosConsolidado'
import TerminosJueces from '../civil/Terminos/ModalTerminosJueces'
import TerminosTipos from '../civil/Terminos/ModalTerminosTipos'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'CivilTablero',
    data(){
        return {
            urlquauntum: quantum + '/civil_controller/totalesCorte/'+ store.get('cod_corte'),
            modalDetalle: false,
            modalText: '',
            modalIngreso: false,
            modalEscrito: false,
            modalTerminos: false,
            dialogIngreso: false,
            dialogTermino: false,
            dialogEscritoResuelto: false,
            dialogEscritoPendiente: false,
            dialogResoluciones: false,
            dialogFallos: false,
            tabIngresos: null,
            tabTerminos: null,
            tabResoluciones: null,
            tabFallos: null,
            fechaPeriodo: '',
            nombreCorte: '',
            nombreTribunal: '',
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo: this.$route.params.tipo
            },          
            // urlquauntum: quantum + '/penal_controller/totalesCorte/'+ store.get('cod_corte'),
            startVal: 0,
            endVal: [0, 0, 0, 0, 0, 0, 0, 0, 0],
            chartOptions: JSON.parse(JSON.stringify(Graph['pie'][0])),
            sentencias: [],
            page: 1,
            pageCount: 0,
            itemsPerPage: 10,
            tableHeader: [],
            tableBody: [],
            headExcelDetalles: [],
            bodyExcelDetalles: []
        }
    }, 
    beforeCreate(){
      store.set('ruta',1)
    },
    created(){
        this.$gtag.event('tablero_civil', { method: 'Google' })
        this.requestData()
    },
    methods:{
        ...mapMutations(['setModal']), // Mutations no Borrar
        ...mapState(['fechas']), // Valores Guardados
        submit(){
            this.requestData()
        },
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
            html2canvas(document.querySelector('.pdf')).then(canvas => {
            let image = canvas.toDataURL('image/png')
            let doc = new jsPDF('l');
            let options = {
                align: 'justify'
                }       
            // doc.text(120, 10, this.$attrs.gls_tribunal,options);
            doc.line(10, 15,290,15);        
            doc.addImage(image, 'png', 10, 20, 280, 200)
            doc.save('Dashboard.pdf')
            })       
        },                
        requestData: function () {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/civil/indicadores'
            const req2 = urlApi + '/generales/tribunal-detalle'
            this.endVal = [0, 0, 0, 0, 0, 0, 0, 0, 0]

            let params = {
                cod_corte: this.user.cod_corte,
                cod_tribunal: this.user.cod_tribunal,
                anoInicio: this.fechas().anoInicio || this.$route.params.ano,
                mesInicio: this.fechas().mesInicio || this.$route.params.mes,
                anoFin: this.fechas().anoFin || this.$route.params.ano,
                mesFin: this.fechas().mesFin || this.$route.params.mes,
                exhorto: this.fechas().exhorto || this.$route.params.exhorto
            }
               // console.log(params);
               // console.log('aqui');
            axios.all([
                    axios.get(req1, {
                        params
                    }),
                    axios.get(req2, {
                        params
                    })                    
                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    const data2 = responses[1].data
                    const ingresos = []
                    const terminos = []
                    this.fechaPeriodo = this.fechas().periodo                  

                    if(this.fechas().TipoBusqueda != "Mensual"){
                        this.chartOptions = JSON.parse(JSON.stringify(Graph['lines'][0]))
                        this.chartOptions.xAxis.categories = this.fechas().calendario
                        this.chartOptions.chart.height = 350
                        this.chartOptions.series = [] // Limpiamos las Series
                    }else{
                        this.chartOptions = JSON.parse(JSON.stringify(Graph['pie'][0]))
                        this.chartOptions.chart.height = 300
                        this.chartOptions.series = [] // Limpiamos las Series
                        this.chartOptions.plotOptions.pie.dataLabels.format =  '<b>{point.name}</b>: {point.y:.0f} ({point.percentage:.1f} %)'                           
                    }

                    //this.chartOptions.title.text =  'Ingresos Vs Términos' // Titulo del grafico de lineas
                    this.chartOptions.title.align = 'left' // Centramos el titulo de Grafico


                    // this.chartOptions.xAxis.categories = this.fechas().calendario
                    Object.values(data1.recordset).map((type) => {
                        ingresos.push({ name: 'Ingresos', y: type.ingresos,  color: '#2979ff'})
                        terminos.push({ name: 'Términos', y: type.terminos,  color: '#2A3F54'})

                        this.endVal[0] += type.ingresos
                        this.endVal[1] += type.terminos
                        this.endVal[3] += type.fallos
                        this.endVal[4] += type.prearchivo_mes
                        this.endVal[5] += type.desarchivo_mes
                        this.endVal[6] += type.resoluciones
                        this.endVal[7] += type.escritos_resueltos
                        this.endVal[8] += type.escritos_pendientes
                        this.endVal[9] = type.escritos_promedios
                    })
                    this.sentencias = []
                    this.setModal(false) // Aqui Manipulamos el modal       

                    Object.values(data2.recordset).map((type) => {
                        this.nombreTribunal = type.gls_tribunal,
                        this.nombreCorte = type.gls_corte                     
                    })     
                    
                    let dataTable = []
                    dataTable.push({ name: "Ingresos", y:  this.endVal[0]})
                    dataTable.push({ name: "Terminos", y: this.endVal[1]})

                    if(this.fechas().TipoBusqueda != "Mensual"){

                        this.chartOptions.series.push({
                            data: ingresos,
                            name: 'Ingresos'
                        },{
                            data: terminos,
                            name: 'Términos'
                        })

                    }else{
                        this.chartOptions.series.push({
                            data: dataTable,
                            name: 'Ingresos vs Terminos',
                            colorByPoint: true
                        })
                    }
               
                    // this.setModal(false) // Aqui Manipulamos el modal       

                })).catch(errors => {
              //  this.setModal(false) // Aqui Manipulamos el modal
            })
          //  this.setModal(false)
        },
    },
    components: {
        FiltrosCompetencias,
        highcharts: Chart,
        countTo,
        ModalLoading,
        ModalEscritos,
        IngresosTipoCausa,
        IngresosProcedimientos,
        TerminosConsolidado,
        TerminosProcedimientos,
        TerminosJueces,
        TerminosTipos,
        ModalDetallesEscritosResueltos,
        ModalDetallesEscritosPendientes,
        ModalResolucionesJueces,
        ModalResolucionesFuncionarios,
        ModalResolucionesNomenclatura,
        ModalFallosFalladas,
        ModalFallosParaFallo,
        ModalFallosPendientes,
        Layout
    }
}
</script>