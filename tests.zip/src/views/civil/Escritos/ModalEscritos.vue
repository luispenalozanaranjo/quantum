<template>
    <div>
        <v-row dense>
            <v-col md="12" class="mt-0">
                <v-simple-table dense>
                    <template>
                        <thead>
                            <tr>
                                <th v-for="item in headTwo" :key="item.index" class="pjud white--text text-center">{{ item.value }}</th>  
                            </tr>                
                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in tbodyTwo"  :key="index">
                                <td class="pjud--text text-center">
                                    <a class="pjud--text text-center" style="text-decoration: none;" @click="solicitudesPendientes(item.ano, item.mes_numero)" > {{item.pendientes}}</a>
                                </td>
                                <td class="text-center" style="background-color: #388E3C;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 0)" > {{item.cero}}</a>
                                </td>
                                <td class="text-center" style="background-color: #388E3C;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 1)" > {{item.uno}}</a>
                                </td>
                                <td class="text-center" style="background-color: #43A047;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 2)" > {{item.dos}}</a>
                                </td>
                                <td class="text-center" style="background-color: #FFAA00;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 3)" > {{item.tres}}</a>
                                </td>
                                <td class="text-center" style="background-color: #FFBB00;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 4)" > {{item.cuatro}}</a>
                                </td>
                                <td class="text-center" style="background-color: #FFCC00;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 5)" > {{item.cinco}}</a>
                                </td>
                                <td class="text-center" style="background-color: #FFCC00;">
                                    <a class="white--text" style="text-decoration: none;" @click="solicitudesRealizadas(item.ano, item.mes_numero, 6)" > {{item.seis_mas}}</a>
                                </td>
                                <td class="pjud--text text-center"> 
                                    <a class="pjud--text text-center" style="text-decoration: none;" > {{item.promedio.toFixed(2)}}%</a>
                                </td>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
                            </tr>
                        </tbody>
                        <!-- <tfoot>
                            <tr>
                                <th v-for="item in headTwo" :key="item.index" class="primary white--text text-center">{{ item.value }}</th>  
                            </tr>                             
                        </tfoot> -->
                    </template>
                </v-simple-table>
            </v-col>
        </v-row>                 
        <!--<ModalLoading/>-->
        <template v-if="vmodal == 0">
            <v-dialog
                v-model="dialog"
                max-width="1500"
                >
                <v-card>
                    <v-card-title class="pjud white--text">
                        Detalle de Escritos
                        <v-spacer></v-spacer>
                        <v-btn
                            color="error"
                            @click="dialog = false"
                            large
                        > 
                            x
                        </v-btn>
                    </v-card-title>
                    <v-card-actions class="px-6">
                        <v-row>
                            <v-col offset="10">        
                                <vue-excel-xlsx class="mt-0 btn pjud white--text text-center"
                                :data="bodyExcelDetalles"
                                :columns="headExcelDetalles"
                                :filename="'EscritosDetalles'"
                                :sheetname="'Hoja1'"
                                >
                                    <v-btn icon class="pjud"><v-icon  large class="white--text">mdi-microsoft-excel</v-icon></v-btn>
                                </vue-excel-xlsx>
                            </v-col>
                        </v-row>                             
                    </v-card-actions>
                    <v-card-text>
                        <v-data-table 
                            :headers="tableHeader"
                            :items="tableBody"
                            :page.sync="page"
                            :items-per-page="itemsPerPage"
                            dense
                            hide-default-footer
                            @page-count="pageCount = $event"                                
                            class="mt-10">
                        </v-data-table>
                        <v-row justify="center"> 
                            <v-col cols="6">
                                <v-pagination v-model="page" :length="pageCount"></v-pagination>
                            </v-col>
                        </v-row>                     
                    </v-card-text>
                </v-card>
            </v-dialog>   
        </template>  
        <template v-if="vmodal == 1">
            <v-dialog
                v-model="dialog"
                max-width="95%"
                >
                <v-card>
                    <v-card-title class="pjud white--text">
                        Detalle de Escritos
                        <v-spacer></v-spacer>
                        <v-btn
                            color="error"
                            @click="dialog = false"
                            large
                        > 
                            x
                        </v-btn>
                    </v-card-title>
                    <v-card-actions class="px-6">
                        <v-row>
                            <v-col offset="10">        
                                <vue-excel-xlsx class="mt-0 btn pjud white--text text-center"
                                :data="bodyExcelDetallesDia"
                                :columns="headExcelDetallesDia"
                                :filename="'EscritosDetalles'"
                                :sheetname="'Hoja1'"
                                >
                                    <v-icon  large class="white--text">mdi-microsoft-excel</v-icon>
                                </vue-excel-xlsx>
                            </v-col>
                        </v-row>                             
                    </v-card-actions>
                    <v-card-text>
                        <v-data-table 
                            :headers="tableHeaderDia"
                            :items="tableBodyDia"
                            :page.sync="page"
                            :items-per-page="itemsPerPage"
                            dense
                            hide-default-footer
                            @page-count="pageCount = $event"                                
                            class="mt-10">
                        </v-data-table>
                        <v-row justify="center"> 
                            <v-col cols="6">
                                <v-pagination v-model="page" :length="pageCount"></v-pagination>
                            </v-col>
                        </v-row>                     
                    </v-card-text>
                </v-card>
            </v-dialog>   
        </template>        
    </div>
</template>
<script>
import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { urlApi } from '../../../config/api'
import { quantum } from '../../../config/quantum'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'ModalEscritos',
    data(){
        return {
            dialog: false,
            vmodal: 0,
            headExcelDetalles: [
                    {
                        label: "Rit",
                        field: "rit",
                    },                    
                    {
                        label: "Fecha Ingreso",
                        field: "fec_ingreso",
                    },
                    {
                        label: "Funcionario",
                        field: "funcionario",
                    },
                    {
                        label: "Tipo Solicitud",
                        field: "gls_tipsolicitud",
                    },    
                    {
                        label: "Tipo Ingreso",
                        field: "gls_ing_solicitud",
                    },
                    {
                        label: "Estado Solicitud",
                        field: "gls_estsolicitud",
                    }                
            ],
            bodyExcelDetalles: [],
            tableHeader: [
                        { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text', width: '10%' }, 
                        { text: 'Fecha Ingreso', align: 'center', value: 'fec_ingreso', class : 'pjud white--text', width: '10%' },                                                    
                        { text: 'Funcionario', align: 'center', value: 'funcionario', class : 'pjud white--text', width: '10%' },
                        { text: 'Tipo Solicitud', align: 'center', value: 'gls_tipsolicitud', class : 'pjud white--text', width: '10%' },
                        { text: 'Tipo Ingreso', align: 'center', value: 'gls_ing_solicitud', class : 'pjud white--text', width: '10%' },
                        { text: 'Estado Solicitud', align: 'center', value: 'gls_estsolicitud', class : 'pjud white--text', width: '10%' }
            ],
            tableBody: [],
            headExcelDetallesDia: [
                    {
                        label: "Rit",
                        field: "rit",
                    }, 
                    {
                        label: "Tipo Solicitud",
                        field: "gls_tipsolicitud",
                    },
                    {
                        label: "Estado Solicitud",
                        field: "gls_estsolicitud",
                    },
                    {
                        label: "Funcionario",
                        field: "funcionario",
                    },
                    {
                        label: "Fecha Solicitud",
                        field: "fec_ingreso",
                    },
                    {
                        label: "Fecha Firma Trámite",
                        field: "fec_resuelto",
                    },
                    {
                        label: "Días",
                        field: "dias",
                    }
            ],
            bodyExcelDetallesDia: [],
            tableHeaderDia: [
                        { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text', width: '10%' },
                        { text: 'Tipo Solicitud', align: 'center', value: 'gls_tipsolicitud', class : 'pjud white--text', width: '10%' },
                        { text: 'Estado Solicitud', align: 'center', value: 'gls_estsolicitud', class : 'pjud white--text', width: '10%' },
                        { text: 'Funcionario', align: 'center', value: 'funcionario', class : 'pjud white--text', width: '10%' },
                        { text: 'Fecha Solicitud', align: 'center', value: 'fec_ingreso', class : 'pjud white--text', width: '10%' },
                        { text: 'Fecha Firma Trámite', align: 'center', value: 'fec_resuelto', class : 'pjud white--text', width: '10%' },
                        { text: 'Días', align: 'center', value: 'dias', class : 'pjud white--text', width: '10%' }
            ],
            tableBodyDia: [],            
            page: 1,
            pageCount: 0,
            itemsPerPage: 10,                                       
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto')
            },
            anos: [],
            head: [ { value: 'Año', index: 0}, 
                    { value: 'Ene', index: 1}, 
                    { value: 'Feb', index: 2}, 
                    { value: 'Mar', index: 3}, 
                    { value: 'Abr', index: 4}, 
                    { value: 'May', index: 5}, 
                    { value: 'Jun', index: 6}, 
                    { value: 'Jul', index: 7}, 
                    { value: 'Ago', index: 8}, 
                    { value: 'Sep', index: 9}, 
                    { value: 'Oct', index: 10}, 
                    { value: 'Nov', index: 11}, 
                    { value: 'Dic', index: 12}
            ],
            tbody: [],
            headTwo: [
                    { value: 'Pendientes', index: 1}, 
                    { value: '0 Día', index: 2}, 
                    { value: '1 Día', index: 3}, 
                    { value: '2 Días', index: 4},
                    { value: '3 Días', index: 5},
                    { value: '4 Días', index: 6},
                    { value: '5 Días', index: 7},
                    { value: '6/+ Días', index: 8},
                    { value: 'Res (%)', index: 9}                    
            ],            
            tbodyTwo: [],
            startVal: 0,
            endVal: [],
            excelHead : [
                {
                    label: "Año",
                    field: "ano",
                },
                {
                    label: "Enero",
                    field: "enero",
                },
                {
                    label: "Febrero",
                    field: "febrero",
                },
                {
                    label: "Marzo",
                    field: "marzo",
                },
                {
                    label: "Abril",
                    field: "abril",
                },
                {
                    label: "Mayo",
                    field: "mayo",
                },
                {
                    label: "Junio",
                    field: "junio",
                },
                {
                    label: "Julio",
                    field: "julio",
                },
                {
                    label: "Agosto",
                    field: "agosto",
                },
                {
                    label: "Septiembre",
                    field: "septiembre",
                },
                {
                    label: "Octubre",
                    field: "octubre",
                },
                {
                    label: "Noviembre",
                    field: "noviembre",
                },
                {
                    label: "Diciembre",
                    field: "diciembre",
                }                                                                                                                                                                                                
            ],
            urlquauntum: quantum + '/civil_controller/totalesCorte/'+ store.get('cod_corte')                  
        }
           
    },
    created(){      
        this.sentRequest()
    },
    props: ['fechasConsulta'], 
    watch:{
        fechasConsulta: function(){
             this.sentRequest()
        },
        fechas () {
            this.sentRequest()
        }
    },    
    methods:{
        
        ...mapState(['meses']), // Valores Guardados
        ...mapState(['fechas']), // Valores Guardados
        ...mapMutations(['setModal']),
        sentRequest(){
            
          //  this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/civil/resumen-escritos-mensual'  
            let params = {
                cod_corte: this.user.cod_corte,
                cod_tribunal: this.user.cod_tribunal,
                anoInicio: this.fechas().anoInicio,
                mesInicio: this.fechas().mesInicio,
                anoFin: this.fechas().anoFin,
                mesFin: this.fechas().mesFin,
                flg_exhorto: this.fechas().exhorto
            }

            axios.all([
                    axios.get(req1, {
                        params
                    }),                  
                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    this.tbodyTwo = []
                    Object.values(data1.recordset).map((type) => {
 
                         this.tbodyTwo.push({   ano: type.ano, 
                                                mes: this.meses()[type.mes - 1],
                                                mes_numero: type.mes,  
                                                pendientes: this.$thousandSeparator(type.escritos_pendientes),
                                                cero: this.$thousandSeparator(type.dias_0) ,
                                                uno: this.$thousandSeparator(type.dias_1) ,
                                                dos: this.$thousandSeparator(type.dias_2) ,
                                                tres: this.$thousandSeparator(type.dias_3) ,
                                                cuatro: this.$thousandSeparator(type.dias_4) ,
                                                cinco: this.$thousandSeparator(type.dias_5) ,
                                                seis_mas: this.$thousandSeparator(type.dias_6_mas) ,
                                                promedio: this.porcentajesTramitacionTribunal(type.dias_0, type.dias_1, type.dias_2, type.dias_3, type.dias_4, type.dias_5, type.dias_6_mas, type.total_escritos_mes, type.escritos_pendientes)
                                            })
                    })
                   
                  //  this.setModal(false) // Aqui Manipulamos el modal

                })).catch(errors => {

            })
        },
        porcentajesTramitacionTribunal(cero, uno, dos, tres, cuatro, cinco, seis, totales, pendiente){
            this.total = 0;
            if( (totales + pendiente) == 0 ){
                return 0;
            }else{
                this.divisor = totales + pendiente;
            }

            if(this.user.cod_corte == 90 || this.user.cod_tribunal == 343){ //santiago , 1ro san miguel
                this.total = (cero + uno + dos + tres + cuatro + cinco)/(this.divisor);
            }
            else {
                this.total = (cero + uno + dos + tres)/(this.divisor);
            }
            return parseFloat(this.total).toFixed(4) * 100
        },
        solicitudesPendientes(ano, mes){
            this.vmodal = 0
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/civil/escritos-pendientes'
              
            axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user.cod_corte,
                            cod_tribunal: this.user.cod_tribunal,
                            anoInicio: this.fechas().anoInicio || this.user.ano,
                            mesInicio: this.fechas().mesInicio || this.user.mes,
                            anoFin: this.fechas().anoFin || this.user.ano,
                            mesFin: this.fechas().mesFin || this.user.mes,
                            flg_exhorto: this.fechas().exhorto                        
                        }
                    })
                ]).then(axios.spread((...responses) => {            
                    const data = responses[0].data.recordset
                    this.tableBody = []
                    this.bodyExcelDetalles = []
                    this.setModal(false)
                    this.dialog = true
                    this.tableBody = data
                    this.bodyExcelDetalles = data

                    console.log(params);

            })).catch(errors => {

            })                                
        },
        solicitudesRealizadas(ano, mes, dia){
            this.vmodal = 1

            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/civil/escritos-resueltos-dia'
            axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user.cod_corte,
                            cod_tribunal: this.user.cod_tribunal,
                            anoInicio: this.fechas().anoInicio || this.user.ano,
                            mesInicio: this.fechas().mesInicio || this.user.mes,
                            anoFin: this.fechas().anoFin || this.user.ano,
                            mesFin: this.fechas().mesFin || this.user.mes,
                            dia: dia,
                            flg_exhorto: this.fechas().exhorto
                        }
                    })
                    
                ]).then(axios.spread((...responses) => {           
                    const data = responses[0].data.recordset
                    this.tableBodyDia = []
                    this.bodyExcelDetallesDia = []
                    this.setModal(false)
                    this.dialog = true
                    this.tableBodyDia = data
                    this.bodyExcelDetallesDia = data
            })).catch(errors => {

            })             
        }
    },
    components:{
        ModalLoading,
        highcharts: Chart,
        countTo
    }
}
</script>