<template>
    <Layout>
        <v-card>
            <v-card-title class="pjud white--text">
                Filtros
                <v-spacer></v-spacer>
                <!-- <v-btn  color="success" :href="this.urlquauntum" style="text-decoration:none">Volver</v-btn>      -->
            </v-card-title>
            <v-card-text>
                <FiltrosCompetencias v-on:buscar="submit" class="mt-4" />
            </v-card-text>
        </v-card>
        <v-card>
            <v-card-title >
                <v-list-item-subtitle class="font-italic pjud--text">{{fechaPeriodo}}</v-list-item-subtitle>
            </v-card-title>
            <v-row md="12" class="mt-0" dense>
                <v-col md="2" class="ml-0"></v-col>
                <v-col md="2" class="ml-0">
                    <v-row class="py-2" justify="center">
                        <v-hover>
                            <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogEscritoResuelto = true">
                                <v-card-title class="white--text">Escritos Resueltos</v-card-title>
                                <v-card-text class="white--text text-center">
                                    <h1><countTo class="count" :startVal="startVal" :endVal="endVal[7]" separator="." :duration="3000"></countTo></h1>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                </v-col>
                <v-col md="1" class="ml-0"></v-col>
                <v-col md="2" class="ml-0">
                    <v-row class="py-2" justify="center">
                        <v-hover>
                            <v-card hover height="100" width="100%" color="pjud" class="cardAction" @click="dialogEscritoPendiente = true">
                                <v-card-title class="white--text">Escritos Pendientes</v-card-title>
                                <v-card-text class="white--text text-center">
                                    <h1><countTo class="count" :startVal="startVal" :endVal="endVal[8]" separator="." :duration="3000"></countTo></h1>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                </v-col>
                <v-col md="1" class="ml-0"></v-col>
                <v-col md="2" class="ml-0">
                    <v-row class="py-2" justify="center">
                        <v-hover>
                            <v-card height="100" width="100%" color="pjud" class="cardAction">
                                <v-card-title class="white--text">Cumplimiento</v-card-title>
                                <v-card-text class="white--text text-center">
                                    <h1><countTo class="count" :startVal="startVal" :endVal="endVal[9]" separator="." :duration="3000" :decimals="2"></countTo> %</h1>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                </v-col>
            </v-row>
        </v-card>
        <ModalEscritosAnual :fechasConsulta="this.fechas()" />
        <v-dialog v-model="dialogEscritoResuelto">
            <v-card>
                <v-card-title class="pjud white--text">
                    Detalle de Escritos
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogEscritoResuelto = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>            
                    <ModalDetallesEscritosResueltos />
                </v-card-text>
            </v-card>
        </v-dialog>
        <v-dialog v-model="dialogEscritoPendiente">
            <v-card>
                <v-card-title class="pjud white--text">
                    Detalle de Escritos Pendientes
                    <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialogEscritoPendiente = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>            
                    <ModalDetallesEscritosPendientes />
                </v-card-text>
            </v-card>
        </v-dialog>
    </Layout>
</template>

<script>

import store from 'store'
import { urlApi } from '../../../config/api'
import { quantum } from '../../../config/quantum'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'

import Layout from '../../../components/layout/LayoutCivil'
import ModalLoading from '../../../components/elementos/ModalLoading'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'
import ModalEscritosAnual from './ModalEscritosAnual'
import ModalDetallesEscritosResueltos from './ModalDetallesEscritosResueltos'
import ModalDetallesEscritosPendientes from './ModalDetallesEscritosPendientes'

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'ModalEscritosMain',
    data () {
        return {
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo: this.$route.params.tipo
            },
            dialogEscritoPendiente: false,
            dialogEscritoResuelto: false,
            startVal: 0,
            endVal: [0, 0, 0, 0, 0, 0, 0, 0, 0],
            tab: null,
            fechaPeriodo: '',
            nombreCorte: '',
            nombreTribunal: '',
            urlquauntum: quantum + '/civil_controller/totalesCorte/'+ store.get('cod_corte')
        }
    },
    beforeCreate(){
      store.set('ruta',1)
    },
    created(){
        this.$gtag.event('tablero_civil', { method: 'Google' })
        this.requestData()
    },
    methods:{
        ...mapMutations(['setModal']), // Mutations no Borrar
        ...mapState(['fechas']), // Valores Guardados
        submit(){
            this.requestData()
        },
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
            html2canvas(document.querySelector('.pdf')).then(canvas => {
            let image = canvas.toDataURL('image/png')
            let doc = new jsPDF('l');
            let options = {
                align: 'justify'
                }       
            // doc.text(120, 10, this.$attrs.gls_tribunal,options);
            doc.line(10, 15,290,15);        
            doc.addImage(image, 'png', 10, 20, 280, 200)
            doc.save('Dashboard.pdf')
            })       
        },                
        requestData: function () {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/civil/indicadores'
            const req2 = urlApi + '/generales/tribunal-detalle'
            this.endVal = [0, 0, 0, 0, 0, 0, 0, 0, 0]

            let params = {
                cod_corte: this.user.cod_corte,
                cod_tribunal: this.user.cod_tribunal,
                anoInicio: this.fechas().anoInicio || this.$route.params.ano,
                mesInicio: this.fechas().mesInicio || this.$route.params.mes,
                anoFin: this.fechas().anoFin || this.$route.params.ano,
                mesFin: this.fechas().mesFin || this.$route.params.mes,
                flg_exhorto: this.fechas().exhorto
            }
            
            axios.all([
                    axios.get(req1, {
                        params
                    }),
                    axios.get(req2, {
                        params
                    })                    
                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    const data2 = responses[1].data
                    const ingresos = []
                    const terminos = []
                    this.fechaPeriodo = this.fechas().periodo                  
                    // this.chartOptions.xAxis.categories = this.fechas().calendario
                    Object.values(data1.recordset).map((type) => {
                        ingresos.push({ name: 'Ingresos', y: type.ingresos,  color: '#2979ff'})
                        terminos.push({ name: 'Términos', y: type.terminos,  color: '#2A3F54'})

                        this.endVal[0] += type.ingresos
                        this.endVal[1] += type.terminos
                        this.endVal[3] += type.fallos
                        this.endVal[4] += type.prearchivo_mes
                        this.endVal[5] += type.desarchivo_mes
                        this.endVal[6] += type.resoluciones
                        this.endVal[7] += type.escritos_resueltos
                        this.endVal[8] += type.escritos_pendientes
                        this.endVal[9] = type.escritos_promedios
                    })
                    this.sentencias = []
                    this.setModal(false) // Aqui Manipulamos el modal       

                    Object.values(data2.recordset).map((type) => {
                        this.nombreTribunal = type.gls_tribunal,
                        this.nombreCorte = type.gls_corte                     
                    })     
                    
                    let dataTable = []
                    dataTable.push({ name: "Ingresos", y:  this.endVal[0]})
                    dataTable.push({ name: "Terminos", y: this.endVal[1]})
                    // this.setModal(false) // Aqui Manipulamos el modal       

                })).catch(errors => {
              //  this.setModal(false) // Aqui Manipulamos el modal
            })
          //  this.setModal(false)
        }
    },
    components:{
        Layout,
        ModalLoading,
        FiltrosCompetencias,
        ModalEscritosAnual,
        highcharts: Chart,
        countTo,
        ModalDetallesEscritosPendientes,
        ModalDetallesEscritosResueltos
    }
}
</script>