<template>
            <v-card>
                <v-card-actions class="px-6">
                    <v-row>
                        <v-col offset="10">        
                            <vue-excel-xlsx class="mt-0 btn pjud white--text text-center"
                            :data="bodyExcelDetallesDia"
                            :columns="headExcelDetallesDia"
                            :filename="'EscritosDetalles'"
                            :sheetname="'Hoja1'"
                            >
                                <v-btn icon class="pjud"><v-icon  large class="white--text">mdi-microsoft-excel</v-icon></v-btn>
                            </vue-excel-xlsx>
                        </v-col>
                    </v-row>                             
                </v-card-actions>
                    <v-card-text>
                        <v-data-table 
                            :headers="tableHeaderDia"
                            :items="tableBodyDia"
                            :page.sync="page"
                            :items-per-page="itemsPerPage"
                            :sort-by="['increment']"
                            dense
                            hide-default-footer
                            @page-count="pageCount = $event"                                
                            class="mt-10">
                        </v-data-table>
                        <v-row justify="center"> 
                            <v-col cols="6">
                                <v-pagination v-model="page" :length="pageCount"></v-pagination>
                            </v-col>
                        </v-row>
                    </v-card-text>
                    <ModalLoading/>     
            </v-card> 
</template>

<script>
import ModalLoading from '../../../components/elementos/ModalLoading'
import Vue from 'vue'
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState,mapMutations } from 'vuex'


export default {
        name: "DetalleEscritosResueltos",
        data: () => ({
            dialog: false
            ,detalleIngresos: []
            ,search: ''
            ,page: 1
            ,pageCount: 0
            ,itemsPerPage: 10
            ,user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            headExcelDetallesDia: [
                    { 
                        label: "#",
                        field: "increment"
                    },
                    {
                        label: "Rit",
                        field: "rit",
                    }, 
                    {
                        label: "Tipo Solicitud",
                        field: "gls_tipsolicitud",
                    },
                    {
                        label: "Estado Solicitud",
                        field: "gls_estsolicitud",
                    },
                    {
                        label: "Funcionario",
                        field: "funcionario",
                    },
                    {
                        label: "Fecha Solicitud",
                        field: "fec_ingreso",
                    },
                    {
                        label: "Fecha Firma Trámite",
                        field: "fec_resuelto",
                    },
                    {
                        label: "Días",
                        field: "dias",
                    }
            ],
            bodyExcelDetallesDia: [],
            tableHeaderDia: [
                        { text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '4%'},
                        { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text', width: '10%' },
                        { text: 'Tipo Solicitud', align: 'center', value: 'gls_tipsolicitud', class : 'pjud white--text', width: '10%' },
                        { text: 'Estado Solicitud', align: 'center', value: 'gls_estsolicitud', class : 'pjud white--text', width: '10%' },
                        { text: 'Funcionario', align: 'center', value: 'funcionario', class : 'pjud white--text', width: '10%' },
                        { text: 'Fecha Solicitud', align: 'center', value: 'fec_ingreso', class : 'pjud white--text', width: '10%' },
                        { text: 'Fecha Firma Trámite', align: 'center', value: 'fec_resuelto', class : 'pjud white--text', width: '10%' },
                        { text: 'Días', align: 'center', value: 'dias', class : 'pjud white--text', width: '10%' }
            ],
            tableBodyDia: [],
        }),
        components: {
            ModalLoading
        },
        created(){ 
            this.requestData()
        },
        methods:{
            ...mapMutations(['setModal']), // Mutations no Borrar
            requestData: function(){
                this.tableBodyDia= []
                const axios = require('axios')
                const req1 = urlApi + '/civil/escritos-resueltos' 
                this.detalleIngresos = []
                this.setModal(true) // Para cargar la ventana Modal

                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {
                    const data1 = responses[0].data
                    let objdetIngreso;
                    let increment = 1

                    Object.values(data1.recordset).map((type) => {

                        objdetIngreso = new Object();
                        objdetIngreso.rit = type.rit
                        objdetIngreso.gls_tipsolicitud = type.gls_tipsolicitud
                        objdetIngreso.gls_estsolicitud = type.gls_estsolicitud
                        objdetIngreso.funcionario = type.funcionario
                        objdetIngreso.fec_ingreso = type.fec_ingreso
                        objdetIngreso.fecha_ingreso = type.fecha_ingreso
                        objdetIngreso.fec_resuelto = type.fec_resuelto
                        objdetIngreso.dias = type.dias
                        objdetIngreso.increment = increment

                        this.tableBodyDia.push(objdetIngreso)
                        this.bodyExcelDetallesDia.push(objdetIngreso)
                        increment ++
                    })
                    this.setModal(false) // Aqui se apaga el Modal Loading


                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })

            }
        },
        watch: {
            fechas() {
                this.requestData()
            }
        },
        computed: {
            ...mapState(['fechas'])
        }
}
</script>

<style scoped>

</style>