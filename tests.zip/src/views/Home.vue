<template>
    <v-container fluid class="mt-16">
        <v-row class="mt-16" dense>
            <v-col v-for="(item) in competencias" :key="item.descripcion" :cols="item.cols" xs4>
                <!-- Alineado a la izquierda. -->
                <router-link :to="{ name: item.name }" v-if="item.id == 1 || item.id == 4" :tabindex="item.id">
                    <v-img :src="item.src" :alt="item.descripcion" aspect-ratio="1" width="250" class="ml-auto ml-12"></v-img>
                </router-link>
                <!-- Centrado. -->
                <router-link :to="{ name: item.name }" v-if="item.id == 2 || item.id == 5" :tabindex="item.id">
                    <v-img :src="item.src" :alt="item.descripcion" aspect-ratio="1" width="250" class="ml-auto mr-auto "></v-img>
                </router-link>
                <!-- Alinieado a la derecha. -->
                <router-link :to="{ name: item.name }" v-if="item.id == 3 || item.id == 6" :tabindex="item.id">
                    <v-img :src="item.src" :alt="item.descripcion" aspect-ratio="1" width="250" class="mr-auto mr-10"></v-img>
                </router-link>
                {{item.to}}
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../config/apiConfig'
import { mapMutations } from 'vuex'
import store from 'store'
export default {
    name: 'Home',
    data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email')
        },
        competencias:[
            {
                Object,
                default: () => {}
            }
	    ]
    }),
    async created() {
        try {
            let objects  = []
            let response =  await this.getUserCompetencias(this.usuario.usuario)
            let id = 1

            response.map(function (object){

                if(object.descripcion == 'Civil' || object.descripcion == 'Corte' || object.descripcion == 'Familia' || object.descripcion == 'Laboral' || object.descripcion == 'Penal' || object.descripcion == 'Cobranza')
                {
                    objects.push({ 
                        id: id,
                        cols: 4,
                        src: "img/Competencias/"+object.descripcion+".jpg",
                        name: object.descripcion,
                        descripcion: object.descripcion
                    })

                    id++
                }

            });

            this.competencias = objects.sort(function(a,b){return a.id - b.id});

            this.setFechas(store.get('fechas'));          

        } catch (error) {
            console.log(error.message);
        }

    },
    methods: {
        ...mapMutations(['setFechas']),

        async getUserCompetencias (usuario) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/user/getUserCompetencias',
                        headers: {},
                        params:{
                            usuario: usuario
                        }
                    })
                    resolve(response.data.competenciasUser)
                } catch (err) {
                    reject(err)
                }
            })
        }
    },
    components: {
        
    }
  }
</script>
