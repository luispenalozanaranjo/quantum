<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on" 
                                    @click="downloadPDF()"                                     
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleResoluciones"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Resoluciones Nomenclaturas'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleResoluciones"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                </ul>
                        </v-tooltip>  
                    </v-toolbar>
                    <v-row dense>
                        <v-col cols="12" xs12>
                            <apexchart type="donut" ref="pieGrafico" class="pr-4 mt-4" height="400" :options="pieChartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json"
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'PenalResolucionesJueces',
	data: () => ({
        dialog: false,        
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes'),
            tipo_tribunal : store.get('tipo_tribunal')            
        },
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        pieChartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGrafico',
                type: 'donut'
            },
            colors: ['#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff', '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080', '#ffffff', '#000000'],
            title: {
                // text: 'Porcentaje de nomenclaturas',
                align: 'left'
            },            
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                    return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            },                     
        },
        excelHead : [
            {
                label: "Juez",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleResoluciones: [],
        excelHeadDetalles : [
            {
                label: "TIPO CAUSA",
                field: "gls_tipo_causa",
            },
            {
                label: "TIPO INGRESO",
                field: "gls_tipo_causa",
            },
            {
                label: "FORMA INICIO",
                field: "gls_formainicio",
            },
            {
                label: "ESTADO PROCESAL",
                field: "gls_estprocesal",
            },
            {
                label: "TIPO TRAMITE",
                field: "gls_tiptramite",
            },
            {
                label: "RIT",
                field: "rit",
            },           
            {
                label: "FECHA INGRESO",
                field: "fec_ingreso",
            },
            {
                label: "FECHA FIRMA",
                field: "fec_cambioestfirma",
            },
            {
                label: "JUEZ",
                field: "funcionario",
            },
            {
                label: "NOMENCLATURA",
                field: "gls_nomenclatura",
            }                                     
        ],        
        search: '',
        headers: [
            { text: 'TIPO CAUSA', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text' },
            { text: 'TIPO INGRESO', align: 'center', value: 'gls_ing_causa', class : 'pjud white--text' },
            { text: 'FORMA INICIO', align: 'center', value: 'gls_formainicio', class : 'pjud white--text' },
            { text: 'ESTADO PROCESAL', align: 'center', value: 'gls_estprocesal', class : 'pjud white--text' },
            { text: 'TIPO TRAMITE', align: 'center', value: 'gls_tiptramite', class : 'pjud white--text' },            
            { text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text' },
            { text: 'FECHA INGRESO', align: 'center', value: 'fec_ingreso', class : 'pjud white--text' },
            { text: 'FECHA FIRMA', align: 'center', value: 'fec_cambioestfirma', class : 'pjud white--text' },
            { text: 'JUEZ', align: 'center', value: 'funcionario', class : 'pjud white--text' },
            { text: 'NOMENCLATURA', align: 'center', value: 'gls_nomenclatura', class : 'pjud white--text' }
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('familia_resoluciones_nomenclaturas', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];

            let response = await this.getResolucionesNomenclaturas(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto,
                this.usuario.tipo_tribunal
            ) // Solicito informacion de los ingresos por tipos.
            
            response.recordset.map((object) => {
                dataLabels.push(object.gls_nomenclatura)
                dataSeries.push(object.cantidad)
                dataTables.push({ name: object.gls_nomenclatura, value:object.cantidad})
                // this.height += 400
            });
            
            this.pieSeries = []
            this.pieSeries = dataSeries;

            this.tables = []
            this.tables = dataTables;

            this.detalleResoluciones = []

            this.pieChartOptions = {...this.pieChartOptions, ...{     
                    labels: dataLabels,
                }   
            } 
         
        },
        async getResolucionesNomenclaturas (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto, tipo_tribunal) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/familia/getResolucionesNomenclaturas',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto,
                            tipo_tribunal: tipo_tribunal
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.resolucionesNomenclaturas)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResolucionesNomenclaturasDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto, tipo_tribunal) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/familia/getResolucionesNomenclaturasDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.resolucionesNomenclaturasDetalles)
                } catch (err) {
                    reject(err)
                }
            })
        },
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })

            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 2) / 100 ), 'INFORME DE RESOLUCIONES POR NOMENCLATURAS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            html2canvas(document.querySelector('#apexchartspieGrafico')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addImage(img, 'png', 10, (( doc.internal.pageSize.height * 15) / 100 ),  width-20, height) // Grafica               
                doc.save('Informe Resoluciones.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getResolucionesNomenclaturasDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto,
                this.usuario.tipo_tribunal
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleResoluciones = response.recordset
            this.loading = !this.loading
        }
    },
    components:{
        countTo
    }        
} 
</script>