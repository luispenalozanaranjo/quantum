<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'Resoluciones'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"                                          
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on" 
                                    @click="downloadPDF()"                                     
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadDetalles()"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleResoluciones"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Tipo Causa'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleResoluciones"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        hide-default-footer
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                                <v-card-actions>
                                    <v-row justify="center"> 
                                        <v-col cols="6">
                                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                                        </v-col>
                                    </v-row>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                </ul>
                        </v-tooltip>  
                    </v-toolbar>
                    <v-row dense>
                        <v-col 
                            sm="12" 
                            md="6"
                            style="max-height: 500px"
                            class="overflow-y-auto"
                        >
                            <apexchart type="bar" class="pr-4 mt-4" height="450" :options="chartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                        <v-col sm="12" md="6">
                            <v-simple-table 
                                fixed-header
                                dense
                                class="pr-4 mt-4"
                                height="500px"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="pjud white--text text-center">
                                            JUEZ
                                        </th>
                                        <th class="pjud white--text text-center">
                                            CANTIDAD
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-left">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo class="count" :startVal="0" :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-col>
                            <v-card flat class="mt-4">
                                <v-card-title>
                                    Firma de resoluciones según bloque horario
                                </v-card-title>
                                <v-card-text>
                                    <apexchart type="heatmap"  :options="heatChartOptions" :series="heatSeries" height="600"></apexchart>
                                </v-card-text>
                            </v-card>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json"
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'FamiliaResolucionesJueces',
	data: () => ({
        dialog: false,        
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        chartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: "barJueces",
                type: 'bar',
                height: 450
            },
            noData: {
                text: 'Visualizando'
            },              
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true, 
                    columnWidth: '70%',
                    barHeight: '70%',
                    dataLabels: {
                        hideOverflowingLabels: true,
                        orientation: 'horizontal'
                    }                    
                },
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opt) {
                    return val.toString().replace('.',',')
                }  
            },
            xaxis: {
                categories: [],             
            },
            yaxis:{
                forceNiceScale: true,
                labels: {
                    show: true,
                    align: 'left',
                    minWidth: 0,
                    maxWidth: 500,
                }
            },
            animations: { 
                enabled: true, 
                easing: "linear", 
                speed: 1500,
                animateGradually: { 
                    enabled: true, 
                    delay: 1500 
                },
                dynamicAnimation: { 
                    enabled: true, 
                    speed: 1500 
                }
            } 
        },
        heatChartOptions: {
            chart: {
                type: 'heatmap',
            },
            dataLabels: {
                enabled: true
            },
            xaxis: {
                type: 'category',
                categories: ['0H-6H', '7H', '8H', '9H', '10H', '11H', '12H', '13H','14H','15H','16H','17H','18H','19H-23H']
            },
            yaxis: {
                labels: {
                    align: 'left',
                    maxWidth: 300,
                }
            },
            plotOptions: {
                heatmap: {
                    shadeIntensity: 0.5,
                    radius: 0,
                    useFillColorAsStroke: true,
                    colorScale: {
                        ranges: [
                            {
                                from: -50,
                                to: 0,
                                name: 'Bajo',
                                color: '#E5E5E5'
                            },
                            {
                                from: 1,
                                to: 500,
                                name: 'Medio',
                                color: '#FF9F33'
                            },
                            {
                                from: 501,
                                to: 20000,
                                name: 'Alto',
                                color: '#FF0000'
                            }
                        ]
                    }
                }
            },
        },
        heatSeries:[{
            name: "",
            data: [],
        }],
        excelHead : [
            {
                label: "Juez",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleResoluciones: [],
        excelHeadDetalles : [
            {
                label: "TIPO CAUSA",
                field: "gls_tipo_causa",
            },
            {
                label: "TIPO INGRESO",
                field: "gls_tipo_causa",
            },
            {
                label: "FORMA INICIO",
                field: "gls_formainicio",
            },
            {
                label: "ESTADO PROCESAL",
                field: "gls_estprocesal",
            },
            {
                label: "TIPO TRAMITE",
                field: "gls_tiptramite",
            },
            {
                label: "RIT",
                field: "rit",
            },           
            {
                label: "FECHA INGRESO",
                field: "fec_ingreso",
            },
            {
                label: "FECHA FIRMA",
                field: "fec_cambioestfirma",
            },
            {
                label: "JUEZ",
                field: "funcionario",
            }                        
        ],        
        search: '',
        headers: [
            { text: 'TIPO CAUSA', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text' },
            { text: 'TIPO INGRESO', align: 'center', value: 'gls_ing_causa', class : 'pjud white--text' },
            { text: 'FORMA INICIO', align: 'center', value: 'gls_formainicio', class : 'pjud white--text' },
            { text: 'ESTADO PROCESAL', align: 'center', value: 'gls_estprocesal', class : 'pjud white--text' },
            { text: 'TIPO TRAMITE', align: 'center', value: 'gls_tiptramite', class : 'pjud white--text' },            
            { text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text' },
            { text: 'FECHA INGRESO', align: 'center', value: 'fec_ingreso', class : 'pjud white--text' },
            { text: 'FECHA FIRMA', align: 'center', value: 'fec_cambioestfirma', class : 'pjud white--text' },
            { text: 'JUEZ', align: 'center', value: 'funcionario', class : 'pjud white--text' }
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('familia_resoluciones_jueces', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];

            let responseHorario = await this.getResolucionesJuecesHorarios();

            let response = await this.getResolucionesJueces(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            response.recordset.map((object) => {
                dataLabels.push(object.gls_funcionario)
                dataSeries.push({ x:object.gls_funcionario, y:object.cantidad })
                dataTables.push({ name: object.gls_funcionario, value:object.cantidad})
            });
            
            this.tables = []
            this.tables = dataTables;

            this.detalleResoluciones = []


            this.chartOptions = {...this.chartOptions, ...{     
                    chart: {
                        height: (dataSeries.length <= 15) ? 450 : (dataSeries.length * 25)
                    }
                }   
            }

            ApexCharts.exec('barJueces', 'updateSeries', [{
                data: dataSeries
            }], true, true);                    
         
        },
        async getResolucionesJueces (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/familia/getResolucionesJueces',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.resolucionesJueces)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResolucionesJuecesDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/familia/getResolucionesJuecesDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.resolucionesJuecesDetalles)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResolucionesJuecesHorarios(){
            const axios = require('axios')
            const req1 = urlApi + '/familia/getResolucionesJuecesHorarios' 
            this.heatSeries = [];
            let contador = 0;

            try{

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte: this.usuario.cod_corte,
                                cod_tribunal: this.usuario.cod_tribunal,
                                anoInicio: this.fechas().anoInicio,
                                mesInicio: this.fechas().mesInicio,
                                anoFin: this.fechas().anoFin,
                                mesFin: this.fechas().mesFin,
                                flg_exhorto: this.fechas().exhorto || 0
                            }
                        });
                        
                        const data = response.data
                    
                        Object.values(data.recordset).map((type) => {

                            if(contador <= 20){
                                this.heatSeries.unshift({
                                    name: type.juez,
                                    data: [{x: '0H-6H', y: (type.cero + type.una + type.dos + type.tres + type.cuatro + type.cinco  + type.seis)},
                                        {x: '7H', y: (type.siete)},
                                        {x: '8H', y: (type.ocho)},
                                        {x: '9H', y: (type.nueve)},
                                        {x: '10H', y: (type.diez)},
                                        {x: '11H', y: (type.once)},
                                        {x: '12H', y: (type.doce)},
                                        {x: '13H', y: (type.trece)},
                                        {x: '14H', y: (type.catorce)},
                                        {x: '15H', y: (type.quince)},
                                        {x: '16H', y: (type.dieciseis)},
                                        {x: '17H', y: (type.diecisiete)},
                                        {x: '18H', y: (type.dieciocho)},
                                        {x: '19H-23H', y: (type.diecinueve + type.veinte + type.veintiuno + type.veintidos + type.veintitres)}]
                                });
                            }

                            contador++;

                        })

                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

            }catch(error){
                console.log(error)
            }
        },
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.tables.map((object) => {
                dataCausas.push([
                        { content: object.name, styles: { halign: 'left', fontSize: 12 } },
                        { content: object.value, styles: { halign: 'center', fontSize: 12 } }
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 2) / 100 ), 'INFORME DE RESOLUCIONES POR JUECES' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                // tableLineColor: [189, 195, 199],
                // tableLineWidth: 0.5,
                // tableLineColor: [0, 0, 0],
                theme: 'grid',
                // bodyStyles: { lineColor: [0, 0, 0] },
                // styles: { padding:0 },
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Juez', styles: { halign: 'center' } },
                        { content: 'Cantidad', styles: { halign: 'center' } }
                    ]
                ],
                body: dataCausas
            })

            html2canvas(document.querySelector('#apexchartsbarJueces')).then(canvas => {
                let wid = canvas.width; 
                let hgt = canvas.height;
                let hratio = hgt/wid;
                let height = width * hratio;     
                let img = canvas.toDataURL('image/png' , wid , hgt)
                doc.addPage();
                doc.addImage(img, 'png', 10, (( doc.internal.pageSize.height * 5) / 100 ),  width-20, height-50) // Grafica               
                doc.save('Informe Resoluciones.pdf') 
            })

        },
        async downloadDetalles(){
            this.dialog = !this.dialog
            this.loading = !this.loading
            let response = await this.getResolucionesJuecesDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleResoluciones = response.recordset
            this.loading = !this.loading
        }                        
    },
    components:{
        countTo
    }        
} 
</script>