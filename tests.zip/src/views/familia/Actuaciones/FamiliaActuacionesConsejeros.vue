<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="detalleActuaciones"
                                    :columns="excelHeadDetalles"
                                    :filename="'Consejero'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on" 
                                    @click="downloadPDF()"                                     
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                </ul>
                        </v-tooltip> 
                    </v-toolbar>
                    <v-row dense>
                        <v-col cols="12" xs12 class="pr-4 pl-4">
                            <v-text-field
                                v-model="search"
                                append-icon=""
                                label="Buscar"
                                single-line
                                hide-details
                                dense
                            ></v-text-field>
                            <v-data-table 
                                :headers="headers"
                                :items="detalleActuaciones"
                                :search="search"
                                :page.sync="causasPage"
                                :items-per-page="causasItemsPerPage"
                                hide-default-footer
                                @page-count="causasPageCount = $event" 
                                :loading="loading"
                                loading-text="Cargando Información... Espere por Favor"                                                                                   
                                dense
                                class="mt-4">
                            </v-data-table>
                        </v-col>
                        <v-col cols="6" offset="3">
                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                        </v-col>                        
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'FamiliaActuacionesJueces',
	data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        detalleActuaciones: [],
        excelHeadDetalles : [
            {
                label: "TIPO CAUSA",
                field: "gls_tipo_causa",
            },
            {
                label: "TIPO INGRESO",
                field: "gls_tipo_causa",
            },
            {
                label: "FORMA INICIO",
                field: "gls_ing_causa",
            },
            {
                label: "ESTADO PROCESAL",
                field: "gls_estprocesal",
            },
            {
                label: "RIT",
                field: "rit",
            },
            {
                label: "FECHA INGRESO",
                field: "fec_ingreso",
            },
            {
                label: "FECHA FIRMA",
                field: "fec_cambioestfirma",
            },            
            {
                label: "FUNCIONARIO",
                field: "funcionario",
            },
            {
                label: "NOMENCLATURA",
                field: "gls_nomenclatura",
            }            
        ],        
        search: '',
        headers: [
            { text: 'TIPO CAUSA', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text' },
            { text: 'TIPO INGRESO', align: 'center', value: 'gls_ing_causa', class : 'pjud white--text' },
            { text: 'FORMA INICIO', align: 'center', value: 'gls_formainicio', class : 'pjud white--text' },
            { text: 'ESTADO PROCESAL', align: 'center', value: 'gls_estprocesal', class : 'pjud white--text' },
            { text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text' },                  
            { text: 'FECHA INGRESO', align: 'center', value: 'fec_ingreso', class : 'pjud white--text' },
            { text: 'FECHA FIRMA', align: 'center', value: 'fec_cambioestfirma', class : 'pjud white--text' },
            { text: 'FUNCIONARIO', align: 'center', value: 'funcionario', class : 'pjud white--text' },
            { text: 'NOMENCLATURA', align: 'center', value: 'gls_nomenclatura', class : 'pjud white--text' }           
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.$gtag.event('familia_actuaciones_consejeros', { method: 'Google' })
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            this.detalleActuaciones = []
            this.loading = !this.loading
            let response = await this.getActuacionesFuncionariosConsejerosDetalles(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            this.detalleActuaciones = response.recordset;
            this.loading = !this.loading

        },
        async getActuacionesFuncionariosConsejerosDetalles (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/familia/getActuacionesFuncionariosConsejerosDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.actuacionesFuncionariosConsejeros)
                } catch (err) {
                    reject(err)
                }
            })
        },
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            let doc = new jsPDF({
                orientation: 'landscape',
                unit: 'mm',
                format: 'letter',
                putOnlyUsedFonts:true
            })
            let dataCausas = []
            let width = doc.internal.pageSize.width; // ancho 297
            let height = doc.internal.pageSize.height; // altura 210

            this.detalleActuaciones.map((object) => {
                dataCausas.push([
                    { content: object.gls_tipo_causa, styles: { halign: 'left', fontSize: 12 } },
                    { content: object.gls_ing_causa, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.gls_formainicio, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.gls_estprocesal, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.rit, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.fec_ingreso, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.fec_cambioestfirma, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.funcionario, styles: { halign: 'center', fontSize: 12 } },
                    { content: object.gls_nomenclatura, styles: { halign: 'center', fontSize: 12 } },
                ])
            });

            doc.setFont('Calibri');
            doc.setFontSize(18);
            doc.text((width / 2), (( height * 2) / 100 ), 'INFORME DE INGRESOS POR TIPOS DE MATERIAS' , { align: 'center' });
            doc.setFontSize(12);
            doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas().periodo , { align: 'left' });
            
            doc.autoTable({
                theme: 'grid',
                startY: 30, // Estos es la posicion de los ejes Y 
                head: [
                    [
                        { content: 'Tipo Causa', styles: { halign: 'center' } },
                        { content: 'Tipo Ingreso', styles: { halign: 'center' } },
                        { content: 'Forma Inicio', styles: { halign: 'center' } },
                        { content: 'Estado Procesal', styles: { halign: 'center' } },
                        { content: 'RIT', styles: { halign: 'center' } },
                        { content: 'Fecha Ingreso', styles: { halign: 'center' } },
                        { content: 'Fecha Firma', styles: { halign: 'center' } },
                        { content: 'Funcionario', styles: { halign: 'center' } },
                        { content: 'Nomenclatura', styles: { halign: 'center' } }                                                                                                                                                                                              
                    ]
                ],
                body: dataCausas
            })

            doc.save('Consejeros.pdf') 

        }       
    }    
} 
</script>