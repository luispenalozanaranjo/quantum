<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    <v-icon >mdi-microsoft-excel</v-icon>  
                                </v-btn>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"                                    
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                </ul>
                        </v-tooltip> 
                    </v-toolbar>
                    <v-row dense>
                        <v-col sm="12" md="6">
                            <apexchart type="bar" class="pr-4 mt-4" height="500" :options="chartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                        <v-col sm="12" md="6">
                            <v-simple-table 
                                fixed-header
                                dense
                                class="pr-4 mt-4"
                                height="500px"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="pjud white--text text-center">
                                            MATERIA
                                        </th>
                                        <th class="pjud white--text text-center">
                                            CANTIDAD
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.name"
                                        >
                                        <td class="text-left">{{ item.name }}</td>
                                        <td class="text-center">{{ item.value }}</td>
                                    </tr>
                                </tbody>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
export default {
    name: 'FamiliaActuacionesJueces',
	data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        chartOptions: {
            chart: {
                id: "barJueces",
                type: 'bar',
                height: 500
            },
            noData: {
                text: 'Visualizando'
            },              
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true     
                }
            },
            dataLabels: {
                // enabled: false
            },
            xaxis: {
                categories: []
            },
            yaxis:{
                labels:{
                    show:true,
                    align: 'left',
                    minWidth: 0,
                    maxWidth: 200
                }
            },
            animations: { 
                enabled: true, 
                easing: "linear", 
                speed: 1500,
                animateGradually: { 
                    enabled: true, 
                    delay: 1500 
                },
                dynamicAnimation: { 
                    enabled: true, 
                    speed: 1500 
                }
            }        
        },
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },
    async created () {
        this.getAll()
    },    
    methods:{
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            let dataLabels = [];
            let dataSeries = [];
            let dataTables = [];

            let response = await this.getActuacionesJueces(
                this.usuario.cod_corte, 
                this.usuario.cod_tribunal,
                this.fechas().anoInicio, 
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin,
                this.fechas().exhorto
            ) // Solicito informacion de los ingresos por tipos.

            response.recordset.map((object) => {
                dataLabels.push(object.gls_funcionario)
                dataSeries.push({ x:object.gls_funcionario, y:object.cantidad })
                dataTables.push({ name: object.gls_funcionario, value:object.cantidad})
            });
            
            this.tables = []
            this.tables = dataTables;

            ApexCharts.exec('barJueces', 'updateSeries', [{
                data: dataSeries
            }], true, true);                    
         
        },
        async getActuacionesJueces (cod_corte, cod_tribunal, anoInicio, mesInicio, anoFin, mesFin, flg_exhorto) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/familia/getActuacionesJueces',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin,
                            flg_exhorto: flg_exhorto     
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.actuacionesJueces)
                } catch (err) {
                    reject(err)
                }
            })
        },        
    }    
} 
</script>