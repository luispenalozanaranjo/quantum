<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-card outlined>
                    <v-card-title class="pr-7 pl-7">
                        <v-toolbar flat class="pjud">
                            <v-toolbar-title >
                                <h2 class="white--text">{{tribunal_descripcion}}</h2>
                            </v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                        </v-toolbar>
                    </v-card-title>
                    <v-card-subtitle class="pr-7 pl-7">
                        <FiltrosCompetencias/>
                    </v-card-subtitle>
                    <v-card-text>
                        <v-tabs v-model="tab" background-color="accent-4" centered>
                            <v-tabs-slider></v-tabs-slider>
                            <v-tab href="#tab-1">Términos Causas</v-tab>
                            <v-tab href="#tab-2">Términos Materias</v-tab>
                            <!-- <v-tab href="#tab-3">Terminos Tipos</v-tab> -->
                        </v-tabs>

                        <v-tabs-items v-model="tab">
                            <v-tab-item id="tab-1">
                                    <FamiliaTerminosTipos />
                            </v-tab-item>
                            <v-tab-item id="tab-2">
                                    <FamiliaTerminosMaterias />
                            </v-tab-item> 
                        </v-tabs-items>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias.vue'
import FamiliaTerminosTipos from './FamiliaTerminosTipos.vue'
import FamiliaTerminosMaterias from './FamiliaTerminosMaterias.vue'
import store from 'store'
import countTo from 'vue-count-to'
export default {
	name: 'FamiliaTerminos',
	data: () => ({
        tab: null,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tribunal_descripcion: '',        
	}),   
    async created () {
        this.$gtag.event('familia_terminos', { method: 'Google' })
        this.getAll()
    },
    methods: {
        async getAll(){
            let response =  await this.getUserCompetenciasCortesTribunalesOne(this.usuario.usuario, 'Familia', this.usuario.cod_tribunal)
            this.tribunal_descripcion = response.descripcion // Nombre del Tribunal.        
        },
        async getUserCompetenciasCortesTribunalesOne (usuario, competencia, cod_tribunal) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/user/getUserCompetenciasCortesTribunalesOne',
                        headers: {},
                        params:{
                            usuario: usuario,
							competencia: competencia,
                            cod_tribunal: cod_tribunal
                        }
                    })
                    // console.log(this.fechas())
                    resolve(response.data.competenciasCortesTribunalesOne)
                } catch (err) {
                    reject(err)
                }
            })
        },                
    },
    components:{
        FiltrosCompetencias,
        countTo,
        FamiliaTerminosTipos,
        FamiliaTerminosMaterias
    }    
}
</script>
