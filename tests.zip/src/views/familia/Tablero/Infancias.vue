<template>
	<v-row dense>
		<v-col cols="12"> 
				<v-tabs
					v-model="tabs"
					fixed-tabs
				>
				<v-tabs-slider></v-tabs-slider>
					<v-tab
						href="#Esperas"
						class="primary--text"
					>
					Esperas
					</v-tab>
					<v-tab
						href="#Cumplimientos"
						class="primary--text"
					>
					Cumplimientos
					</v-tab>
					<v-tab
						href="#Egresos"
						class="primary--text"
					>
					Egreso
					</v-tab>									
				</v-tabs>
				<v-tabs-items v-model="tabs">
					<v-tab-item
						value='Esperas'
					>
						<Esperas />
					</v-tab-item>
					<v-tab-item
						value='Cumplimientos'
					>
						<Cumplimientos />
					</v-tab-item>
					<v-tab-item
						value='Egresos'
					>
						<Egresos />
					</v-tab-item>						
				</v-tabs-items>
    </v-col>
  </v-row>
</template>
<script>
import Esperas from '../Tablero/Esperas'
import Cumplimientos from '../Tablero/Cumplimientos'
import Egresos from '../Tablero/Egresos'

export default {
  name: 'Infancias',
  data () {
    return {
      tabs: null
    }
  },
  created () {
    this.$gtag.event('tablero_familia_infancias', { method: 'Google' })
  },
  components: {
    Esperas,
    Cumplimientos,
    Egresos
  }
}
</script>