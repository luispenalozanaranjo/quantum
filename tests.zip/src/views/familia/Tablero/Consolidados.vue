<template>
	<v-row dense>
		<v-col cols="12"> 
			<v-card>
				<v-tabs
					v-model="tabs"
					fixed-tabs
				>
				<v-tabs-slider></v-tabs-slider>
					<v-tab
						href="#Gestiones"
						class="primary--text"
					>
					Gestiones
						<!-- <v-icon>mdi-phone</v-icon> -->
					</v-tab>
					<v-tab
						href="#Infancia"
						class="primary--text"
					>
					Infancia
						<!-- <v-icon>mdi-phone</v-icon> -->
					</v-tab>
					<v-tab
						href="#AudienciasMaterias"
						class="primary--text"
					>
					Audiencia
						<!-- <v-icon>mdi-phone</v-icon> -->
					</v-tab>										
				</v-tabs>
				<v-tabs-items v-model="tabs">
					<v-tab-item
						value='Gestiones'
					>
						<Gestiones />
					</v-tab-item>
					<v-tab-item
						value='Infancia'
					>
						<Infancias />
					</v-tab-item>
					<v-tab-item
						value='AudienciasMaterias'
					>
						<AudienciasMaterias />
					</v-tab-item>										
				</v-tabs-items>
			</v-card>
		</v-col>			
	</v-row>
</template>
<script>
import Gestiones from '../Tablero/Gestiones'
import Infancias from '../Tablero/Infancias'
import AudienciasMaterias from '../Tablero/AudienciasMaterias'
// import Inventarios from '../familia/Inventarios'
// import Tramites from '../familia/Tramites'
export default {
  name: 'Consolidados',
  data () {
    return {
		tabs: null
    }
  },
  created () {
    this.$gtag.event('tablero_familia', { method: 'Google' })
  },
  methods: {
    requestData: function (dateRange) {
		
    //   this.dateRange = dateRange

    //   const axios = require('axios')
    //   const ing_url = url + '/familia/tribunal'
    //   this.urlquauntum = quantum + '/familia_controller/totalesCorte/'+ this.user[0].cod_corte

    //   const get = async ing_url => {
    //     try {
    //       const response = await axios.get(ing_url, {
    //         params: {
    //           cod_tribunal: this.user[0].cod_tribunal
    //         }
    //       })
    //       const data = response.data
    //       this.gls_tribunal = data.recordset[0].gls_tribunal;

    //     } catch (error) {
    //       console.log(error)
    //     }
    //   }

    //   get(ing_url)
    },    
  },
  components: {
	Gestiones,
    Infancias,
    AudienciasMaterias,
    // Inventarios,
    // Tramites
  }
}
</script>