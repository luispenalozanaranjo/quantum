<template>
	<v-row dense>
    <v-col xs12 cols="12">
		<v-row dense>
			<v-col xs12 cols="12">
				<v-row dense>
					<v-col xs12 cols="3" class="text-center">
						<span>Total Ambulatorios</span>
						<br/>
						<h2>
							<countTo class="count green--text" :startVal="startVal" :endVal="endVal[0]" separator="." :duration="3000"></countTo>
						</h2>
					</v-col>
					<v-col xs12 cols="3" class="text-center">
						<span class="count_top">Total Fae-Fas</span>
						<br/>
						<h2>
							<countTo class="count green--text" :startVal="startVal" :endVal="endVal[1]" separator="." :duration="3000"></countTo>
						</h2>
					</v-col>
					<v-col xs12 cols="3" class="text-center">
						<span class="count_top">Residenciales</span>
						<br/>
						<h2>
							<countTo class="count green--text" :startVal="startVal" :endVal="endVal[2]" separator="." :duration="3000"></countTo>                 
						</h2>
					</v-col>
					<v-col xs12 cols="3" class="text-center">
						<span class="count_top">Total</span>
						<br/>
						<h2>
							<countTo class="count green--text" :startVal="startVal" :endVal="endVal[3]" separator="." :duration="3000"></countTo>               
						</h2>
					</v-col>        
				</v-row>
				<v-row>
					<v-col cols="10" offset="1">
						<vue-excel-xlsx class="btn text-center"
                                :data="items"
                                :columns="excelHead"
                                :filename="'EsperasFamilia'"
                                :sheetname="'Hoja1'"
                    	>
                            <v-tooltip top>
                                <template v-slot:activator="{ on, attrs }">
       								          <v-btn
                                  class="mx-2"
                                  fab
                                  dark
                                  small
                                  color="success"
                                  v-bind="attrs" v-on="on"
                        			  >
                            			<v-icon >mdi-microsoft-excel</v-icon>
                        			  </v-btn>
                                </template>
                                <span>Exportar a excel</span>
                            </v-tooltip>
                    	</vue-excel-xlsx>
						<v-data-table
							:headers="itemsHeader"
							:items="items"
							:items-per-page="10"
							class="mt-5 elevation-1"
							dense
						>
							<template v-slot:[`item.gls_centroresidencial`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.gls_centroresidencial }}
								</div>
							</template>
							<template v-slot:[`item.descripcion`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.descripcion }}
								</div>
							</template>
							<template v-slot:[`item.rut`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.rut }}
								</div>
							</template>
							<template v-slot:[`item.rit`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.rit }}
								</div>
							</template>
							<template v-slot:[`item.gls_tipolitigante`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.gls_tipolitigante }}
								</div>
							</template>	
							<template v-slot:[`item.fecha_resolucion`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.fecha_resolucion }}
								</div>
							</template>	
							<template v-slot:[`item.flg_80bis`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.flg_80bis }}
								</div>
							</template>
							<template v-slot:[`item.dia`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.dia }}
								</div>
							</template>								
							<template v-slot:[`item.fec_nacimiento`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.fec_nacimiento }}
								</div>
							</template>						
							<template v-slot:[`item.flg_curador`]="{ item }">
								<div
								:class="compruebaEdad(item.edad)"
								>
								{{ item.flg_curador }}
								</div>
							</template>
							<template v-slot:[`item.edad`]="{ item }">
								<v-alert
								dense
								outlined
								:type="compruebaEdadAlert(item.edad)"
								class="mt-2"
								>
								{{ item.edad }}
								</v-alert>
							</template>
						</v-data-table>  
					</v-col>
				</v-row>
			</v-col>
      </v-row>
    </v-col>
  </v-row>
</template>
<script>
import { url } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import downloadexcel from "vue-json-excel";

export default {
  name: 'Cumplimientos',
  data () {
    return {
        startVal: 0,
        endVal: [0, 0, 0],            
        user: [{
          usuario_id : store.get('user_usuario_id'),
          cod_corte : store.get('cod_corte'),
          cod_tribunal : store.get('cod_tribunal'),
          ano : store.get('ano'),
          mes : store.get('mes')
        }],
        dateRange: [new Date(2020, 0, 1), new Date(2020, 11, 31)],
        itemsHeader: [{text: 'Centro', align: 'center', sortable: false, value: 'gls_centroresidencial', class: 'pjud white--text'},
                            {text: 'Tipo', align: 'center', sortable: false, value: 'descripcion', class: 'pjud white--text'},
                            {text: 'RUT', align: 'center', sortable: false, value: 'rut', class: 'pjud white--text'},
                            {text: 'RIT', align: 'center', sortable: false, value: 'rit', class: 'pjud white--text'},
                            {text: 'Tipo Lit', align: 'center', sortable: false, value: 'gls_tipolitigante', class: 'pjud white--text'},
                            {text: 'Fec. Resolución', align: 'center', sortable: false, value: 'fecha_resolucion', class: 'pjud white--text'},
                {text: '80 BIS', align: 'center', sortable: false, value: 'flg_80bis', class: 'pjud white--text'},
                {text: 'T. Espera', align: 'center', sortable: false, value: 'dia', class: 'pjud white--text'},
                {text: 'F. Nacimiento', align: 'center', sortable: false, value: 'fec_nacimiento', class: 'pjud white--text'},
                {text: 'Edad', align: 'center', sortable: false, value: 'edad', class: 'pjud white--text'},
                {text: 'Curador', align: 'center', sortable: false, value: 'flg_curador', class: 'pjud white--text'},
        ],
        fields: [
            {
                key: "gls_centroresidencial",
                label: "Centro",
                sortable: true
            },          
            {
                key: 'descripcion',
                label: 'Tipo',
                sortable: true
            },
            {
                key: 'rut',
                label: 'RUT',
                sortable: true
            },            
            {
                key: 'rit',
                label: 'RIT',
                sortable: true
            },
            {
                key: 'gls_tipolitigante',
                label: 'Tipo Lit',
                sortable: true
            },            
            {
                key: 'fecha_resolucion',
                label: 'Fec. Resolución',
                sortable: true
            },
            {
                key: 'flg_80bis',
                label: '80 BIS',
                sortable: true
            },
            {
                key: 'dia',
                label: 'T. Cumplimientos',
                sortable: true
            },
            {
                key: 'fec_nacimiento',
                label: 'F. Nacimiento',
                sortable: true
            },
            {
                key: 'edad',
                label: 'Edad',
                sortable: true
            },
            {
                key: 'flg_curador',
                label: 'Curador',
                sortable: true
            }                        
		    ],
        excelHead : [  {label: "Centro",      field: "gls_centroresidencial",},
                        {label: "Tipo",    field: "descripcion",},
                        {label: "RUT",  field: "rut",},
						{label: "RIT",  field: "rit",},             
						{label: "Tipo Lit",  field: "gls_tipolitigante",},             
						{label: "Fec. Resolución",  field: "fecha_resolucion",},             
						{label: "80 BIS",  field: "flg_80bis",},             
						{label: "T. Espera",  field: "dia",},             
						{label: "F. Nacimiento",  field: "fec_nacimiento",},             
						{label: "Edad",  field: "edad",},
						{label: "Curador",  field: "flg_curador",},
        ],
        totalRows: 1,
        currentPage: 1,
        perPage: 10,
        pageOptions: [10, 20, 30],
        filter: null,
        filterOn: [],    
        items: [],
        data : [],
        arraynew:[]
    }
  },
  created () {
    this.$gtag.event('tablero_familia_infancias_esperas', { method: 'Google' })
    this.requestData()
  },
  methods: {
	compruebaEdadAlert(item) {
     	return item > 17 ? 'error' : ''
  	},
	compruebaEdad(item) {
     	return item > 17 ? 'red--text' : ''
  	}, 
	limpiar(){
		  this.arraynew = []
          this.arraynew=this.items
          this.filter=''
    },
    update (value) {
      this.startVal = 0
      this.endVal = [0, 0, 0]
      this.requestData(value)
	}, 
	startDownload(){
			 this.arraynew = []
        if(this.filter === '') {
          this.arraynew = this.data
          return this.arraynew;
        }else {
          if(this.filter === null) {
            this.arraynew = this.data
            return this.arraynew;
          } else {
			/// Filtro el array 
              this.arraynew = this.items.filter((m) =>  
              (((m.gls_centroresidencial.toLowerCase().match(this.filter)) || (m.gls_centroresidencial.match(this.filter))) && (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              || (((m.descripcion.toLowerCase().match(this.filter)) || (m.descripcion.match(this.filter))) && 
              ((this.filterOn[0] == 'descripcion' || this.filterOn[1] == 'descripcion' || this.filterOn[2] == 'descripcion' ) ||
              (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined)))
              || (((m.rut.toLowerCase().match(this.filter)) || (m.rut.match(this.filter))) && (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              || (((m.rit.toLowerCase().match(this.filter)) || (m.rit.match(this.filter))) &&
              ((this.filterOn[0] == 'rit' || this.filterOn[1] == 'rit' || this.filterOn[2] == 'rit' ) ||
              (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined)))                   
              ||  (((m.gls_tipolitigante.toLowerCase().match(this.filter)) || (m.gls_tipolitigante.match(this.filter)))  &&
               (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))                    
              || ((m.fecha_resolucion.match(this.filter)) && 
              ((this.filterOn[0] == 'fecha_resolucion' || this.filterOn[1] == 'fecha_resolucion' || this.filterOn[2] == 'fecha_resolucion' ) ||
              (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined)))
              || (((m.flg_80bis.toLowerCase().match(this.filter)) || (m.flg_80bis.match(this.filter))) && (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              || ((m.dia == this.filter) && (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              || ((m.fec_nacimiento == this.filter) && 
                 (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              || ((m.edad == this.filter) && (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              || (((m.flg_curador.toLowerCase().match(this.filter)) || (m.flg_curador.match(this.filter))) && (this.filterOn[0] == undefined && this.filterOn[1] ==  undefined && this.filterOn[2] == undefined))
              );
				}
			}	 
    },    
    requestData: function (dateRange) {

      const axios = require('axios')
      const req1 = url + '/familia/centrosEsperas'
      const req2 = url + '/familia/centrosEsperasDetalles'


      axios.all([
        axios.get(req1, {
          params: {
            cod_corte: this.user[0].cod_corte,
            cod_tribunal: this.user[0].cod_tribunal
          }
        }),
        axios.get(req2, {
          params: {
            cod_corte: this.user[0].cod_corte,
            cod_tribunal: this.user[0].cod_tribunal
          }
        })
      ]).then(axios.spread((...responses) => {

        const data1 = responses[0].data
        const data2 = responses[1].data
        let aux = 0;

        Object.values(data1.recordset).map((type) => {
          this.endVal[aux] = type.cantidad;
          aux++;
        })

        this.endVal[aux] =  this.endVal[0] + this.endVal[1] + this.endVal[2]

        Object.values(data2.recordset).map((type) => {
            this.items.push({isActive: true, 
								gls_centroresidencial: type.gls_centroresidencial, 
                             	descripcion: type.descripcion, 
								rut: type.rut, 
								rit: type.rit, 
                             	gls_tipolitigante: type.gls_tipolitigante, 
								fecha_resolucion: type.fecha_resolucion, 
                             	flg_80bis: type.flg_80bis, 
								dia: type.dia.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'), 
                             	fec_nacimiento: type.fec_nacimiento, 
								edad: type.edad, 
								flg_curador: type.flg_curador
							});
            
			      this.data.push({ gls_centroresidencial: type.gls_centroresidencial, descripcion: type.descripcion, rut: type.rut, gls_tipolitigante: type.gls_tipolitigante, rit: type.rit, fecha_resolucion: type.fecha_resolucion, flg_80bis: type.flg_80bis, dia: type.dia.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'), fec_nacimiento: type.fec_nacimiento, edad: type.edad, flg_curador: type.flg_curador});
        
        })

        this.totalRows = this.items.length;
        this.$forceUpdate()

      })).catch(errors => {

      })
    },       
  },
  components: {
    countTo,
	  downloadexcel
  }
}
</script>

<style lang="scss">
.ve-avatar {
  height: 32px;
  width: 32px;
  border-radius: 50%;
  border: thin solid #aaa;
}
</style>
