<template>
	<v-container>
	<v-row dense>
		<v-col xs12 cols="5">
			<v-card
				min-height="350"
				max-height="400"
				elevation="0"
			>
				<v-card-title class="pjud white--text">
					Comparativa Ingresos Vs Términos
				</v-card-title>                      
				<!-- <v-card-subtitle>Tiempo de interaccón medio</v-card-subtitle> -->
				<v-card-text>
					<apexchart :type="typeChart" height="300" :options="pieChartOptionPie" :series="pieSeries"></apexchart>
				</v-card-text>
			</v-card>
		</v-col>
		<v-col xs12 cols="3">
			<v-card
				min-height="350"
				max-height="400"
				elevation="0"
			>
				<v-card-text>
					<v-row dense>
						<v-col xs12 cols="12">
							<v-hover>
								<v-card hover height="100" width="100%" color="pjud"   class="cardAction" >
									<v-card-title class="white--text justify-center">Ingresos</v-card-title>
									<v-card-subtitle class="white--text text-center">
										<h2>
											<countTo  :startVal="0" :endVal="this.count.cantidad_ingresos" separator="." :duration="2000">
											</countTo>
										</h2>
									</v-card-subtitle>
								</v-card>
							</v-hover>
						</v-col>
					</v-row>
					<v-row dense>
						<v-col xs12 cols="12">
							<v-hover>
								<v-card hover height="100" width="100%" color="pjud"   class="cardAction" >
									<v-card-title class="white--text justify-center">Términos</v-card-title> 
									<v-card-subtitle class="white--text text-center">
										<h2>
											<countTo  :startVal="0" :endVal="this.count.cantidad_terminos" separator="." :duration="2000">
											</countTo>
										</h2>
									</v-card-subtitle>	
								</v-card>
							</v-hover>
						</v-col>
					</v-row>
					<v-row dense>
						<v-col xs12 cols="12">
							<v-hover>
								<v-card hover height="100" width="100%" color="pjud"   class="cardAction" > 
									<v-card-title class="white--text justify-center">Resoluciones</v-card-title>
									<v-card-subtitle class="white--text text-center">
										<h2>
											<countTo  :startVal="0" :endVal="this.count.cantidad_resoluciones" separator="." :duration="2000">
											</countTo>
										</h2>
									</v-card-subtitle>									
								</v-card>
							</v-hover>
						</v-col>
					</v-row>
				</v-card-text>
			</v-card>
		</v-col>
		<v-col xs12 cols="4">
			<v-card
				min-height="350"
				max-height="400"
				elevation="1"
			>
				<v-card-title class="pjud white--text">
					Resoluciones por Juez
					<v-spacer></v-spacer>
					<v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn>
				</v-card-title>
				<v-card-text>
					<v-row v-for="(juez, index) in resJuez" v-bind:key="juez.name" >
						<v-col xs12 cols="12" v-if="index <= 4">
							<v-row dense>
								<v-col class="primary--text" xs12 cols="8">
									<b>{{ juez.name | capitalize }}</b>
								</v-col>
								<v-col class="primary--text text-center" xs12 cols="4">
									<countTo class="count" :startVal="0" :endVal="juez.cantidadRes" separator="." :duration="1000"></countTo>
								</v-col>
							</v-row>
							<v-divider></v-divider>
						</v-col>
					</v-row>
				</v-card-text>
			</v-card>
		</v-col>             
	</v-row>
	<v-row dense>
		<v-col xs12 cols="5">
			<v-card
				min-height="350"
				max-height="400"
			>
				<v-card-title class="pjud white--text">
					Audiencias
				</v-card-title>                      
				<!-- <v-card-subtitle>Tiempo de interaccón medio</v-card-subtitle> -->
				<v-card-text>
					<v-card
						min-height="135"
						max-height="140"
						elevation="0"
					>
					<v-card-text>
						<v-row dense>
							<v-col xs12 cols="4" class="mt-5">
								Audiencias
								<v-spacer></v-spacer>
								Realizadas
							</v-col>
							<v-col xs12 cols="4" class="mt-2">
								<v-row>
									<v-col xs12 cols="3" class="float-left">
										<v-icon size="40" v-if="RealizadaEstadoMesAnterior == 'descendente'" v-text="'mdi-arrow-down-circle-outline'" color="red"></v-icon>
										<v-icon size="40" v-if="RealizadaEstadoMesAnterior == 'ascendente'" v-text="'mdi-arrow-up-circle-outline'" color="green"></v-icon>
										<v-icon size="40" v-if="RealizadaEstadoMesAnterior == 'equivalente'" v-text="'mdi-arrow-up-circle-outline'" color="yellow"></v-icon>
									</v-col>
									<v-col xs12 cols="9" class="primary--text text-right">
										<label>{{textAudiencias}}</label>
										<h5 class="primary--text text-center">
											<label v-if="RealizadaEstadoMesAnterior == 'ascendente'">+</label>
											{{ RealaizadaMesAnterior }} %
										</h5>
									</v-col>
								</v-row>
							</v-col>
							<v-col xs12 cols="4" class="primary--text text-center mt-7">
								<h3>
									<countTo class="count" :startVal="0" :endVal="audrealizada" separator="." :duration="3000"></countTo>
								</h3>
							</v-col>
						</v-row>
					</v-card-text>
				</v-card>
					<v-divider></v-divider>
					<v-card
						min-height="135"
						max-height="140"
						elevation="0"
					>
					<v-card-text>					
						<v-row dense>
							<v-col xs12 cols="4" class="mt-5">
								Audiencias
								<v-spacer></v-spacer>
								No Realizadas
							</v-col>
							<v-col xs12 cols="4" class="mt-2">
								<v-row>
									<v-col xs12 cols="3" class="float-left">
										<v-icon size="40" v-if="NoRealizadaEstadoMesAnterior == 'descendente'" v-text="'mdi-arrow-down-circle-outline'" color="red"></v-icon>
										<v-icon size="40" v-if="NoRealizadaEstadoMesAnterior == 'ascendente'" v-text="'mdi-arrow-up-circle-outline'" color="green"></v-icon>
										<v-icon size="40" v-if="NoRealizadaEstadoMesAnterior == 'equivalente'" v-text="'mdi-arrow-up-circle-outline'" color="yellow"></v-icon>
									</v-col>
									<v-col xs12 cols="9" class="primary--text text-right">
										<label>{{textAudiencias}}</label>
										<h5 class="primary--text text-center">
											<label v-if="NoRealizadaEstadoMesAnterior == 'ascendente'">+</label>
											{{ NoRealizadaMesAnterior }} %
										</h5>
									</v-col>
								</v-row>
							</v-col>
							<v-col xs12 cols="4" class="primary--text text-center mt-7">
								<h3>
									<countTo class="count" :startVal="0" :endVal="audnorealizada" separator="." :duration="3000"></countTo>
								</h3>
							</v-col>
						</v-row>
					</v-card-text>
					</v-card>
				</v-card-text>
			</v-card>
		</v-col>
		<v-col xs12 cols="3">
			<v-row>
				<v-col xs12 cols="12">
					<v-card
						min-height="140"
						max-height="160"
					>
						<v-card-title class="pjud white--text">
							<v-spacer></v-spacer>
							<v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn>
						</v-card-title>
						<v-card-text>
							<v-row dense>
								<v-col xs12 cols="10" class="primary--text">
									<b>Preparatorias</b><br>Atraso promedio minutos
								</v-col>
								<v-col xs12 cols="2" c class="primary--text">
									<b><countTo :startVal=0 :endVal="audAtrasoPrep" separator="." :duration="2000"></countTo>Min</b>
								</v-col>                      
							</v-row>
						</v-card-text>
					</v-card>
				</v-col>
			</v-row>
			<v-row>
				<v-col xs12 cols="12">
					<v-card
						min-height="140"
						max-height="160"
					>
						<v-card-title class="pjud white--text">
							<v-spacer></v-spacer>
							<v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn>
						</v-card-title>
						<v-card-text>
							<v-row dense>
								<v-col xs12 cols="10" class="primary--text">
									<b>Juicio</b><br>Atraso promedio minutos
								</v-col>
								<v-col xs12 cols="2" c class="primary--text">
									<b><countTo :startVal=0 :endVal="audAtrasoJuicio" separator="." :duration="2000"></countTo>Min</b>
								</v-col>                      
							</v-row>							
						</v-card-text>
					</v-card>
				</v-col>
			</v-row>			
		</v-col>
		<v-col xs12 cols="4">
			<v-card
				min-height="350"
				max-height="400"
			>
				<v-card-title class="pjud white--text">
					Términos por Tipos
					<v-spacer></v-spacer>
					<v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn>
				</v-card-title>
				<v-card-text>
					<v-row v-for="(tipos, index) in terTipos" v-bind:key="tipos.name" >
						<v-col xs12 cols="12" v-if="index <= 4">
							<v-row dense>
								<v-col class="primary--text" xs12 cols="8">
									<b>{{ tipos.name | capitalize }}</b>
								</v-col>
								<v-col class="primary--text text-center" xs12 cols="4">
									<countTo class="count" :startVal="0" :endVal="tipos.cantidad" separator="." :duration="1000"></countTo>
								</v-col>
							</v-row>
							<v-divider></v-divider>
						</v-col>
					</v-row>
				</v-card-text>
			</v-card>
		</v-col>             
	</v-row>	
	</v-container>
</template>

<script>
// import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'
import { url } from '../../../config/api'
import { mapState , mapMutations } from 'vuex'
import store from 'store'
import countTo from 'vue-count-to'

export default {
	name: 'Gestiones',
	data () {
		return {  
			user: {
				usuario_id : store.get('user_usuario_id'),
				cod_corte : store.get('cod_corte'),
				cod_tribunal : store.get('cod_tribunal'),
				ano : store.get('ano'),
				mes : store.get('mes')
			},
			count: {},
			typeChart: 'pie',
			pieSeries: [],
			pieChartOptionPie: {
				labels: ['Ingresos', 'Terminos']
			},
			resJuez: [],
			terTipos: [],
            audrealizada: 0,
            audnorealizada: 0,
            audnorealizadatotal: 0,
            audsuspendida: 0,
            audreprogramadas: 0,
            audAtrasoJuicio: 0,
            audAtrasoPrep: 0,
            audEstadoJuicio: "",
            audEstadoPrep: "",
            RealaizadaMesAnterior: 0,
            NoRealizadaMesAnterior: 0,
            RealizadaEstadoMesAnterior: "",
            NoRealizadaEstadoMesAnterior: "",
            textAudiencias: 'Mes Anterior',
            dialogAtrasos: false,
            detalleAtrasosPrepData: [],
            detalleAtrasosJuicioData: [],
            juicioORprep: '',
            headers: [],
            totalAtrasosJuicio: 0,
            totalAtrasosPrep: 0,
            excelHead : [
                        {label: "#" ,field: "increment"},
                        {label: "RIT" ,field:  "rit"},
                        {label: "juez" ,field:  "juez"},
                        {label: "fec_trabajo" ,field: "fec_trabajo"},
                        {label: "hora_estipulada" ,field: "hora_estipulada"},
                        {label: "hora_inicio" ,field: "hora_inicio"},
                        {label: "minutos_atraso" ,field: "minutos_atraso"}
            ]			
		}
	},
	created () {
		this.requestData()
		// this.ValidarPermiso()
	},
	computed: {
		...mapState(['active'])
	},
	watch: {
		active () {
			this.change = true
			this.update()
		}
	},  
	methods: {
		...mapMutations(['setModal']), // Mutations no Borrar
		...mapState(['fechas']), // Valores Guardados
		requestData: function (option = 1) {

		switch (this.fechas().TipoBusqueda) {
			case 'Mensual':
				this.option = 1
			break;
			case 'Trimestre':
				this.option = 2
			break; 
			case 'CuatrimestreFijo':
				this.option = 4
			break; 
			case 'CuatrimestreMovil':
				this.option = 5
			break; 
			case 'AñoFijo':
				this.option = 6
			break;       
			case 'AñoMovil':
				this.option = 3
			break; 
			default:
				this.option = 1
			break;
		}

		const axios = require('axios')
		const req1 = url + '/familia/indicador_cantidad_ingreso'
		const req2 = url + '/familia/resolucionesFuncionarios'
		const req3 = url + '/familia/terminosTipos'
		const req4 = url + '/familia/audienciasEstados'
		const req5 = url + '/familia/audienciasAtrasos'
		const req6 = url + '/familia/audienciasAtrasos'			

		const paramsOne = {  
				cod_corte: this.user.cod_corte,
				cod_tribunal: this.user.cod_tribunal,
				anoInicio: this.fechas().anoInicio || this.$route.params.ano,
				mesInicio: this.fechas().mesInicio || this.$route.params.mes,
				anoFin: this.fechas().anoFin || this.$route.params.ano,
				mesFin: this.fechas().mesFin || this.$route.params.mes,
				flag_exhorto: this.fechas().exhorto || 1
			}
		const paramsTwo = {  
				cod_corte: this.user.cod_corte,
				cod_tribunal: this.user.cod_tribunal,
				anoInicio: this.fechas().anoInicio || this.$route.params.ano,
				mesInicio: this.fechas().mesInicio || this.$route.params.mes,
				anoFin: this.fechas().anoFin || this.$route.params.ano,
				mesFin: this.fechas().mesFin || this.$route.params.mes,
				tipo_cargo_id: 1
			}
		const paramsThree = {  
				cod_corte: this.user.cod_corte,
				cod_tribunal: this.user.cod_tribunal,
				anoInicio: this.fechas().anoInicio || this.$route.params.ano,
				mesInicio: this.fechas().mesInicio || this.$route.params.mes,
				anoFin: this.fechas().anoFin || this.$route.params.ano,
				mesFin: this.fechas().mesFin || this.$route.params.mes
			}			

		const paramsFour = {
				cod_corte: this.user.cod_corte,
				cod_tribunal: this.user.cod_tribunal,
				anoInicio: this.fechas().anoInicio || this.$route.params.ano,
				mesInicio: this.fechas().mesInicio || this.$route.params.mes,
				anoFin: this.fechas().anoFin || this.$route.params.ano,
				mesFin: this.fechas().mesFin || this.$route.params.mes,
				tipoBusqueda: this.fechas().TipoBusqueda || "Mensual"
			}

		const paramsFive = {
				cod_corte: this.user.cod_corte,
				cod_tribunal: this.user.cod_tribunal,
				anoInicio: this.fechas().anoInicio || this.$route.params.ano,
				mesInicio: this.fechas().mesInicio || this.$route.params.mes,
				anoFin: this.fechas().anoFin || this.$route.params.ano,
				mesFin: this.fechas().mesFin || this.$route.params.mes,
				tipo_audiencia: "Juicio",
				tipoBusqueda: this.fechas().TipoBusqueda || "Mensual"
			}

		const paramsSix = {
				cod_corte: this.user.cod_corte,
				cod_tribunal: this.user.cod_tribunal,
				anoInicio: this.fechas().anoInicio || this.$route.params.ano,
				mesInicio: this.fechas().mesInicio || this.$route.params.mes,
				anoFin: this.fechas().anoFin || this.$route.params.ano,
				mesFin: this.fechas().mesFin || this.$route.params.mes,
				tipo_audiencia: "Preparatoria",
				tipoBusqueda: this.fechas().TipoBusqueda || "Mensual"
			}	
		// this.setModal(true)      
		// this.fechasotras = this.$setDate(option); 

		axios.all([
			axios.get(req1, {
				params: paramsOne
			}),
			axios.get(req2, {
				params: paramsTwo
			}),
			axios.get(req3, {
				params: paramsThree
			}),
			axios.get(req4, {
				params: paramsFour
			}),
			axios.get(req5, {
				params: paramsFive
			}),
			axios.get(req6, {
				params: paramsSix
			}),									
		]).then(axios.spread((...responses) => {

			const seriesPie = responses[0].data
			const dataResolucion = responses[1].data
			const dataTerminos = responses[2].data
			const dataAudiencias = responses[3].data
			const audiencias = []
			let audienciasMesAnterior = []
			let objAudiencia;	

			this.count = seriesPie.ListaCortes[0].ListaTribunalDto[0].ListaIndicadores[0] //  Total indicadores
			this.pieSeries = [this.count.cantidad_ingresos,this.count.cantidad_terminos]

			Object.values(dataResolucion.recordset).map((type) => {
				this.resJuez.push({name: type.nombre_funcionario, cantidadRes: type.cantidad})
			})

			Object.values(dataTerminos.recordset).map((type) => {
				this.terTipos.push({name: type.gls_tipfallada, cantidad: type.cantidad})
			})

			dataAudiencias.forEach(responseAud => {
				audiencias.push(responseAud.cantidad)

				objAudiencia = new Object();
				objAudiencia.PorcentajeMesAnterior = responseAud.PorcentajeMesAnterior
				objAudiencia.estado = responseAud.estado
				objAudiencia.cantidad = responseAud.cantidad
				objAudiencia.estado_audiencia_id = responseAud.estado_audiencia_id
				objAudiencia.cantidadNOREALIZADA = responseAud.cantidadNOREALIZADA
			
				audienciasMesAnterior.push(objAudiencia)
			});

			//INI-Obtener atraso de audiencias
			let dataAtrasos = responses[4].data
			this.audAtrasoJuicio = Math.round(dataAtrasos.audiencias_atrasos_prctn,0)

			if(this.audAtrasoJuicio < 0){
				this.audAtrasoJuicio = 0
			}

			this.audEstadoJuicio = dataAtrasos.estado
			dataAtrasos = responses[5].data
			this.audAtrasoPrep = Math.round(dataAtrasos.audiencias_atrasos_prctn,0)

			if(this.audAtrasoPrep < 0){
				this.audAtrasoPrep = 0
			}

			this.audEstadoPrep = dataAtrasos.estado
			//FIN-Obtener atraso de audiencias
			this.audrealizada = audiencias[0]
			this.audnorealizadatotal = audienciasMesAnterior.find(element => element.estado_audiencia_id == 99).cantidadNOREALIZADA
			this.audnorealizada = audiencias[1]
			this.audsuspendida = audiencias[2]
			this.audreprogramadas = audiencias[3]
			this.RealaizadaMesAnterior =  Math.round(audienciasMesAnterior.find(element => element.estado_audiencia_id == 1).PorcentajeMesAnterior)
			this.NoRealizadaMesAnterior = Math.round(audienciasMesAnterior.find(element => element.estado_audiencia_id == 2).PorcentajeMesAnterior)//Math.round(audienciasMesAnterior.find(element => element.estado_audiencia_id == 99).PorcentajeMesAnterior)
			this.RealizadaEstadoMesAnterior =  audienciasMesAnterior[0].estado
			this.NoRealizadaEstadoMesAnterior = audienciasMesAnterior.find(element => element.estado_audiencia_id == 99).estado
	
			// this.setModal(false) // Aqui Manipulamos el modal 

		})).catch(errors => {
			console.log(errors)
		})
		},
		toggleModal(){
			this.IsVisibility = !this.IsVisibility;
		},

		setTipoModal(value){
			this.tipoModal = value
		
		},

		update (value) {
			this.startVal = 0
			this.endVal = [0, 0, 0]
			this.requestData(value)
		
		},
		changeGraph(value,value2,value3){

		//console.log(value);
		
		
			switch(value){
				case 1:
				this.graph = 'pie' 
					
				break;
				default:
				
				this.graph = 'column';
				break;
			}

			this.api = value2
			this.title = value3
		
		},
		// ValidarPermiso(){
		// 		const axios = require('axios')
		// 		const req1 = url + '/familia/permisosComparativas' 

		// 		const get = async req1 => {
		// 			try{
		// 				const response = await axios.get(req1, {
		// 					params: {
		// 						id_usuario: this.user[0].usuario_id
		// 					}        
		// 				})
						
		// 				const data = response.data

		// 				if(data.estado == 'ACEPTADO')
		// 				{
		// 					this.MostrarComparativa = true
		// 				}else{
		// 					this.MostrarComparativa = false
		// 				}

		// 			} 
		// 			catch (error) {
		// 				console.log(error)
		// 			}
		// 		}

		// 		get(req1)
		// },
	
	},
	components: {
		// FiltrosCompetencias,
		countTo,
		// highcharts: Chart,
		// url,		
		// Bigtooltip,
		// Modal,
		// Audiencias,
		// ModalJuezTermino,
		// ModalEscritos,
		// ModalResoluciones,
		// ModalLoading,
		// ModalComparativas
	}		
}
</script>