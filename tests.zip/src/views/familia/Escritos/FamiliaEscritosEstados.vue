<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12">
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="detalleEscritosPlazos"
                                    :columns="excelHead"
                                    :filename="'Escritos'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <!-- <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="dialog = !dialog"                                    
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip> -->
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleResueltos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Escritos Resueltos'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headersResuelto"
                                        :items="detalleResueltos"
                                        :search="search"
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>  
                        <v-dialog max-width="95%" v-model="dialogPendientes">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detallePendientes"
                                                    :columns="excelHeadDetallesPendientes"
                                                    :filename="'Escritos Pendientes'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialogPendientes = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headersPendiente"
                                        :items="detallePendientes"
                                        :search="search"
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>  
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                Escritos Resueltos:
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                    <li>• Estado de la solicitud "Resuelto"</li>
                                    <li>• Estado de firma "Firmado"</li>
                                </ul>
                                Escritos Pendientes:
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                    <li>• Estado de la solicitud "Pendiente"</li>
                                    <li>• Excluye Estado de firma "invalidadas"</li>
                                </ul>
                        </v-tooltip>                       
                    </v-toolbar>
                    <v-row dense>
                        <v-col md="6" class="d-flex justify-center">
                            <v-hover v-slot:default="{ hover }">
                                <v-card 
                                    hover
                                    :elevation="hover ? 12 : 2"
                                    :class="{ 'on-hover': hover }"
                                    class="mt-2"
                                    color="#00bbd9"
                                    @click="dialog = true"
                                    width="70%"
                                    
                                >
                                    <v-card-title class="white--text">Resueltos</v-card-title>
                                    <v-card-text>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="totalResueltos"
                                            separator="."
                                            :duration="1000"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-col>
                        <v-col md="6" class="d-flex justify-center">
                            <v-hover v-slot:default="{ hover }">
                                <v-card 
                                    hover
                                    :elevation="hover ? 12 : 2"
                                    :class="{ 'on-hover': hover }"
                                    class="mt-2"
                                    color="#e74a25"
                                    @click="dialogPendientes = true"
                                    width="70%"
                                    
                                >
                                    <v-card-title class="white--text">Pendientes</v-card-title>
                                    <v-card-text>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="totalPendientes"
                                            separator="."
                                            :duration="1000"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-col md="12">
                            <v-data-table 
                                :headers="headersEscritosPlazos"
                                :items="detalleEscritosPlazos" 
                                disable-sort
                                class="mx-2 elevation-1 mb-3"
                                hide-default-footer
                                :items-per-page="causasItemsPerPage"
                            >
                                <template v-slot:[`body`]="{ items }">
                                    <tbody>
                                        <tr v-if="loadingEscritosPlazos">
                                            <td colspan="10"  class="text-center">
                                                <v-progress-linear indeterminate></v-progress-linear>
                                                 <p class="text--secondary">Cargando Información... Espere por favor</p>
                                            </td>
                                        </tr>
                                        <tr v-for="item in items " :key="item.increment">
                                            <td class="text-center">{{ item.ano }}</td>
                                            <td class="text-center">{{ item.mes }}</td>
                                            <td class="text-center"><countTo class="count" :startVal="0" :endVal="item.cantidad_pendientes" separator="." :duration="2000"></countTo></td>
                                            <td class="text-center">
                                                <v-chip dark color="success">
                                                    <countTo  :startVal="0" :endVal="item.cero_dias" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                            <td class="text-center">
                                                <v-chip dark color="success">
                                                    <countTo  :startVal="0" :endVal="item.un_dia" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                            <td class="text-center">
                                                <v-chip dark color="success">
                                                    <countTo  :startVal="0" :endVal="item.dos_dias" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                            <td class="text-center">
                                                <v-chip dark color="#FFC430">
                                                    <countTo  :startVal="0" :endVal="item.tres_dias" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                            <td class="text-center">
                                                <v-chip dark color="#FFC436">
                                                    <countTo   :startVal="0" :endVal="item.cuatro_dias" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                            <td class="text-center">
                                                <v-chip dark color="#FF9300">
                                                    <countTo   :startVal="0" :endVal="item.cinco_dias" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                            <td class="text-center">
                                                <v-chip dark color="#FF5800">
                                                    <countTo   :startVal="0" :endVal="item.seis_dias" separator="." :duration="2000"></countTo>
                                                </v-chip>
                                            </td>
                                        </tr>
                                    </tbody>
                                </template>
                            </v-data-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'FamiliaEscritosEstados',
	data: () => ({
        dialog: false,     
        dialogPendientes: false,
        loadingEscritosPlazos: true,
        total: 0,   
        totalPendientes: 0,
        detallePendientes: [],
        totalResueltos: 0,
        detalleResueltos: [],
        detalleEscritosPlazos: [],
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        excelHead : [{label: "Año"          ,field:  "ano"},
                    {label: "Mes"           ,field:  "mes"},                                                                                                                                                                       
                    {label: "Pendientes"    ,field:  "cantidad_pendientes"},
                    {label: "0 días"        ,field:  "cero_dias"},
                    {label: "1 día"         ,field:  "un_dia"},
                    {label: "2 días"        ,field:  "dos_dias"},
                    {label: "3 días"        ,field:  "tres_dias"},
                    {label: "4 días"        ,field:  "cuatro_dias"},
                    {label: "5 días"        ,field:  "cinco_dias"},
                    {label: "6 días"        ,field:  "seis_dias"},
        ],
        detalleEscritos: [],
        excelHeadDetalles : [
                {label: "Id Solicitud"      ,field: "crr_idsolicitud",},
                {label: "Rit"               ,field: "rit",},
                {label: "Tipo Causa"        ,field: "gls_tipo_causa",},
                {label: "Fec.Ing Causa"     ,field: "fec_ingreso",},
                {label: "Tipo Solicitud"    ,field: "gls_tipsolicitud",},
                {label: "Tipo Ingreso"      ,field: "gls_ing_escrito",},
                {label: "Est. Firma"        ,field: "gls_estfirma",},   
                {label: "Est. Escrito"      ,field: "gls_estsolicitud",}, 
                {label: "Fec.Ing Escrito"   ,field: "fecha_escrito",},
                {label: "Fec. Resuelto"     ,field: "fecha_resuelto",},
                {label: "Días Duración"     ,field: "dias_duracion",}            
        ],    
        excelHeadDetallesPendientes : [
                {label: "Id Solicitud"      ,field: "crr_idsolicitud",},
                {label: "Rit"               ,field: "rit",},
                {label: "Tipo Causa"        ,field: "gls_tipo_causa",},
                {label: "Fec.Ing Causa"     ,field: "fec_ingreso",},
                {label: "Tipo Solicitud"    ,field: "gls_tipsolicitud",},
                {label: "Tipo Ingreso"      ,field: "gls_ing_escrito",},
                {label: "Est. Firma"        ,field: "gls_estfirma",},   
                {label: "Est. Escrito"      ,field: "gls_estsolicitud",}, 
                {label: "Fec.Ing Escrito"   ,field: "fecha_escrito",},         
        ],       
        search: '',
        headersResuelto: [
            { text: 'Id Solicitud', align: 'center', value: 'crr_idsolicitud', class : 'pjud white--text subtitle-2' },
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text subtitle-2' },
            { text: 'Fec.Ing Causa', align: 'center', value: 'fec_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Solicitud', align: 'center', value: 'gls_tipsolicitud', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Ingreso', align: 'center', value: 'gls_ing_escrito', class : 'pjud white--text subtitle-2' },
            { text: 'Est. Firma', align: 'center', value: 'gls_estfirma', class : 'pjud white--text subtitle-2' },
            { text: 'Est. Escrito', align: 'center', value: 'gls_estsolicitud', class : 'pjud white--text subtitle-2' },   
            { text: 'Fec.Ing Escrito', align: 'center', value: 'fecha_escrito', class : 'pjud white--text subtitle-2' },
            { text: 'Fec. Resuelto', align: 'center', value: 'fecha_resuelto', class : 'pjud white--text subtitle-2' },        
            { text: 'Días Duración', align: 'center', value: 'dias_duracion', class : 'pjud white--text subtitle-2' }, 
        ],
        headersPendiente: [
            { text: 'Id Solicitud', align: 'center', value: 'crr_idsolicitud', class : 'pjud white--text subtitle-2' },
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text subtitle-2' },
            { text: 'Fec.Ing Causa', align: 'center', value: 'fec_ingreso', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Solicitud', align: 'center', value: 'gls_tipsolicitud', class : 'pjud white--text subtitle-2' },
            { text: 'Tipo Ingreso', align: 'center', value: 'gls_ing_escrito', class : 'pjud white--text subtitle-2' },
            { text: 'Est. Firma', align: 'center', value: 'gls_estfirma', class : 'pjud white--text subtitle-2' },
            { text: 'Est. Escrito', align: 'center', value: 'gls_estsolicitud', class : 'pjud white--text subtitle-2' },   
            { text: 'Fec.Ing Escrito', align: 'center', value: 'fecha_escrito', class : 'pjud white--text subtitle-2' },
        ],
        headersEscritosPlazos: [
            { text: 'Año', align: 'center', value: 'ano', class : 'pjud white--text subtitle-2' },
            { text: 'Mes', align: 'center', value: 'mes', class : 'pjud white--text subtitle-2' },
            { text: 'Pendientes', align: 'center', value: 'cantidad_pendientes', class : 'pjud white--text subtitle-2' },
            { text: '0 días', align: 'center', value: 'cero_dias', class : 'pjud white--text subtitle-2' },
            { text: '1 día', align: 'center', value: 'un_dia', class : 'pjud white--text subtitle-2' },
            { text: '2 días', align: 'center', value: 'dos_dias', class : 'pjud white--text subtitle-2' },
            { text: '3 días', align: 'center', value: 'tres_dias', class : 'pjud white--text subtitle-2' },
            { text: '4 días', align: 'center', value: 'cuatro_dias', class : 'pjud white--text subtitle-2' },   
            { text: '5 días', align: 'center', value: 'cinco_dias', class : 'pjud white--text subtitle-2' },
            { text: '6 días (o más)', align: 'center', value: 'seis_dias', class : 'pjud white--text subtitle-2' },        
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 20,
        loading: false      
	}),
    watch: {
        fechas() {
            this.getEscritosEstados();
            this.getEscritosResueltos();
            this.getEscritosPlazos();
        }
    },
    created () {
        try {
            this.getEscritosEstados();
            this.getEscritosResueltos();
            this.getEscritosPlazos();
        } catch (error) {
            console.log(error.messagge);
        }
    },    
    methods:{
        async getEscritosEstados(){
            try {
                const req = urlApi+'/familia/getResumenesTribunales';
                let arrayTribunal = [];
                this.totalResueltos = 0;
                this.totalPendientes = 0;
                arrayTribunal.push(this.usuario.cod_tribunal);


                const getEscritos = await axios.get(req, {
                        params:{
                            cod_corte:  this.usuario.cod_corte,
                            cod_tribunal:  arrayTribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio:this.fechas. mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                });


                if (getEscritos.status == 200 || getEscritos.status == 304) {
                    this.totalResueltos = getEscritos.data.resumenesTribunales.recordset[0].escritos_resueltos;
                    this.totalPendientes = getEscritos.data.resumenesTribunales.recordset[0].escritos_pendientes;
                }

            } catch (error) {
                console.log(error.message);
            }
         
        },
        async getEscritosResueltos(){
            this.detalleResueltos = [];
            this.loading = true;

            try {
                const req = urlApi+'/familia/getEscritosDetallesResueltos';

                const getEscritos = await axios.get(req, {
                        params:{
                            cod_corte:  this.usuario.cod_corte,
                            cod_tribunal:  this.usuario.cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio:this.fechas. mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                });

                if (getEscritos.status == 200 || getEscritos.status == 304) {
                    
                    getEscritos.data.forEach(escrito => {
                    
                        this.detalleResueltos.push({
                            crr_idsolicitud: escrito.crr_idsolicitud,
                            rit: escrito.rit,
                            gls_tipo_causa: escrito.gls_tipo_causa,
                            fec_ingreso: escrito.fec_ingreso,
                            gls_tipsolicitud: escrito.gls_tipsolicitud,
                            gls_ing_escrito: escrito.gls_ing_escrito,
                            gls_estfirma: escrito.gls_estfirma,
                            gls_estsolicitud: escrito.gls_estsolicitud,
                            crr_idparte: escrito.crr_idparte,
                            fecha_escrito: escrito.fecha_escrito,
                            fecha_resuelto: escrito.fecha_resuelto,
                            dias_duracion: escrito.dias_duracion,
                            ano: escrito.ano,
                            mes: escrito.mes
                        });

                    });

                    this.loading = false;
                }

            } catch (error) {
                this.loading = false;
                console.log(error.message);
            }
         
        },
        async getEscritosPlazos(){
            this.detalleEscritosPlazos = [];
            this.detallePendientes = [];
            let increment = 0;
            let detalleEscritosPendientesPlazo = [];
            this.loadingEscritosPlazos = true;

            try {
                //ESCRITOS PENDIENTES
                const req1 = urlApi+'/familia/getEscritosDetallesPendientes';

                const getEscritosPendientes = await axios.get(req1, {
                        params:{
                            cod_corte:  this.usuario.cod_corte,
                            cod_tribunal:  this.usuario.cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio:this.fechas. mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                });

                if (getEscritosPendientes.status == 200 || getEscritosPendientes.status == 304) {
                    
                    getEscritosPendientes.data.forEach(escrito => {
                    
                        this.detallePendientes.push({
                            crr_idsolicitud: escrito.crr_idsolicitud,
                            rit: escrito.rit,
                            gls_tipo_causa: escrito.gls_tipo_causa,
                            fec_ingreso: escrito.fec_ingreso,
                            gls_tipsolicitud: escrito.gls_tipsolicitud,
                            gls_ing_escrito: escrito.gls_ing_escrito,
                            gls_estfirma: escrito.gls_estfirma,
                            gls_estsolicitud: escrito.gls_estsolicitud,
                            crr_idparte: escrito.crr_idparte,
                            fecha_escrito: escrito.fecha_escrito,
                            ano: escrito.ano,
                            mes: escrito.mes
                        });

                    });

                }

                //ESCRITOS PLAZOS
                const req = urlApi+'/familia/getEscritosResueltosPlazos';

                const getEscritos = await axios.get(req, {
                        params:{
                            cod_corte:  this.usuario.cod_corte,
                            cod_tribunal:  this.usuario.cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio:this.fechas. mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                });

                if (getEscritos.status == 200 || getEscritos.status == 304) {

                    getEscritos.data.forEach(escrito => {

                        detalleEscritosPendientesPlazo = this.detallePendientes.filter(esc => esc.ano == escrito.ano && esc.mes == escrito.mes);
                        
                        this.detalleEscritosPlazos.push({
                            increment: increment,
                            ano: escrito.ano,
                            mes: escrito.mes,
                            cantidad_pendientes: detalleEscritosPendientesPlazo.length,
                            cero_dias: escrito.cero_dias,
                            un_dia: escrito.un_dia,
                            dos_dias: escrito.dos_dias,
                            tres_dias: escrito.tres_dias,
                            cuatro_dias: escrito.cuatro_dias,
                            cinco_dias: escrito.cinco_dias,
                            seis_dias: escrito.seis_dias
                        });

                        increment ++;

                    });

                }
                detalleEscritosPendientesPlazo = [];
                this.loadingEscritosPlazos = false;

            } catch (error) {
                this.loadingEscritosPlazos = false;
                console.log(error.message);
            }
         
        },            
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            try {
                
                let doc = new jsPDF({
                    orientation: 'p',
                    unit: 'mm',
                    format: 'letter',
                    putOnlyUsedFonts:true
                });

                let dataEscritos = []
                let width = doc.internal.pageSize.width; // ancho 297
                let height = doc.internal.pageSize.height; // altura 210

                this.detalleEscritosPlazos.map((object) => {
                    dataEscritos.push([
                            { content: object.ano, styles: { halign: 'center' } },
                            { content: object.mes, styles: { halign: 'center' } },
                            { content: object.cantidad_pendientes, styles: { halign: 'center' } },
                            { content: object.cero_dias, styles: { halign: 'center' } },
                            { content: object.un_dia, styles: { halign: 'center' } },
                            { content: object.dos_dias, styles: { halign: 'center' } },
                            { content: object.tres_dias, styles: { halign: 'center' } },
                            { content: object.cuatro_dias, styles: { halign: 'center' } },
                            { content: object.cinco_dias, styles: { halign: 'center' } },
                            { content: object.seis_dias, styles: { halign: 'center' } }
                    ])
                });

                doc.setFont('Calibri');
                doc.setFontSize(18);
                doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE ESCRITOS' , { align: 'center' });
                doc.setFontSize(12);
                doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas.periodo , { align: 'left' });
                
                doc.autoTable({
                    theme: 'grid',
                    startY: 30, // Estos es la posicion de los ejes Y 
                    head: [
                        [
                            { content: 'Año', styles: { halign: 'center' } },
                            { content: 'Mes', styles: { halign: 'center' } },
                            { content: 'Pendientes', styles: { halign: 'center' } },
                            { content: '0 días', styles: { halign: 'center' } },
                            { content: '1 día', styles: { halign: 'center' } },
                            { content: '2 días', styles: { halign: 'center' } },
                            { content: '3 días', styles: { halign: 'center' } },
                            { content: '4 días', styles: { halign: 'center' } },
                            { content: '5 días', styles: { halign: 'center' } },
                            { content: '6 días', styles: { halign: 'center' } },
                        ]
                    ],
                    body: dataEscritos
                })

                doc.save('Informe Escritos.pdf') 


            } catch (error) {
                console.log(error.message)
            }

        },              
    },
    computed:{
        ...mapState(['fechas']), // Valores Guardados
    },
    components:{
        countTo
    }        
} 
</script>
<style scoped>
    .tdCenter {
        text-align: center;
    }
</style>