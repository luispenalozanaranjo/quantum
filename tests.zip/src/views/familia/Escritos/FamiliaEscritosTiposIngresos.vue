<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="tables"
                                    :columns="excelHead"
                                    :filename="'EscritosTiposIngresos'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                        
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="downloadPDF()"                                   
                                >
                                    <v-icon >mdi-file-pdf-box</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar PDF</span>
                        </v-tooltip>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="dialog = !dialog"                                    
                                >
                                    <v-icon >mdi-table-eye</v-icon>
                                </v-btn>
                            </template>
                            <span>Visualizar Detalle</span>
                        </v-tooltip>
                        <v-dialog max-width="95%" v-model="dialog">
                            <v-card>
                                <v-card-title  class="pjud">
                                        <v-tooltip top>  
                                            <template v-slot:activator="{ on, attrs }">
                                                <vue-excel-xlsx
                                                    :data="detalleEscritos"
                                                    :columns="excelHeadDetalles"
                                                    :filename="'Escritos Tipos Ingresos'"
                                                    :sheetname="'Hoja1'"
                                                >  
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined
                                                        color="white"
                                                        v-bind="attrs"
                                                        v-on="on"
                                                    >
                                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                                    </v-btn>
                                                </vue-excel-xlsx>
                                            </template>
                                            <span>Exportar Excel</span>                                                
                                        </v-tooltip>
                                        <v-spacer></v-spacer>                                          
                                        <v-tooltip top>
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-btn
                                                        class="mx-2"
                                                        outlined                                                    
                                                        color="white"
                                                        @click="dialog = false"
                                                        v-bind="attrs"
                                                        v-on="on"                                                    
                                                    > 
                                                        X
                                                    </v-btn>
                                                </template>
                                            <span>Cerrar</span>
                                        </v-tooltip>                                        
                                </v-card-title>
                                <v-card-text>
                                    <v-text-field
                                        v-model="search"
                                        append-icon=""
                                        label="Buscar"
                                        single-line
                                        hide-details
                                    ></v-text-field>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="detalleEscritos"
                                        :search="search"
                                        :page.sync="causasPage"
                                        :items-per-page="causasItemsPerPage"
                                        @page-count="causasPageCount = $event" 
                                        :loading="loading"
                                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                                        dense
                                        class="mt-4">
                                    </v-data-table>                            
                                </v-card-text>
                            </v-card>
                        </v-dialog>  
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                    color="white"
                                    dark
                                    large
                                    v-bind="attrs"
                                    v-on="on"
                                >
                                    mdi-information-outline
                                </v-icon>
                                </template>
                                <h4 class="orange--text headline">Criterios</h4>
                                <ul>
                                    <li>• Excluye causas invalidadas</li>
                                </ul>
                        </v-tooltip>                       
                    </v-toolbar>
                    <v-row dense>
                        <v-col 
                            sm="12"
                            md="6"
                        >
                            <apexchart type="donut" class="pr-4 mt-4" height="450" :options="pieChartOptions" :series="pieSeries"></apexchart>
                        </v-col>
                        <v-col
                            sm="12"
                            md="6"
                        >
                            <v-simple-table 
                                dense
                                class="pr-4 mt-4"
                            >
                                <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center subtitle-2">
                                            Tipo Ingreso
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            Cantidad
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in tables"
                                        :key="item.id"
                                        >
                                        <td class="text-center">{{ item.name }}</td>
                                        <td class="text-center">
                                            <countTo :startVal=0 :endVal="item.value" separator="." :duration="1000"></countTo>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                <tr class="pjud white--text">
                                    <th class="text-center subtitle-2">Total</th>
                                    <th class="text-center">
                                        <countTo
                                            class="count subtitle-2"
                                            :startVal="0"
                                            :endVal="total"
                                            separator="."
                                            :duration="1000"
                                        ></countTo>
                                    </th>
                                </tr>
                            </tfoot>
                                </template>
                            </v-simple-table>
                        </v-col>
                    </v-row>
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import es from "apexcharts/dist/locales/es.json";
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
    name: 'FamiliaEscritosTiposIngresos',
	data: () => ({
        dialog: false,     
        total: 0,   
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        tables: [],
        pieSeries: [] ,
        pieLabel: [] ,
        pieChartOptions: {
            chart: {
                locales: [es],
                defaultLocale: "es",                
                id: 'pieGraficoEscritosIngresos',
                type: 'donut'
            },
            noData: {
                text: 'Visualizando'
            },                
            labels: [],
            dataLabels: {
                enabled: true,
                formatter: function (val) {
                return val.toFixed(2).toString().replace('.',',') + '%'
                }  
            },            
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '22px',
                                fontFamily: 'Rubik',
                                color: '#dfsda',
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '30px',
                                fontFamily: 'Helvetica, Arial, sans-serif',
                                color: undefined,
                                offsetY: 8,
                                formatter: function (val) {
                                    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                }
                            },
                            total: {
                                show: true,
                                label: 'Total',
                                color: '#373d3f',
                                formatter: function (w) {
                                    return  w.globals.seriesTotals.reduce((a, b) => {return a + b}, 0).toLocaleString()
                                }
                            }
                        }
                    }
                }
            },          
        },
        excelHead : [
            {
                label: "Tipo Ingreso",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleEscritos: [],
        excelHeadDetalles : [
            {
                label: "Id Solicitud",
                field: "crr_idsolicitud",
            },
            {
                label: "Rit",
                field: "rit",
            },
            {
                label: "Tipo Causa",
                field: "gls_tipo_causa",
            },
            {
                label: "Fec.Ing Causa",
                field: "fec_ingreso",
            },
            {
                label: "Tipo Solicitud",
                field: "gls_tipsolicitud",
            },
            {
                label: "Tipo Ingreso",
                field: "gls_ing_escrito",
            },
            {
                label: "Est. Firma",
                field: "gls_estfirma",
            },   
            {
                label: "Est. Escrito",
                field: "gls_estsolicitud",
            }, 
            {
                label: "Fec.Ing Escrito",
                field: "fecha_escrito",
            },
            {
                label: "Fec. Resuelto",
                field: "fecha_resuelto",
            }            
        ],        
        search: '',
        headers: [
            { text: 'Id Solicitud', align: 'center', value: 'crr_idsolicitud', class : 'pjud white--text"' },
            { text: 'Rit', align: 'center', value: 'rit', class : 'pjud white--text' },
            { text: 'Tipo Causa', align: 'center', value: 'gls_tipo_causa', class : 'pjud white--text' },
            { text: 'Fec.Ing Causa', align: 'center', value: 'fec_ingreso', class : 'pjud white--text' },
            { text: 'Tipo Solicitud', align: 'center', value: 'gls_tipsolicitud', class : 'pjud white--text' },
            { text: 'Tipo Ingreso', align: 'center', value: 'gls_ing_escrito', class : 'pjud white--text' },
            { text: 'Est. Firma', align: 'center', value: 'gls_estfirma', class : 'pjud white--text' },
            { text: 'Est. Escrito', align: 'center', value: 'gls_estsolicitud', class : 'pjud white--text' },   
            { text: 'Fec.Ing Escrito', align: 'center', value: 'fecha_escrito', class : 'pjud white--text' },
            { text: 'Fec. Resuelto', align: 'center', value: 'fecha_resuelto', class : 'pjud white--text' },        
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: false      
	}),
    watch: {
        fechas() {
            this.getEscritosTiposIngresos();
            this.getEscritosTiposDetalles();
        }
    },
    created () {
        try {
            this.getEscritosTiposIngresos();
            this.getEscritosTiposDetalles();
        } catch (error) {
            console.log(error.messagge);
        }
    },    
    methods:{
        
        async getEscritosTiposIngresos(){
            let dataLabels = [];
            this.pieSeries = []
            let seriesAux = [];
            this.tables = [];
            this.total = 0;

            try {
                const req = urlApi+'/familia/getEscritosTiposIngresos';

                const getEscritos = await axios.get(req, {
                        params:{
                            cod_corte:  this.usuario.cod_corte,
                            cod_tribunal:  this.usuario.cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio:this.fechas. mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                });

                if (getEscritos.status == 200 || getEscritos.status == 304) {
                    
                    getEscritos.data.forEach(escrito => {
                    
                        this.tables.push({
                            id: escrito.tip_ing_causa,
                            name: escrito.gls_ing_causa,
                            value: escrito.cantidad_escritos
                        });

                        this.total += escrito.cantidad_escritos;

                        seriesAux.push(escrito.cantidad_escritos);
                        dataLabels.push(escrito.gls_ing_causa)

                    });
                }

                ApexCharts.exec('pieGraficoEscritosIngresos', "updateOptions", {
                    labels: dataLabels,
                });

                ApexCharts.exec(
                    'pieGraficoEscritosIngresos',
                    'updateSeries',
                    seriesAux,
                    true,
                );     

            } catch (error) {
                console.log(error.messagge);
            }
         
        },
        async getEscritosTiposDetalles () {

            try {
                const req = urlApi+'/familia/getEscritosDetallesTipos';

                const getEscritos = await axios.get(req, {
                        params:{
                            cod_corte:  this.usuario.cod_corte,
                            cod_tribunal:  this.usuario.cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio:this.fechas. mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                });

                if (getEscritos.status == 200 || getEscritos.status == 304) {
                    this.detalleEscritos = getEscritos.data;
                    this.loading = false;
                }

            } catch (error) {
                console.log(error.messagge);
            }

        },        
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba

            try {
                
                let doc = new jsPDF({
                    orientation: 'p',
                    unit: 'mm',
                    format: 'letter',
                    putOnlyUsedFonts:true
                });

                let dataCausas = []
                let width = doc.internal.pageSize.width; // ancho 297
                let height = doc.internal.pageSize.height; // altura 210

                this.tables.map((object) => {
                    dataCausas.push([
                            { content: object.name, styles: { halign: 'left' } },
                            { content: object.value, styles: { halign: 'center' } }
                    ])
                });

                doc.setFont('Calibri');
                doc.setFontSize(18);
                doc.text((width / 2), (( height * 5) / 100 ), 'INFORME DE ESCRITOS POR TIPOS DE INGRESOS' , { align: 'center' });
                doc.setFontSize(12);
                doc.text(14, (( height * 8) / 100 ), 'Período: '+this.fechas.periodo , { align: 'left' });
                
                doc.autoTable({
                    theme: 'grid',
                    startY: 30, // Estos es la posicion de los ejes Y 
                    head: [
                        [
                            { content: 'Tipo Ingreso', styles: { halign: 'center' } },
                            { content: 'Cantidad', styles: { halign: 'center' } }
                        ]
                    ],
                    body: dataCausas
                })

                html2canvas(document.querySelector('#apexchartspieGraficoEscritosIngresos')).then(canvas => {
                    let wid = canvas.width; 
                    let hgt = canvas.height;
                    let hratio = hgt/wid;
                    let height = width * hratio;     
                    let img = canvas.toDataURL('image/png' , wid , hgt)
                    doc.addImage(img, 'png', 10, doc.previousAutoTable.finalY + 10,  width-20, height-20) // Grafica               
                    doc.save('Informe Escritos.pdf') 
                })

            } catch (error) {
                console.log(error.messagge)
            }

        },              
    },
    computed:{
        ...mapState(['fechas']), // Valores Guardados
    },
    components:{
        countTo
    }        
} 
</script>