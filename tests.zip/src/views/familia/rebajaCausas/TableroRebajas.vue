<template>
    <Layout>
        <v-card>
            <v-card-title class="pjud white--text">
                Filtros
                <v-spacer></v-spacer>
                <!-- <v-btn  color="success" :href="this.urlquauntum" style="text-decoration:none">Volver</v-btn>      -->
            </v-card-title>
            <v-card-text>
                <FiltrosEstadisticas class="mt-4"/>
            </v-card-text>
        </v-card>
        <v-tabs v-model="tab" background-color="accent-4" centered>
            <v-tabs-slider></v-tabs-slider>
            <v-tab href="#tab-1">Resumen</v-tab>
            <v-tab href="#tab-2">Inventario 31 de Diciembre de {{ ano - 1 }}</v-tab>
            <v-tab href="#tab-3">Inventario {{ ultimoDia }} de {{ nombreMes }} de {{ ano }}</v-tab>
            <v-tab href="#tab-4">Rebaja de Causas en Tramitación</v-tab>
        </v-tabs>
        <v-tabs-items v-model="tab">
            <v-tab-item id="tab-1">
                <DashboardRebaja />
            </v-tab-item>
            <v-tab-item id="tab-2">
                <AñoAnteriorRebaja />
            </v-tab-item>
            <v-tab-item id="tab-3">
                <AñoActualRebaja />
            </v-tab-item>
            <v-tab-item id="tab-4">
                <ComparativaRebaja />
            </v-tab-item>
        </v-tabs-items>
    </Layout>
</template>
<script>
import FiltrosEstadisticas from '../../../components/elementos/FiltrosEstadisticas'
import store from 'store'
import DashboardRebaja from './ModalDashboardRebaja'
import AñoAnteriorRebaja from './ModalAñoAnteriorRebaja'
import AñoActualRebaja from './ModalAñoActualRebaja'
import ComparativaRebaja from './ModalComparativaRebaja'
import { mapState, mapMutations } from 'vuex'
import { quantum } from '../../../config/quantum'
import Layout from '../../../components/layout/LayoutGeneral'
import moment from 'moment-timezone'
moment.locale('es');

export default {
    name: 'IngresosMain',
    data () {
        return {
            ano: 0,
            nombreMes: '',
            ultimoDia: 0,
            tab: null
            , urlquauntum: quantum + '/familia_controller/totalesCorte/'+ store.get('cod_corte')
        }
    },
    created(){
        
        this.inicio()
    },
    methods:{
        inicio() {
            const objFechas = store.get('fechas');
            this.ano = this.fechas.ano;
            this.nombreMes = moment.months()[(this.fechas.mes - 1)]
            this.ultimoDia = moment(this.fechas.mes, 'MM').endOf('month').format('DD')
        }
    },
    components: {
        DashboardRebaja,
        AñoAnteriorRebaja,
        AñoActualRebaja,
        ComparativaRebaja,
        FiltrosEstadisticas,
        Layout
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.inicio()
        }
    }
} 
</script>