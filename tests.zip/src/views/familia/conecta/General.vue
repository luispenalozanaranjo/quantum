<template>
    <v-container fluid>
        <LayoutConecta @clicked="update" v-bind:dateRange="dateRange" />
        <v-row dense>
            <v-col xs12 cols="6">
                <v-card
                    min-height="330"
                    max-height="330"
                >
                    <v-card-title class="pjud white--text">
                        Total Atenciones
                        <v-spacer></v-spacer>
                        <!-- <v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn> -->
                    </v-card-title>                      
                    <!-- <v-card-subtitle>Tiempo de interaccón medio</v-card-subtitle> -->
                    <v-card-text>
                        <apexchart type="area" height="250" :options="lineChartOptions" :series="lineSeries"></apexchart>
                    </v-card-text>
                </v-card>
            </v-col>
            <v-col xs12 cols="3">
                <v-card
                    min-height="330"
                    max-height="330"
                >
                    <v-card-title class="pjud white--text">
                        Estado Atenciones
                        <v-spacer></v-spacer>
                        <!-- <v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn> -->
                    </v-card-title>
                    <v-card-text>
                        <v-data-table 
                            :headers="headerEstados"
                            :items="arrEstados"
                            hide-default-footer
                            disable-sort
                            
                            class="mt-5"
                        >
                            <template v-slot:[`body`]="{ items }">
                                <tbody>
                                    <tr v-for="(item) in items " :key="item.id" >
                                    <td class="primary--text" ><v-icon :color="item.color" v-text="item.icon"></v-icon>{{ item.descripcion }}</td>
                                    <td><countTo class="count"  :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo></td>
                                    </tr>
                                </tbody>
                            </template>
                        </v-data-table>
                    </v-card-text>
                </v-card>
            </v-col>
            <v-col xs12 cols="3">
                <v-card
                    min-height="330"
                    max-height="330"
                >
                    <v-card-title class="pjud white--text">
                        Efectividad
                        <v-spacer></v-spacer>
                        <!-- <v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn> -->
                    </v-card-title>
                    <v-card-text class="mt-5">
                        <apexchart type="donut" height="250" :options="donutChartOptionsDonut" :series="donutSeries"></apexchart>
                    </v-card-text>
                </v-card>
            </v-col>             
        </v-row>
        <v-row dense>
             <v-col xs12 cols="4">
                <v-card>
                   <v-card-title class="pjud white--text">
                        Tipo Atenciones
                        <v-spacer></v-spacer>
                        <!-- <v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn> -->
                    </v-card-title>                    
                    <!-- <v-card-subtitle></v-card-subtitle> -->
                    <v-card-text >
                        <apexchart type="donut" height="320" :options="donutTwoChartOptionsDonut" :series="donutTwoSeries"></apexchart>                  
                    </v-card-text>
                </v-card>
            </v-col>              
            <v-col xs12 cols="8">
                <v-card>
                   <v-card-title class="pjud white--text">
                        Solicitudes Vs Atenciones
                        <v-spacer></v-spacer>
                        <!-- <v-btn small outlined color="white" @click="dialogJueces = true">Detalle</v-btn> -->
                    </v-card-title>                    
                    <!-- <v-card-subtitle></v-card-subtitle> -->
                    <v-card-text >
                        <apexchart type="scatter" height="305" :options="scatterChartOptions" :series="scatterSeries"></apexchart>                
                    </v-card-text>
                </v-card>
            </v-col>            
        </v-row>
        <ModalLoading />
    </v-container>
</template>
<script>
import store from 'store'
import { GChart } from 'vue-google-charts'
import countTo from 'vue-count-to'
import { url } from '../../../config/api'
import moment from 'moment-timezone'
import axios from 'axios'
import LayoutConecta from '../../../components/layout/LayoutConecta.vue'
import ModalLoading from '../../../components/elementos/ModalLoading'
import { mapState, mapMutations } from 'vuex'
export default {
    name: 'ConectaGeneral',
    data(){
        return {
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto')
            },
            dateRange: [],
            intervalsDates: [],

            arrEstados: [
                // {
                //     id: 1,
                //     color: 'yellow',
                //     icon: 'mdi-step-forward',
                //     descripcion: 'Pendiente',
                //     cantidad: 0
                // },
                // {
                //     id: 2,
                //     color: 'success',
                //     icon: 'mdi-check',
                //     descripcion: 'Aceptada',
                //     cantidad: 0
                // },
                {
                    id: 1,
                    color: 'red',
                    icon: 'mdi-stop',
                    descripcion: 'Rechazada',
                    cantidad: 0
                },
                {
                    id: 2,
                    color: 'warning',
                    icon: 'mdi-exit-run',
                    descripcion: 'Abandonada',
                    cantidad: 0
                },
                {
                    id: 3,
                    color: 'success',
                    icon: 'mdi-check-all',
                    descripcion: 'Finalizada',
                    cantidad: 0
                }
            ],
            headerEstados: [
                { text: '', value: 'nombre', class : 'primary--text'},
                { text: 'Cantidad',  value: 'resoluciones', class : 'primary--text'},
            ],

            lineSeries: [
                {
                    name: 'Atenciones',
                    data: []
                }
            ],
            lineChartOptions: {
                chart: {
                    id: 'realtimeChart',
                    height: 350,
                    type: 'area'                  
                },
                noData: {
                    text: 'Visualizando'
                },                 
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth'
                },
                tooltip: {
                    x: {
                        format: 'dd/MM/yy HH:mm'
                    },
                },
                xaxis: {
                    type: 'datetime'
                }                                 
            },

            donutSeries: [],
            donutChartOptionsDonut: {
                chart: {
                    id: 'chartId',
                    type: 'donut'
                },
                noData: {
                    text: 'Visualizando'
                },                
                labels: ['Éxito', 'Perdida'],
                plotOptions: {
                    pie: {
                        donut: {
                            labels: {
                                show: true,
                                name: {
                                    show: true,
                                    fontSize: '22px',
                                    fontFamily: 'Rubik',
                                    color: '#dfsda',
                                    offsetY: -10
                                },
                                value: {
                                    show: true,
                                    fontSize: '16px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    color: undefined,
                                    offsetY: 8,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                total: {
                                    show: true,
                                    label: 'Total',
                                    color: '#373d3f',
                                    formatter: function (w) {
                                        return  w.globals.seriesTotals.reduce((a, b) => {
                                        return a + b
                                        }, 0)
                                    }
                                }
                            }
                        }
                    }
                }
            },

            donutTwoSeries: [],
            donutTwoChartOptionsDonut: {
                chart: {
                    id: 'chartIdTwo',
                    height: 320,
                    type: 'donut'
                },
                noData: {
                    text: 'Visualizando'
                },                
                labels: ['Video LLamada', 'Chat','Whatsapp'],
                plotOptions: {
                    pie: {
                        donut: {
                            labels: {
                                show: true,
                                name: {
                                    show: true,
                                    fontSize: '22px',
                                    fontFamily: 'Rubik',
                                    color: '#dfsda',
                                    offsetY: -10
                                },
                                value: {
                                    show: true,
                                    fontSize: '16px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    color: undefined,
                                    offsetY: 8,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                total: {
                                    show: true,
                                    label: 'Total',
                                    color: '#373d3f',
                                    formatter: function (w) {
                                        return  w.globals.seriesTotals.reduce((a, b) => {
                                        return a + b
                                        }, 0)
                                    }
                                }
                            }
                        }
                    }
                }
            },

            scatterSeries: [],
            scatterChartOptions: {
                chart: {
                    id: 'realtimeScatter',
                    height: 320,
                    type: 'scatter',
                    zoom: {
                        enabled: true,
                        type: 'xy'
                    }
                },
                noData: {
                    text: 'Visualizando'
                },
                xaxis: {
                    tickAmount: 10,
                },
                yaxis: {
                    max: 100
                }                       
            }
        }
    },
    created(){
        this.$gtag.event('familia_conecta', { method: 'Google' })
        this.dateRange =  this.$setDateConecta(this.user.ano, this.user.mes, this.user.rango) // Rango de Busqueda de las Atenciones.
        this.intervalsDates = this.$setDateIntervalConecta(this.dateRange[0], this.dateRange[1]) // Intervalo de las fechas de busqueda. 
    },
    mounted() {
        this.getAtenciones(this.user.cod_corte,this.user.cod_tribunal,moment(this.dateRange[0]).format('YYYY-MM-DD'),moment(this.dateRange[1]).format('YYYY-MM-DD'))  
    },    
    methods:{
        ...mapMutations(['setModal']), // Mutations para Visualizar el modal de obteniendo Informacion
        getAtenciones(cod_corte, cod_tribunal, fechaInicio, fechaTermino){
            this.setModal(true) // Aqui Manipulamos el modal
            const req1 = url + '/familia/familiaConectaAtenciones'
            const req2 = url + '/familia/familiaConectaAtencionesTipos'
            const req3 = url + '/familia/familiaConectaAtencionesEstados'
            const req4 = url + '/familia/familiaConectaAtencionesMotivos'

            axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            fechaInicio: fechaInicio,
                            fechaTermino: fechaTermino 
                        }
                    }),
                    axios.get(req2, {
                        params: {
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            fechaInicio: fechaInicio,
                            fechaTermino: fechaTermino 
                        }
                    }),
                    axios.get(req3, {
                        params: {
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            fechaInicio: fechaInicio,
                            fechaTermino: fechaTermino 
                        }
                    }),
                    axios.get(req4, {
                        params: {
                            cod_corte: cod_corte,
                            cod_tribunal: cod_tribunal,
                            fechaInicio: fechaInicio,
                            fechaTermino: fechaTermino 
                        }
                    })                                      

                ]).then(axios.spread((...responses) => {
                    let dataLines  =  responses[0].data
                    let dataDonutTwo  =  responses[1].data
                    let dataTable  =  responses[2].data
                    let dataScatter  =  responses[3].data
                    let lineSeries = []
                    
                    let donutsSeriesTwo = []
                    let radarSeries = []
                    let tableSeries = []
                    let scatterSeriesFinal = []

                    this.intervalsDates.map((obj) => { 
                         
                        let valid =  dataLines.recordset.filter(element => element.fecha === obj)
                        if(valid[0] !== undefined){
                           lineSeries.push({ x:obj, y:valid[0].cantidad })
                        }else{
                           lineSeries.push({ x:obj, y:0})
                        }
                    })
                    
                    dataDonutTwo.recordset.map((obj2) => { 
                        donutsSeriesTwo.push(obj2.cantidad)                      
                    })    

                    this.arrEstados.map((obj3) => { 
                        let valid3 =  dataTable.recordset.filter(element => element.descripcion === obj3.descripcion)
                        if(valid3[0] !== undefined){
                             tableSeries.push({
                                id: obj3.id,
                                color: obj3.color,
                                icon: obj3.icon,
                                descripcion: obj3.descripcion,
                                cantidad: valid3[0].cantidad
                            })
                        }else{
                             tableSeries.push({
                                id: obj3.id,
                                color: obj3.color,
                                icon: obj3.icon,
                                descripcion: obj3.descripcion,
                                cantidad: obj3.cantidad
                            })
                        }
                    }) 
                                    
                    dataScatter.recordset.map((obj4) => { 
                        scatterSeriesFinal.push(
                            {
                                name: obj4.descripcion,
                                data: [
                                    [ 
                                      obj4.total,
                                      obj4.porcentaje
                                    ]
                                ]
                            }

                        )                      
                    })
                                        
                    this.donutSeries = [tableSeries[2].cantidad, tableSeries[0].cantidad + tableSeries[1].cantidad]
                    this.donutTwoSeries = donutsSeriesTwo
                    this.arrEstados = tableSeries
                    this.scatterSeries = scatterSeriesFinal

                    ApexCharts.exec('realtimeChart', 'updateSeries', [{
                        data: lineSeries
                    }], false, true);                    
                  
                    ApexCharts.exec('realtimeRadar', 'updateSeries', [{
                        data: radarSeries
                    }], false, true);  
                    
                    this.setModal(false) // Cerrando Modal
                })).catch(errors => {
                    this.setModal(false) // Cerrando Modal
                    console.log(errors)
            })
        },     
        update(dateRange) {
            this.intervalsDates = this.$setDateIntervalConecta(dateRange[0], dateRange[1]) // Intervalo de las fechas de busqueda.
            this.getAtenciones(this.user.cod_corte,this.user.cod_tribunal,moment(dateRange[0]).format('YYYY-MM-DD'),moment(dateRange[1]).format('YYYY-MM-DD')) 
        }       
    },
    components: {
        GChart,
        countTo,
        LayoutConecta,
        ModalLoading
    }    
}
</script>