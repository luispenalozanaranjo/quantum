<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">                                 
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    @click="addUser()"
                                >
                                    <v-icon >mdi-plus</v-icon>
                                </v-btn>
                            </template>
                            <span>Añadir</span>
                        </v-tooltip>
                        <v-spacer></v-spacer>
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="detUsuarios"
                                    :columns="excelHeadUsuarios"
                                    :filename="'Usuarios'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                        :disabled="disExport"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>
                        </v-tooltip>
                    </v-toolbar>
                    <v-row dense>
                        <v-col cols="12" xs12 class="pr-4 pl-4">
                            <v-text-field
                                v-model="search"
                                append-icon=""
                                label="Buscar"
                                single-line
                                hide-details
                            ></v-text-field>
                            <v-data-table 
                                :headers="headers"
                                :items="items"
                                :search="search"
                                :page.sync="causasPage"
                                :items-per-page="causasItemsPerPage"
                                hide-default-footer
                                @page-count="causasPageCount = $event" 
                                :loading="loading"
                                loading-text="Cargando Información... Espere por Favor"                                                                                   
                                class="mt-4"
                            >
                                    <template v-slot:[`item.nombre_completo`]="{ item }">
                                        <td class="text-left">{{ item.nombre_completo }}</td>     
                                    </template>
                                    <template v-slot:[`item.tribunal`]="{ item }">
                                        <td class="text-left">{{ item.tribunal }}</td>     
                                    </template>                                    
                                    <template v-slot:[`item.roles`]="{ item }">
                                        <v-btn
                                            class="mx-2"
                                            outlined
                                            color="blue"
                                            small
                                            @click="viewRoles(item.roles)"
                                        >
                                            <v-icon>
                                                mdi-table-eye
                                            </v-icon>
                                        </v-btn>          
                                    </template>
                                    <template v-slot:[`item.edit`]="{ item }">
                                        <v-btn
                                            class="mx-2"
                                            outlined
                                            color="green"
                                            small
                                            @click="addPermit(item)"
                                        >
                                            <v-icon>
                                                mdi-pencil
                                            </v-icon>
                                        </v-btn>        
                                    </template>                                      
                            </v-data-table> 
                            <v-dialog max-width="35%" v-model="dialog">
                                <v-card>
                                    <v-card-title class="pjud white--text">
                                    Roles asignados a este permiso:
                                    </v-card-title>
                                    <v-card-text>
                                        <v-list-item v-for="(item) in roles" :key="item._id">
                                            <v-list-item-content>
                                                <v-list-item-title>{{ item.descripcion }}
                                                    <v-divider ></v-divider>
                                                </v-list-item-title>
                                            </v-list-item-content>
                                        </v-list-item>
                                    </v-card-text>
                                    <v-card-actions>
                                    <v-btn
                                        color="green darken-1"
                                        text
                                        @click="dialog = false"
                                    >
                                        Cerrar
                                    </v-btn>
                                    </v-card-actions>
                                </v-card>                                
                            </v-dialog>
                            <v-dialog max-width="70%" v-model="dialogAdd">                               
                                <v-card>
                                    <v-card-title 
                                        class="pjud white--text"
                                    >
                                    Creación de Usuarios
                                    </v-card-title>
                                    <v-card-text class="mt-4">
                                        <v-row dense v-if="show">
                                            <v-col	xs12 cols="12"> 
                                                <v-alert
                                                dense
                                                :type="alertType"
                                                class="mt-5"
                                                >
                                                {{ message }}
                                                </v-alert>						
                                            </v-col>								
                                        </v-row>                                         
                                        <v-form v-model="valid">
											<v-text-field
												v-model="nombres"
												:rules="nombresRules"
												name="nombre_completo"
												label="Nombres"
												type="text"
												outlined
                                                dense
											></v-text-field>
											<v-text-field
												v-model="usuario"
												:rules="[usuarioRules.required, usuarioRules.min, usuarioRules.noSpace]"
												name="usuario"
												label="Usuario"
												type="text"
												outlined
                                                dense
											></v-text-field>
											<v-text-field
												v-model="contrasena"
                                                :rules="[contrasenaRules.required, contrasenaRules.min, contrasenaRules.noSpace]"
												name="contrasena"
												label="Contraseña"
												type="text"
												outlined
                                                dense
											></v-text-field>
											<v-text-field
												v-model="email"
												:rules="emailRules"
												name="email"
												label="Email"
												type="text"
												outlined
                                                dense
											></v-text-field>
											<v-text-field
												v-model="rut"
												:rules="rutRules"
												name="rut"
												label="RUT"
												type="text"
												outlined
                                                dense
											></v-text-field>                                                                                        
                                            <v-autocomplete
                                                v-model="roleAdd"
                                                :items="rolesAdd"
                                                outlined
                                                dense
                                                chips
                                                small-chips
                                                label="Roles"
                                                multiple
                                            ></v-autocomplete>
                                            <v-autocomplete
                                                v-model="tribunalAdd"
                                                :items="tribunalesAdd"
                                                outlined
                                                dense
                                                chips
                                                small-chips
                                                label="Tribunales"
                                            ></v-autocomplete>                                           
											<v-btn
												:disabled="!valid"
												block
												color="primary"
												@click="submit"
											>
												Guardar
											</v-btn>                                                                                                                                   
                                        </v-form>
                                    <br/>
                                    <v-btn
                                        class="pjud white--text"
                                        block
                                        @click="dialogAdd = false"
                                    >
                                        Cerrar
                                    </v-btn>
                                    </v-card-text>

                                </v-card>
                            </v-dialog>        
                            <!-- INI-EDITAR      -->
                            <v-dialog max-width="50%" v-model="dialogEdit">                               
                                <v-card>
                                    <v-card-title 
                                        class="pjud white--text"
                                    >
                                    Editar Usuario
                                    </v-card-title>
                                    <v-card-text class="mt-4">
                                        <v-row dense v-if="show">
                                            <v-col	xs12 cols="12">
                                                <v-alert
                                                dense
                                                :type="alertType"
                                                class="mt-5"
                                                >
                                                {{ message }}
                                                </v-alert>
                                            </v-col>
                                        </v-row>
                                        <v-form v-model="valid">
											<v-text-field
												v-model="userEdit.nombre_completo"
												:rules="nombresRules"
												name="nombre_completo_edit"
												label="Nombres"
												type="text"
												outlined
                                                dense
											></v-text-field>
											<v-text-field
												v-model="userEdit.email"
												:rules="emailRules"
												name="email"
												label="Email"
												type="text"
												outlined
                                                dense
											></v-text-field>
											<v-text-field
												v-model="userEdit.rut"
												:rules="rutRules"
												name="rut"
												label="RUT"
												type="text"
												outlined
                                                dense
											></v-text-field>                                                                                        
                                            <v-autocomplete
                                                v-model="userEdit.rolesSelected"
                                                :items="rolesAdd"
                                                outlined
                                                dense
                                                chips
                                                small-chips
                                                label="Roles"
                                                multiple
                                            ></v-autocomplete>
                                            <v-autocomplete
                                                v-model="userEdit.tribunal"
                                                :items="tribunalesAdd"
                                                outlined
                                                dense
                                                chips
                                                small-chips
                                                label="Tribunales"
                                            ></v-autocomplete>
                                            <v-switch
                                                v-model="userEdit.estado.activo"
                                                label="¿Activo?"
                                            ></v-switch>
											<v-btn
												:disabled="!valid"
												block
												color="primary"
												@click="editUser()"
											>
												Guardar
											</v-btn>
                                        </v-form>
                                    <br/>
                                    <v-btn
                                        class="pjud white--text"
                                        block
                                        @click="dialogEdit = false"
                                    >
                                        Cerrar
                                    </v-btn>
                                    </v-card-text>

                                </v-card>
                            </v-dialog>            
                            <!-- FIN-EDITAR      -->       
                        </v-col>
                        <v-col cols="12" xs12>
                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                        </v-col>
                    </v-row>                                     
                </v-sheet>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../../config/apiConfig'
import store from 'store'
export default {
	name: 'Usuarios',
	data () {
		return {
        dialog: false,
        dialogView: false,
        dialogAdd: false,
        dialogEdit: false,
        dialogShow: false,        
        alertType: "info",
        userLocked: false,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        search: '',
        headers: [
            { text: 'NOMBRES', align: 'center', value: 'nombre_completo', class : 'pjud white--text' },
            { text: 'EMAIL', align: 'center', value: 'email', class : 'pjud white--text' },
            { text: 'USUARIOS', align: 'center', value: 'usuario', class : 'pjud white--text' },
            { text: 'RUT', align: 'center', value: 'rut', class : 'pjud white--text' },
            { text: 'TRIBUNAL', align: 'center', value: 'tribunal', class : 'pjud white--text' },
            { text: 'ROLES', align: 'center', value: 'roles', class : 'pjud white--text' },
            { text: 'EDITAR', align: 'center', value: 'edit', class : 'pjud white--text' }
        ],
        items: [],
        detUsuarios: [],
        disExport: true,
        excelHeadUsuarios : [
            {
                label: "Nombre",
                field: "nombre_completo",
            },
            {
                label: "Email",
                field: "email",
            },            
            {
                label: "Usuario",
                field: "usuario",
            },
            {
                label: "RUT",
                field: "rut",
            },
            {
                label: "Tribunal",
                field: "tribunal",
            },
        ],        
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10,
        loading: true,
        roles: [],
        valid: true, //  Variables del Formulario.
        userEdit: {
            nombre_completo: '',
            email: '',
            rut: '',
            estado: {
                activo: false,
                nro_intentos: 0,
                glosa: ''
            },
            roles: [],
            rolesSelected: [],
            tribunal: '',
        },
        nombres: '',
        nombresRules: [
            v => !!v || 'Nombre Completo Requerido',
        ],
        usuario: '',
        usuarioRules: {
            required: value => !!value || 'Usuario Requerido.',
            min: v => v.length == 8 || 'El largo debe ser 8 caracteres.',
            noSpace: v => (v || '').indexOf(' ') < 0 || 'Espacios en blanco no permitidos.'
        },
        contrasena: '',
        contrasenaRules: {
            required: value => !!value || 'Contraseña Requerida.',
            min: v => v.length == 8 || 'El largo debe ser 8 caracteres.',
            noSpace: v => (v || '').indexOf(' ') < 0 || 'Espacios en blanco no permitidos.'
        },
        email: '',
        emailRules: [
            v => !!v || 'El Email es obligatorio.',
        ],
        rut: '',
        rutRules: [
            v => !!v || 'El N° de documento es obligatorio.'
        ],
        roleAdd: [],
        rolesAdd: [],
        tribunalAdd: [],
        tribunalesAdd: [],
        show: false,
        message: ''
		}
	},
    created () {
        try {
            this.$gtag.event('usuarios', { method: 'Google' })
            this.getData();
        } catch (error) {
            console.log(error.message);
        }        
    },    
    methods: {
        async getData(){
            try {
                this.loading = true
                let response  = await this.getUsers()
                let responseTwo = await this.getRoles()
                let responseTree = await this.getTribunales()
                let userList = []
                let rolesList = []
                let tribunalesList = []
                this.detUsuarios = []

                response.map((object) => {
                        
                    userList =  response;

                    this.detUsuarios.push({
                        nombre_completo: object.nombre_completo,
                        email: object.email,
                        usuario: object.usuario,
                        rut: object.rut,
                        tribunal: (object.cod_tribunal_origen) ? object.cod_tribunal_origen.descripcion : '' 
                    });
                });

                responseTwo.map((object) => {
                    rolesList.push(object.descripcion)
                });

                responseTree.map((object) => {
                    tribunalesList.push(object.descripcion)
                }); 

                this.items = userList
                this.rolesAdd = rolesList
                this.tribunalesAdd = tribunalesList
                this.loading = false
                this.disExport = false

            } catch (error) {
                console.log(error.message);
            }        
        },
		async validate () {
		    this.$refs.form.validate()
        },
		async submit () {
			return new Promise(async (resolve, reject) => {
                try{
                    let response = await axios.post(
                        url+'/user/createUser', {
                        params: {
                            nombre_completo: this.nombres,
                            usuario: this.usuario,
                            contrasena: this.contrasena,
                            email: this.email,
                            rut: this.rut,
                            roles: this.roleAdd,
                            tribunal: this.tribunalAdd
                        }
                    })

                    if (response.status != 200) {
                        this.message = response.data.message
                        this.alertType = "warning"
                    }else{
                        this.message = 'Usuario creado exitosamente.'
                        this.alertType = "info"
                    }

                    this.show = true
                    setTimeout(() => this.show = false, 5000);

                    return resolve(response.data.message)
                } catch (err) {
                    reject(err)
                }
			});
		},        
        async getUsers () {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/user/getUser',
                        headers: {}
                    })
                    resolve(response.data.users)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getTribunales () {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/tribunal/getTribunales',
                        headers: {}
                    })
                    resolve(response.data.tribunales)
                } catch (err) {
                    reject(err)
                }
            })
        },        
        async getRoles () {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/role/getRoles',
                        headers: {}
                    })
                    resolve(response.data.roles)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async viewRoles (roles) {
            this.roles  = roles
            this.dialog = !this.dialog
        },
        async addUser (_id = null) {
            this.dialogAdd = !this.dialogAdd
        },
        addPermit(userData){
            try {
                let rolesArray = [];
                this.userEdit = userData;

                this.userEdit.roles.forEach(rol => {
                    rolesArray.push(rol.descripcion);
                });

                this.userEdit.rolesSelected = rolesArray;
                this.userEdit.tribunal = this.userEdit.cod_tribunal_origen.descripcion;

                this.dialogEdit = true; 

            } catch (error) {
                console.log(error.message);
            }

        },
        async editUser () {
            try {
                const urlRequest = url + '/user/' + this.userEdit._id

                if(this.userEdit.estado.activo){
                    this.userEdit.estado.glosa = 'activado mediante el mantenedor';
                    this.userEdit.estado.nro_intentos = 0;
                }else{
                    this.userEdit.estado.glosa = 'bloqueado por mantenedor';
                    this.userEdit.estado.nro_intentos = 0;
                }
                
                const response = await axios.patch(
                        urlRequest, {
                        params: {
                            email: this.userEdit.email,
                            rut: this.userEdit.rut,
                            nombre_completo: this.userEdit.nombre_completo,
                            roles: this.userEdit.rolesSelected,
                            tribunal: this.userEdit.tribunal,
                            estado: this.userEdit.estado
                        }
                });

                if (response.status != 200) {
                    this.message = response.data.observacion;
                    this.alertType = "warning";
                }else{
                    this.message = response.data.observacion;
                    this.alertType = "info";
                    this.getData();
                }

                this.show = true
                setTimeout(() => this.show = false, 5000);


            } catch (error) {
                console.log(error.message);
            }
		},     
    }
}
</script>