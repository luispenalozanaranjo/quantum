<template>
    <v-container>
        <v-row justify="center">
            <v-col md="5">
                <v-form ref="form" v-model="formValid">
                    <v-card>
                        <v-card-title>
                            Cambiar contraseña de acceso
                        </v-card-title>
                        <v-card-text>
                            <v-row>
                                <v-col>
                                    <v-text-field
                                        v-model="oldPassword"
                                        :append-icon="showOldPass ? 'mdi-eye' : 'mdi-eye-off'"
                                        :rules="[rules.required, rules.noSpace, rules.noSimbol]"
                                        :type="showOldPass ? 'text' : 'password'"
                                        name="txtOldPassword"
                                        label="Clave actual"
                                        hint="8 caracteres obligatorios"
                                        counter
                                        @click:append="showOldPass = !showOldPass"
                                        tabindex="1"
                                        >
                                    </v-text-field>
                                </v-col>
                            </v-row>
                            <v-row>
                                <v-col>
                                    <v-text-field
                                        v-model="newPassword"
                                        :append-icon="showNewPass ? 'mdi-eye' : 'mdi-eye-off'"
                                        :rules="[rules.required, rules.min, rules.noSpace, rules.noSimbol]"
                                        :type="showNewPass ? 'text' : 'password'"
                                        name="txtNewPassword"
                                        label="Clave nueva"
                                        hint="8 caracteres obligatorios"
                                        counter
                                        @click:append="showNewPass = !showNewPass"
                                        tabindex="2"
                                        >
                                    </v-text-field>
                                </v-col>
                            </v-row>
                            <v-row>
                                <v-col>
                                    <v-text-field
                                        v-model="reNewPassword"
                                        :append-icon="showReNewPass ? 'mdi-eye' : 'mdi-eye-off'"
                                        :rules="[rules.required, rules.min, rules.comparePassword, rules.noSpace]"
                                        :type="showReNewPass ? 'text' : 'password'"
                                        name="txtReNewPassword"
                                        label="Reingrese clave nueva"
                                        hint="8 caracteres minimos"
                                        counter
                                        @click:append="showReNewPass = !showReNewPass"
                                        tabindex="3"
                                        >
                                    </v-text-field>
                                </v-col>
                            </v-row>
                        </v-card-text>
                        <v-card-actions>
                            <v-btn
                                color="error"
                                @click="cleanForm()"
                                tabindex="5"
                            >
                                Limpiar
                            </v-btn>
                            <v-spacer></v-spacer>
                            <v-btn
                                color="success"
                                @click="changePassword()"
                                tabindex="4"
                            >
                                Cambiar Clave
                            </v-btn>
                        </v-card-actions>
                        <v-row dense v-if="showAlert">
						    <v-col	xs12 cols="12"> 
							    <v-alert
									dense
                                    text
									:type="typeAlert"
									class="mt-5"
								>
									{{ message }}
								</v-alert>					
							</v-col>								
						</v-row>
                    </v-card>
                </v-form>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import ModalLoading from '../components/ModalLoading'
import store from 'store'
import AuthService from '@/services/auth'

export default {
    name: 'Folder',
    data() {
        return {
            valid: true,        
            usuario: {
                usuario: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
            },
            dniRules: [
                v => !!v || 'El N° de documento es obligatorio',
                v => this.validateDni(v) || 'Rut Invalido',
            ],                   
            message: '',
            showAlert: false, 
            typeAlert: 'success',
            oldPassword: '',
            newPassword: '',
            reNewPassword: '',
            showOldPass : false,
            showNewPass: false,
            showReNewPass: false,
            formValid: false,
            rules: {
                required: value => !!value || 'Obligatorio.',
                min: v => (v.length == 8) || '8 caracteres obligatorios',
                comparePassword: v => this.comparePassword(v) || 'Las contraseñas ingresadas son distintas',
                noSpace: v => (v || '').indexOf(' ') < 0 || 'Espacios en blanco no permitidos',
                noSimbol:  v => this.noSimbol(v) || 'Las contraseñas deben contener unicamente letras y numeros',
            },
        };
    },
    created(){
        try {
            this.$gtag.event('CambiarContrasena', { method: 'Google' });
        } catch (error) {
            console.log(error.message);
        }
    },
    methods: {
        ...mapMutations(['setModal']), // Mutations.
        async changePassword(){
            try {

                console.log(this.formValid);
                if(this.formValid){

                    const response = await AuthService.changePassword(this.usuario.usuario, this.newPassword);

                    this.showAlert = true;

                    if(response.status != 200){
                        this.message = 'Error: No hemos logrado cambiar la contraseña.'
                        this.typeAlert = 'error'
                    }else {
                        this.message = 'Contraseña modificada correctamente.'
                        this.typeAlert = 'success'
                    }
    
                }else {
                    this.$refs.form.validate()
                }


            } catch (error) {
                console.log(error);
            }
        },
        cleanForm(){
            try {
                this.$refs.form.reset();
                this.showAlert = false;
            } catch (error) {
                console.log(error)
            }
        },
        comparePassword(){
            try {

                if(this.newPassword == this.reNewPassword) return true;
                else return false;

            } catch (error) {
                console.log(error);
                return false;
            }
        },
        noSimbol(v){
            try {
                
                const regexp= /^[^\W_]+$/

                if(regexp.test(v)) return true;
                else return false;

            } catch (error) {
                console.log(error);
                return false;
            }
        }
    },        
    components: {
        ModalLoading
    }    
}
</script>
