<template>
    <v-container fluid>
        <div>
            <iframe  class="responsive-iframe" :src="frame.url"></iframe>
        </div>
    </v-container>
    
</template>
<style scoped>
.responsive-iframe {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0px;
  right: 0;
  width: 100%;
  height: 100%;
  border: 0;
}

#cl_boton {
    z-index: 9999; 
    position: absolute; 
    top: 5.2%;
    right: 5%;
}


</style>
<script>
import store from 'store'

export default {
    name: "CartillaVisitaMinTop",
    data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            cod_tribunal : store.get('cod_tribunal'),
            ano : store.get('ano'),
            mes : store.get('mes'),
            perfil_corte: store.get('perfil_corte'),            
        },
        frame:{
            url: "",
        },
    }),
    created(){
        try {
            this.$gtag.event('cartilla_visita_ministro_top', { method: 'Google' })
            
            if (this.usuario.perfil_corte === 1){
                this.frame.url = "https://reportes.pjud.cl/Reports/powerbi/DDI/00_Reportes_publicos_internos/01_Subdepartamento%20de%20Estad%C3%ADsticas/03_Cartilla%20TOP/corte%20cartilla%20top?filter=kode%2Fentradaco%20eq%20"+ this.usuario.cod_corte + "&rs:Embed=true"
            }else{
                this.frame.url = "https://reportes.pjud.cl/Reports/powerbi/DDI/00_Reportes_publicos_internos/01_Subdepartamento%20de%20Estad%C3%ADsticas/03_Cartilla%20TOP/Cartilla%20TOP?filter=kode%2FEntrada%20eq%20"+ this.usuario.cod_tribunal + "&rs:Embed=true"
            }

            
            
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {}
}
</script>
