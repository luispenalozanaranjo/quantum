<template>
	<v-layout
		id="parallax-pjud"
		class="back"
	>
		<v-container fill-height>
			<v-row justify="center">
				<v-col>
					<v-form 
						v-model="valid"
						lazy-validation
						id="loginform" 
						action="Home">
						<v-row
							align="center"
							justify="center"
							>
							<v-col
								class="text-center"
								xs12
								cols="4"
							>
								<v-card class="elevation-12" color="rgb(0, 0, 0, 0.35)">
									<v-card-title class="white--text">
										Recuperar Contraseña
										<v-spacer></v-spacer>
										<v-icon size="60" color="rgb(89, 86, 85, 0.35)">mdi-lock</v-icon>
									</v-card-title>
									<v-card-subtitle class="text-left white--text">
										Ingrese su correo institucional de la cuenta
									</v-card-subtitle>
									<v-card-text >
										<v-form>
											<v-text-field
												v-model="email"
												:rules="emailRules"
												name="email"
												label="mail@pjud.cl"
												type="text"
												solo
											></v-text-field>		
											<v-btn
												:disabled="!valid"
												block
												color="primary"
												@click="submit"
											>
												Enviar
											</v-btn>
											<v-btn
												block
												color="success"
												@click="goLogin"
												class="mt-2"
											>
												Volver
											</v-btn>
											<v-row dense v-if="show">
												<v-col	xs12 cols="12"> 
													<v-alert
													dense
													type="error"
													class="mt-5"
													>
													{{ message }}
													</v-alert>						
												</v-col>								
											</v-row>
											<v-row dense v-if="showSuccess">
												<v-col	xs12 cols="12"> 
													<v-alert
													dense
													type="success"
													class="mt-5"
													>
													{{ message }}
													</v-alert>						
												</v-col>								
											</v-row>
										</v-form>
									</v-card-text>
								</v-card>							
							</v-col>
						</v-row>
					</v-form>
				</v-col>
			</v-row>
		</v-container>
	</v-layout>
</template>

<script>
import AuthService from '@/services/auth'
// import store from 'store'
export default {
	name: 'RecuperarContrasena',
	data () {
		return {
			valid: true,
			email: '',
			emailRules: [
				v => !!v || 'Email Requerido',
			],				
			show: false,
			showSuccess: false,
			message: ''
		}
	},
	created(){
		try {
			this.$gtag.event('RecuperarContrasena', { method: 'Google' });
		} catch (error) {
			console.log(error.message);
		}
	},
	methods: {
		validate () {
			this.$refs.form.validate()
		},		
		submit: async function () {
			try {

				const response = await AuthService.recuperarConstrasena(this.email);

				if (response.status != 200) {
					this.message = response.data.message;
					this.showSuccess = false;
					this.show = true;
				}else {
					this.show = false;
					this.showSuccess = true;
					this.message = response.data.resultado;
				}

			} catch (error) {
				this.message = error;
				this.showSuccess = false;
				this.show = true;
			}

		},
		goLogin: function () {
			try {
				this.$router.push('Login');

			} catch (error) {
				this.message = error;
				this.showSuccess = false;
				this.show = true;
			}

		}
	},	
	mounted() {
		document.getElementById('parallax-pjud').style.height = '100%'
		document.getElementById('parallax-pjud').style.widht = '100%'
	}    
}
</script>
<style>
html {
    overflow:   scroll;
    scrollbar-width: none;
}
html::-webkit-scrollbar {
      display: none;
      width: 0px;
      background: transparent;
}

.back {
  background-image: url("../../public/img/Corte_Suprema.jpg");
  background-size: cover;
}

</style>