<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-card>
                    <v-card-title>
                        <v-toolbar flat class="pjud">
                            <v-toolbar-title >
                                <h2 class="white--text">{{corte_descripcion}}</h2>
                            </v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                        </v-toolbar>
                    </v-card-title>
                    <v-card-subtitle>
                        <FiltrosCompetencias/>
                    </v-card-subtitle>
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>  
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="cortes"
                                    :columns="excelHeadDetalles"
                                    :filename="'Resumen Cortes'"
                                    :sheetname="'Hoja1'"
                                >  
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                            </template>
                            <span>Exportar Excel</span>                                                
                        </v-tooltip>                        
                    </v-toolbar>
                    <v-card-text>
                        <v-simple-table
                            dense
                        >
                            <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            CORTE
                                        </th>
                                        <th class="white--text text-center">
                                            INGRESOS
                                        </th>
                                        <th class="white--text text-center">
                                            FALLOS
                                        </th>
                                        <!-- <th class="white--text text-center">
                                            RESOLUCIONES
                                        </th>                                         -->
                                        <th class="white--text text-center">
                                            ESCRITOS
                                        </th>
                                        <th class="white--text text-center">
                                            INVENTARIOS
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in cortes"
                                        :key="item.cod_corte"
                                        >
                                        <td>
                                            {{item.corte_descripcion}}
                                            <!-- <router-link style="text-decoration: none;" :to="{ name: 'ApelacionesTablero' }"> 
                                                {{item.corte_descripcion}}
                                            </router-link>                                             -->
                                        </td>
                                        <!-- <{{item.enero}}    -->
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('ApelacionesRecursos', item.cod_corte)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.recursos" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('ApelacionesFallos', item.cod_corte)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.fallos" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                            
                                        </td>
                                        <!-- <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('ApelacionesResoluciones', item.cod_corte)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.resoluciones" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                            
                                        </td>                                           -->
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('ApelacionesEscritos', item.cod_corte)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.escritos" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                            
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span style="text-decoration: none;" v-on:click="goDetallesIndicadores('ApelacionesInventarios', item.cod_corte)"> 
                                                    <countTo class="count" :startVal="0" :endVal="item.inventarios" separator="." :duration="1000"></countTo>
                                                </span>
                                            </a>                                             
                                        </td>                                                                                                                                                          
                                    </tr>
                                </tbody>
                            </template>
                        </v-simple-table>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import { urlApi } from '../../../config/api'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias.vue'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
export default {
	name: 'FamiliaIndicadores',   
	data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte')
        },
        cod_corte: 0,
        corte_descripcion: '',
        cod_tribunal: 0,
        cortes:[],
        excelHeadDetalles : [
            {
                label: "CORTE",
                field: "corte_descripcion",
            },
            {
                label: "INGRESOS",
                field: "recursos",
            },
            {
                label: 'FALLOS',
                field: 'fallos',
            },
            { 
                label: 'ESCRITOS',
                field: 'escritos',
            },
            { 
                label: 'INVENTARIOS',
                field: 'inventarios',
            }
        ]    
	}),
    watch: {
        '$store.state.fechas'() {
            this.getAll()
        }
    },      
    methods: {
        ...mapState(['fechas']), // Valores Guardados
        async getAll(){
            this.cod_corte = this.$route.params.cod_corte
            let objects  = []
            let datos    = [] // Arreglo para obtener los datos de los tribunales. 
            let response =  await this.getCortes(this.cod_corte)

            response.cortes.map(function (object){
                let position = response.cortes.findIndex(element => element.cod_corte === parseInt(this.cod_corte))
                this.corte_descripcion = response.cortes[position].descripcion
                objects.push(object.cod_corte) // Recorro el objeto para obtener todos los tribunales asociados al usuario.
            }, this)

            let responseTwo = await this.getResumenesCortes(
                this.cod_corte,
                this.fechas().anoInicio,
                this.fechas().mesInicio,
                this.fechas().anoFin,
                this.fechas().mesFin
            ) // Solicito toda los indicadores de los corte.

            if(responseTwo.recordset.length > 1)
                responseTwo.recordset.pop()
            
            responseTwo.recordset.map(function (objects){ // Recorro el objeto para obtener todos los indicadores asociados a los corte.
                let position = response.cortes.findIndex(element => element.cod_corte === objects.cod_corte)
                datos.push({ 
                    cod_corte: objects.cod_corte,
                    corte_descripcion: response.cortes[position].descripcion,
                    recursos: objects.recursos,
                    fallos: objects.fallos,
                    resoluciones: objects.resoluciones,
                    escritos: objects.escritos,
                    inventarios: objects.inventarios                                                                  
                })
            })

            this.cortes = datos // Lleno el arreglo de Corte con los indicadores

        },
        async getCortes(cod_corte) {

            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/corte/getCorte',
                        headers: {},
                        /* params:{
                            cod_corte: cod_corte
                        } */
                    })
                    resolve(response.data)
                } catch (err) {
                    reject(err)
                }
            })
        },
        async getResumenesCortes (cod_corte, anoInicio, mesInicio, anoFin, mesFin) { // Faltan los parametros de ano, mes, tipo de busqueda y exhortos.
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/apelaciones/getResumenesCortes',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            anoInicio: anoInicio,
                            mesInicio: mesInicio,
                            anoFin: anoFin,
                            mesFin: mesFin
                        }
                    })
                    resolve(response.data.resumenesCortes)
                } catch (err) {
                    reject(err)
                }
            })
        },
        goDetallesIndicadores(paramRoute, paramCod_corte){
            try {

                store.set('cod_corte', paramCod_corte);
                this.$router.push({ name: paramRoute });

            } catch (error) {
                console.log(error.message);
            }
        }        
    },   
    components:{
        FiltrosCompetencias,
        countTo
    }
}
</script>     