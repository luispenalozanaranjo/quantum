<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" x12>
                <v-sheet
                    outlined 
                    class="mx-auto"
                >
                    <v-toolbar flat class="pjud" dense>
                        <v-tooltip top>  
                            <template v-slot:activator="{ on, attrs }">
                                <vue-excel-xlsx
                                    :data="detalleInventario"
                                    :columns="excelHeadDetalles"
                                    :filename="'Inventario'"
                                    :sheetname="'Hoja1'"
                                    v-if="usuario.cod_corte != 0"
                                >
                                    <v-btn
                                        class="mx-2"
                                        outlined
                                        color="white"
                                        v-bind="attrs"
                                        v-on="on"
                                    >
                                        <v-icon >mdi-microsoft-excel</v-icon>  
                                    </v-btn>
                                </vue-excel-xlsx>
                                <v-btn
                                    class="mx-2"
                                    outlined
                                    color="white"
                                    v-bind="attrs"
                                    v-on="on"
                                    v-if="usuario.cod_corte == 0"
                                    @click=" excelDownload();"
                                >
                                <v-icon v-if="!isLoading">mdi-microsoft-excel</v-icon>
                                <v-progress-circular v-else :size="24" :width="2" color="white" indeterminate></v-progress-circular>
                                </v-btn>
                            </template>
                            <span>Exportar Excel</span>                                                
                        </v-tooltip>                        
                    </v-toolbar>
                    <v-text-field
                        v-model="search"
                        append-icon=""
                        label="Buscar"
                        single-line
                        hide-details
                        class="pr-7 pl-7"
                    ></v-text-field>
                    <v-data-table 
                        :headers="headers"
                        :items="detalleInventario"
                        :search="search"
                        :page.sync="causasPage"
                        :items-per-page="causasItemsPerPage"
                        hide-default-footer
                        @page-count="causasPageCount = $event" 
                        :loading="loading"
                        loading-text="Cargando Información... Espere por Favor"                                                                                   
                        dense
                        class="pr-7 pl-7">
                    </v-data-table>
                    <v-row justify="center"> 
                        <v-col cols="6">
                            <v-pagination v-model="causasPage" :length="causasPageCount"></v-pagination>
                        </v-col>
                    </v-row>                                      
                </v-sheet>
            </v-col> 
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { urlApi } from '../../../config/api'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
export default {
	name: 'ApelacionesInventarios',
	data: () => ({
        isLoading: false,
        tab: null,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        excelHead : [
            {
                label: "Tipo Libro",
                field:  "name",
            },
            {
            
                label: "Cantidad",
                field:  "value",
            }                                                                                                                                                                             
        ], // Inicio de variables para el dataTables.
        detalleInventario: [],
        excelHeadDetalles : [
            {
                label: "COD CORTE",
                field: "cod_corte",
            },
            {
                label: "CORTE",
                field: "gls_corte",
            },
            {
                label: 'ROL',
                field: 'rol_recurso_ape',
            },
            { 
                label: 'AÑO',
                field: 'era_recurso_ape',
            },
            { 
                label: 'TIPO LIBRO',
                field: 'gls_libro',
            },
            { 
                label: 'COD RECURSO',
                field: 'tip_recurso_ape',
            },
            { 
                label: 'TIPO RECURSO',
                field: 'gls_recurso',
            },
            { 
                label: 'CARATULADO',
                field: 'gls_caratulado',
            },
            { 
                label: 'COMPETENCIA',
                field: 'gls_competencia',
            },
            { 
                label: 'FECHA RECURSO',
                field: 'fec_recurso',
            },
            { 
                label: 'ESTADO PROCESAL',
                field: 'gls_estprocesal_ape',
            },
            { 
                label: 'TIPO INGRESO',
                field: 'gls_ing_recurso',
            },
            { 
                label: 'EN TABLA',
                field: 'en_tabla',
            },
            { 
                label: 'UBICACIÓN',
                field: 'gls_ubicacion',
            },
            { 
                label: 'COD. TRIBUNAL',
                field: 'cod_tribunal',
            },
            { 
                label: 'TRIBUNAL',
                field: 'gls_tribunal',
            },
            { 
                label: 'TIPO CAUSA',
                field: 'tip_causa',
            },
            { 
                label: 'ROL CAUSA',
                field: 'rol_causa',
            },
            { 
                label: 'ERA CAUSA',
                field: 'era_causa',
            },
            { 
                label: 'COD MATERIA',
                field: 'cod_materia',
            },
            { 
                label: 'MATERIA',
                field: 'gls_materia',
            },

        ],        
        search: '',
        headers: [
            { text: 'COD CORTE', align: 'center', value: 'cod_corte', class : 'pjud white--text' },
            { text: 'CORTE', align: 'center', value: 'gls_corte', class : 'pjud white--text' },
            { text: 'ROL', align: 'center', value: 'rol_recurso_ape', class : 'pjud white--text' },
            { text: 'AÑO', align: 'center', value: 'era_recurso_ape', class : 'pjud white--text' },
            { text: 'TIPO LIBRO', align: 'center', value: 'gls_libro', class : 'pjud white--text' },
            { text: 'COD RECURSO', align: 'center', value: 'tip_recurso_ape', class : 'pjud white--text' },
            { text: 'TIPO RECURSO', align: 'center', value: 'gls_recurso', class : 'pjud white--text' },
            { text: 'CARATULADO', align    : 'center', value: 'gls_caratulado', class : 'pjud white--text' },
            { text: 'COMPETENCIA', align    : 'center', value: 'gls_competencia', class : 'pjud white--text' },
            { text: 'FECHA RECURSO', align: 'center', value: 'fec_recurso', class : 'pjud white--text' },
            { text: 'ESTADO PROCESAL', align: 'center', value: 'gls_estprocesal_ape', class : 'pjud white--text' },
            { text: 'TIPO INGRESO', align: 'center', value: 'gls_ing_recurso', class : 'pjud white--text' },
            { text: 'EN TABLA', align: 'center', value: 'en_tabla', class : 'pjud white--text' }  ,
            { text: 'UBICACIÓN', align: 'center', value: 'gls_ubicacion', class : 'pjud white--text' }  ,
            { text: 'COD TRIBUNAL', align: 'center', value: 'cod_tribunal', class : 'pjud white--text' }  ,
            { text: 'TRIBUNAL', align: 'center', value: 'gls_tribunal', class : 'pjud white--text' }  ,
            { text: 'TIPO CAUSA', align: 'center', value: 'tip_causa', class : 'pjud white--text' }  ,
            { text: 'ROL CAUSA', align: 'center', value: 'rol_causa', class : 'pjud white--text' }  ,
            { text: 'ERA CAUSA', align: 'center', value: 'era_causa', class : 'pjud white--text' }  ,
            { text: 'COD MATERIA', align: 'center', value: 'cod_materia', class : 'pjud white--text' },
            { text: 'MATERIA', align: 'center', value: 'gls_materia', class : 'pjud white--text' },
           
        ],
        causasPage: 1,
        causasPageCount: 0,
        causasItemsPerPage: 10 ,
        loading: true      
	}),    
    async created () {
        this.$gtag.event('apelaciones_inventarios_detalles', { method: 'Google' })
        this.loading = false
    },
    mounted(){
        this.getAll();
    },
    methods: { 
        async getAll(){

            this.loading = true;

            let response = await this.getInventariosDetalles(
                this.usuario.cod_corte, 
                this.fechas.anoInicio, 
                this.fechas.mesInicio,
                this.fechas.diaInicio
            ) // Solicito informacion de los ingresos por tipos detalles.

            this.detalleInventario = response.recordset;
            this.loading = false;
        },
        async getInventariosDetalles (cod_corte, anoInicio, mesInicio, diaInicio) {
            this.detalleInventario = [];
            this.loading = true;
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: urlApi+'/apelaciones/getInventariosDetalles',
                        headers: {},
                        params:{
                            cod_corte: cod_corte,
                            ano: anoInicio,
                            mes: mesInicio,
                            dia: diaInicio
                        }
                    })
                    resolve(response.data.inventariosDetalles)
                } catch (err) {
                    reject(err)
                }
            })
        },                       
        async excelDownload(){
            this.isLoading = true;

            const req = urlApi + '/apelaciones/exportarInventarios';

            const get = async req => {
                try{
                    const response = await axios.get(req, {
                        responseType: 'blob',
                        params: {
                            ano:  this.fechas.anoInicio || this.$route.params.ano,
                            mes: this.fechas.mesInicio || this.$route.params.mes,
                            dia: this.fechas.diaInicio || this.$route.params.dia,
                            cod_corte: this.usuario.cod_corte || this.$route.params.cod_corte,
                        }
                    });
                        
                    const url = window.URL.createObjectURL(new Blob([response.data]));
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', 'Inventario.xlsx'); // nombre del archivo de descarga
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                } 
                catch (error) {
                    console.log(error);
                } finally {
                    this.isLoading = false;
                }
            }

            get(req);  

        },
    },
    computed: {
        ...mapState(['fechas']),
    },
    watch: {
        fechas() { 
            this.getAll();
        },
    },
    components:{
        countTo
    }    
}
</script>
