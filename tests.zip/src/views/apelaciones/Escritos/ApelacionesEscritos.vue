<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-card outlined>
                    <v-card-title class="pr-7 pl-7">
                        <v-toolbar flat class="pjud">
                            <v-toolbar-title >
                                <h2 class="white--text">{{ corte_descripcion }}</h2>
                            </v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                        </v-toolbar>
                    </v-card-title>
                    <v-card-subtitle class="pr-7 pl-7">
                        <FiltrosCompetencias/>
                    </v-card-subtitle>
                    <v-card-text>
                        <v-tabs v-model="tab" background-color="accent-4" centered>
                            <v-tabs-slider></v-tabs-slider>
                            <v-tab href="#tab-1">Escritos Tipos</v-tab>
                        </v-tabs>
                        <v-tabs-items v-model="tab">
                            <v-tab-item id="tab-1">
                                    <ApelacionesEscritosTipos />
                            </v-tab-item>
                        </v-tabs-items>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias.vue'
import ApelacionesEscritosTipos from './ApelacionesEscritosTipos.vue'
// import FamiliaIngresosMaterias from './FamiliaIngresosMaterias.vue'
import store from 'store'
import countTo from 'vue-count-to'
export default {
	name: 'ApelacionesEscritos',
	data: () => ({
        tab: null,
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email'),
            cod_corte : store.get('cod_corte'),
            ano : store.get('ano'),
            mes : store.get('mes')            
        },
        corte_descripcion: '',        
	}),   
    async created () {
        this.$gtag.event('apelaciones_escritos', { method: 'Google' })
        this.getAll()
    },
    methods: {
        async getAll(){
            let response =  await this.getCortes(this.usuario.cod_corte)
            this.corte_descripcion = response[0].descripcion // Nombre de la Corte.      
        },
        async getCortes(cod_corte) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/corte/getCortes',
                        headers: {},
                        params:{
                            cod_corte: cod_corte
                        }
                    })
                    resolve(response.data.getCorte)
                } catch (err) {
                    reject(err)
                }
            })
        }                
    },
    components:{
        FiltrosCompetencias,
        countTo,
        ApelacionesEscritosTipos
    }    
}
</script>
