<template>
	<v-layout
		id="parallax-pjud"
		class="back"
	>
		<v-container fill-height>
			<v-row justify="center">
				<v-col>
					<v-form 
						v-model="valid"
						lazy-validation
						id="loginform" 
						action="Home">
						<v-row
							align="center"
							justify="center"
							>
							<v-col
								class="text-center"
								xs12
								cols="4"
							>
								<v-card class="elevation-12" color="rgb(0, 0, 0, 0.35)">
									<v-card-title class="white--text">
										Login
										<v-spacer></v-spacer>
										<v-icon size="60" color="rgb(89, 86, 85, 0.35)">mdi-lock</v-icon>
									</v-card-title>
									<v-card-subtitle class="text-left white--text">
										Ingrese Usuario y Contraseña:
									</v-card-subtitle>
									<v-card-text >
										<v-form>
											<v-text-field
												v-model="usuario"
												:rules="usuarioRules"
												name="usuario"
												label="Usuario"
												type="text"
												tabindex="1"
												solo
											></v-text-field>
											<v-text-field
												v-model="contrasena"
												:rules="constrasenaRules"
												name="contrasena"
												label="Contraseña"
												type="password"
												tabindex="2"
												solo
											></v-text-field>								
											<v-btn
												:disabled="!valid"
												block
												color="primary"
												@click="submit"
												tabindex="3"
											>
												Ingrese
											</v-btn>
											<v-row dense v-if="show">
												<v-col	xs12 cols="12"> 
													<v-alert
													dense
													type="error"
													class="mt-5"
													>
													{{ message }}
													</v-alert>						
												</v-col>								
											</v-row>
										</v-form>
										<br />
										<h3><a 
												@click="goRecuperarConstrasena()" 
												class="white--text" 
												style="text-decoration: none;"
												tabindex="4"
											>
												Recuperar Contraseña
											</a>
										</h3>
									</v-card-text>
								</v-card>							
							</v-col>
						</v-row>
					</v-form>
				</v-col>
			</v-row>
		</v-container>
	</v-layout>
</template>

<script>
import AuthService from '@/services/auth'
import moment from 'moment-timezone'
import { mapMutations } from 'vuex'
import store from 'store'

moment.locale('es');

export default {
	name: 'Login',
	data () {
		return {
			valid: true,
			usuario: '',
			usuarioRules: [
				v => !!v || 'Usuario Requerido',
			],				
			contrasena: '',		
			constrasenaRules: [
				v => !!v || 'Contraseña Requerida',
			],			
			show: false,
			message: ''
		}
	},
	methods: {
		...mapMutations(['setFechas']),

		validate () {
			this.$refs.form.validate()
		},		

		submit: function () {
			return new Promise(async (resolve) => {
				const response = await AuthService.login(
					this.usuario,
					this.contrasena
				)

				if (response.status != 200) {

					if(response.status >= 500){
						this.message = 'Quantum no se encuentra disponible en este momento. Disculpe las molestias.'
						this.show = true
						return resolve('error')
					}

					this.message = response.data.message
					this.show = true
					return resolve(response.data.message)
					
				}
				
				this.setFechasFiltros();
				this.$router.push('Home');

			})
		},
		setFechasFiltros(){
			try {
				//Setear fecha para el filtro


				const paramFecha =  new Date();
				let fechas = {};
				let calendario = [];

				fechas.dateNow = (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10);
				fechas.diaInicio = moment(fechas.dateNow).format('D');
				fechas.anoInicio = paramFecha.getFullYear();
				fechas.mesInicio = paramFecha.getMonth() + 1;
				fechas.diaFin = moment(fechas.dateNow).format('D');
				fechas.mesFin = paramFecha.getMonth() + 1; 
				fechas.anoFin = paramFecha.getFullYear();
				fechas.exhorto = 1;
				fechas.nombreMesInicio = moment.months()[(fechas.mesInicio-1)];
                fechas.nombreMesFin = moment.months()[(fechas.mesFin-1)];
                fechas.periodo = "De " + fechas.nombreMesInicio + " " + fechas.anoInicio + " - Hasta " +  fechas.nombreMesFin + " " + fechas.anoFin;
                fechas.TipoBusqueda = 'Mensual';
                fechas.PeriodoAntanoInicio = Number(moment(new Date(fechas.mesInicio+'/01/'+fechas.anoInicio)).format('YYYY'));
                fechas.PeriodoAntanoFin = Number(moment(new Date(fechas.mesFin+'/01/'+fechas.anoFin)).format('YYYY'));
                fechas.PeriodoAntmesInicio = Number(moment(new Date(fechas.mesInicio+'/01/'+fechas.anoInicio)).format('M'));
                fechas.PeriodoAntmesFin = Number(moment(new Date(fechas.mesFin+'/01/'+fechas.anoFin)).format('M'));
                calendario.push(moment().month(fechas.mesFin).format('MMMM'));
                fechas.calendario = calendario;
				fechas.rangoSelected = 1; //mensual
				

				store.set('fechas', fechas)

			} catch (error) {
				console.log(error.message);
			}
		},
		beforeEnter: function (el) {
			setTimeout(() => {
				this.show = false
			}, 700 * 10)
		},
		goRecuperarConstrasena: function(){
			this.$router.push('RecuperarContrasena')
		},
	},	
	mounted() {
		document.getElementById('parallax-pjud').style.height = '100%'
		document.getElementById('parallax-pjud').style.widht = '100%'
	}    
}
</script>
<style>
html {
    overflow:   scroll;
    scrollbar-width: none;
}
html::-webkit-scrollbar {
      display: none;
      width: 0px;
      background: transparent;
}

.back {
  background-image: url("../../public/img/Corte_Suprema.jpg");
  background-size: cover;
}


</style>