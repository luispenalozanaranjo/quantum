<template>
        <v-card color="grey">
            <v-card>
                <v-card-title>
                    Detalle Resoluciones Jueces
                    <v-spacer></v-spacer>
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-icon
                                color="orange"
                                dark
                                large
                                v-bind="attrs"
                                v-on="on"
                            >
                                mdi-information-outline
                            </v-icon>
                        </template>
                        <h4 class="orange--text">Criterios</h4>
                        Estados de los tramites:<br/>
                        <ul>
                            <li>• Firmados</li>
                        </ul>
                    </v-tooltip>
                </v-card-title>
                <v-card-subtitle>
                    {{fechaPeriodo}}
                </v-card-subtitle>
                <v-card-text>
                    <apexchart type="bar"  height="550" :options="barChartOptions" :series="barSeries" ref="barChart2"></apexchart>

                    <vue-excel-xlsx class="btn text-center"
                            :data="arrResolucionesData"
                            :columns="excelHead"
                            :filename="'Resoluciones'"
                            :sheetname="'Hoja1'"
                    >
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                    class="mx-2"
                                    fab
                                    dark
                                    small
                                    color="success"
                                    v-bind="attrs" v-on="on"
                                >
                                    <v-icon >mdi-microsoft-excel</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar a excel</span>
                        </v-tooltip>
                    </vue-excel-xlsx>

                    <v-data-table
                        :headers="ResolucionesHeader"
                        :items="arrResolucionesData"
                        :items-per-page="10"
                        dense
                        class="mt-2"
                    >
                        <template v-slot:item="{ item }">
                            <tr>
                                <td  class="text-center">{{item.contador}}</td>
                                <td  class="text-center">{{item.nombre}}</td>
                                <td  class="text-center">
                                    <v-btn text @click="goNomenclaturas(item.id_funcionario)">
                                        <countTo class="count" :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo>
                                    </v-btn>
                                </td>
                            </tr>
                        </template>
                        <template  v-slot:[`body.append`]>
                            <tr class="pjud">
                                <td  class="text-center  subtitle-2 white--text">
                                    Total
                                </td>
                                <td>
                                </td>
                                <td  class="text-center  subtitle-2">
                                    <v-btn text @click="goNomenclaturas()" class="white--text">
                                        <countTo class="count" :startVal="0" :endVal="totalResoluciones" separator="." :duration="1000"></countTo>
                                    </v-btn>
                                </td>
                            </tr>
                        </template>
                    </v-data-table>
                </v-card-text>
            </v-card>
            <v-card class="mt-1">
                <v-card-title>
                    Detalle firma de resoluciones según bloque horario
                </v-card-title>
                <v-card-subtitle>
                    {{fechaPeriodo}}
                </v-card-subtitle>
                <v-card-text>
                    <apexchart type="heatmap"  :options="heatChartOptions" :series="heatSeries"></apexchart>
                </v-card-text>
            </v-card>


        </v-card>
</template>

<script>
import { GChart } from 'vue-google-charts'
import { urlApi } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import store from 'store'
import countTo from 'vue-count-to'

export default {
    name: 'ResolucionesJuez',
    data() {
        return{
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto'),
                tipo:  (this.$route.params.tipo === undefined) ? store.get('tipo') : this.$route.params.tipo
            },
            fechaPeriodo: '',
            arrResolucionesData: [],
            totalResoluciones: 0,
            ResolucionesHeader: [{text: '#', align: 'center', sortable: false, value: 'contador', class: 'pjud white--text subtitle-2'},
                                {text: 'Nombre', align: 'center', sortable: false, value: 'nombre', class: 'pjud white--text subtitle-2'},
                                {text: 'Cantidad', align: 'center', sortable: true, value: 'cantidad', class: 'pjud white--text subtitle-2'},
            ],
            excelHead : [   {label: "#", field: "contador",},
                        {label: "Nombre", field: "nombre",},
                        {label: "Cantidad", field: "cantidad",},
            ],
            barSeries: [{
                name: "Nro Resoluciones",
                data: [],
            }],
            barChartOptions: {
                chart: {
                    type: 'bar',
                    stacked: false,
                    id: 'barChart2',
                },
                plotOptions: {
                    bar: {
                        horizontal: true,
                    },
                },
                yaxis: {
                    labels: {
                        align: 'left',
                        maxWidth: 300,
                    }
                },
                colors: ["#775DD0"],
                noData: {
                    text: 'Visualizando',
                },
                xaxis: {
                    categories: [],
                    labels: {
                        formatter: function (value) {
                            return value;
                        }
                    }
                },
                fill: {
                    opacity: 1
                },
                legend: {
                    position: 'top',
                    horizontalAlign: 'center',
                    offsetX: 40
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
			}, 
            heatSeries:[{
                name: "",
                data: [],
            }],
            heatChartOptions: {
                chart: {
                    type: 'heatmap',
                },
                dataLabels: {
                    enabled: true
                },
                xaxis: {
                    type: 'category',
                    categories: ['0H-6H', '7H', '8H', '9H', '10H', '11H', '12H', '13H','14H','15H','16H','17H','18H','19H-23H']
                },
                yaxis: {
                    labels: {
                        align: 'left',
                        maxWidth: 300,
                    }
                },
                plotOptions: {
                    heatmap: {
                        shadeIntensity: 0.5,
                        radius: 0,
                        useFillColorAsStroke: true,
                        colorScale: {
                        ranges: [{
                            from: -50,
                            to: 0,
                            name: 'Bajo',
                            color: '#E5E5E5'
                            },
                            {
                            from: 1,
                            to: 120,
                            name: 'Medio',
                            color: '#FF9F33'
                            },
                            {
                            from: 121,
                            to: 1000,
                            name: 'Alto',
                            color: '#FF0000'
                            }
                        ]
                        }
                    }
                },
            }
            
    
        }
    },
    created(){
        try {
            this.$gtag.event('laboral_resoluciones_jueces', { method: 'Google' });
            this.fechaPeriodo = this.fechas.periodo;
            this.getResolucionesJueces();
            this.getResolucionesJuecesHorarios();
        } catch (error) {
            console.log(error);
        }

    },
    methods: {
        ...mapMutations(['setId_funcionario','setTipoFuncionario']),

        goNomenclaturas(id_funcionario){
            try {
                this.setId_funcionario(id_funcionario);
                this.setTipoFuncionario('juez');
                this.$router.push({ name: 'LaboralResolucionesNomenclaturas' });

            } catch (error) {
                console.log(error);
            }
        },

        async getResolucionesJueces(){

            const axios = require('axios')
            const req1 = urlApi + '/laboral/resoluciones_juez' 
            this.arrResolucionesData = []
            this.totalResoluciones = 0
            this.barChartOptions.xaxis.categories = []
            this.barSeries[0].data = []

            try{

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte: this.user.cod_corte,
                                cod_tribunal: this.user.cod_tribunal,
                                anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                                mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                                anoFin: this.fechas.anoFin || this.$route.params.ano,
                                mesFin: this.fechas.mesFin || this.$route.params.mes,
                                flg_exhorto: this.fechas.exhorto || 0
                            }
                        })
                        
                        const data = response.data
                        
                        let cantidad = 0
                        let totalOtros = 0
                    
                        Object.values(data.recordset).map((type) => {
                            
                            //top 15 de jueces con mayores resoluciones
                            //carga de data utilizada en el grafico de barra
                            if(cantidad < 20){
                                this.barChartOptions.xaxis.categories.push(type.nombre)
                                this.barSeries[0].data.push(type.cantidad_res)
                            } else {
                                //sumo los con menores resoluciones
                                totalOtros += type.cantidad_res
                            }

                            //Total de resoluciones
                            this.totalResoluciones += type.cantidad_res

                            //carga de data utilizada en el datatable
                            this.arrResolucionesData.push({
                                contador: cantidad,
                                id_funcionario: type.id_funcionario,
                                nombre: type.nombre,
                                cantidad: type.cantidad_res
                            })


                            cantidad += 1

                        })

                        //agrego los con menores resoluciones
                        if(totalOtros > 0){
                            //carga de data utilizada en el grafico de barra
                            this.barChartOptions.xaxis.categories.push("OTROS")
                            this.barSeries[0].data.push(totalOtros)

                        }


                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)



            }catch(error){
                console.log(error)
            }

        },
        async getResolucionesJuecesHorarios(){
            const axios = require('axios')
            const req1 = urlApi + '/laboral/resoluciones_juez_horarios' 
            this.heatSeries = []

            try{

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte: this.user.cod_corte,
                                cod_tribunal: this.user.cod_tribunal,
                                anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                                mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                                anoFin: this.fechas.anoFin || this.$route.params.ano,
                                mesFin: this.fechas.mesFin || this.$route.params.mes,
                                flg_exhorto: this.fechas.exhorto || 0
                            }
                        })
                        
                        const data = response.data
                    
                        Object.values(data.recordset).map((type) => {
                            
                            this.heatSeries.unshift({
                                name: type.nombre,
                                data: [{x: '0H-6H', y: (type.cero + type.una + type.dos + type.tres + type.cuatro + type.cinco  + type.seis)},
                                       {x: '7H', y: (type.siete)},
                                       {x: '8H', y: (type.ocho)},
                                       {x: '9H', y: (type.nueve)},
                                       {x: '10H', y: (type.diez)},
                                       {x: '11H', y: (type.once)},
                                       {x: '12H', y: (type.doce)},
                                       {x: '13H', y: (type.trece)},
                                       {x: '14H', y: (type.catorce)},
                                       {x: '15H', y: (type.quince)},
                                       {x: '16H', y: (type.dieciseis)},
                                       {x: '17H', y: (type.diecisiete)},
                                       {x: '18H', y: (type.dieciocho)},
                                       {x: '19H-23H', y: (type.diecinueve + type.veinte + type.veintiuno + type.veintidos + type.veintitres)}]
                            })


                        })


                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

            }catch(error){
                console.log(error)
            }
        },
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas() {
            this.fechaPeriodo = this.fechas.periodo;
            this.getResolucionesJueces();
            this.getResolucionesJuecesHorarios();
            this.$forceUpdate();
        }
    },
    components: {
        GChart,
        countTo
    },
}

</script>