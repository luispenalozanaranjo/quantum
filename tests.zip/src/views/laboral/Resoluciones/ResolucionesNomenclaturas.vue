<template>
    <layout>
        <v-card>
            <v-card>
                <v-card-title>
                    Resoluciones Nomenclaturas
                    <v-spacer></v-spacer>
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-icon
                                color="orange"
                                dark
                                large
                                v-bind="attrs"
                                v-on="on"
                            >
                                mdi-information-outline
                            </v-icon>
                        </template>
                        <h4 class="orange--text">Criterios</h4>
                        Estados de los tramites:<br/>
                        <ul>
                            <li>• Firmados</li>
                        </ul>
                    </v-tooltip>
                </v-card-title>
                <v-card-subtitle>
                    {{fechaPeriodo}}
                </v-card-subtitle>
                <v-card-text>
                    <ModalDetalle :tipoModal="this.tipoModal" />

                    <apexchart  height="430" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico"></apexchart>

                    <vue-excel-xlsx class="btn text-center mt-3"
                            :data="Query_Resoluciones"
                            :columns="excelHead"
                            :filename="'Resoluciones_Nomenclaturas'"
                            :sheetname="'Hoja1'"
                    >
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                    class="mx-2"
                                    fab
                                    dark
                                    small
                                    color="success"
                                    v-bind="attrs" v-on="on"
                                >
                                    <v-icon >mdi-microsoft-excel</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar a excel</span>
                        </v-tooltip>
                    </vue-excel-xlsx>

                    <v-data-table 
                            :items="Query_Resoluciones"
                            :sort-by="['cantidad']"
                            :sort-desc="[true]"
                            dense
                            class="mt-2"
                            >
                            <template v-slot:[`header`]>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text subtitle-2 text-center">#</th>
                                        <th class="white--text subtitle-2 text-center">Nomenclatura</th>
                                        <th class="white--text subtitle-2 text-center">Cantidad</th>
                                    </tr>
                                </thead>
                            </template>
                            <template v-slot:item="{ item }">
                                <tr>
                                    <td class="text-center">{{ item.increment }}</td>
                                    <td class="text-center">{{ item.gls_nomenclatura }}</td>
                                    <td class="text-center"><countTo class="count" :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo></td>
                                </tr>
                            </template>
                            <template  v-slot:[`body.append`]>
                                <tr class="pjud white--text">
                                    <th></th>
                                    <th class="text-center subtitle-2">Total</th>
                                    <th class="text-center subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                                </tr>
                            </template>
                    </v-data-table>

                    <ModalLoading/>

                    <FiltrosCompetencias v-show="false"/>
                </v-card-text>
            </v-card>
        </v-card>
    </Layout>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import Layout from '../../../components/competencias/laboral/Layout'
import countTo from 'vue-count-to'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"
import ModalDetalle from '../ModalDetalles.vue'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'


export default {
    name: 'ResolucionesNomenclaturas',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            tipoModal: "resolucionesNomenclaturas",
            Query_Resoluciones: [],        
            headers: [
                { text: '#',  align: 'center', value: 'increment', class : 'primary white--text', width: '10%'},
                { text: 'Nomenclatura',  align: 'center', value: 'gls_nomenclatura', class : 'primary white--text', width: '60%' },
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'primary white--text', width: '30%' },
              ],
            excelHead : [
                {
                    label: "#",
                    field: "increment",

                },

                {
                
                    label: "Tipo Causa",
                    field:  "gls_nomenclatura",
  
                },


                {
                
                    label: "Cantidad",
                    field:  "cantidad",
  
                },

                 {
                    label: "Total",
                    field: "totales",
                }

                                                                                                                                                                                               
            ],
            total : 0 ,
            fechaPeriodo: '',
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    id: 'pieGrafico',
                    height: 430,
                    type: 'pie',
                },
                dataLabels: {
                    enabled: true,
                    enabledOnSeries: true,
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                    horizontalAlign: 'center',
                    onItemHover: {
                        highlightDataSeries: true
                    },
                    onItemClick: {
                        toggleDataSeries: true
                    },
                    // floating: true,
                },
			}, 
        }
    },
    created(){
        try {
            this.$gtag.event('laboral_resoluciones_nomenclaturas', { method: 'Google' });
            this.fechaPeriodo = this.fechas.periodo;
            // this.getResolucionesNomenclaturas();
        } catch (error) {
            console.log(error);
        }
       
    },
    components: {
        ModalLoading,
        countTo,
        Layout,
        ModalDetalle,
        FiltrosCompetencias
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
                
            html2canvas(document.querySelector('.pdfi')).then(canvas => {
                let image = canvas.toDataURL('image/png')
                
                let doc = new jsPDF('p', 'pt', 'a1');
                doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
                doc.save('DashboardTerminos.pdf')
            })
        },  
 
        getResolucionesNomenclaturas() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/resoluciones_nomenclaturas_total';
            this.Query_Resoluciones = [];
            this.total = 0;
            let dataLabelsAux = [];
            let dataSeriesAux = [];
            let tipo_cargo = 0;


            switch(this.tipoFuncionario){
                case 'juez':
                    tipo_cargo = 2;
                    break;
                case 'funcionario':
                    tipo_cargo = 3;
                    break;
                default:
                    tipo_cargo = 0;
                    break;
            }


            axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhorto || 0,
                            id_funcionario: this.id_funcionario || 0,
                            tipo_cargo: tipo_cargo
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data;
                    let objIngreso;
                    let increment = 1;
                    let acumulador = 0;
                   
                    Object.values(data1.recordset).map((type) => {

                        objIngreso = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                        objIngreso.increment = increment
                        objIngreso.gls_nomenclatura = type.gls_nomenclatura
                        objIngreso.cantidad = type.cantidad
                        this.total= this.total + type.cantidad


                        if(increment < 20){
                            dataLabelsAux.push(type.gls_nomenclatura);
                            dataSeriesAux.push(type.cantidad);
                        }else {
                            acumulador += type.cantidad
                        }

                        this.Query_Resoluciones.push(objIngreso) // push para la tabla 

                        increment ++;
                       
                    });

                    if(acumulador > 0){
                        dataLabelsAux.push("Otros");
                        dataSeriesAux.push(acumulador);
                    }

                    //Series
                    this.pieSeries = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);

                    this.setModal(false) // Aqui Manipulamos el modal                     

                })).catch(errors => {
                    console.log(errors);
                    this.setModal(false); // Aqui Manipulamos el modal                     
                })
            
        }  
    },
    computed: {
        ...mapState(['fechas','id_funcionario','tipoFuncionario'])
    },
    watch: {
        fechas () {
            try {
                this.fechaPeriodo = this.fechas.periodo;
                this.getResolucionesNomenclaturas();
            } catch (error) {
                console.log(error.message)
            }

        }
    }
} 
</script>