<template>
    <v-card class="pdfi" color="grey">
        <v-card>
            <v-card-title>
                Total de actuaciones por nomenclaturas
                <v-spacer></v-spacer>
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <v-icon
                            color="orange"
                            dark
                            large
                            v-bind="attrs"
                            v-on="on"
                        >
                            mdi-information-outline
                        </v-icon>
                    </template>
                    <h4 class="orange--text">Criterios</h4>
                    Estados de los tramites:<br/>
                    <ul>
                        <li>• Firmados</li>
                    </ul>
                </v-tooltip>
            </v-card-title>
            <v-card-subtitle>
                {{fechas.periodo}}
            </v-card-subtitle>
            <v-card-text>
                <!-- INI DETALLE INGRESOS -->
                <ModalDetalle :tipoModal="this.tipoModal" />
                <!-- FIN DETALLE INGRESOS -->
                <apexchart height="400" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico3"></apexchart>

                <vue-excel-xlsx class="btn text-center mt-5"
                    :data="dataActResoluciones"
                    :columns="excelHead"
                    :filename="'Act_Resoluciones'"
                    :sheetname="'Hoja1'"
                >
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs" v-on="on"
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>
                            </v-btn>
                        </template>
                        <span>Exportar a excel</span>
                    </v-tooltip>
                </vue-excel-xlsx>
                
                <v-data-table 
                    :items="dataActResoluciones"
                    :sort-by="['cantidad']"
                    :sort-desc="[false]"
                    dense
                    class="mt-2"
                >
                    <template v-slot:[`header`]>
                        <thead class="pjud">
                            <tr>
                                <th class="white--text subtitle-2 text-center">#</th>
                                <th class="white--text subtitle-2 text-center">nomenclaturas</th>
                                <th class="white--text subtitle-2 text-center">Cantidad</th>
                            </tr>
                        </thead>
                    </template>
                    <template v-slot:item="{ item }">
                        <tr>
                            <td class="text-center">{{ item.increment }}</td>
                            <td class="text-center">{{ item.gls_tipo_solicitud }}</td>
                            <td class="text-center"><countTo class="count" :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo></td>
                        </tr>
                    </template>
                    <template  v-slot:[`body.append`]>
                        <tr class="pjud white--text">
                            <th></th>
                            <th class="text-center subtitle-2">Total</th>
                            <th class="text-center subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                        </tr>
                    </template>
                </v-data-table>
            </v-card-text>
        </v-card>

        <v-card class="mt-1">
            <v-card-title>
                Comparativa anual por nomenclatura
            </v-card-title>
            <v-card-subtitle>
                Año: {{fechas.anoInicio}}
            </v-card-subtitle>
            <v-card-text>
                <apexchart type="line"  height="350" :options="ChartOptionsLine" :series="SeriesLine" ref="pieChart"></apexchart>
            </v-card-text>
        </v-card>
        <ModalLoading/>
    </v-card>
</template>


<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { urlApi } from '../../../config/api'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import ModalDetalle from '../ModalDetalles.vue'
import es from "apexcharts/dist/locales/es.json";
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"

export default {
    name: 'ActuacionesResoluciones',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            dataActResoluciones: [],        
            excelHead : [{label: "#",               field: "increment"},
                        {label: "Funcionario",     field:  "nombre"},
                        {label: "Cantidad",         field:  "cantidad"}
            ],
            total : 0 , 
            tipoModal: "actuaciones_detalle",
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    id: 'pieGrafico3',
                    height: 400,
                    type: 'pie',
                    locales: [es],
                    defaultLocale: "es",  
                },
                noData: {
                    text: 'Visualizando'
                },  
                dataLabels: {
                    enabled: true,
                    formatter: function (val) {
                        return val.toFixed(2).toString().replace('.',',') + '%'
                    }  
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                },
			}, 
            SeriesLine: [{
                name: "Nomeclaturas",
                data: []
            }],
            ChartOptionsLine: {
                chart: {
                    height: 350,
                    type: 'line',
                    zoom: {
                        enabled: false
                    }
                },
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    width: [5, 5, 5, 5 ,5 ,5 ,5 ,5 ,5 ,5],
                    curve: 'smooth'
                },
                // legend: {
                //     tooltipHoverFormatter: function(val, opts) {
                //         return val + ' - ' + opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex] + ''
                //     }
                // },
                markers: {
                    size: 3,
                    hover: {
                        sizeOffset: 6
                    }
                },
                grid: {
                    borderColor: '#f1f1f1',
                },
                xaxis: {
                    categories: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep','Oct','Nov','Dic'],
                }
			}, 
        }
    },
    created(){
        try {
            this.$gtag.event('laboral_actuaciones_resoluciones', { method: 'Google' });
            this.getActuacionesResoluciones();
            this.getActuacionesResolucionesAnual();
        } catch (error) {
            console.log(error);
        }
       

    },
    components: {
        ModalLoading,
        ModalDetalle,
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar
 
        getActuacionesResoluciones() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/actuaciones_tipos_solicitudes';
            this.dataActResoluciones = [];
            this.total = 0;
            let dataLabelsAux = [];
            let dataSeriesAux = [];
              
            axios.all([
                    axios.get(req1, {
                    params: {
                        cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                        cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                        anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                        mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                        anoFin: this.fechas.anoFin || this.$route.params.ano,
                        mesFin: this.fechas.mesFin || this.$route.params.mes,
                        flg_exhorto: this.fechas.exhorto || 0
                    }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data;
                    let increment = 1;
                    let totalizador = 0;


                    Object.values(data1.recordset).map((type) => {

                        this.dataActResoluciones.push({
                            increment: increment
                            ,id_tipo_solicitud: type.id_tipo_solicitud
                            ,gls_tipo_solicitud: type.gls_tipo_solicitud
                            ,cantidad: type.cantidad
                        });


                        if(increment <= 15){
                            dataSeriesAux.push(Number(type.cantidad));
                            dataLabelsAux.push(type.gls_tipo_solicitud);
                            
                        }else {
                            totalizador += type.cantidad;
                        }


                        this.total += type.cantidad;
                        increment ++ ;
                    })

                    if(totalizador > 0){
                        dataSeriesAux.push(totalizador);
                        dataLabelsAux.push("Otros");
                        
                    }
                    //Series
                    this.pieSeries = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico3', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);

                    this.setModal(false);                   

            })).catch(errors => {
                console.log(errors);
                this.setModal(false);                    
            })
            
        },
        getActuacionesResolucionesAnual() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/actuaciones_tipos_solicitudes_anual';
            this.total = 0;
            this.SeriesLine = [];
            this.ChartOptionsLine.stroke.width = [];
            
           
              
            axios.all([
                    axios.get(req1, {
                    params: {
                        cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                        cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                        anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                        flg_exhorto: this.fechas.exhorto || 0
                    }
                    })

                ]).then(axios.spread((...responses) => {

                    const data = responses[0].data;
                    let auxArray = [];
                    let totalizador = 0;
                    let dataActRes = [];
                    
                    //Obtengo solo los codigos de las nomenclaturas
                    let dataResAux = data.recordset.map(a => a.id_tipo_solicitud);
                    //dejo los valores unicos
                    dataResAux = dataResAux.filter((v, i, a) => a.indexOf(v) === i);

                    dataResAux.forEach(e => {

                        auxArray = data.recordset.filter(element => element.id_tipo_solicitud == e);
                        auxArray = auxArray.map(a => a.cantidad);
                        totalizador = auxArray.reduce((a, b) => a + b, 0);
                        this.ChartOptionsLine.stroke.width.push(5);


                        dataActRes.push({
                            id_tipo_solicitud: e,
                            gls_tipo_solicitud: data.recordset.find(element => element.id_tipo_solicitud == e) == undefined ? "Sin Nombre" : data.recordset.find(element => element.id_tipo_solicitud == e).gls_tipo_solicitud,
                            enero: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 1) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 1).cantidad,
                            febrero: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 2) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 2).cantidad,
                            marzo: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 3) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 3).cantidad,
                            abril: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 4) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 4).cantidad,
                            mayo: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 5) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 5).cantidad,
                            junio: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 6) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 6).cantidad,
                            julio: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 7) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 7).cantidad,
                            agosto: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 8) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 8).cantidad,
                            septiembre: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 9) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 9).cantidad,
                            octubre: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 10) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 10).cantidad,
                            noviembre: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 11) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 11).cantidad,
                            diciembre: data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 12) == undefined ? 0 : data.recordset.find(element => element.id_tipo_solicitud == e && element.mes == 12).cantidad,
                            total: totalizador,
                        });

                    });

                    auxArray = dataActRes.sort(function(a, b){return b.total  - a.total})

                    let arrAuxSeries = [];

                    auxArray.forEach(e => {

                        arrAuxSeries.push({
                            name : e.gls_tipo_solicitud,
                            data: [
                                e.enero,
                                e.febrero,
                                e.marzo,
                                e.abril,
                                e.mayo,
                                e.junio,
                                e.julio,
                                e.agosto,
                                e.septiembre,
                                e.noviembre,
                                e.diciembre
                            ]
                        });

                    });

                    this.SeriesLine = arrAuxSeries;

                    this.setModal(false);                   

            })).catch(errors => {
                console.log(errors);
                this.setModal(false);                    
            })
            
        },

    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.getActuacionesResoluciones();
            // this.getActuacionesResolucionesAnual();
        }
    }
} 
</script>