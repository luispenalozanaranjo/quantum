<template>
        <v-dialog :max-width="ancho" v-model="dialog">
            <template v-slot:activator="{ on, attrs }">
                <v-btn class="pjud white--text"  v-bind="attrs"  v-on="on" @click="requestData">
                    {{btnLabel}}
                </v-btn>
            </template>
            <v-card>
                <v-card-title class="pjud white--text">
                    {{tituloLabel}}
                     <v-spacer></v-spacer>
                    <v-btn
                        color="error"
                        @click="dialog = false"
                        large
                    > 
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                        <v-row>
                            <v-col>
                                <vue-excel-xlsx class="btn text-center mt-5"
                                    :data="detalleData"
                                    :columns="excelHead"
                                    :filename="'Detalles'"
                                    :sheetname="'Hoja1'"
                                >
                                    <v-tooltip top>
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-btn
                                                class="mx-2"
                                                fab
                                                dark
                                                small
                                                color="success"
                                                v-bind="attrs" v-on="on"
                                            >
                                                <v-icon >mdi-microsoft-excel</v-icon>
                                            </v-btn>
                                        </template>
                                        <span>Exportar a excel</span>
                                    </v-tooltip>
                                </vue-excel-xlsx>
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col>
                                <v-text-field
                                    v-model="search"
                                    append-icon=""
                                    label="Buscar"
                                    single-line
                                    hide-details
                                ></v-text-field>
                                <v-data-table 
                                    :headers="headers"
                                    :items="detalleData"
                                    :search="search"
                                    dense
                                    class="mt-4">
                                </v-data-table>
                            </v-col>
                        </v-row>
                </v-card-text>
            </v-card>
        </v-dialog>
</template>

<script>
// import ModalLoading from '../../components/elementos/ModalLoading'
import { mapState,mapMutations } from 'vuex'
import store from 'store'
import { urlApi } from '../../config/api'

export default {
        name: "ModalDetalles",
        data: () => ({
            dialog: false
            ,detalleData: []
            ,search: ''
            ,headers: []
            ,user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }]
            ,excelHead :[],
            btnLabel: "Ver Detalles",
            tituloLabel: "",
            ancho: "1200px",
        }),
         components: {
        // ModalLoading
        },
        methods:{
             ...mapMutations(['setModal']), // Mutations no Borrar
            requestData: function(){

                switch(this.tipoModal){
                    case "terminosTipos":
                        this.terminosTiposData();
                        break;
                    case "terminosMaterias":
                        this.terminosMaterias();
                        break
                    case "terminosProcedimientos":
                        this.terminosProcedimientos();
                        break;
                    case "escritosTipos":
                        this.escritosTipos();
                        break;
                    case "actuaciones_detalle":
                        this.actuaciones_detalle();
                        break;
                    case "resolucionesNomenclaturas":
                        this.resolucionesNomenclaturas();
                        break;
                    default:
                        console.log("Props no identificado ModalDetalles")
                        break
                }



            },
            terminosProcedimientos: function(){
                const axios = require('axios');
                const req1 = urlApi + '/laboral/detalles_procedimientos_terminos'; 
                this.detalleData = [];
                   this.search = "";
                this.setModal(true); // Para cargar la ventana Modal
                //cabecera de la tabla
                this. tituloLabel= "Detalles Procedimientos";

                this.headers = [
                    {text: '#', align: 'center', value: 'increment', class : 'pjud white--text subtitle-2'},
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Tipo Término', align: 'center', value: 'gls_tipfallada', class : 'pjud white--text subtitle-2'},
                    {text: 'Procedimiento', align: 'center', value: 'gls_procedimiento', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Ingreso', align: 'center', value: 'fecha_ingreso_causa', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Término', align: 'center', value: 'fecha_firma', class : 'pjud white--text subtitle-2'},
                    {text: 'Duración dias', align: 'center', value: 'duracion', class : 'pjud white--text subtitle-2'}
                ];
                //cabecera del excel
                this.excelHead =[
                     { label: "#",field: "increment" }
                    ,{ label: "RIT",field: "rit" }
                    ,{ label: "Tipo Término",field: "gls_tipfallada" }
                    ,{ label: "Procedimiento",field: "gls_procedimiento" }
                    ,{ label: "Fec. Ingreso",field: "fecha_ingreso_causa" }
                    ,{ label: "Fec. Término",field: "fecha_firma" }
                    ,{ label: "Duración dias",field: "duracion" }
                ];

                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data;
                    let objDetTermino;
                    let increment = 1;

                    Object.values(data1.recordset).map((type) => {

                        objDetTermino = new Object();
                        objDetTermino.rit = type.rit;
                        objDetTermino.gls_tipfallada = type.gls_tipfallada;
                        objDetTermino.gls_procedimiento = type.gls_procedimiento;
                        objDetTermino.fecha_ingreso_causa = type.fecha_ingreso_causa;
                        objDetTermino.fecha_firma = type.fecha_firma;
                        objDetTermino.duracion = type.duracion;
                        objDetTermino.increment = increment;

                        this.detalleData.push(objDetTermino);
                        increment ++
                    })
                    this.setModal(false) // Para apagar el loaddin modal
            
                })).catch(errors => {
                    this.setModal(false);
                    console.log(errors);
                })



            },
            terminosMaterias: function(){
                const axios = require('axios');
                const req1 = urlApi + '/laboral/detalles_materias_terminos'; 
                this.detalleData = [];
                this.search = "";
                this.setModal(true) // Para cargar la ventana Modal
                //cabecera de la tabla
                this. tituloLabel= "Detalles Materias";

                this.headers = [
                    {text: '#', align: 'center', value: 'increment', class : 'pjud white--text subtitle-2', width: '4%'},
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2', width: '13%'},
                    {text: 'Tipo Término', align: 'center', value: 'gls_tipfallada', class : 'pjud white--text subtitle-2', width: '14%'},
                    {text: 'Procedimiento', align: 'center', value: 'gls_procedimiento', class : 'pjud white--text subtitle-2', width: '13%'},
                    {text: 'Materias', align: 'center', value: 'gls_materia', class : 'pjud white--text subtitle-2', width: '17%'},
                    {text: 'Fec. Ingreso', align: 'center', value: 'fecha_ingreso_causa', class : 'pjud white--text subtitle-2', width: '13%'},
                    {text: 'Fec. Término', align: 'center', value: 'fecha_firma', class : 'pjud white--text subtitle-2', width: '13%'},
                    {text: 'Duración dias', align: 'center', value: 'duracion', class : 'pjud white--text subtitle-2', width: '13%'}
                ]
                //cabecera del excel
                this.excelHead =[
                     { label: "#",field: "increment" }
                    ,{ label: "RIT",field: "rit" }
                    ,{ label: "Tipo Término",field: "gls_tipfallada" }
                    ,{ label: "Procedimiento",field: "gls_procedimiento" }
                    ,{ label: "Materias",field: "gls_materia" }
                    ,{ label: "Fec. Ingreso",field: "fecha_ingreso_causa" }
                    ,{ label: "Fec. Término",field: "fecha_firma" }
                    ,{ label: "Duración dias",field: "duracion" }
                ]

                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data;
                    let objDetTermino;
                    let increment = 1;

                    Object.values(data1.recordset).map((type) => {

                        objDetTermino = new Object();
                        objDetTermino.rit = type.rit;
                        objDetTermino.gls_tipfallada = type.gls_tipfallada;
                        objDetTermino.gls_procedimiento = type.gls_procedimiento;
                        objDetTermino.gls_materia = type.gls_materia;
                        objDetTermino.fecha_ingreso_causa = type.fecha_ingreso_causa;
                        objDetTermino.fecha_firma = type.fecha_firma;
                        objDetTermino.duracion = type.duracion;
                        objDetTermino.increment = increment;

                        this.detalleData.push(objDetTermino);
                        increment ++;
                    })
                    this.setModal(false) // Para apagar el loaddin modal
            
                })).catch(errors => {
                    this.setModal(false);
                    console.log(errors);
                })



            },
            terminosTiposData: function(){
                
                const axios = require('axios');
                const req1 = urlApi + '/laboral/detalles_tipos_terminos';
                this.detalleData = [];
                   this.search = "";
                this.setModal(true) // Para cargar la ventana Modal
                //cabecera de la tabla
                this. tituloLabel= "Detalles Términos Tipos";
                this.headers = [
                    {text: '#', align: 'center', value: 'increment', class : 'pjud white--text subtitle-2', width: '4%'},
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2', width: '16%'},
                    {text: 'Tipo Término', align: 'center', value: 'gls_tipfallada', class : 'pjud white--text subtitle-2', width: '16%'},
                    {text: 'Procedimiento', align: 'center', value: 'gls_procedimiento', class : 'pjud white--text subtitle-2', width: '16%'},
                    {text: 'Fec. Ingreso', align: 'center', value: 'fecha_ingreso_causa', class : 'pjud white--text subtitle-2', width: '16%'},
                    {text: 'Fec. Término', align: 'center', value: 'fecha_firma', class : 'pjud white--text subtitle-2', width: '16%'},
                    {text: 'Duración dias', align: 'center', value: 'duracion', class : 'pjud white--text subtitle-2', width: '16%'}
                ];
                //cabecera del excel
                this.excelHead =[
                     { label: "#",field: "increment" }
                    ,{ label: "RIT",field: "rit" }
                    ,{ label: "Tipo Término",field: "gls_tipfallada" }
                    ,{ label: "Procedimiento",field: "gls_procedimiento" }
                    ,{ label: "Fec. Ingreso",field: "fecha_ingreso_causa" }
                    ,{ label: "Fec. Término",field: "fecha_firma" }
                    ,{ label: "Duración dias",field: "duracion" }
                ];


                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objDetTermino;
                    let increment = 1

                    Object.values(data1.recordset).map((type) => {

                        objDetTermino = new Object();
                        objDetTermino.rit = type.rit
                        objDetTermino.gls_tipfallada = type.gls_tipfallada
                        objDetTermino.gls_procedimiento = type.gls_procedimiento
                        objDetTermino.fecha_ingreso_causa = type.fecha_ingreso_causa
                        objDetTermino.fecha_firma = type.fecha_firma
                        objDetTermino.duracion = type.duracion
                        objDetTermino.increment = increment

                        this.detalleData.push(objDetTermino)
                        increment ++
                    })
                    this.setModal(false) // Para apagar el loaddin modal
            
                })).catch(errors => {
                    console.log(errors)
                })
            },
            escritosTipos: function(){
                const axios = require('axios');
                const req1 = urlApi + '/laboral/escritos_tipos_detalles';
                this.ancho = "1500px";
                this.detalleData = [];
                this.search = "";
                this.setModal(true); // Para cargar la ventana Modal
                //cabecera de la tabla
                this.tituloLabel= "Detalle de escritos";

                this.headers = [
                    {text: 'ID Solicitud', align: 'center', value: 'crr_idsolicitud', class : 'pjud white--text subtitle-2'},
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Procedimiento', align: 'center', value: 'procedimiento', class : 'pjud white--text subtitle-2'},
                    {text: 'Referencia', align: 'center', value: 'referencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Ingreso Causa', align: 'center', value: 'fec_ingreso_causa', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Ingreso Escrito', align: 'center', value: 'fecha_ingreso_escrito', class : 'pjud white--text subtitle-2'},
                    {text: 'Estado Firma', align: 'center', value: 'estado_firma', class : 'pjud white--text subtitle-2'},
                    {text: 'Est.Solicitud', align: 'center', value: 'estado_solicitud', class : 'pjud white--text subtitle-2'},
                    {text: 'Forma Ingreso', align: 'center', value: 'forma_ingreso', class : 'pjud white--text subtitle-2'},
                ]
                //cabecera del excel
                this.excelHead =[
                     { label: "ID Solicitud",field: "crr_idsolicitud" }
                    ,{ label: "RIT",field: "rit" }
                    ,{ label: "Procedimiento",field: "procedimiento" }
                    ,{ label: "Referencia",field: "referencia" }
                    ,{ label: "Fec. Ingreso Causa",field: "fec_ingreso_causa" }
                    ,{ label: "Fec. Ingreso Escrito",field: "fecha_ingreso_escrito" }
                    ,{ label: "Estado Firma",field: "estado_firma" }
                    ,{ label: "Estado Solicitud",field: "estado_solicitud" }
                    ,{ label: "Forma Ingreso",field: "forma_ingreso" }
                ]

                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objDetTermino;

                    Object.values(data1.recordset).map((type) => {

                        objDetTermino = new Object();
                        objDetTermino.crr_idsolicitud = type.crr_idsolicitud;
                        objDetTermino.rit = type.rit;
                        objDetTermino.procedimiento = type.procedimiento;
                        objDetTermino.referencia = type.referencia;
                        objDetTermino.fec_ingreso_causa = type.fec_ingreso_causa;
                        objDetTermino.fecha_ingreso_escrito = type.fecha_ingreso_escrito;
                        objDetTermino.estado_firma = type.estado_firma;
                        objDetTermino.estado_solicitud = type.estado_solicitud;
                        objDetTermino.forma_ingreso = type.forma_ingreso;

                        this.detalleData.push(objDetTermino)

                    })
                    this.setModal(false) // Para apagar el loaddin modal
            
                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })


            },
            actuaciones_detalle: function(){
                const axios = require('axios');
                const req1 = urlApi + '/laboral/actuaciones_detalle';
                this.ancho = "1200px";
                this.detalleData = [];
                this.search = "";
                this.setModal(true); // Para cargar la ventana Modal
                //cabecera de la tabla
                this.tituloLabel= "Detalle de Actuaciones";

                this.headers = [
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Nomenclatura', align: 'center', value: 'gls_nomenclatura', class : 'pjud white--text subtitle-2'},
                    {text: 'Nombre', align: 'center', value: 'nombre', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Actuación', align: 'center', value: 'fec_actuacion', class : 'pjud white--text subtitle-2'},
                    {text: 'Estado Firma', align: 'center', value: 'gls_estfirma', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Firma', align: 'center', value: 'fec_firma', class : 'pjud white--text subtitle-2'},
                    
                ]
                //cabecera del excel
                this.excelHead =[
                     { label: "RIT",field: "rit" }
                    ,{ label: "Nomenclatura",field: "gls_nomenclatura" }
                    ,{ label: "Nombre",field: "nombre" }
                    ,{ label: "Fec. Actuación",field: "fec_actuacion" }
                    ,{ label: "Estado Firma",field: "gls_estfirma" }
                    ,{ label: "Fec. Firma",field: "fec_firma" }
                    
                ]

                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio: this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhorto || 0
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objDetActuaciones;

                    Object.values(data1.recordset).map((type) => {

                        objDetActuaciones = new Object();
                        objDetActuaciones.crr_idsolicitud = type.crr_causa;
                        objDetActuaciones.rit = type.rit;
                        objDetActuaciones.gls_nomenclatura = type.gls_nomenclatura;
                        objDetActuaciones.tip_causa = type.tip_causa;
                        objDetActuaciones.rol_causa = type.rol_causa;
                        objDetActuaciones.era_causa = type.era_causa;
                        objDetActuaciones.fec_actuacion = type.fec_actuacion;
                        objDetActuaciones.fec_firma = type.fec_firma;
                        objDetActuaciones.gls_estfirma = type.gls_estfirma;
                        objDetActuaciones.nombre = type.nombre;

                        this.detalleData.push(objDetActuaciones);

                    })
                    this.setModal(false) // Para apagar el loaddin modal
            
                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })


            },
            
            resolucionesNomenclaturas: function(){
                const axios = require('axios');
                const req1 = urlApi + '/laboral/resoluciones_nomenclaturas_detalle';
                this.ancho = "1800px";
                this.detalleData = [];
                this.search = "";
                this.setModal(true); // Para cargar la ventana Modal
                //cabecera de la tabla
                this.tituloLabel= "Detalle de Resoluciones";
                let tipo_cargo = 0;

                this.headers = [
                    {text: 'ID Tramite', align: 'center', value: 'crr_idtramite', class : 'pjud white--text subtitle-2'},
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Nomenclatura', align: 'center', value: 'gls_nomenclatura', class : 'pjud white--text subtitle-2'},
                    {text: 'Procedimiento', align: 'center', value: 'procedimiento', class : 'pjud white--text subtitle-2'},
                    {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text subtitle-2'},
                    {text: 'Cargo Juez', align: 'center', value: 'cargo_juez', class : 'pjud white--text subtitle-2'},
                    {text: 'Funcionario', align: 'center', value: 'funcionario', class : 'pjud white--text subtitle-2'},
                    {text: 'Cargo Funcionario', align: 'center', value: 'cargo_funcionario', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Envío', align: 'center', value: 'fec_envio', class : 'pjud white--text subtitle-2'},
                    {text: 'Hora Envío', align: 'center', value: 'hora_envio', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Firma', align: 'center', value: 'fec_firma', class : 'pjud white--text subtitle-2'},
                    {text: 'Hora Firma', align: 'center', value: 'hora_firma', class : 'pjud white--text subtitle-2'},
                ]
                //cabecera del excel
                this.excelHead =[
                     { label: "ID Tramite",field: "crr_idtramite" }
                    ,{ label: "RIT",field: "rit" }
                    ,{ label: "Nomenclatura",field: "gls_nomenclatura" }
                    ,{ label: "Procedimiento",field: "procedimiento" }
                    ,{ label: "Juez",field: "juez" }
                    ,{ label: "Cargo Juez",field: "cargo_juez" }
                    ,{ label: "Funcionario",field: "funcionario" }
                    ,{ label: "Cargo Funcionario",field: "cargo_funcionario" }
                    ,{ label: "Fec. Envío",field: "fec_envio" }
                    ,{ label: "Hora Envío",field: "hora_envio" }
                    ,{ label: "Fec. Firma",field: "fec_firma" }
                    ,{ label: "Hora Firma",field: "hora_firma" }
                ];

                
                switch(this.tipoFuncionario){
                    case 'juez':
                        tipo_cargo = 2;
                        break;
                    case 'funcionario':
                        tipo_cargo = 3;
                        break;
                    default:
                        tipo_cargo = 0;
                        break;
                };


                axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                            id_funcionario: this.id_funcionario || 0,
                            tipo_cargo: tipo_cargo
                        }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objDetResNomenclatura;

                    Object.values(data1.recordset).map((type) => {

                        objDetResNomenclatura = new Object();
                        objDetResNomenclatura.crr_idtramite = type.crr_idtramite;
                        objDetResNomenclatura.rit = type.rit;
                        objDetResNomenclatura.gls_nomenclatura = type.gls_nomenclatura;
                        objDetResNomenclatura.procedimiento = type.procedimiento;
                        objDetResNomenclatura.juez = type.juez;
                        objDetResNomenclatura.cargo_juez = type.cargo_juez;
                        objDetResNomenclatura.funcionario = type.funcionario;
                        objDetResNomenclatura.cargo_funcionario = type.cargo_funcionario;
                        objDetResNomenclatura.fec_envio = type.fec_envio;
                        objDetResNomenclatura.hora_envio = type.hora_envio;
                        objDetResNomenclatura.fec_firma = type.fec_firma;
                        objDetResNomenclatura.hora_firma = type.hora_firma;

                        this.detalleData.push(objDetResNomenclatura)

                    })
                    this.setModal(false) // Para apagar el loaddin modal
            
                })).catch(errors => {
                    this.setModal(false)
                    console.log(errors)
                })


            },
        },
        computed: {
            ...mapState(['fechas','id_funcionario','tipoFuncionario'])
        },
        props: ['tipoModal']
}
</script>

<style scoped>

</style>