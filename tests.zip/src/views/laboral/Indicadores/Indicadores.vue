<template>
    <v-container fluid>
        <v-row dense>
            <v-col cols="12" xs12>
                <v-card>
                    <v-card-title>
                        <v-toolbar flat class="pjud">
                            <v-toolbar-title >
                                <h2 class="white--text">{{corte_descripcion}}</h2>
                            </v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                        </v-toolbar>
                    </v-card-title>
                    <v-card-subtitle>
                        <FiltrosCompetencias/>
                    </v-card-subtitle>
                    <v-card-text>
                        <v-simple-table
                            dense
                        >
                            <template v-slot:default>
                                <thead class="pjud">
                                    <tr>
                                        <th class="white--text text-center subtitle-2">
                                            TRIBUNAL
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            INGRESOS
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            TÉRMINOS
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            AUDIENCIAS
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            RESOLUCIONES
                                        </th>
                                        <th class="white--text text-center subtitle-2">
                                            ESCRITOS
                                        </th>   
                                        <th class="white--text text-center subtitle-2">
                                            ACTUACIONES
                                        </th>                                                                                                                              
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="item in dataResumenesIndicadores"
                                        :key="item.cod_tribunal"
                                        >
                                        <td>            
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralTablero', item.cod_corte, item.cod_tribunal)">  
                                                    {{item.gls_tribunal}}
                                                </span>  
                                            </a>                       
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralIngresos', item.cod_corte, item.cod_tribunal)">  
                                                    <countTo class="count" :startVal="0" :endVal="item.ingresos" separator="." :duration="1000"></countTo>
                                                </span>  
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralTerminos', item.cod_corte, item.cod_tribunal)">  
                                                    <countTo class="count" :startVal="0" :endVal="item.terminos" separator="." :duration="1000"></countTo>
                                                </span>  
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralAudiencias', item.cod_corte, item.cod_tribunal)">  
                                                    <countTo class="count" :startVal="0" :endVal="item.audiencias" separator="." :duration="1000"></countTo>
                                                </span>  
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralResoluciones', item.cod_corte, item.cod_tribunal)">  
                                                    <countTo class="count" :startVal="0" :endVal="item.resoluciones" separator="." :duration="1000"></countTo>
                                                </span>  
                                            </a>
                                        </td>       
                                        <td class="text-center">
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralEscritos', item.cod_corte, item.cod_tribunal)">  
                                                    <countTo class="count" :startVal="0" :endVal="item.escritos" separator="." :duration="1000"></countTo>
                                                </span>  
                                            </a>
                                        </td> 
                                        <td class="text-center">
                                            <a>
                                                <span v-on:click="goDetallesIndicadores('LaboralActuaciones', item.cod_corte, item.cod_tribunal)">  
                                                    <countTo class="count" :startVal="0" :endVal="item.actuaciones" separator="." :duration="1000"></countTo>
                                                </span>  
                                            </a>
                                        </td>                                                                                                                                                          
                                    </tr>
                                </tbody>
                                <tfoot class="pjud">
                                    <tr>
                                        <th class="white--text text-center">
                                            Totales
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('ingresos')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('terminos')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('audiencias')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('resoluciones')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('escritos')" separator="." :duration="1000"></countTo>
                                        </th>
                                        <th class="white--text text-center">
                                            <countTo class="count" :startVal="0" :endVal="calcularTotal('actuaciones')" separator="." :duration="1000"></countTo>
                                        </th>
                                    </tr>
                                </tfoot>
                            </template>
                        </v-simple-table>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import { urlApi } from '../../../config/api'
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias.vue'
import store from 'store'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'

export default {
	name: 'LaboralIndicadores',   
	data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email')
        },
        cod_corte: 0,
        corte_descripcion: '',
        cod_tribunal: 0,
        tribunales:[],
        dataResumenesIndicadores: [],     
	}),  
	created () {
        try {
            
            this.cod_corte = this.$route.params.cod_corte;
            this.getCorte();
            // this.getResumenIndicadores();

        } catch (error) {
            console.log(error.message)
        }
	},
    methods: {
        async getCorte(){

            try {
                
                const response = await  axios({
                                            method: 'GET',
                                            url: url+'/user/getUserCompetenciasCortesTribunales',
                                            headers: {},
                                            params:{
                                                usuario: this.usuario.usuario,
							                    competencia: 'Laboral',
                                                cod_corte: this.cod_corte
                                            }
                });

                this.corte_descripcion = response.data.competenciasCortesTribunales[0].corte_descripcion // Nombre de la Corte.

            } catch (error) {
                throw new Error(error.message);
            }
        },

        async getResumenIndicadores(){

            this.dataResumenesIndicadores = [];

            try {
                
                const response = await  axios({
                                            method: 'GET',
                                            url: urlApi+'/laboral/resumenes_indicadores',
                                            headers: {},
                                            params:{
                                                cod_corte: this.cod_corte
                                                ,anoInicio: this.fechas.anoInicio
                                                ,mesInicio: this.fechas.mesInicio
                                                ,anoFin: this.fechas.anoFin
                                                ,mesFin: this.fechas.mesFin
                                                ,flg_exhorto: this.fechas.exhorto
                                            }
                });

                const data = response.data;

                Object.values(data.recordset).map((res) => {

                        this.dataResumenesIndicadores.push({
                            cod_corte: res.cod_corte,
                            cod_tribunal: res.cod_tribunal,
                            id_corte_tribunal: res.id_corte_tribunal,
                            gls_tribunal: res.gls_tribunal,
                            ingresos: res.ingresos,
                            terminos: res.terminos,
                            resoluciones: res.resoluciones,
                            audiencias: res.audiencias,
                            escritos: res.escritos,
                            actuaciones: res.actuaciones
                        });

                });


            } catch (error) {
                throw new Error(error.message);
            }
        },

        goDetallesIndicadores(paramRoute, paramCod_corte, paramCod_tribunal){
            try {

                store.set('cod_tribunal', paramCod_tribunal);
                store.set('cod_corte', paramCod_corte);
                this.$router.push({ name: paramRoute });


            } catch (error) {
                console.log(error.message);
            }
        },
        formatNumber(number) {
            if (number != 0){
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            } else {
                return '-'
            }
        },
        calcularTotal(propiedad) {
            return this.dataResumenesIndicadores.reduce((total, item) => total + item[propiedad], 0);
        }

    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas() {
            // this.fechaPeriodo = this.fechas.periodo;
            this.getResumenIndicadores();
        }
    },
    components:{
        FiltrosCompetencias,
        countTo,
    }
}
</script>     