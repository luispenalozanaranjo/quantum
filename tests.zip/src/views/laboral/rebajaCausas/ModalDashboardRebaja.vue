<template>
    <v-card class="pdfi" id="pdfi">
        <v-card-text>
            <v-row md="12" class="mt-0" dense>
                <v-col sm="12">
                    <v-spacer></v-spacer>
                </v-col> 
                <v-col md="9">
                    <highcharts  :options="chartOptions" :constructor-type="'chart'" class="mt-2" />
                </v-col>
                <v-col md="2" class="ml-0">
                    <v-row justify="center">
                        <v-hover>
                            <v-card height="100" width="100%" color="pjud" class="cardAction">
                                <v-card-text class="white--text text-center">
                                    <h6>Causas en Tramitación al 31 de Diciembre de {{ ano - 1 }}</h6>
                                    <h4><countTo class="count" :startVal="0" :endVal="dataCard[0].INV_ANIO_ANTERIOR" separator="." :duration="3000"></countTo></h4>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                    <v-row class="py-2" justify="center">
                        <v-hover>
                            <v-card height="100" width="100%" color="pjud" class="cardAction">
                                <v-card-text class="white--text text-center">
                                    <h6>Causas en Tramitación al {{ ultimoDia }} de {{ nombreMes }} de {{ ano }}</h6>
                                    <h4><countTo class="count" :startVal="0" :endVal="dataCard[0].INV_MES" separator="." :duration="3000"></countTo></h4>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                    <v-row class="py-2" justify="center">
                        <v-hover>
                            <v-card height="100" width="100%" color="pjud" class="cardAction">
                                <v-card-text class="white--text text-center">
                                    <h6>Total Causas Rebajadas</h6>
                                    <h4><countTo class="count" :startVal="0" :endVal="dataCard[0].REBAJA_MES" separator="." :duration="3000"></countTo></h4>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                    <v-row class="py-2" justify="center">
                        <v-hover>
                            <v-card height="100" width="100%" color="pjud" class="cardAction">
                                <v-card-text class="white--text text-center">
                                    <h6>Porcentaje Causas Rebajadas</h6>
                                    <h4><countTo class="count" :startVal="0" :endVal="((dataCard[0].REBAJA_MES / dataCard[0].INV_ANIO_ANTERIOR)*100)" separator="." :duration="3000" :decimals="1"></countTo>%</h4>
                                </v-card-text>
                            </v-card>
                        </v-hover>
                    </v-row>
                </v-col>
            </v-row>
        </v-card-text>
    <ModalLoading/>
    </v-card>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
// import exporta from 'highcharts/modules/export-data'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import ModalDetalleInventario from './ModalDetallesInventario'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"
import moment from 'moment-timezone'
moment.locale('es');

loadDrillDown(HighCharts)
stockInit(HighCharts)
exporting(HighCharts)

export default {
    name: 'DetalleInventario',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            Query_Ingreso: [],
            dialog: false,
            totaNolMasivo: 0,       
            headers: [
                { text: 'COD_CORTE',  align: 'center', class : 'pjud white--text', width: '5%'},
                { text: 'CORTE',  align: 'center', class : 'pjud white--text', width: '10%' },
                { text: 'COD_TRIBUNAL', align: 'center', class : 'pjud white--text', width: '5%' },
                { text: 'TRIBUNAL', align: 'center', class : 'pjud white--text', width: '10%' }
              ],
            excelHead : [
                {
                    label: "Ingreso",
                    field: "ingreso",
                },
                {
                    label: "Masiva",
                    field: "masivo",
                },
                {
                    label: "No Masiva",
                    field: "nomasivo",
                }                                                                                                                                                                                  
            ],
            excelHead2 : [
                {
                    label: "#",
                    field: "increment",
                },
                {
                    label: "Tipo Materia",
                    field:  "gls_materia",
                },
                {
                    label: "Cantidad",
                    field:  "cantidad",
                }                                                                                                                                                        
            ],
            total : 0 ,
            fechaPeriodo: '',
            chartOptions: JSON.parse(JSON.stringify(Graph['lines'][0])),
            detalleInventario: [],
            search: '',
            page: 1,
            pageCount: 0,
            itemsPerPage: 10,
            dataCard: [],
            mes: store.get('mes'),
            ano: store.get('ano'),
            nombreMes: '',
            ultimoDia: 0,
            headersDetalle: [
                {text: '#', align: 'center', value: 'increment', class : 'pjud white--text', width: '2%'},
                {text: 'CÓD. CORTE', align: 'center', value: 'codigo_corte', class : 'pjud white--text', width: '4%'},
                {text: 'CORTE', align: 'center', value: 'corte', class : 'pjud white--text', width: '6%'},
                {text: 'CÓD. TRIBUNAL', align: 'center', value: 'codigo_tribunal', class : 'pjud white--text', width: '4%'},
                {text: 'TRIBUNAL', align: 'center', value: 'tribunal', class : 'pjud white--text', width: '6%'},
                {text: 'TIPO CAUSA', align: 'center', value: 'tipo_causa', class : 'pjud white--text', width: '8%'},
                {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text', width: '8%'},
                {text: 'AÑO', align: 'center', value: 'ano', class : 'pjud white--text', width: '8%'},
                {text: 'FECHA INGRESO', align: 'center', value: 'fecha_ingreso', class : 'pjud white--text', width: '8%'},
                {text: 'CÓD. MATERIA', align: 'center', value: 'codigo_materia', class : 'pjud white--text', width: '8%'},
                {text: 'MATERIA', align: 'center', value: 'materia', class : 'pjud white--text', width: '8%'},
                {text: 'ETAPA CAUSA', align: 'center', value: 'etapa_causa', class : 'pjud white--text', width: '8%'},
                {text: 'ULT. DILIGENCIA', align: 'center', value: 'ult_diligencia', class : 'pjud white--text', width: '8%'},
                {text: 'FECHA ULT. DILIGENCIA', align: 'center', value: 'fecha_ult_diligencia', class : 'pjud white--text', width: '10%'}
            ],
            excelHeadDetalle :[
                 { label: "#",field: "increment" }
                ,{ label: "CÓD. CORTE",field: "codigo_corte" }
                ,{ label: "CORTE",field: "corte" }
                ,{ label: "CÓD. TRIBUNAL",field: "codigo_tribunal" }
                ,{ label: "TRIBUNAL",field: "tribunal" }
                ,{ label: "TIPO CAUSA",field: "tipo_causa" }
                ,{ label: "RIT",field: "rit" }
                ,{ label: "AÑO",field: "ano" }
                ,{ label: "CÓD. MATERIA",field: "codigo_materia" }
                ,{ label: "MATERIA",field: "materia" }
                ,{ label: "ETAPA CAUSA",field: "etapa_causa" }
                ,{ label: "ULT. DILIGENCIA",field: "ult_diligencia" }
                ,{ label: "FECHA ULT. DILIGENCIA",field: "fecha_ult_diligencia" }
            ]
        }
    },
    created(){
        this.consulta_ingreso()
    },
    components: {
        // FiltrosCompetencias,
        ModalLoading,
        highcharts: Chart,
        ModalDetalleInventario,
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar
        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
            html2canvas(document.querySelector('.pdfi')).then(canvas => {
                let image = canvas.toDataURL('image/png')
                
                let doc = new jsPDF('p', 'pt', 'a1');
                doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
                doc.save('DashboardIngresos.pdf')
            })    
        },
        consulta_ingreso(){
            this.setModal(true) // Aqui Manipulamos el modal
            const objFechas = store.get('fechas')
            // this.ano = (this.fechas.mes == 1)?this.fechas.ano - 1:this.fechas.ano;
            this.ano = this.fechas.ano;
            this.nombreMes = moment.months()[(this.fechas.mes - 1)]
            this.ultimoDia = moment((this.fechas.mes), 'MM').endOf('month').format('DD')
            const axios = require('axios')
            if(!isNaN(this.fechas.corte)){
                const req1 = 'https://estadisticaservices.pjud.cl/laboral/grafico/'+ this.fechas.corte +'/'+ this.fechas.tribunal +'/' + (this.fechas.ano - 1)  
                const req2 = 'https://estadisticaservices.pjud.cl/multi/resumen_rebaja_causas/'+ this.fechas.corte +'/' + this.fechas.tribunal + '/'+ this.fechas.ano + '/' + this.fechas.mes + '/LABORAL'
                this.Query_Ingreso = []
                this.dataCard = []
                this.total = 0
                this.fechaPeriodo = this.fechas.periodo

                axios.all([
                        axios.get(req1),
                        axios.get(req2)
                    ]).then(axios.spread((...responses) => {

                        let data = responses[0].data
                        this.dataCard = responses[1].data
                        let desde = data.length - 11
                        let res = []
                        for (let i = desde; i < data.length; i++ ){
                            res.push(data[i]);
                        }
                        let seriel    = [];
                        let mes       = [];
                        Object.values(res).map((type) => {
                                seriel.push(type.count);
                                if ( type._id.PERIODO_MES == 1 )
                                mes.push('Ene - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 2 )
                                mes.push('Feb - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 3 )
                                mes.push('Mar - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 4 )
                                mes.push('Abr - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 5 )
                                mes.push('May - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 6 )
                                mes.push('Jun - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 7 )
                                mes.push('Jul - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 8 )
                                mes.push('Ago - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 9 )
                                mes.push('Sep - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 10 )
                                mes.push('Oct - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 11 )
                                mes.push('Nov - '+type._id.PERIODO_ANO);
                                else if ( type._id.PERIODO_MES == 12 )
                                mes.push('Dic - '+type._id.PERIODO_ANO);
                        });
                        this.chartOptions.xAxis.categories = mes
                        this.chartOptions.yAxis.title.text = 'Causas en Tramitación'
                        this.chartOptions.chart.height = 350
                        this.chartOptions.series = []
                        this.chartOptions.series.push({
                                data: seriel,
                                name: 'Periodo'
                            })
                        this.setModal(false) // Aqui Manipulamos el modal
                    })).catch(errors => {
                        this.setModal(false)
                        console.log(errors)
                })   
            }
        }
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.consulta_ingreso()
        }
    }
} 
</script>