<template>
    <v-card class="pdfit grey">
        <v-card>
            <v-card-title>
                Porcentaje de audiencias por tipo
            </v-card-title>
            <v-card-subtitle>
                {{ fechas.periodo }}
            </v-card-subtitle>
            <v-card-text>
                <apexchart
                    height="350"
                    :options="pieChartOptions"
                    :series="pieSeries"
                    ref="pieGrafico"
                ></apexchart>
            </v-card-text>
        </v-card>
        <v-card class="mt-1">
            <v-card-title>
                Porcentaje de audiencias por estado
                <v-spacer></v-spacer>
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <v-icon
                            color="orange"
                            dark
                            large
                            v-bind="attrs"
                            v-on="on"
                        >
                            mdi-information-outline
                        </v-icon>
                    </template>
                    <h4 class="orange--text">Criterios</h4>
                    Audiencias Realizadas:<br/>
                    <ul>
                        <li>• Estados "Audiencias Firmadas" y "Grabadas"</li>
                        <li>• Tramite "Firmado" y "Pregrabado"</li>
                        <li>• Excluye estado procesal "Invalidado"</li>
                    </ul>
                    Audiencias No Realizadas:<br/>
                    <ul>
                        <li>• Estado "No Realizada"</li>
                        <li>• Nomenclatura "Audiencia no realizada"</li>
                    </ul>
                    Audiencias Suspendidas:<br/>
                    <ul>
                        <li>• Estado "Suspendida"</li>
                        <li>• Nomenclatura "Suspensión de la audiencia"</li>
                    </ul>
                    Audiencias Reprogramadas:<br/>
                    <ul>
                        <li>• Estado "No Realizada"</li>
                        <li>• Nomenclatura "Reprogramar"</li>
                        <li>• Excluye motivos de suspension "Ddo. no se presenta" y "Dte. no se presenta"</li>
                    </ul>
                </v-tooltip>
            </v-card-title>
            <v-card-subtitle>
                {{ fechas.periodo }}
            </v-card-subtitle>
            <v-card-text>
                <apexchart
                    height="350"
                    :options="pieChartOptionsEstados"
                    :series="pieSeriesEstados"
                    ref="pieGrafico2"
                ></apexchart>
            </v-card-text>
        </v-card>
        <v-card class="mt-1">
            <v-card-title>
                Resumen audiencias por estado
            </v-card-title>
            <v-card-subtitle>
                {{ fechas.periodo }}
            </v-card-subtitle>
            <v-card-text>
                <v-simple-table dense>
                    <template>
                        <thead>
                            <tr>
                                <th
                                    v-for="item in headersAudienciasEstados"
                                    :key="item.index"
                                    class="pjud white--text text-center subtitle-2"
                                >
                                    {{ item.text }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="(item, index) in dataAudienciasEstados"
                                :key="index"
                            >
                                <td class="text-center">
                                    {{ item.increment }}
                                </td>
                                <td class="text-center">
                                    {{ item.estado_audiencias }}
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasEstadosDetalle(
                                                item.id_estado_audiencia
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.cantidad"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="pjud white--text">
                                <th></th>
                                <th class="text-center subtitle-2">Total</th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totalEstadosAudiencias"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                            </tr>
                        </tfoot>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-card>
        <v-card class="mt-1">
            <v-card-title>
                Resumen programación audiencias por tipo
            </v-card-title>
            <v-card-subtitle>
                {{ fechas.periodo }}
            </v-card-subtitle>
            <v-card-text>
                <v-simple-table dense>
                    <template>
                        <thead>
                            <tr>
                                <th
                                    v-for="item in headersAudienciasTipos"
                                    :key="item.index"
                                    class="pjud white--text text-center subtitle-2"
                                >
                                    {{ item.text }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="(item, index) in dataAudienciasTipos"
                                :key="index"
                            >
                                <td class="text-center">
                                    {{ item.increment }}
                                </td>
                                <td class="text-center">
                                    {{ item.tipoAudiencia }}
                                </td>
                                <td class="text-center">
                                    {{ item.diasPromedio }}
                                </td>
                                <td class="text-center">
                                    {{ item.minPromedio }}
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasTipoDetalle(
                                                item.id_tipo_audiencia
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.cantidad"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="pjud white--text">
                                <th></th>
                                <th class="text-center subtitle-2">Total</th>
                                <th></th>
                                <th></th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totalTiposAudiencias"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                            </tr>
                        </tfoot>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-card>

        <v-card class="mt-1">
            <v-card-title>
                Detalles programación audiencia por procedimiento anual
            </v-card-title>
            <v-card-subtitle>
                {{ fechas.periodo }}
            </v-card-subtitle>
            <v-card-text>
                <v-simple-table dense>
                    <template>
                        <thead class="pjud Separador">
                            <tr>
                                <th
                                    rowspan="2"
                                    class="white--text text-center subtitle-2"
                                >
                                    Procedimiento
                                </th>
                                <th
                                    colspan="12"
                                    class="white--text text-center subtitle-2 "
                                >
                                    Cantidad de Audiencias
                                </th>
                                <th
                                    rowspan="2"
                                    class="white--text text-center subtitle-2 "
                                >
                                    Total
                                </th>
                            </tr>
                            <tr>
                                <th class="white--text text-center subtitle-2">
                                    Ene
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Feb
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Mar
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Abr
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    May
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Jun
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Jul
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Ago
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Sep
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Oct
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Nov
                                </th>
                                <th class="white--text text-center subtitle-2 ">
                                    Dic
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="(item,
                                index) in dataAudienciasProcedimientos"
                                :key="index"
                            >
                                <td class="text-center">
                                    {{ item.name }}
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                1
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.enero"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                2
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.febrero"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                3
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.marzo"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                4
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.abril"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                5
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.mayo"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                6
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.junio"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                7
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.julio"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                8
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.agosto"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                9
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.septiembre"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                10
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.octubre"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                11
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.noviembre"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasProcedimientosDetalle(
                                                item.name,
                                                12
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.diciembre"
                                            separator="."
                                            :duration="1500"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.total"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="pjud white--text">
                                <th class="text-center subtitle-2">Total</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totalAudienciasProc"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                            </tr>
                        </tfoot>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-card>
        <v-card class="mt-1">
            <v-card-title>
                Audiencias por procedimiento division anual
            </v-card-title>
            <v-card-subtitle> Año: {{ fechas.anoInicio }} </v-card-subtitle>
            <v-card-text>
                <apexchart
                    type="line"
                    height="350"
                    :options="pieChartOptionsLine"
                    :series="pieSeriesLine"
                    ref="lineChart"
                ></apexchart>
            </v-card-text>
        </v-card>

        <!-- MODAL -->
        <v-dialog max-width="1200px" v-model="dialog">
            <v-card>
                <v-card-title class="pjud white--text">
                    {{ tituloLabel }}
                    <v-spacer></v-spacer>
                    <v-btn color="error" @click="dialog = false" large>
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-col>
                                <vue-excel-xlsx
                                    class="btn text-center"
                                    :data="dataModalDetalle"
                                    :columns="excelHead"
                                    :filename="'Detalles'"
                                    :sheetname="'Hoja1'"
                                >
                                    <v-tooltip top>
                                        <template
                                            v-slot:activator="{ on, attrs }"
                                        >
                                            <v-btn
                                                class="mx-2"
                                                fab
                                                dark
                                                small
                                                color="success"
                                                v-bind="attrs"
                                                v-on="on"
                                            >
                                                <v-icon
                                                    >mdi-microsoft-excel</v-icon
                                                >
                                            </v-btn>
                                        </template>
                                        <span>Exportar a excel</span>
                                    </v-tooltip>
                                </vue-excel-xlsx>
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col>
                                <v-text-field
                                    v-model="search"
                                    append-icon=""
                                    label="Buscar"
                                    single-line
                                    hide-details
                                ></v-text-field>
                                <v-data-table
                                    :headers="headers"
                                    :items="dataModalDetalle"
                                    :search="search"
                                    disable-sort
                                    dense
                                    class="mt-4"
                                >
                                </v-data-table>
                            </v-col>
                        </v-row>
                        <!-- <ModalLoading/> -->
                    </v-container>
                </v-card-text>
            </v-card>
        </v-dialog>
    </v-card>
</template>
<script>

import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import es from "apexcharts/dist/locales/es.json";
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"


export default {
    name: 'AudienciasTotales',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            pieSeriesLine: [{
                name: "Desktops",
                data: [10, 41, 35, 51, 49, 62, 69, 91, 148,200,10,100]
            }],
            pieChartOptionsLine: {
                chart: {
                    id: 'lineChart',
                    height: 350,
                    type: 'line',
                    zoom: {
                        enabled: false
                    }
                },
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    width: [5, 5, 5, 5 ,5],
                    curve: 'smooth'
                },
                legend: {
                    tooltipHoverFormatter: function(val, opts) {
                        return val + ' - ' + opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex] + ''
                    }
                },
                markers: {
                    size: 3,
                    hover: {
                        sizeOffset: 6
                    }
                },
                grid: {
                    borderColor: '#f1f1f1',
                },
                xaxis: {
                    categories: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep','Oct','Nov','Dic'],
                }
			}, 
            pieSeriesEstados: [],
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    id: 'pieGrafico',
                    height: 400,
                    type: 'pie',
                    locales: [es],
                    defaultLocale: "es", 
                },
                noData: {
                    text: 'Visualizando'
                },  
                dataLabels: {
                    enabled: true,
                    formatter: function (val) {
                        return val.toFixed(2).toString().replace('.',',') + '%'
                    }  
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                }
			}, 
            pieSeriesEstados: [],
            pieChartOptionsEstados: {
                chart: {
                    id: 'pieGrafico2',
                    height: 400,
                    type: 'pie',
                    locales: [es],
                    defaultLocale: "es", 
                },
                noData: {
                    text: 'Visualizando'
                },  
                dataLabels: {
                    enabled: true,
                    formatter: function (val) {
                        return val.toFixed(2).toString().replace('.',',') + '%'
                    }  
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                }
			}, 
            headersAudienciasEstados: [
                { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text caption',},
                { text: 'Estado Audiencias',  align: 'center', value: 'estado_audiencias', class : 'pjud white--text caption'},
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text caption' }
            ],
            dataAudienciasEstados: [],  
            headersAudienciasTipos: [
                { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text caption',},
                { text: 'Tipo Audiencia',  align: 'center', value: 'tipoAudiencia', class : 'pjud white--text caption'},
                { text: 'Días Promedio', align: 'center', value: 'diasPromedio', class : 'pjud white--text caption' },
                { text: 'Minutos Promedio', align: 'center', value: 'minPromedio', class : 'pjud white--text caption' },
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text caption' },
            ],
            dataAudienciasTipos: [],  
            totalEstadosAudiencias: 0,
            totalTiposAudiencias: 0,
            dataAudienciasProcedimientos: [],
            totalAudienciasProc: 0,
            dataModalDetalle: [],
            tituloLabel: '',
            dialog: false,
            headers: [],
            search: '',
            excelHead: [],

        }
    },
    created(){
        try {
            this.$gtag.event('laboral_audiencias_totales', { method: 'Google' });
            this.getAudienciasTipos();
            this.getAudienciasEstados();
            this.getAudienciasProcedimientos();
            
        } catch (error) {
            console.log(error);
        }
        
    },
    components: {
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar
         
        // downloadPDF(){
        //     // window.scrollTo(0,0) // Desplaza hacia arriba
                
        //     html2canvas(document.querySelector('.pdfit')).then(canvas => {
        //         let image = canvas.toDataURL('image/png')
        //         let doc = new jsPDF('p', 'pt', 'a1');
        //         doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
        //         doc.save('DashboardIngresos.pdf')
        //     })       
        // },

        async getAudienciasTipos() {
            // this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_tipos' ;
            let dataLabelsAux = [];
            let dataSeriesAux = [];
            this.dataAudienciasTipos = [];
            this.totalTiposAudiencias = 0;


            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0
                        }
                    });
                        
                    const data = response.data;
                    let contador = 1;

                    Object.values(data.recordset).map((type) => {

                        dataLabelsAux.push(type.tipoaudiencia);
                        dataSeriesAux.push(type.cantidad);

                        this.dataAudienciasTipos.push({
                            increment: contador,
                            tipoAudiencia: type.tipoaudiencia,
                            id_tipo_audiencia: type.id_tipo_audiencia,
                            diasPromedio: type.promedio,
                            minPromedio: type.min,
                            cantidad: type.cantidad
                        });

                        this.totalTiposAudiencias += type.cantidad;
                        contador ++;

                    })

                    //Series
                    this.pieSeries = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);


                } 
                catch (error) {
                        console.log(error)
                }
            }


            get(req1);                 
            
        },

        async getAudienciasEstados() {
            // this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_estados' ;
            let dataLabelsAux = [];
            let dataSeriesAux = [];
            this.dataAudienciasEstados = [];
            this.totalEstadosAudiencias = 0;

            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0
                        }
                    });
                        
                    const data = response.data;
                    let contador = 1;

                    Object.values(data.recordset).map((type) => {

                        dataLabelsAux.push(type.estado_audiencias);
                        dataSeriesAux.push(type.cantidad);

                        this.dataAudienciasEstados.push({
                            increment: contador,
                            estado_audiencias: type.estado_audiencias,
                            cantidad: type.cantidad,
                            id_estado_audiencia: type.id_estado_audiencia
                        });

                        this.totalEstadosAudiencias += type.cantidad;

                        contador ++;

                    });

                    //Series
                    this.pieSeriesEstados = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico2', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);
                    


                } 
                catch (error) {
                    console.log(error);
                }
            }


            get(req1);

            // this.setModal(false) // Aqui Manipulamos el modal                     
            
        },

        async getAudienciasProcedimientos() {
            // this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_procedimientos' ;
            this.dataAudienciasProcedimientos = [];
            this.totalAudienciasProc = 0;
            this.pieSeriesLine = new Array();

            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0
                        }
                    });
                        
                    const data = response.data;
                    let auxArray = [];
                    let totalizador = 0;
                    let auxTotal = 0;

                    //Obtengo solo los codigos de las nomenclaturas
                    let dataProcedimientos = data.recordset.map(a => a.procedimiento);
                    //dejo los valores unicos
                    dataProcedimientos = dataProcedimientos.filter((v, i, a) => a.indexOf(v) === i);

                    dataProcedimientos.forEach(e => {

                        auxArray = data.recordset.filter(element => element.procedimiento == e);
                        auxArray = auxArray.map(a => a.cantidad);
                        totalizador = auxArray.reduce((a, b) => a + b, 0);
                        
                        this.dataAudienciasProcedimientos.push({
                            name: e,
                            enero: data.recordset.find(element => element.procedimiento == e && element.mes == 1) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 1).cantidad,
                            febrero: data.recordset.find(element => element.procedimiento == e && element.mes == 2) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 2).cantidad,
                            marzo: data.recordset.find(element => element.procedimiento == e && element.mes == 3) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 3).cantidad,
                            abril: data.recordset.find(element => element.procedimiento == e && element.mes == 4) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 4).cantidad,
                            mayo: data.recordset.find(element => element.procedimiento == e && element.mes == 5) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 5).cantidad,
                            junio: data.recordset.find(element => element.procedimiento == e && element.mes == 6) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 6).cantidad,
                            julio: data.recordset.find(element => element.procedimiento == e && element.mes == 7) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 7).cantidad,
                            agosto: data.recordset.find(element => element.procedimiento == e && element.mes == 8) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 8).cantidad,
                            septiembre: data.recordset.find(element => element.procedimiento == e && element.mes == 9) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 9).cantidad,
                            octubre: data.recordset.find(element => element.procedimiento == e && element.mes == 10) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 10).cantidad,
                            noviembre: data.recordset.find(element => element.procedimiento == e && element.mes == 11) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 11).cantidad,
                            diciembre: data.recordset.find(element => element.procedimiento == e && element.mes == 12) == undefined ? 0 : data.recordset.find(element => element.procedimiento == e && element.mes == 12).cantidad,
                            total: totalizador,
                        });

                        this.totalAudienciasProc += totalizador;
                        

                    });

                    auxArray = this.dataAudienciasProcedimientos.sort(function(a, b){return b.total  - a.total})

                    auxArray.forEach(e => {

                        this.pieSeriesLine.push({
                            name : e.name,
                            data: [
                                e.enero,
                                e.febrero,
                                e.marzo,
                                e.abril,
                                e.mayo,
                                e.junio,
                                e.julio,
                                e.agosto,
                                e.septiembre,
                                e.noviembre,
                                e.diciembre
                            ]
                        });

                    });


                } 
                catch (error) {
                    console.log(error);
                }
            }


            get(req1);

            // this.setModal(false) // Aqui Manipulamos el modal                     
            
        },

        async getAudienciasEstadosDetalle(id_estado_audiencia){
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_estados_detalle' ;
            this.dataModalDetalle = [];
            this.tituloLabel = 'Detalle Audiencias Estados'
            this.headers = [
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Tipo Audiencia', align: 'center', value: 'tipo_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Estado Audiencia', align: 'center', value: 'estado_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Audiencia', align: 'center', value: 'fecha_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text subtitle-2'},
                    {text: 'Motivo', align: 'center', value: 'motivo', class : 'pjud white--text subtitle-2'}
            ]

            this.excelHead =[
                    { label: "RIT",field: "rit" }
                    ,{ label: "Tipo Audiencia",field: "tipo_audiencia" }
                    ,{ label: "Estado Audiencia",field: "estado_audiencia" }
                    ,{ label: "Fec. Audiencia",field: "fecha_audiencia" }
                    ,{ label: "Juez",field: "juez" }
                    ,{ label: "Motivo",field: "motivo" }
            ]


            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0,
                            id_estado_audiencia: id_estado_audiencia || 0,
                        }
                    });
                        
                    const data = response.data;

                    Object.values(data.recordset).map((type) => {

                        this.dataModalDetalle.push({
                            rit: type.rit,
                            tipo_audiencia: type.gls_tipaudiencia,
                            estado_audiencia: type.gls_estaudiencia,
                            fecha_audiencia: type.fec_audiencia,
                            juez: type.nombre_completo,
                            motivo: type.gls_motsuspaud
                        });
                    });

                    this.dialog = true;


                } 
                catch (error) {
                    console.log(error);
                    this.dialog = false;
                }
            }


            get(req1);
      
        },

        async getAudienciasTipoDetalle(id_tipo_audiencia){
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_tipos_detalle' ;

            this.dataModalDetalle = [];
            this.tituloLabel = 'Detalle Audiencias Tipos'
            this.headers = [
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Tipo Audiencia', align: 'center', value: 'tipo_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Estado Audiencia', align: 'center', value: 'estado_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Audiencia', align: 'center', value: 'fecha_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text subtitle-2'},
                    {text: 'Motivo', align: 'center', value: 'motivo', class : 'pjud white--text subtitle-2'}
            ]

            this.excelHead =[
                    { label: "RIT",field: "rit" }
                    ,{ label: "Tipo Audiencia",field: "tipo_audiencia" }
                    ,{ label: "Estado Audiencia",field: "estado_audiencia" }
                    ,{ label: "Fec. Audiencia",field: "fecha_audiencia" }
                    ,{ label: "Juez",field: "juez" }
                    ,{ label: "Motivo",field: "motivo" }
            ]


            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0,
                            id_tipo_audiencia: id_tipo_audiencia || 0,
                        }
                    });
                        
                    const data = response.data;

                    Object.values(data.recordset).map((type) => {

                        this.dataModalDetalle.push({
                            rit: type.rit,
                            tipo_audiencia: type.gls_tipaudiencia,
                            estado_audiencia: type.gls_estaudiencia,
                            fecha_audiencia: type.fec_audiencia,
                            juez: type.nombre_completo,
                            motivo: type.gls_motsuspaud
                        });
                    });

                    this.dialog = true;


                } 
                catch (error) {
                    console.log(error);
                    this.dialog = false;
                }
            }


            get(req1);
      
        },

        async getAudienciasProcedimientosDetalle(gls_tipo_causa, mes){
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_procedimientos_detalle' ;

            this.dataModalDetalle = [];
            this.tituloLabel = 'Detalle Audiencias Procedimientos'
            this.headers = [
                    {text: 'RIT', align: 'center', value: 'rit', class : 'pjud white--text subtitle-2'},
                    {text: 'Tipo Audiencia', align: 'center', value: 'tipo_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Estado Audiencia', align: 'center', value: 'estado_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Fec. Audiencia', align: 'center', value: 'fecha_audiencia', class : 'pjud white--text subtitle-2'},
                    {text: 'Juez', align: 'center', value: 'juez', class : 'pjud white--text subtitle-2'},
                    {text: 'Motivo', align: 'center', value: 'motivo', class : 'pjud white--text subtitle-2'}
            ]

            this.excelHead =[
                    { label: "RIT",field: "rit" }
                    ,{ label: "Tipo Audiencia",field: "tipo_audiencia" }
                    ,{ label: "Estado Audiencia",field: "estado_audiencia" }
                    ,{ label: "Fec. Audiencia",field: "fecha_audiencia" }
                    ,{ label: "Juez",field: "juez" }
                    ,{ label: "Motivo",field: "motivo" }
            ]


            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: mes || this.$route.params.mes,
                            anoFin: this.fechas.anoInicio || this.$route.params.ano,
                            mesFin: mes || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0,
                            gls_tipo_causa: gls_tipo_causa || 0,
                        }
                    });
                        
                    const data = response.data;

                    Object.values(data.recordset).map((type) => {

                        this.dataModalDetalle.push({
                            rit: type.rit,
                            tipo_audiencia: type.gls_tipaudiencia,
                            estado_audiencia: type.gls_estaudiencia,
                            fecha_audiencia: type.fec_audiencia,
                            juez: type.nombre_completo,
                            motivo: type.gls_motsuspaud
                        });
                    });

                    this.dialog = true;


                } 
                catch (error) {
                    console.log(error);
                    this.dialog = false;
                }
            }


            get(req1);
      
        }

    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.getAudienciasTipos();
            this.getAudienciasEstados();
            this.getAudienciasProcedimientos();
        }
    }
} 
</script>



<style lang="css" scoped>

.Separador th {
    border: 1px solid rgb(190, 190, 190);
    white-space: nowrap;
}


</style>