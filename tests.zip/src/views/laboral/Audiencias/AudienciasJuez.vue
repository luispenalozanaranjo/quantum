<template>
    <v-card class="pdfit grey">
        <v-card>
            <v-card-title>
                Detalle jueces por tipo audiencia
            </v-card-title>
            <v-card-subtitle>
                {{ fechas.periodo }}
            </v-card-subtitle>
            <v-card-text>
                <apexchart
                    :options="barChartOptions"
                    :series="barSeries"
                    ref="barChart"
                ></apexchart>
            </v-card-text>
        </v-card>
        <v-card class="mt-1">
            <v-card-title>
                <v-list-item two-line>
                    <v-list-item-content>
                        <v-list-item-title class="headline"
                            >Cantidad de audiencia por juez y
                            tipo</v-list-item-title
                        >
                        <v-list-item-subtitle class="font-italic">{{
                            fechas.periodo
                        }}</v-list-item-subtitle>
                    </v-list-item-content>
                </v-list-item>
            </v-card-title>
            <v-card-text>
                <v-simple-table fixed-header height="700px">
                    <template v-slot:default>
                        <thead>
                            <tr>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    Juez
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    Tipo Audiencia
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    Cantidad
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    T
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    M
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    O
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    I
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    S
                                </th>
                                <th
                                    class="pjud white--text subtitle-2 text-center"
                                >
                                    Promedio Duración(Min,)
                                </th>
                            </tr>
                        </thead>
                        <tbody v-for="(juez, index) in dataJuez" :key="index">
                            <tr class="Separador">
                                <td
                                    :rowspan="
                                        dataAudienciasJuez.filter(
                                            aud => aud.juez == juez
                                        ).length + 1
                                    "
                                >
                                    {{ juez }}
                                </td>
                            </tr>
                            <tr
                                v-for="(item,
                                index) in dataAudienciasJuez.filter(
                                    aud => aud.juez == juez
                                )"
                                :key="index"
                                class="Separador"
                            >
                                <td>{{ item.tipo_audiencia }}</td>
                                <td class="text-center">
                                    <v-btn
                                        text
                                        @click.stop="
                                            getAudienciasJuezDetalle(
                                                item.id_tipo_audiencia,
                                                item.id_funcionario
                                            )
                                        "
                                    >
                                        <countTo
                                            :startVal="0"
                                            :endVal="item.cantidad"
                                            separator="."
                                            :duration="2000"
                                        ></countTo>
                                    </v-btn>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.T"
                                        separator="."
                                        :duration="2000"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.M"
                                        separator="."
                                        :duration="2000"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.O"
                                        separator="."
                                        :duration="2000"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.I"
                                        separator="."
                                        :duration="2000"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.S"
                                        separator="."
                                        :duration="2000"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.duracion"
                                        separator="."
                                        :duration="2000"
                                    ></countTo>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="pjud white--text">
                                <th class="text-center subtitle-2">Total</th>
                                <th></th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalAudienciasJuez"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalT"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalM"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalO"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalI"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalS"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                                <th class="text-center subtitle-2">
                                    <countTo
                                        :startVal="0"
                                        :endVal="totales.totalDuracion"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </th>
                            </tr>
                        </tfoot>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-card>

        <!-- MODAL -->
        <v-dialog max-width="1200px" v-model="dialog">
            <v-card>
                <v-card-title class="pjud white--text">
                    {{ tituloLabel }}
                    <v-spacer></v-spacer>
                    <v-btn color="error" @click="dialog = false" large>
                        x
                    </v-btn>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-col>
                                <vue-excel-xlsx
                                    class="btn text-center"
                                    :data="dataModalDetalle"
                                    :columns="excelHead"
                                    :filename="'Detalles'"
                                    :sheetname="'Hoja1'"
                                >
                                    <v-tooltip top>
                                        <template
                                            v-slot:activator="{ on, attrs }"
                                        >
                                            <v-btn
                                                class="mx-2"
                                                fab
                                                dark
                                                small
                                                color="success"
                                                v-bind="attrs"
                                                v-on="on"
                                            >
                                                <v-icon
                                                    >mdi-microsoft-excel</v-icon
                                                >
                                            </v-btn>
                                        </template>
                                        <span>Exportar a excel</span>
                                    </v-tooltip>
                                </vue-excel-xlsx>
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col>
                                <v-text-field
                                    v-model="search"
                                    append-icon=""
                                    label="Buscar"
                                    single-line
                                    hide-details
                                ></v-text-field>
                                <v-data-table
                                    :headers="headers"
                                    :items="dataModalDetalle"
                                    :search="search"
                                    disable-sort
                                    dense
                                    class="mt-4"
                                >
                                </v-data-table>
                            </v-col>
                        </v-row>
                        <!-- <ModalLoading/> -->
                    </v-container>
                </v-card-text>
            </v-card>
        </v-dialog>
    </v-card>
</template>

<script>
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

export default {
    name: 'AudienciasTotales',
    data() {
        return {
            user: [
                {
                    usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                    cod_corte: store.get('cod_corte'),
                    cod_tribunal: store.get('cod_tribunal'),
                    ano: store.get('ano'),
                    mes: store.get('mes'),
                },
            ],
            search: '',
            tituloLabel: '',
            excelHead: [
                { label: 'RIT', field: 'rit' },
                { label: 'Tipo Audiencia', field: 'tipo_audiencia' },
                { label: 'Estado Audiencia', field: 'estado_audiencia' },
                { label: 'Fec. Audiencia', field: 'fecha_audiencia' },
                { label: 'Juez', field: 'juez' },
                { label: 'Motivo', field: 'motivo' },
                { label: 'Procedimiento', field: 'tipo_causa' },
                { label: 'Duración Minutos', field: 'duracion' },
            ],
            headers: [
                {
                    text: 'RIT',
                    align: 'center',
                    value: 'rit',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Tipo Audiencia',
                    align: 'center',
                    value: 'tipo_audiencia',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Estado Audiencia',
                    align: 'center',
                    value: 'estado_audiencia',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Fec. Audiencia',
                    align: 'center',
                    value: 'fecha_audiencia',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Juez',
                    align: 'center',
                    value: 'juez',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Motivo',
                    align: 'center',
                    value: 'motivo',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Procedimiento',
                    align: 'center',
                    value: 'tipo_causa',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Duración Minutos',
                    align: 'center',
                    value: 'duracion',
                    class: 'pjud white--text subtitle-2',
                },
            ],
            dataModalDetalle: [],
            dialog: false,
            totales: {
                totalAudienciasJuez: 0,
                totalT: 0,
                totalM: 0,
                totalO: 0,
                totalI: 0,
                totalS: 0,
                totalDuracion: 0,
            },
            dataAudienciasJuez: [],
            dataJuez: [],
            barSeries: [],
            barChartOptions: {
                chart: {
                    type: 'bar',
                    stacked: true,
                },
                plotOptions: {
                    bar: {
                        horizontal: true,
                    },
                },
                stroke: {
                    width: 1,
                    colors: ['#fff'],
                },
                yaxis: {
                    labels: {
                        align: 'left',
                        maxWidth: 300,
                    },
                },
                xaxis: {
                    categories: [],
                    labels: {
                        formatter: function(value) {
                            return value
                        },
                    },
                },
                fill: {
                    opacity: 1,
                },
                legend: {
                    position: 'top',
                    horizontalAlign: 'center',
                    offsetX: 40,
                },
            },
        }
    },
    created() {
        try {
            this.$gtag.event('laboral_audiencias_juez', { method: 'Google' })
            this.getAudienciasJueces()
        } catch (error) {
            console.log(error)
        }
    },
    components: {
        countTo,
    },
    methods: {
        async getAudienciasJueces() {
            // this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/laboral/audiencias_juez'
            this.barChartOptions.xaxis.categories = []
            this.barSeries = []
            this.dataAudienciasJuez = []
            this.totales.totalT = 0
            this.totales.totalM = 0
            this.totales.totalM = 0
            this.totales.totalI = 0
            this.totales.totalS = 0
            this.totales.totalAudienciasJuez = 0
            this.totales.totalDuracion = 0

            const get = async req1 => {
                try {
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte:
                                this.user[0].cod_corte ||
                                this.$route.params.cod_corte,
                            cod_tribunal:
                                this.user[0].cod_tribunal ||
                                this.$route.params.cod_tribunal,
                            anoInicio:
                                this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio:
                                this.fechas.mesInicio || this.$route.params.mes,
                            anoFin:
                                this.fechas.anoFin || this.$route.params.ano,
                            mesFin:
                                this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0,
                        },
                    })

                    const data = response.data
                    this.dataAudienciasJuez = data.recordset
                    let contador = 1
                    let dataTipoAudiencia = data.recordset.map(
                        a => a.tipo_audiencia
                    )
                    let dataJueces = data.recordset.map(a => a.juez)
                    let auxRow = []
                    let cantidad = 0
                    //dejo los valores unicos
                    dataTipoAudiencia = dataTipoAudiencia.filter(
                        (v, i, a) => a.indexOf(v) === i
                    )
                    this.dataJuez = dataJueces.filter(
                        (v, i, a) => a.indexOf(v) === i
                    )

                    Object.values(data.recordset).map(type => {
                        this.totales.totalT += type.T
                        this.totales.totalM += type.M
                        this.totales.totalO += type.O
                        this.totales.totalI += type.I
                        this.totales.totalS += type.S
                        this.totales.totalAudienciasJuez += type.cantidad
                        this.totales.totalDuracion += type.duracion
                    })

                    //Ingreso los tipos de audiencias
                    dataTipoAudiencia.forEach(ta => {
                        this.barSeries.push({
                            name: ta,
                            data: [],
                        })
                    })

                    //Ingreso las cantidades respectivas para cada juez
                    this.barSeries.forEach(se => {
                        this.dataJuez.forEach(j => {
                            auxRow = data.recordset.filter(
                                element =>
                                    element.tipo_audiencia == se.name &&
                                    element.juez == j
                            )
                            auxRow = auxRow.map(a => a.cantidad)
                            cantidad = auxRow[0]

                            if (cantidad == undefined) cantidad = 0

                            se.data.push(cantidad)
                        })
                    })

                    this.dataJuez.forEach(j => {
                        this.barChartOptions.xaxis.categories.push(j)
                    })

                    // console.log(this.dataAudienciasJuez.filter(aud => aud.juez == 'ALBERTO ALAMOS VALENZUELA').length);
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },

        async getAudienciasJuezDetalle(id_tipo_audiencia, id_funcionario) {
            try {
                const axios = require('axios')
                const req1 = urlApi + '/laboral/audiencias_juez_detalle'
                this.tituloLabel = ''
                this.dataModalDetalle = []
                this.search = ''

                const get = async req1 => {
                    try {
                        const response = await axios.get(req1, {
                            params: {
                                cod_corte:
                                    this.user[0].cod_corte ||
                                    this.$route.params.cod_corte,
                                cod_tribunal:
                                    this.user[0].cod_tribunal ||
                                    this.$route.params.cod_tribunal,
                                anoInicio:
                                    this.fechas.anoInicio ||
                                    this.$route.params.ano,
                                mesInicio:
                                    this.fechas.mesInicio ||
                                    this.$route.params.mes,
                                anoFin:
                                    this.fechas.anoFin ||
                                    this.$route.params.ano,
                                mesFin:
                                    this.fechas.mesFin ||
                                    this.$route.params.mes,
                                flg_exhorto: this.fechas.exhortos || 0,
                                id_tipo_audiencia: id_tipo_audiencia || 0,
                                id_funcionario: id_funcionario || 0,
                            },
                        })

                        const data = response.data

                        console.log(data)

                        Object.values(data.recordset).map(type => {
                            this.tituloLabel =
                                'Audiencias ' +
                                type.gls_tipaudiencia +
                                ' realizadas por ' +
                                type.nombre_completo

                            this.dataModalDetalle.push({
                                rit: type.rit,
                                tipo_audiencia: type.gls_tipaudiencia,
                                estado_audiencia: type.gls_estaudiencia,
                                fecha_audiencia: type.fec_audiencia,
                                juez: type.nombre_completo,
                                motivo: type.gls_motsuspaud,
                                tipo_causa: type.gls_tipo_causa,
                                duracion: type.duracion_minutos,
                            })
                        })

                        this.dialog = true
                    } catch (error) {
                        console.log(error)
                    }
                }

                get(req1)
            } catch (error) {
                console.log(error)
                this.dialog = false
            }
        },
    },
    computed: {
        ...mapState(['fechas']),
    },
    watch: {
        fechas() {
            this.getAudienciasJueces()
        },
    },
}
</script>

<style lang="css" scoped>
.Separador td {
    border: 1px solid rgb(224, 220, 220);
    white-space: nowrap;
}
</style>
