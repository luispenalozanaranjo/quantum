<template>
    <v-card class="pdfit grey">
        <v-card>
            <v-card-title>
                Resumen agendamiento
            </v-card-title>
            <v-card-text>
                <v-simple-table>
                    <template>
                        <thead class="pjud Separador">
                            <tr>
                                <th
                                    rowspan="3"
                                    class="white--text text-center subtitle-2"
                                >
                                    Tipos <br />Audiencias
                                </th>
                                <th
                                    rowspan="3"
                                    class="white--text text-center subtitle-2 "
                                >
                                    Tipos <br />Causas
                                </th>
                                <th
                                    colspan="36"
                                    class="white--text text-center subtitle-2 "
                                >
                                    Agendamiento de Audiencias
                                </th>
                                <th
                                    rowspan="3"
                                    class="white--text text-center subtitle-2 "
                                >
                                    Total Anual
                                </th>
                            </tr>
                            <tr>
                                <th
                                    v-for="item in mesesArray"
                                    :key="item + '2'"
                                    colspan="3"
                                    class="white--text text-center subtitle-2"
                                >
                                    {{ item }}
                                </th>
                            </tr>
                            <tr>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Total <br />Aud.
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    % en <br />Plazo
                                </th>
                                <th class="white--text text-center subtitle-2">
                                    Promedio <br />dias
                                </th>
                            </tr>
                        </thead>
                        <tbody class="Separadortd">
                            <td rowspan="5">Aud. Juicio</td>
                            <tr
                                v-for="item in dataAudienciasAge"
                                :key="item.tipo_causa + '1'"
                            >
                                <td class="text-center">
                                    {{ item.tipo_causa }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.enero.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.enero.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.enero.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.febrero.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.febrero.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.febrero.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.marzo.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.marzo.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.marzo.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.abril.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.abril.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.abril.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.mayo.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.mayo.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.mayo.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.junio.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.junio.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.junio.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.julio.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.julio.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.julio.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.agosto.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.agosto.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.agosto.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.septiembre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.septiembre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.septiembre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.octubre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.octubre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.octubre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.noviembre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.noviembre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.noviembre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.diciembre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.diciembre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.diciembre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="
                                            item.enero.total_aud +
                                                item.febrero.total_aud +
                                                item.marzo.total_aud +
                                                item.abril.total_aud +
                                                item.mayo.total_aud +
                                                item.junio.total_aud +
                                                item.julio.total_aud +
                                                item.agosto.total_aud +
                                                item.septiembre.total_aud +
                                                item.octubre.total_aud +
                                                item.noviembre.total_aud +
                                                item.diciembre.total_aud
                                        "
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                            </tr>
                            <td rowspan="5">Aud. Prep.</td>
                            <tr
                                v-for="item in dataAudienciasAgeP"
                                :key="item.tipo_causa"
                            >
                                <td class="text-center">
                                    {{ item.tipo_causa }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.enero.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.enero.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.enero.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.febrero.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.febrero.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.febrero.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.marzo.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.marzo.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.marzo.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.abril.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.abril.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.abril.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.mayo.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.mayo.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.mayo.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.junio.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.junio.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.junio.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.julio.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.julio.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.julio.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.agosto.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.agosto.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.agosto.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.septiembre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.septiembre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.septiembre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.octubre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.octubre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.octubre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.noviembre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.noviembre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.noviembre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="item.diciembre.total_aud"
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                                <td class="text-center">
                                    {{ item.diciembre.en_plazo }}%
                                </td>
                                <td class="text-center">
                                    {{ item.diciembre.promedio }}
                                </td>
                                <td class="text-center">
                                    <countTo
                                        :startVal="0"
                                        :endVal="
                                            item.enero.total_aud +
                                                item.febrero.total_aud +
                                                item.marzo.total_aud +
                                                item.abril.total_aud +
                                                item.mayo.total_aud +
                                                item.junio.total_aud +
                                                item.julio.total_aud +
                                                item.agosto.total_aud +
                                                item.septiembre.total_aud +
                                                item.octubre.total_aud +
                                                item.noviembre.total_aud +
                                                item.diciembre.total_aud
                                        "
                                        separator="."
                                        :duration="1500"
                                    ></countTo>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot></tfoot>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-card>
    </v-card>
</template>

<script>
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"

export default {
    name: 'AudienciasAgendamientos',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            mesesArray: ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
            dataAudienciasAge: [],
            dataAudienciasAgeP:[],
            totalPrep: 0,
            totalJuicio: 0
        }
    },
    created(){
        try {
            this.$gtag.event('laboral_audiencias_agendamiento', { method: 'Google' });
            this.getAudienciasAgendamientoJuicio();
            this.getAudienciasAgePreparatoria();
        } catch (error) {
            console.log(error);
        }
        
    },
    components: {
        countTo
    },
    methods: { 
        async getAudienciasAgendamientoJuicio() {
            // this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_agendamiento_juicio' ;
            this.dataAudienciasAge = [];
            // this.totalTiposAudiencias = 0;
           

            const get = async req1 => {
                try{

                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0
                        }
                    });
                   
                    const data = response.data;
                    let contador = 1;
                    //Obtengo solo los tipos de causas
                    let dataTiposCausas = data.recordset.map(a => a.tip_causa);
                    //dejo los valores unicos
                    dataTiposCausas = dataTiposCausas.filter((v, i, a) => a.indexOf(v) === i);

                    // console.log(data.recordset);

                    dataTiposCausas.forEach(tc => {

                        this.dataAudienciasAge.push({
                            tipo_audiencia: 'Aud. Juicio',
                            tipo_causa: tc,
                            enero: {
                                total_aud: data.recordset.filter(item => item.mes == 1 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 1 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 1 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 1 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 1 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 1 && item.tip_causa == tc).promedio,
                            },
                            febrero: {
                                total_aud: data.recordset.filter(item => item.mes == 2 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 2 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 2 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 2 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 2 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 2 && item.tip_causa == tc).promedio,
                            },
                            marzo: {
                                total_aud: data.recordset.filter(item => item.mes == 3 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 3 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 3 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 3 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 3 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 3 && item.tip_causa == tc).promedio,
                            },
                            abril: {
                                total_aud: data.recordset.filter(item => item.mes == 4 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 4 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 4 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 4 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 4 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 4 && item.tip_causa == tc).promedio,
                            },
                            mayo: {
                                total_aud: data.recordset.filter(item => item.mes == 5 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 5 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 5 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 5 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 5 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 5 && item.tip_causa == tc).promedio,
                            },
                            junio: {
                                total_aud: data.recordset.filter(item => item.mes == 6 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 6 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 6 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 6 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 6 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 6 && item.tip_causa == tc).promedio,
                            },
                            julio: {
                                total_aud: data.recordset.filter(item => item.mes == 7 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 7 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 7 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 7 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 7 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 7 && item.tip_causa == tc).promedio,
                            },
                            agosto: {
                                total_aud: data.recordset.filter(item => item.mes == 8 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 8 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 8 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 8 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 8 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 8 && item.tip_causa == tc).promedio,
                            },
                            septiembre: {
                                total_aud: data.recordset.filter(item => item.mes == 9 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 9 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 9 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 9 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 9 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 9 && item.tip_causa == tc).promedio,
                            },
                            octubre: {
                                total_aud: data.recordset.filter(item => item.mes == 10 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 10 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 10 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 10 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 10 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 10 && item.tip_causa == tc).promedio,
                            },
                            noviembre: {
                                total_aud: data.recordset.filter(item => item.mes == 11 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 11 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 11 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 11 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 11 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 11 && item.tip_causa == tc).promedio,
                            },
                            diciembre: {
                                total_aud: data.recordset.filter(item => item.mes == 12 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 12 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 12 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 12 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 12 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 12 && item.tip_causa == tc).promedio,
                            }
                        });


                    });

                    
                    this.dataAudienciasAge.forEach(e => {
                        this.totalPrep = (e.enero.total_aud + e.febrero.total_aud + e.febrero.total_aud + e.marzo.total_aud + e.abril.total_aud + e.mayo.total_aud + e.junio.total_aud + e.julio.total_aud + e.agosto.total_aud + e.septiembre.total_aud + e.octubre.total_aud + e.noviembre.total_aud + e.diciembre.total_aud)
                    });

                } 
                catch (error) {
                        console.log(error)
                }
            }


            get(req1);                 
            
        },
        async getAudienciasAgePreparatoria() {

            const axios = require('axios');
            const req1 = urlApi + '/laboral/audiencias_agendamiento_preparatoria' ;
            this.dataAudienciasAgeP = [];


            const get = async req1 => {
                try{

                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0
                        }
                    });
                   
                    const data = response.data;
                    let contador = 1;
                    //Obtengo solo los tipos de causas
                    let dataTiposCausas = data.recordset.map(a => a.tip_causa);
                    //dejo los valores unicos
                    dataTiposCausas = dataTiposCausas.filter((v, i, a) => a.indexOf(v) === i);

                    // console.log(data.recordset);

                    dataTiposCausas.forEach(tc => {

                        this.dataAudienciasAgeP.push({
                            tipo_audiencia: 'Aud. Preparatoria',
                            tipo_causa: tc,
                            enero: {
                                total_aud: data.recordset.filter(item => item.mes == 1 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 1 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 1 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 1 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 1 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 1 && item.tip_causa == tc).promedio,
                            },
                            febrero: {
                                total_aud: data.recordset.filter(item => item.mes == 2 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 2 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 2 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 2 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 2 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 2 && item.tip_causa == tc).promedio,
                            },
                            marzo: {
                                total_aud: data.recordset.filter(item => item.mes == 3 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 3 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 3 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 3 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 3 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 3 && item.tip_causa == tc).promedio,
                            },
                            abril: {
                                total_aud: data.recordset.filter(item => item.mes == 4 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 4 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 4 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 4 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 4 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 4 && item.tip_causa == tc).promedio,
                            },
                            mayo: {
                                total_aud: data.recordset.filter(item => item.mes == 5 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 5 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 5 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 5 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 5 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 5 && item.tip_causa == tc).promedio,
                            },
                            junio: {
                                total_aud: data.recordset.filter(item => item.mes == 6 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 6 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 6 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 6 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 6 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 6 && item.tip_causa == tc).promedio,
                            },
                            julio: {
                                total_aud: data.recordset.filter(item => item.mes == 7 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 7 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 7 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 7 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 7 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 7 && item.tip_causa == tc).promedio,
                            },
                            agosto: {
                                total_aud: data.recordset.filter(item => item.mes == 8 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 8 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 8 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 8 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 8 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 8 && item.tip_causa == tc).promedio,
                            },
                            septiembre: {
                                total_aud: data.recordset.filter(item => item.mes == 9 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 9 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 9 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 9 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 9 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 9 && item.tip_causa == tc).promedio,
                            },
                            octubre: {
                                total_aud: data.recordset.filter(item => item.mes == 10 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 10 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 10 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 10 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 10 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 10 && item.tip_causa == tc).promedio,
                            },
                            noviembre: {
                                total_aud: data.recordset.filter(item => item.mes == 11 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 11 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 11 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 11 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 11 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 11 && item.tip_causa == tc).promedio,
                            },
                            diciembre: {
                                total_aud: data.recordset.filter(item => item.mes == 12 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 12 && item.tip_causa == tc).total,
                                en_plazo: data.recordset.filter(item => item.mes == 12 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 12 && item.tip_causa == tc).cantidad,
                                promedio: data.recordset.filter(item => item.mes == 12 && item.tip_causa == tc).length == 0 ? 0 : data.recordset.find(item => item.mes == 12 && item.tip_causa == tc).promedio,
                            },
                        });


                    });

                    this.dataAudienciasAgeP.forEach(e => {
                        this.totalPrep = (e.enero.total_aud + e.febrero.total_aud + e.febrero.total_aud + e.marzo.total_aud + e.abril.total_aud + e.mayo.total_aud + e.junio.total_aud + e.julio.total_aud + e.agosto.total_aud + e.septiembre.total_aud + e.octubre.total_aud + e.noviembre.total_aud + e.diciembre.total_aud)
                    });

                } 
                catch (error) {
                        console.log(error)
                }
            }


            get(req1);                 
            
        },
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
        }
    }
}

</script>


<style lang="css" scoped>

.Separador th {
    border: 1px solid rgb(190, 190, 190);
    white-space: nowrap;
}

.Separadortd td {
    border-bottom: 1px solid rgb(223, 220, 220);
    border-right: 1px solid rgb(223, 220, 220);
    white-space: nowrap;
}



</style>