<template>
    <v-card>
        <v-card-text>
            <v-row>
                <v-col cols="12">
                    <v-row>
                        <!-- GRAFICO, INGRESOS, TERMINOS Y RESOLUCIONES -->
                        <v-col md="5">
                            <highcharts
                                :options="chartOptions"
                                :constructor-type="'chart'"
                            />
                        </v-col>
                        <v-col md="3">
                            <v-row justify="center">
                                <v-hover v-slot:default="{ hover }">
                                    <v-card
                                        hover
                                        height="100"
                                        width="270"
                                        :elevation="hover ? 12 : 2"
                                        :class="{ 'on-hover': hover }"
                                        class="cardAction pjud"
                                        @click="
                                            goIndicadores('LaboralIngresos')
                                        "
                                    >
                                        <v-card-title class="white--text">
                                            Total Ingresos
                                        </v-card-title>
                                        <v-card-text class="white--text">
                                            <v-progress-linear
                                                indeterminate
                                                color="white"
                                                v-show="showIngresosBar"
                                            ></v-progress-linear>
                                            <countTo
                                                class="count headline"
                                                :startVal="0"
                                                :endVal="TotalIngresos"
                                                separator="."
                                                :duration="1000"
                                                v-show="!showIngresosBar"
                                            ></countTo>
                                        </v-card-text>
                                    </v-card>
                                </v-hover>
                            </v-row>
                            <v-row class="py-2" justify="center">
                                <v-card height="100" width="270" class="pjud">
                                    <v-card-title
                                        class="white--text"
                                        align="center"
                                    >
                                        Total T&eacute;rminos
                                        <v-spacer></v-spacer>
                                        <v-switch
                                            color="red"
                                            v-model="archivoEspecial"
                                            hide-details
                                            dense
                                            class="mt-0 py-0"
                                        ></v-switch>
                                        <v-tooltip bottom color="#1D1B1B">
                                            <template
                                                v-slot:activator="{ on, attrs }"
                                            >
                                                <h6
                                                    class="body-1 mt-0 py-0"
                                                    v-bind="attrs"
                                                    v-on="on"
                                                >
                                                    a.e
                                                </h6>
                                            </template>
                                            <span>¿Archivos Especiales?</span>
                                        </v-tooltip>
                                    </v-card-title>
                                    <v-card-text
                                        class="white--text"
                                        style="cursor: pointer;"
                                        @click="
                                            goIndicadores('LaboralTerminos')
                                        "
                                    >
                                        <v-progress-linear
                                            indeterminate
                                            color="white"
                                            class="mb-0"
                                            v-show="showTerminosBar"
                                        ></v-progress-linear>
                                        <countTo
                                            class="count headline"
                                            :startVal="0"
                                            :endVal="TotalTerminos"
                                            separator="."
                                            :duration="1000"
                                            v-show="!showTerminosBar"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-row>
                            <v-row justify="center">
                                <v-hover v-slot:default="{ hover }">
                                    <v-card
                                        hover
                                        height="100"
                                        width="270"
                                        class="pjud"
                                        :elevation="hover ? 12 : 2"
                                        :class="{ 'on-hover': hover }"
                                        @click="
                                            goIndicadores('LaboralResoluciones')
                                        "
                                    >
                                        <v-card-title class="white--text">
                                            Total Resoluciones
                                        </v-card-title>
                                        <v-card-text class="white--text">
                                            <v-progress-linear
                                                indeterminate
                                                color="white"
                                                class="mb-0"
                                                v-show="showResolucionesBar"
                                            ></v-progress-linear>
                                            <countTo
                                                class="count headline"
                                                :startVal="0"
                                                :endVal="TotalResoluciones"
                                                separator="."
                                                :duration="1000"
                                                v-show="!showResolucionesBar"
                                            ></countTo>
                                        </v-card-text>
                                    </v-card>
                                </v-hover>
                            </v-row>
                        </v-col>
                        <!-- ANALISIS POR JUEZ -->
                        <v-col md="4">
                            <v-card>
                                <v-card-title class="pjud white--text">
                                    Analisis por Juez
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        small
                                        outlined
                                        color="white"
                                        @click="dialogJueces = true"
                                        >Detalle</v-btn
                                    >
                                </v-card-title>
                                <v-card-text>
                                    <v-data-table
                                        :headers="headerAnalisisJuez"
                                        :items="arrResumenJuez"
                                        :sort-by="['resoluciones']"
                                        hide-default-footer
                                        :sort-desc="[true]"
                                        disable-sort
                                    >
                                        <template v-slot:[`body`]="{ items }">
                                            <tbody>
                                                <tr
                                                    v-for="(item,
                                                    index) in items"
                                                    :key="
                                                        item.crr_idfuncionario
                                                    "
                                                >
                                                    <td
                                                        style="width:40%;"
                                                        v-if="index <= 4"
                                                    >
                                                        {{
                                                            item.nombre.toUpperCase()
                                                        }}
                                                    </td>
                                                    <td
                                                        style="width:25%; text-align: center"
                                                        v-if="index <= 4"
                                                    >
                                                        <countTo
                                                            class="count"
                                                            :startVal="0"
                                                            :endVal="
                                                                item.resoluciones
                                                            "
                                                            separator="."
                                                            :duration="1000"
                                                        ></countTo>
                                                    </td>
                                                    <td
                                                        style="width:25%; text-align: center"
                                                        v-if="index <= 4"
                                                    >
                                                        {{
                                                            item.aud_realizadas
                                                        }}&nbsp;({{
                                                            item.conciliaciones
                                                        }})
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </template>
                                    </v-data-table>
                                    <b />
                                    <p
                                        class="text--secondary font-italic"
                                        style="text-align: right;"
                                    >
                                        () = numero de conciliaciones
                                    </p>
                                </v-card-text>
                            </v-card>
                        </v-col>
                    </v-row>
                    <!-- AUDIENCIAS -->
                    <v-row>
                        <v-col md="5">
                            <v-row>
                                <v-col>
                                    <v-row align="center" justify="center">
                                        <v-col md="4" class="text-center">
                                            <span class="title colorPjud">
                                                Audiencias <br />
                                                Realizadas
                                            </span>
                                        </v-col>
                                        <v-col md="2" class="text-center">
                                            <font-awesome-icon
                                                v-if="
                                                    audRealizadasEstado ==
                                                        'descendente'
                                                "
                                                icon="arrow-circle-down"
                                                size="2x"
                                                class="rojo"
                                            />
                                            <font-awesome-icon
                                                v-if="
                                                    audRealizadasEstado ==
                                                        'ascendente'
                                                "
                                                icon="arrow-circle-up"
                                                size="2x"
                                                class="verde"
                                            />
                                            <font-awesome-icon
                                                v-if="
                                                    audRealizadasEstado ==
                                                        'equivalente'
                                                "
                                                icon="arrow-circle-right"
                                                size="2x"
                                                class="amarillo"
                                            />
                                        </v-col>
                                        <v-col md="2" class="text-center">
                                            {{ glosaPeriodoAnterior }} anterior
                                            <br />
                                            <span
                                                v-if="
                                                    audRealizadasEstado ==
                                                        'ascendente'
                                                "
                                                class="title colorPjud"
                                            >
                                                <span>+</span
                                                >{{ audRealizadasPrcnt }}%
                                            </span>
                                            <span
                                                v-if="
                                                    audRealizadasEstado !=
                                                        'ascendente'
                                                "
                                                class="title colorPjud"
                                            >
                                                {{ audRealizadasPrcnt }}%
                                            </span>
                                        </v-col>
                                        <v-col md="4" class="text-center mt-2">
                                            <span class="headline">
                                                <countTo
                                                    class="count colorPjud"
                                                    :startVal="0"
                                                    :endVal="audRealizadasTotal"
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                    </v-row>
                                    <hr />
                                    <v-row align="center" justify="center">
                                        <v-col md="4" class="text-center">
                                            <span class="title colorPjud">
                                                Audiencias <br />
                                                No Realizadas
                                            </span>
                                        </v-col>
                                        <v-col md="2" class="text-center">
                                            <font-awesome-icon
                                                v-if="
                                                    audNORealizadasEstado ==
                                                        'ascendente'
                                                "
                                                icon="arrow-circle-up"
                                                size="2x"
                                                class="rojo"
                                            />
                                            <font-awesome-icon
                                                v-if="
                                                    audNORealizadasEstado ==
                                                        'descendente'
                                                "
                                                icon="arrow-circle-down"
                                                size="2x"
                                                class="verde"
                                            />
                                            <font-awesome-icon
                                                v-if="
                                                    audNORealizadasEstado ==
                                                        'equivalente'
                                                "
                                                icon="arrow-circle-right"
                                                size="2x"
                                                class="amarillo"
                                            />
                                        </v-col>
                                        <v-col md="2" class="text-center">
                                            {{ glosaPeriodoAnterior }} anterior
                                            <br />
                                            <span
                                                v-if="
                                                    audNORealizadasEstado ==
                                                        'ascendente'
                                                "
                                                class="title colorPjud"
                                            >
                                                <span>+</span
                                                >{{ audNORealizadasPrcnt }}%
                                            </span>
                                            <span
                                                v-if="
                                                    audNORealizadasEstado !=
                                                        'ascendente'
                                                "
                                                class="title colorPjud"
                                            >
                                                {{ audNORealizadasPrcnt }}%
                                            </span>
                                        </v-col>
                                        <v-col md="4" class="text-center">
                                            <span class="headline">
                                                <countTo
                                                    class="count colorPjud"
                                                    :startVal="0"
                                                    :endVal="
                                                        audNORealizadasTotal
                                                    "
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                    </v-row>
                                    <hr />
                                </v-col>
                            </v-row>
                            <v-card class="pjud">
                                <v-card-text>
                                    <v-row align="center">
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            <span class="headline">
                                                No <br />
                                                Efectuadas
                                            </span>
                                        </v-col>
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            Suspendidas <br />
                                            <span class="headline">
                                                <countTo
                                                    class="count white--text"
                                                    :startVal="0"
                                                    :endVal="audSuspendidas"
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            No Realizadas <br />
                                            <span class="headline">
                                                <countTo
                                                    class="count white--text"
                                                    :startVal="0"
                                                    :endVal="audNoRealizadas"
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            Reprogramadas <br />
                                            <span class="headline">
                                                <countTo
                                                    class="count white--text"
                                                    :startVal="0"
                                                    :endVal="audReprogramadas"
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                    </v-row>
                                </v-card-text>
                            </v-card>
                            <v-card class="pjud mt-1">
                                <v-card-text>
                                    <v-row align="center">
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            <span class="headline">Salas</span>
                                        </v-col>
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            Creadas <br />
                                            <span class="headline">
                                                <countTo
                                                    class="count white--text"
                                                    :startVal="0"
                                                    :endVal="cantidadSalas"
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                            Utilizadas<br />
                                            <span class="headline">
                                                <countTo
                                                    class="count white--text"
                                                    :startVal="0"
                                                    :endVal="
                                                        cantidadSalasUsadas
                                                    "
                                                    separator="."
                                                    :duration="1000"
                                                ></countTo>
                                            </span>
                                        </v-col>
                                        <v-col
                                            md="3"
                                            class="text-center white--text"
                                        >
                                        </v-col>
                                    </v-row>
                                </v-card-text>
                            </v-card>
                        </v-col>
                        <v-col md="3">
                            <v-card>
                                <v-card-title class="pjud white--text">
                                    Atraso en Inicio Audiencias
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        small
                                        outlined
                                        color="white"
                                        @click="dialogAtrasos = true"
                                        >Detalle</v-btn
                                    >
                                </v-card-title>
                                <v-card-text>
                                    <v-row>
                                        <v-col md="8">
                                            <span class="title colorPjud"
                                                >Preparatorias</span
                                            >
                                            <br />
                                            Atraso Promedio Min.
                                        </v-col>
                                        <v-col md="4">
                                            <span class="title">
                                                {{ atrasosPromedioPrep }} min
                                            </span>
                                        </v-col>
                                    </v-row>
                                    <hr />
                                    <v-row>
                                        <v-col md="8">
                                            <span class="title colorPjud"
                                                >Juicio</span
                                            >
                                            <br />
                                            Atraso Promedio Min.
                                        </v-col>
                                        <v-col md="4">
                                            <span class="title">
                                                {{ atrasosPromedioJuicio }} min
                                            </span>
                                        </v-col>
                                    </v-row>
                                </v-card-text>
                            </v-card>
                        </v-col>
                        <!-- TERMINOS -->
                        <v-col md="4">
                            <v-card class="mr-3">
                                <v-card-title class="pjud white--text">
                                    T&eacute;rminos
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        small
                                        outlined
                                        color="white"
                                        @click="dialogTerTopfive = true"
                                        >Detalle</v-btn
                                    >
                                </v-card-title>
                                <v-card-text>
                                    <v-data-table
                                        :items="Terminos"
                                        :sort-by="['cantidad']"
                                        hide-default-footer
                                        :sort-desc="[true]"
                                        disable-sort
                                    >
                                        <template v-slot:[`body`]="{ items }">
                                            <tbody>
                                                <tr
                                                    v-for="(item,
                                                    index) in items"
                                                    :key="item.gls_termino"
                                                >
                                                    <td
                                                        style="width:50%;"
                                                        v-if="index <= 4"
                                                    >
                                                        {{ item.gls_termino }}
                                                    </td>
                                                    <td
                                                        style="width:50%; text-align: center"
                                                        v-if="index <= 4"
                                                    >
                                                        <countTo
                                                            class="count"
                                                            :startVal="0"
                                                            :endVal="
                                                                item.cantidad
                                                            "
                                                            separator="."
                                                            :duration="1000"
                                                        ></countTo>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </template>
                                    </v-data-table>
                                </v-card-text>

                                <!-- MODALES Y OTROS ELEMENTOS FUERA DEL TABLERO-->
                                <FiltrosCompetencias
                                    class="mt-4"
                                    style="display: none"
                                />
                                <!-- MODAL HORARIO DE INICIO AUDIENCIAS-->
                                <v-dialog
                                    v-model="dialogAtrasos"
                                    max-width="1100"
                                >
                                    <v-card>
                                        <v-card-title class="pjud white--text">
                                            Atraso Inicio de Audiencias
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="error"
                                                @click="dialogAtrasos = false"
                                                large
                                            >
                                                x
                                            </v-btn>
                                        </v-card-title>
                                        <v-card-text>
                                            <vue-excel-xlsx
                                                class="btn text-center mt-2"
                                                :data="dataDetalleAtrasos"
                                                :columns="excelHeadAtrasos"
                                                :filename="'detalleAtrasos'"
                                                :sheetname="'Hoja1'"
                                            >
                                                <v-tooltip top>
                                                    <template
                                                        v-slot:activator="{
                                                            on,
                                                            attrs,
                                                        }"
                                                    >
                                                        <v-btn
                                                            class="mx-2"
                                                            fab
                                                            dark
                                                            small
                                                            color="success"
                                                            v-bind="attrs"
                                                            v-on="on"
                                                        >
                                                            <v-icon
                                                                >mdi-microsoft-excel</v-icon
                                                            >
                                                        </v-btn>
                                                    </template>
                                                    <span
                                                        >Exportar a excel</span
                                                    >
                                                </v-tooltip>
                                            </vue-excel-xlsx>
                                            <v-data-table
                                                :headers="headerDetalleAtrasos"
                                                :items="dataDetalleAtrasos"
                                                :sort-desc="[true]"
                                                dense
                                                class="mt-5"
                                            >
                                                <template
                                                    v-slot:[`body`]="{ items }"
                                                >
                                                    <tbody>
                                                        <tr
                                                            v-for="item in items"
                                                            :key="item.contador"
                                                        >
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                {{ item.rit }}
                                                            </td>
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                {{
                                                                    item.gls_tipaudiencia
                                                                }}
                                                            </td>
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                {{
                                                                    item.fecha_audiencia
                                                                }}
                                                            </td>
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                {{
                                                                    item.hora_estipulada
                                                                }}
                                                            </td>
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                {{
                                                                    item.hora_ini_real
                                                                }}
                                                            </td>
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                <countTo
                                                                    class="count"
                                                                    :startVal="
                                                                        0
                                                                    "
                                                                    :endVal="
                                                                        item.minutos_atraso
                                                                    "
                                                                    separator="."
                                                                    :duration="
                                                                        1000
                                                                    "
                                                                ></countTo>
                                                            </td>
                                                            <td
                                                                style="text-align: center;"
                                                            >
                                                                {{ item.juez }}
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </template>
                                            </v-data-table>
                                        </v-card-text>
                                    </v-card>
                                </v-dialog>
                                <!-- MODAL TERMINOS POR TIPO (TOP5) -->
                                <v-dialog
                                    v-model="dialogTerTopfive"
                                    max-width="500"
                                >
                                    <v-card>
                                        <v-card-title class="pjud white--text">
                                            T&eacute;rminos Tipos
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="error"
                                                @click="
                                                    dialogTerTopfive = false
                                                "
                                                large
                                                >x</v-btn
                                            >
                                        </v-card-title>
                                        <v-card-text>
                                            <vue-excel-xlsx
                                                class="btn text-center mt-2"
                                                :data="Terminos"
                                                :columns="
                                                    excelHeadTerminosTipos
                                                "
                                                :filename="
                                                    'detalleTerminosTipos'
                                                "
                                                :sheetname="'Hoja1'"
                                            >
                                                <v-tooltip top>
                                                    <template
                                                        v-slot:activator="{
                                                            on,
                                                            attrs,
                                                        }"
                                                    >
                                                        <v-btn
                                                            class="mx-2"
                                                            fab
                                                            dark
                                                            small
                                                            color="success"
                                                            v-bind="attrs"
                                                            v-on="on"
                                                        >
                                                            <v-icon
                                                                >mdi-microsoft-excel</v-icon
                                                            >
                                                        </v-btn>
                                                    </template>
                                                    <span
                                                        >Exportar a excel</span
                                                    >
                                                </v-tooltip>
                                            </vue-excel-xlsx>

                                            <v-data-table
                                                :headers="headerTipoTermino"
                                                :items="Terminos"
                                                :sort-by="['cantidad']"
                                                :sort-desc="[true]"
                                                class="mt-2"
                                            >
                                                <template
                                                    v-slot:[`body`]="{ items }"
                                                >
                                                    <tbody>
                                                        <tr
                                                            v-for="item in items"
                                                            :key="
                                                                item.gls_termino
                                                            "
                                                        >
                                                            <td
                                                                style="width:50%;"
                                                            >
                                                                {{
                                                                    item.gls_termino
                                                                }}
                                                            </td>
                                                            <td
                                                                style="width:50%; text-align: center"
                                                            >
                                                                <countTo
                                                                    class="count"
                                                                    :startVal="
                                                                        0
                                                                    "
                                                                    :endVal="
                                                                        item.cantidad
                                                                    "
                                                                    separator="."
                                                                    :duration="
                                                                        1000
                                                                    "
                                                                ></countTo>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr
                                                            class="pjud white--text"
                                                        >
                                                            <th
                                                                class="subtitle-2 text-center"
                                                            >
                                                                Total
                                                            </th>
                                                            <th
                                                                class="subtitle-2 text-center"
                                                            >
                                                                <countTo
                                                                    class="count"
                                                                    :startVal="
                                                                        0
                                                                    "
                                                                    :endVal="
                                                                        TotalTerminosTipos
                                                                    "
                                                                    separator="."
                                                                    :duration="
                                                                        1000
                                                                    "
                                                                ></countTo>
                                                            </th>
                                                        </tr>
                                                    </tfoot>
                                                </template>
                                            </v-data-table>
                                        </v-card-text>
                                    </v-card>
                                </v-dialog>
                                <!-- MODAL INGRESOS -->
                                <v-dialog
                                    v-model="dialogIngreso"
                                    max-width="1500"
                                >
                                    <v-card>
                                        <v-card-title>
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="error"
                                                @click="dialogIngreso = false"
                                                large
                                                >x</v-btn
                                            >
                                        </v-card-title>
                                        <v-card-text>
                                            <v-tabs
                                                v-model="tabIngresos"
                                                background-color="accent-4"
                                                centered
                                            >
                                                <v-tabs-slider></v-tabs-slider>
                                                <v-tab href="#tab-1"
                                                    >Ingresos Causas</v-tab
                                                >
                                                <v-tab href="#tab-2"
                                                    >Ingresos Materias</v-tab
                                                >
                                                <v-tab href="#tab-3"
                                                    >Ingresos Tipos</v-tab
                                                >
                                            </v-tabs>
                                            <v-tabs-items
                                                v-model="tabIngresos"
                                                class="py-1"
                                            >
                                                <v-tab-item id="tab-1">
                                                    <IngresosCausas />
                                                </v-tab-item>
                                                <v-tab-item id="tab-2">
                                                    <IngresosTipoMaterias />
                                                </v-tab-item>
                                                <v-tab-item id="tab-3">
                                                    <IngresosTipoIngresos />
                                                </v-tab-item>
                                            </v-tabs-items>
                                        </v-card-text>
                                    </v-card>
                                </v-dialog>
                                <!-- MODAL TERMINOS -->
                                <v-dialog
                                    v-model="dialogTerminos"
                                    max-width="1500"
                                >
                                    <v-card>
                                        <v-card-title>
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="error"
                                                @click="dialogTerminos = false"
                                                large
                                                >x</v-btn
                                            >
                                        </v-card-title>
                                        <v-card-text>
                                            <v-tabs
                                                v-model="tabTerminos"
                                                background-color="accent-4"
                                                centered
                                            >
                                                <v-tabs-slider></v-tabs-slider>
                                                <v-tab href="#tab-1"
                                                    >Tipo T&eacute;rmino</v-tab
                                                >
                                                <v-tab href="#tab-2"
                                                    >Tipo Materia</v-tab
                                                >
                                                <v-tab href="#tab-3"
                                                    >Tipo Procedimiento</v-tab
                                                >
                                            </v-tabs>
                                            <v-tabs-items
                                                v-model="tabTerminos"
                                                class="py-1"
                                            >
                                                <v-tab-item id="tab-1">
                                                    <TerminosTipos
                                                        :archivoEspecial="
                                                            this.archivoEspecial
                                                        "
                                                    />
                                                </v-tab-item>
                                                <v-tab-item id="tab-2">
                                                    <TerminosMaterias />
                                                </v-tab-item>
                                                <v-tab-item id="tab-3">
                                                    <TerminosProcedimientos />
                                                </v-tab-item>
                                            </v-tabs-items>
                                        </v-card-text>
                                    </v-card>
                                </v-dialog>
                                <!-- MODAL RESOLUCIONES -->
                                <v-dialog
                                    v-model="dialogResoluciones"
                                    max-width="1250"
                                >
                                    <v-card>
                                        <v-card-title
                                            class="primary white--text"
                                        >
                                            Resoluciones Nomenclaturas
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="error"
                                                @click="
                                                    dialogResoluciones = false
                                                "
                                                >x</v-btn
                                            >
                                        </v-card-title>
                                        <v-card-text>
                                            <ResolucionesNomenclaturas />
                                        </v-card-text>
                                    </v-card>
                                </v-dialog>
                                <!-- MODAL RESUMEN JUECES -->
                                <v-dialog
                                    v-model="dialogJueces"
                                    max-width="1100"
                                >
                                    <v-card>
                                        <v-card-title class="pjud white--text">
                                            Analisis por juez
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="error"
                                                @click="dialogJueces = false"
                                                large
                                                >x</v-btn
                                            >
                                        </v-card-title>
                                        <v-card-text>
                                            <v-tabs
                                                v-model="tab"
                                                background-color="accent-4"
                                                centered
                                            >
                                                <v-tabs-slider></v-tabs-slider>
                                                <v-tab href="#tab-1"
                                                    >Ranking</v-tab
                                                >
                                                <v-tab href="#tab-2"
                                                    >Detalle Resoluciones</v-tab
                                                >
                                                <v-tab href="#tab-3"
                                                    >Detalle Audiencias</v-tab
                                                >
                                                <v-tab href="#tab-4"
                                                    >Detalle
                                                    Conciliaciones</v-tab
                                                >
                                            </v-tabs>

                                            <v-tabs-items
                                                v-model="tab"
                                                class="py-1"
                                            >
                                                <v-tab-item id="tab-1">
                                                    <vue-excel-xlsx
                                                        class="btn text-center"
                                                        :data="arrResumenJuez"
                                                        :columns="
                                                            excelHeadJueces
                                                        "
                                                        :filename="
                                                            'Analisis por Juez'
                                                        "
                                                        :sheetname="'Hoja1'"
                                                    >
                                                        <v-tooltip top>
                                                            <template
                                                                v-slot:activator="{
                                                                    on,
                                                                    attrs,
                                                                }"
                                                            >
                                                                <v-btn
                                                                    class="mx-2"
                                                                    fab
                                                                    dark
                                                                    small
                                                                    color="success"
                                                                    v-bind="
                                                                        attrs
                                                                    "
                                                                    v-on="on"
                                                                >
                                                                    <v-icon
                                                                        >mdi-microsoft-excel</v-icon
                                                                    >
                                                                </v-btn>
                                                            </template>
                                                            <span
                                                                >Exportar a
                                                                excel</span
                                                            >
                                                        </v-tooltip>
                                                    </vue-excel-xlsx>

                                                    <v-data-table
                                                        :headers="
                                                            headerDetalleJueces
                                                        "
                                                        :items="arrResumenJuez"
                                                        :sort-by="[
                                                            'resoluciones',
                                                        ]"
                                                        :sort-desc="[true]"
                                                        dense
                                                        class="mt-5"
                                                    >
                                                        <template
                                                            v-slot:[`body`]="{
                                                                items,
                                                            }"
                                                        >
                                                            <tbody>
                                                                <tr
                                                                    v-for="item in items"
                                                                    :key="
                                                                        item.crr_idfuncionario
                                                                    "
                                                                >
                                                                    <td
                                                                        style=""
                                                                    >
                                                                        {{
                                                                            item.nombre
                                                                        }}
                                                                    </td>
                                                                    <td
                                                                        style="text-align: center"
                                                                    >
                                                                        <countTo
                                                                            class="count"
                                                                            :startVal="
                                                                                0
                                                                            "
                                                                            :endVal="
                                                                                item.resoluciones
                                                                            "
                                                                            separator="."
                                                                            :duration="
                                                                                1000
                                                                            "
                                                                        ></countTo>
                                                                    </td>
                                                                    <td
                                                                        style="text-align: center"
                                                                    >
                                                                        {{
                                                                            item.aud_realizadas
                                                                        }}
                                                                    </td>
                                                                    <td
                                                                        style="text-align: center"
                                                                    >
                                                                        {{
                                                                            item.conciliaciones
                                                                        }}
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                            <tfoot>
                                                                <tr
                                                                    class="pjud white--text"
                                                                >
                                                                    <th
                                                                        style="text-align: center"
                                                                    >
                                                                        Total
                                                                    </th>
                                                                    <th
                                                                        style="text-align: center"
                                                                    >
                                                                        <countTo
                                                                            class="count"
                                                                            :startVal="
                                                                                0
                                                                            "
                                                                            :endVal="
                                                                                totalResJueces
                                                                            "
                                                                            separator="."
                                                                            :duration="
                                                                                1000
                                                                            "
                                                                        ></countTo>
                                                                    </th>
                                                                    <th
                                                                        style="text-align: center"
                                                                    >
                                                                        <countTo
                                                                            class="count"
                                                                            :startVal="
                                                                                0
                                                                            "
                                                                            :endVal="
                                                                                totalAudJueces
                                                                            "
                                                                            separator="."
                                                                            :duration="
                                                                                1000
                                                                            "
                                                                        ></countTo>
                                                                    </th>
                                                                    <th
                                                                        style="text-align: center"
                                                                    >
                                                                        <countTo
                                                                            class="count"
                                                                            :startVal="
                                                                                0
                                                                            "
                                                                            :endVal="
                                                                                totalConciJueces
                                                                            "
                                                                            separator="."
                                                                            :duration="
                                                                                1000
                                                                            "
                                                                        ></countTo>
                                                                    </th>
                                                                </tr>
                                                            </tfoot>
                                                        </template>
                                                    </v-data-table>
                                                </v-tab-item>
                                                <v-tab-item id="tab-2">
                                                    <!--DETALLE DE RESOLUCIONES -->
                                                    <vue-excel-xlsx
                                                        class="btn text-center"
                                                        :data="
                                                            arrDetalleResoluciones
                                                        "
                                                        :columns="
                                                            excelHeadDetResoluciones
                                                        "
                                                        :filename="
                                                            'DetalleResoluciones'
                                                        "
                                                        :sheetname="'Hoja1'"
                                                    >
                                                        <v-tooltip top>
                                                            <template
                                                                v-slot:activator="{
                                                                    on,
                                                                    attrs,
                                                                }"
                                                            >
                                                                <v-btn
                                                                    class="mx-2"
                                                                    fab
                                                                    dark
                                                                    small
                                                                    color="success"
                                                                    v-bind="
                                                                        attrs
                                                                    "
                                                                    v-on="on"
                                                                >
                                                                    <v-icon
                                                                        >mdi-microsoft-excel</v-icon
                                                                    >
                                                                </v-btn>
                                                            </template>
                                                            <span
                                                                >Exportar a
                                                                excel</span
                                                            >
                                                        </v-tooltip>
                                                    </vue-excel-xlsx>

                                                    <v-data-table
                                                        :headers="
                                                            headerDetResoluciones
                                                        "
                                                        :items="
                                                            arrDetalleResoluciones
                                                        "
                                                        dense
                                                        class="mt-4"
                                                    >
                                                    </v-data-table>
                                                </v-tab-item>
                                                <v-tab-item id="tab-3">
                                                    <!--DETALLE DE AUDIENCIAS -->
                                                    <vue-excel-xlsx
                                                        class="btn text-center"
                                                        :data="
                                                            arrDetalleAudiendiasRealizada
                                                        "
                                                        :columns="
                                                            excelHeadDetAudiencias
                                                        "
                                                        :filename="
                                                            'DetalleAudiencias'
                                                        "
                                                        :sheetname="'Hoja1'"
                                                    >
                                                        <v-tooltip top>
                                                            <template
                                                                v-slot:activator="{
                                                                    on,
                                                                    attrs,
                                                                }"
                                                            >
                                                                <v-btn
                                                                    class="mx-2"
                                                                    fab
                                                                    dark
                                                                    small
                                                                    color="success"
                                                                    v-bind="
                                                                        attrs
                                                                    "
                                                                    v-on="on"
                                                                >
                                                                    <v-icon
                                                                        >mdi-microsoft-excel</v-icon
                                                                    >
                                                                </v-btn>
                                                            </template>
                                                            <span
                                                                >Exportar a
                                                                excel</span
                                                            >
                                                        </v-tooltip>
                                                    </vue-excel-xlsx>

                                                    <v-data-table
                                                        :headers="
                                                            headerDetAudienciaRealizada
                                                        "
                                                        :items="
                                                            arrDetalleAudiendiasRealizada
                                                        "
                                                        dense
                                                        class="mt-4"
                                                    >
                                                    </v-data-table>
                                                </v-tab-item>
                                                <v-tab-item id="tab-4">
                                                    <!--DETALLE DE CONCILIACIONES -->
                                                    <vue-excel-xlsx
                                                        class="btn text-center"
                                                        :data="
                                                            arrDetalleConciliaciones
                                                        "
                                                        :columns="
                                                            excelHeadDetAudiencias
                                                        "
                                                        :filename="
                                                            'DetalleConciliaciones'
                                                        "
                                                        :sheetname="'Hoja1'"
                                                    >
                                                        <v-tooltip top>
                                                            <template
                                                                v-slot:activator="{
                                                                    on,
                                                                    attrs,
                                                                }"
                                                            >
                                                                <v-btn
                                                                    class="mx-2"
                                                                    fab
                                                                    dark
                                                                    small
                                                                    color="success"
                                                                    v-bind="
                                                                        attrs
                                                                    "
                                                                    v-on="on"
                                                                >
                                                                    <v-icon
                                                                        >mdi-microsoft-excel</v-icon
                                                                    >
                                                                </v-btn>
                                                            </template>
                                                            <span
                                                                >Exportar a
                                                                excel</span
                                                            >
                                                        </v-tooltip>
                                                    </vue-excel-xlsx>

                                                    <v-data-table
                                                        :headers="
                                                            headerDetConciliaciones
                                                        "
                                                        :items="
                                                            arrDetalleConciliaciones
                                                        "
                                                        dense
                                                        class="mt-4"
                                                    >
                                                    </v-data-table>
                                                </v-tab-item>
                                            </v-tabs-items>
                                        </v-card-text>
                                    </v-card>
                                </v-dialog>
                            </v-card>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
        </v-card-text>
    </v-card>
</template>

<script>
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'
import { urlApi } from '../../../config/api'
import store from 'store'
import { mapState, mapMutations } from 'vuex'
import { Graph } from '../../../config/Highcharts'
import { Chart } from 'highcharts-vue'
import exporting from 'highcharts/modules/exporting'
import HighCharts from 'highcharts'
import loadDrillDown from 'highcharts/modules/drilldown'
import stockInit from 'highcharts/modules/stock'
import countTo from 'vue-count-to'
import IngresosCausas from '../../../views/laboral/Ingresos/Ingresos'
import IngresosTipoIngresos from '../../../views/laboral/Ingresos/Ingresos_tipoIngresos'
import IngresosTipoMaterias from '../../../views/laboral/Ingresos/Ingresos_tipoMaterias'
import TerminosTipos from '../../../views/laboral/Terminos/TerminosTipos'
import TerminosMaterias from '../../../views/laboral/Terminos/TerminosMaterias'
import TerminosProcedimientos from '../../../views/laboral/Terminos/TerminosProcedimientos'
import ResolucionesNomenclaturas from '../../../views/laboral/Resoluciones/ResolucionesNomenclaturas'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

export default {
    name: 'LaboralTablero',
    data() {
        return {
            chartOptions: JSON.parse(JSON.stringify(Graph['pie'][0])),
            user: [
                {
                    usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                    cod_corte: store.get('cod_corte'),
                    cod_tribunal: store.get('cod_tribunal'),
                    ano: store.get('ano'),
                    mes: store.get('mes'),
                },
            ],
            tab: false,
            showIngresosBar: false,
            showTerminosBar: false,
            showResolucionesBar: false,
            TotalIngresos: 0,
            TotalTerminos: 0,
            TotalResoluciones: 0,
            Terminos: [],
            dialogIngreso: false,
            dialogTerminos: false,
            dialogResoluciones: false,
            dialogTerTopfive: false,
            dialogJueces: false,
            dialogAtrasos: false,
            tabIngresos: null,
            tabTerminos: null,
            tabResoluciones: null,
            audRealizadasTotal: 0,
            audNORealizadasTotal: 0,
            audNoRealizadas: 0,
            audSuspendidas: 0,
            audReprogramadas: 0,
            nombreTribunal: '',
            arrResumenJuez: [],
            audRealizadasPrcnt: 0,
            audNORealizadasPrcnt: 0,
            audRealizadasEstado: '',
            audNORealizadasEstado: '',
            glosaPeriodoAnterior: '',
            atrasosPromedioPrep: 0,
            atrasosPromedioJuicio: 0,
            cantidadSalas: 0,
            cantidadSalasUsadas: 0,
            archivoEspecial: true,
            totalResJueces: 0,
            totalAudJueces: 0,
            totalConciJueces: 0,
            TotalTerminosTipos: 0,
            dataDetalleAtrasos: [],
            arrDetalleResoluciones: [],
            arrDetalleAudiendiasRealizada: [],
            arrDetalleConciliaciones: [],
            headerDetalleAtrasos: [
                {
                    text: 'RIT',
                    align: 'center',
                    value: 'rit',
                    class: 'pjud white--text subtitle-2',
                    width: '13%',
                },
                {
                    text: 'Tipo Aud.',
                    align: 'center',
                    value: 'gls_tipaudiencia',
                    class: 'pjud white--text subtitle-2',
                    width: '13%',
                },
                {
                    text: 'Fecha Aud.',
                    align: 'center',
                    value: 'fecha_audiencia',
                    class: 'pjud white--text subtitle-2',
                    width: '12%',
                },
                {
                    text: 'Hora Aud.',
                    align: 'center',
                    value: 'hora_estipulada',
                    class: 'pjud white--text subtitle-2',
                    width: '12%',
                },
                {
                    text: 'Hora Real',
                    align: 'center',
                    value: 'hora_ini_real',
                    class: 'pjud white--text subtitle-2',
                    width: '12%',
                },
                {
                    text: 'Atraso(min)',
                    align: 'center',
                    value: 'minutos_atraso',
                    class: 'pjud white--text subtitle-2',
                    width: '12%',
                },
                {
                    text: 'Juez',
                    align: 'center',
                    value: 'juez',
                    class: 'pjud white--text subtitle-2',
                    width: '17%',
                },
            ],
            headerDetalleJueces: [
                {
                    text: 'Juez',
                    align: 'center',
                    value: 'nombre',
                    class: 'pjud white--text subtitle-2',
                    width: '40%',
                },
                {
                    text: 'Resoluciones',
                    align: 'center',
                    value: 'resoluciones',
                    class: 'pjud white--text subtitle-2',
                    width: '20%',
                },
                {
                    text: 'Audiencias Realizadas',
                    align: 'center',
                    value: 'aud_realizadas',
                    class: 'pjud white--text subtitle-2',
                    width: '20%',
                },
                {
                    text: 'Conciliaciones',
                    align: 'center',
                    value: 'conciliaciones',
                    class: 'pjud white--text subtitle-2',
                    width: '20%',
                },
            ],
            headerDetResoluciones: [
                {
                    text: 'Id Causa',
                    align: 'center',
                    value: 'crr_causa',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Rit',
                    align: 'center',
                    value: 'rit',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Id Tramite',
                    align: 'center',
                    value: 'crr_idtramite',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Juez',
                    align: 'center',
                    value: 'funcionario',
                    class: 'pjud white--text subtitle-2',
                    width: '17%',
                },
                {
                    text: 'Fec. Ingreso',
                    align: 'center',
                    value: 'fec_ingreso',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Fec. Tramite',
                    align: 'center',
                    value: 'fec_tramite',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
            ],
            headerDetAudienciaRealizada: [
                {
                    text: 'Id Causa',
                    align: 'center',
                    value: 'crr_causa',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Rit',
                    align: 'center',
                    value: 'rit',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Fec. Ingreso',
                    align: 'center',
                    value: 'fec_ingreso',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Fec. Audiencia',
                    align: 'center',
                    value: 'fec_audiencia_real',
                    class: 'pjud white--text subtitle-2',
                    width: '17%',
                },
                {
                    text: 'Tipo Audiencia',
                    align: 'center',
                    value: 'gls_tipaudiencia',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Juez',
                    align: 'center',
                    value: 'funcionario',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
            ],
            headerDetConciliaciones: [
                {
                    text: 'Id Causa',
                    align: 'center',
                    value: 'crr_causa',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Rit',
                    align: 'center',
                    value: 'rit',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Fec. Ingreso',
                    align: 'center',
                    value: 'fec_ingreso',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Fec. Audiencia',
                    align: 'center',
                    value: 'fec_audiencia_real',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Tipo Audiencia',
                    align: 'center',
                    value: 'gls_tipaudiencia',
                    class: 'pjud white--text subtitle-2',
                    width: '16%',
                },
                {
                    text: 'Juez',
                    align: 'center',
                    value: 'funcionario',
                    class: 'pjud white--text subtitle-2',
                    width: '17%',
                },
            ],
            headerAnalisisJuez: [
                {
                    text: '',
                    align: 'center',
                    value: 'nombre',
                    class: 'primary--text',
                    width: '50%',
                },
                {
                    text: 'Resoluciones',
                    align: 'center',
                    value: 'resoluciones',
                    class: 'subtitle-2',
                },
                {
                    text: 'Audiencias Realizadas',
                    align: 'center',
                    value: 'aud_realizadas',
                    class: 'subtitle-2',
                },
            ],
            headerTipoTermino: [
                {
                    text: 'Tipo',
                    align: 'center',
                    value: 'gls_termino',
                    class: 'pjud white--text subtitle-2',
                },
                {
                    text: 'Cantidad',
                    align: 'center',
                    value: 'cantidad',
                    class: 'pjud white--text subtitle-2',
                },
            ],
            excelHeadJueces: [
                { label: 'Juez', field: 'nombre' },
                { label: 'Resoluciones', field: 'resoluciones' },
                { label: 'Audiencias Realizadas', field: 'aud_realizadas' },
                { label: 'Conciliaciones', field: 'conciliaciones' },
            ],
            excelHeadDetResoluciones: [
                { label: 'Id Causa', field: 'crr_causa' },
                { label: 'Rit', field: 'rit' },
                { label: 'Id Tramite', field: 'crr_idtramite' },
                { label: 'Juez', field: 'funcionario' },
                { label: 'Fec Ingreso', field: 'fec_ingreso' },
                { label: 'Fec Tramite', field: 'fec_tramite' },
            ],
            excelHeadDetAudiencias: [
                { label: 'Id Causa', field: 'crr_causa' },
                { label: 'Rit', field: 'rit' },
                { label: 'Fec. Ingreso', field: 'fec_ingreso' },
                { label: 'Fec. Audiencia', field: 'fec_audiencia_real' },
                { label: 'Tipo Audiencia', field: 'gls_tipaudiencia' },
                { label: 'Juez', field: 'funcionario' },
            ],
            excelHeadAtrasos: [
                { label: 'RIT', field: 'rit' },
                { label: 'Tipo Audiencia', field: 'gls_tipaudiencia' },
                { label: 'Fecha Audiencia', field: 'fecha_audiencia' },
                { label: 'Hora Audiencia', field: 'hora_estipulada' },
                { label: 'Hora Real', field: 'hora_ini_real' },
                { label: 'Atraso(min)', field: 'minutos_atraso' },
                { label: 'Juez', field: 'juez' },
            ],
            excelHeadTerminosTipos: [
                { label: 'Tipo Termino', field: 'gls_termino' },
                { label: 'Cantidad', field: 'cantidad' },
            ],
        }
    },
    created() {
        this.$gtag.event('tablero_laboral', { method: 'Google' })
    },
    methods: {
        ...mapMutations([
            'setModal',
            'setId_funcionario',
            'setTipoFuncionario',
        ]),

        async consultaIngresos() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/ingresos_totales'

            try {
                this.showIngresosBar = true
                this.TotalIngresos = 0
                this.chartOptions.series = []
                this.chartOptions.plotOptions.pie.dataLabels.format =
                    '<b>{point.name}</b>: {point.percentage:.1f} % ({point.y:.0f})'

                const params = {
                    cod_corte: this.user[0].cod_corte,
                    cod_tribunal: this.user[0].cod_tribunal,
                    anoInicio: this.fechas.anoInicio,
                    mesInicio: this.fechas.mesInicio,
                    anoFin: this.fechas.anoFin,
                    mesFin: this.fechas.mesFin,
                    flg_exhorto: this.fechas.exhorto,
                }

                const respIngresosTotales = await axios.get(req1, { params })

                const dataIngresos = respIngresosTotales.data

                Object.values(dataIngresos.recordset).map(type => {
                    this.TotalIngresos = type.cantidad
                })

                let dataTable = []
                dataTable.push({ name: 'Ingresos', y: this.TotalIngresos })
                dataTable.push({ name: 'Terminos', y: this.TotalTerminos })

                this.chartOptions.series = []
                this.chartOptions.series.push({
                    data: dataTable,
                    name: 'Ingresos vs Terminos',
                    colorByPoint: true,
                })

                this.showIngresosBar = false
            } catch (error) {
                console.log(error.message)
            }
        },

        async consultaTerminos() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/terminos_totales'
            let archivoEspecialParam = ''

            try {
                this.showTerminosBar = true

                if (this.archivoEspecial) {
                    archivoEspecialParam = 't'
                } else {
                    archivoEspecialParam = 'f'
                }

                const params = {
                    cod_corte: this.user[0].cod_corte,
                    cod_tribunal: this.user[0].cod_tribunal,
                    anoInicio: this.fechas.anoInicio,
                    mesInicio: this.fechas.mesInicio,
                    anoFin: this.fechas.anoFin,
                    mesFin: this.fechas.mesFin,
                    archivoEspecial: archivoEspecialParam,
                    flg_exhorto: this.fechas.exhorto,
                }

                const respTerminosTotales = await axios.get(req1, { params })
                const dataTerminos = respTerminosTotales.data

                this.TotalTerminos = 0

                Object.values(dataTerminos.recordset).map(type => {
                    this.TotalTerminos = type.cantidad
                })

                let dataTable = []
                dataTable.push({ name: 'Ingresos', y: this.TotalIngresos })
                dataTable.push({ name: 'Terminos', y: this.TotalTerminos })

                this.chartOptions.series = []
                this.chartOptions.series.push({
                    data: dataTable,
                    name: 'Ingresos vs Terminos',
                    colorByPoint: true,
                })

                this.showTerminosBar = false
            } catch (error) {
                throw error
            }
        },

        async consultaResoluciones() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/resoluciones_totales'

            try {
                this.showResolucionesBar = true

                const params = {
                    cod_corte: this.user[0].cod_corte,
                    cod_tribunal: this.user[0].cod_tribunal,
                    anoInicio: this.fechas.anoInicio,
                    mesInicio: this.fechas.mesInicio,
                    anoFin: this.fechas.anoFin,
                    mesFin: this.fechas.mesFin,
                    flg_exhorto: this.fechas.exhorto,
                }

                const respResolucionesTotales = await axios.get(req1, {
                    params,
                })
                const dataTerminos = respResolucionesTotales.data

                this.TotalResoluciones = 0

                Object.values(dataTerminos.recordset).map(type => {
                    this.TotalResoluciones = type.cantidad
                })

                this.showResolucionesBar = false
            } catch (error) {
                console.log(error.message)
            }
        },

        openDialogResoluciones() {
            try {
                this.setId_funcionario(0)
                this.setTipoFuncionario('')
                // this.dialogResoluciones = true;
                this.$router.push({ name: 'LaboralResolucionesNomenclaturas' })
            } catch (error) {
                console.log(error)
            }
        },

        goIndicadores(paramRoute) {
            try {
                this.$router.push({ name: paramRoute })
            } catch (error) {
                console.log(error.message)
            }
        },
        async reqTerminosTipos() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/terminos_tipos'
            let archivoEspecialParam = ''

            try {
                if (this.archivoEspecial) {
                    archivoEspecialParam = 't'
                } else {
                    archivoEspecialParam = 'f'
                }

                const params = {
                    cod_corte: this.user[0].cod_corte,
                    cod_tribunal: this.user[0].cod_tribunal,
                    anoInicio: this.fechas.anoInicio,
                    mesInicio: this.fechas.mesInicio,
                    anoFin: this.fechas.anoFin,
                    mesFin: this.fechas.mesFin,
                    archivoEspecial: archivoEspecialParam,
                    flg_exhorto: this.fechas.exhorto,
                }

                const respTerminosData = await axios.get(req1, { params })
                const TerminosData = respTerminosData.data

                let objDetTermino
                let arrayTerminos = []
                this.Terminos = []
                this.TotalTerminosTipos = 0

                Object.values(TerminosData.recordset).map(type => {
                    objDetTermino = new Object()
                    objDetTermino.gls_termino = type.gls_tipfallada
                    objDetTermino.cantidad = type.cantidad
                    this.TotalTerminosTipos += type.cantidad
                    arrayTerminos.push(objDetTermino)
                })

                this.Terminos = arrayTerminos
            } catch (error) {
                throw error
            }
        },
        async obtenerNombreTribunal() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/tribunal_detalle'

            try {
                const params = {
                    cod_corte: this.user[0].cod_corte,
                    cod_tribunal: this.user[0].cod_tribunal,
                }

                const respTribunal = await axios.get(req1, { params })
                const arrayTribunal = respTribunal.data

                Object.values(arrayTribunal.recordset).map(type => {
                    this.nombreTribunal = type.gls_tribunal
                })
            } catch (error) {
                throw error
            }
        },
        async obtenerAudienciasTotales() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/audiencias_resumen'

            const get = async req1 => {
                try {
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })
                    const data = response.data
                    this.audRealizadasTotal = 0
                    this.audNoRealizadas = 0
                    this.audSuspendidas = 0
                    this.audReprogramadas = 0
                    this.audNORealizadasTotal = 0

                    Object.values(data.recordset).map(type => {
                        this.audRealizadasTotal += type.aud_realizadas
                        this.audNoRealizadas += type.aud_no_realizadas
                        this.audSuspendidas += type.aud_suspendidas
                        this.audReprogramadas += type.aud_reprogramadas
                        this.audNORealizadasTotal +=
                            type.aud_no_realizadas +
                            type.aud_suspendidas +
                            type.aud_reprogramadas
                    })
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
        async audienciasVSperiodoanterior() {
            //ESTE METODO DEBE EJECUTARSE DESPUES DE [obtenerAudienciasTotales], YA QUE UTILIZA LAS VARIABLES QUE SE CARGAN EN DICHO METODO
            const axios = require('axios')
            const req1 = urlApi + '/laboral/audiencias_resumen'

            const get = async req1 => {
                try {
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.PeriodoAntanoInicio,
                            mesInicio: this.fechas.PeriodoAntmesInicio,
                            anoFin: this.fechas.PeriodoAntanoFin,
                            mesFin: this.fechas.PeriodoAntmesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })
                    const data = response.data
                    let audRealizadasTotalant = 0
                    let audNORealizadasTotalant = 0

                    Object.values(data.recordset).map(type => {
                        audRealizadasTotalant += type.aud_realizadas
                        audNORealizadasTotalant +=
                            type.aud_no_realizadas +
                            type.aud_suspendidas +
                            type.aud_reprogramadas
                    })

                    this.audRealizadasPrcnt = Math.round(
                        ((this.audRealizadasTotal - audRealizadasTotalant) *
                            100) /
                            audRealizadasTotalant
                    )
                    this.audNORealizadasPrcnt = Math.round(
                        ((this.audNORealizadasTotal - audNORealizadasTotalant) *
                            100) /
                            audNORealizadasTotalant
                    )

                    switch (true) {
                        case this.audRealizadasTotal < audRealizadasTotalant:
                            this.audRealizadasEstado = 'descendente'
                            break
                        case this.audRealizadasTotal > audRealizadasTotalant:
                            this.audRealizadasEstado = 'ascendente'
                            break
                        case this.audRealizadasTotal == audRealizadasTotalant:
                            this.audRealizadasEstado = 'equivalente'
                            break
                    }

                    switch (true) {
                        case this.audNORealizadasTotal <
                            audNORealizadasTotalant:
                            this.audNORealizadasEstado = 'descendente'
                            break
                        case this.audNORealizadasTotal >
                            audNORealizadasTotalant:
                            this.audNORealizadasEstado = 'ascendente'
                            break
                        case this.audNORealizadasTotal ==
                            audNORealizadasTotalant:
                            this.audNORealizadasEstado = 'equivalente'
                            break
                    }

                    switch (this.fechas.TipoBusqueda) {
                        case 'Mensual':
                            this.glosaPeriodoAnterior = 'Mes'
                            break
                        case 'CuatrimestreMovil':
                            this.glosaPeriodoAnterior = 'Cuatrimestre'
                            break
                        case 'CuatrimestreFijo':
                            this.glosaPeriodoAnterior = 'Cuatrimestre'
                            break
                        case 'AñoFijo':
                            this.glosaPeriodoAnterior = 'Año'
                            break
                        case 'AñoMovil':
                            this.glosaPeriodoAnterior = 'Año'
                            break
                        case 'Trimestre':
                            this.glosaPeriodoAnterior = 'Trimestre'
                            break
                        default:
                            this.glosaPeriodoAnterior = ''
                            break
                    }
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
        obtenerResumenJueces() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/jueces_resumen'
            const req2 = urlApi + '/laboral/resoluciones_detalle'
            const req3 = urlApi + '/laboral/audiencias_realizadas_resumen'
            const req4 = urlApi + '/laboral/conciliaciones_detalle'

            const get = async req => {
                try {
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    const responseRes = await axios.get(req2, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    const responseAud = await axios.get(req3, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    const responseCon = await axios.get(req4, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    const data = response.data
                    let objResumen
                    this.arrResumenJuez = []
                    this.totalResJueces = 0
                    this.totalAudJueces = 0
                    this.totalConciJueces = 0

                    Object.values(data.recordset).map(type => {
                        if (type.aud_totales != 0 || type.resoluciones != 0) {
                            objResumen = new Object()
                            objResumen.id = type.crr_idfuncionario
                            objResumen.nombre = type.nombre_completo
                            objResumen.aud_realizadas = type.aud_realizadas
                            objResumen.aud_no_realizadas =
                                type.aud_no_realizadas
                            objResumen.aud_suspendidas = type.aud_suspendidas
                            objResumen.aud_reprogramadas =
                                type.aud_reprogramadas
                            objResumen.aud_totales = type.aud_totales
                            objResumen.resoluciones = type.resoluciones
                            objResumen.conciliaciones = type.conciliaciones
                            this.totalResJueces += objResumen.resoluciones
                            this.totalAudJueces += objResumen.aud_realizadas
                            this.totalConciJueces += objResumen.conciliaciones

                            this.arrResumenJuez.push(objResumen)
                        }
                    })

                    const dataRes = responseRes.data
                    let objDetellaRes
                    this.arrDetalleResoluciones = []

                    Object.values(dataRes.recordset).map(type => {
                        objDetellaRes = new Object()
                        objDetellaRes.crr_causa = type.crr_causa
                        objDetellaRes.rit = type.rit
                        objDetellaRes.crr_idtramite = type.crr_idtramite
                        objDetellaRes.funcionario = type.funcionario
                        objDetellaRes.fec_ingreso = type.fec_ingreso
                        objDetellaRes.fec_tramite = type.fec_tramite

                        this.arrDetalleResoluciones.push(objDetellaRes)
                    })

                    const dataAud = responseAud.data
                    let objDetalleAud
                    this.arrDetalleAudiendiasRealizada = []

                    Object.values(dataAud.recordset).map(type => {
                        objDetalleAud = new Object()
                        objDetalleAud.crr_causa = type.crr_causa
                        objDetalleAud.rit = type.rit
                        objDetalleAud.fec_ingreso = type.fec_ingreso
                        objDetalleAud.fec_audiencia_real =
                            type.fec_audiencia_real
                        objDetalleAud.gls_tipaudiencia = type.gls_tipaudiencia
                        objDetalleAud.funcionario = type.nombre

                        this.arrDetalleAudiendiasRealizada.push(objDetalleAud)
                    })

                    const dataCon = responseCon.data
                    let objDetalleCon
                    this.arrDetalleConciliaciones = []

                    Object.values(dataCon.recordset).map(type => {
                        objDetalleCon = new Object()
                        objDetalleCon.crr_causa = type.crr_causa
                        objDetalleCon.rit = type.rit
                        objDetalleCon.funcionario = type.funcionario
                        objDetalleCon.fec_ingreso = type.fec_ingreso
                        objDetalleCon.gls_tipaudiencia = type.gls_tipaudiencia
                        objDetalleCon.fec_audiencia_real =
                            type.fec_audiencia_real

                        this.arrDetalleConciliaciones.push(objDetalleCon)
                    })
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
        async obtenerPromedioAtrasos() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/audiencias_prep_promedio_atrasos'
            const req2 = urlApi + '/laboral/audiencias_juicio_promedio_atrasos'

            const get = async req1 => {
                try {
                    const responsePrep = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    const responseJuicio = await axios.get(req2, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    //PREPARATORIAS
                    const dataPrep = responsePrep.data

                    Object.values(dataPrep.recordset).map(type => {
                        this.atrasosPromedioPrep = type.prom_atraso
                    })

                    //JUICIOS
                    const dataJuicio = responseJuicio.data

                    Object.values(dataJuicio.recordset).map(type => {
                        this.atrasosPromedioJuicio = type.prom_atraso
                    })
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
        async obtenerSalas() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/salas_creadas'
            const req2 = urlApi + '/laboral/salas_usadas'

            const get = async req1 => {
                try {
                    const responseCantSalas = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                        },
                    })

                    const responseCantSalasUsadas = await axios.get(req2, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    //PREPARATORIAS
                    const dataCantSalas = responseCantSalas.data

                    Object.values(dataCantSalas.recordset).map(type => {
                        this.cantidadSalas = type.cantidad
                    })

                    //JUICIOS
                    const dataCantSalasUsadas = responseCantSalasUsadas.data

                    Object.values(dataCantSalasUsadas.recordset).map(type => {
                        this.cantidadSalasUsadas = type.cantidad
                    })
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
        async terminosTotales() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/terminos_totales'
            let archivoEspecialParam = ''

            if (this.archivoEspecial) {
                archivoEspecialParam = 't'
            } else {
                archivoEspecialParam = 'f'
            }

            const get = async req1 => {
                try {
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            archivoEspecial: archivoEspecialParam,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })
                    //INI-Terminos Totales
                    const TerminosTotales = response.data
                    this.TotalTerminos = 0

                    Object.values(TerminosTotales.recordset).map(type => {
                        this.TotalTerminos = type.cantidad
                    })
                    //FIN-Terminos Totales
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
        async detalleAtrasosAudiencias() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/audiencias_detalle_atrasos'

            const get = async req1 => {
                try {
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal,
                            anoInicio: this.fechas.anoInicio,
                            mesInicio: this.fechas.mesInicio,
                            anoFin: this.fechas.anoFin,
                            mesFin: this.fechas.mesFin,
                            flg_exhorto: this.fechas.exhorto,
                        },
                    })

                    //JUICIOS
                    const dataDetalleAtrasos = response.data
                    this.dataDetalleAtrasos = []
                    let objDetalleAtraso
                    let contador = 0

                    Object.values(dataDetalleAtrasos.recordset).map(type => {
                        contador += 1
                        objDetalleAtraso = new Object()
                        objDetalleAtraso.contador = contador
                        objDetalleAtraso.rit = type.rit
                        objDetalleAtraso.gls_tipaudiencia =
                            type.gls_tipaudiencia
                        objDetalleAtraso.fecha_audiencia = type.fecha_audiencia
                        objDetalleAtraso.hora_estipulada = type.hora_estipulada
                        objDetalleAtraso.hora_ini_real = type.hora_ini_real
                        objDetalleAtraso.minutos_atraso = type.minutos_atraso
                        objDetalleAtraso.juez = type.juez
                        this.dataDetalleAtrasos.push(objDetalleAtraso)
                    })
                } catch (error) {
                    console.log(error)
                }
            }

            get(req1)
        },
    },
    computed: {
        ...mapState(['fechas']),
    },
    watch: {
        fechas() {
            try {
                this.consultaIngresos()
                this.consultaTerminos()
                this.consultaResoluciones()
                this.reqTerminosTipos()
                this.obtenerNombreTribunal()
                this.obtenerAudienciasTotales()
                this.obtenerResumenJueces()
                this.audienciasVSperiodoanterior()
                this.obtenerPromedioAtrasos()
                this.obtenerSalas()
                this.detalleAtrasosAudiencias()

                this.$forceUpdate()
            } catch (error) {
                console.log(error)
            }
        },
        async archivoEspecial() {
            this.terminosTotales()
            this.reqTerminosTipos()
        },
    },
    components: {
        FiltrosCompetencias,
        highcharts: Chart,
        IngresosCausas,
        IngresosTipoIngresos,
        IngresosTipoMaterias,
        TerminosTipos,
        TerminosMaterias,
        TerminosProcedimientos,
        countTo,
        ResolucionesNomenclaturas,
    },
}
</script>

<style scoped>
.v-card .cardAction {
    transition: opacity 0.4s ease-in-out;
}

.v-card:not(.on-hover) .cardAction {
    opacity: 1;
}

.show-btns .cardAction {
    color: rgba(255, 255, 255, 1) !important;
}

.verde {
    color: #00df69;
}

.amarillo {
    color: #f4f000;
}

.rojo {
    color: #fc0202;
}

.colorPjud {
    color: #5461a9;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}
</style>
