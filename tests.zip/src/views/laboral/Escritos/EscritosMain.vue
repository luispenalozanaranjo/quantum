<template>
    <Layout>
        <v-card>
            <v-card flat>
                <v-card-title class="pjud white--text">
                    Filtros
                    <v-spacer></v-spacer>                
                </v-card-title>
                <v-card-text>
                    <FiltrosCompetencias class="mt-4"/>
                </v-card-text>
            </v-card>

            <v-card-text>
                <v-tabs v-model="tab" background-color="accent-4" centered>
                    <v-tabs-slider></v-tabs-slider>
                    <v-tab href="#tab-1">Tipos Escritos</v-tab>
                    <v-tab href="#tab-2">Tipos de Ingresos</v-tab>
                </v-tabs>

                <v-tabs-items v-model="tab">
                    <v-tab-item id="tab-1">
                            <EscritosTipos />
                    </v-tab-item>
                    <v-tab-item id="tab-2">
                            <EscritosTiposIngresos />
                    </v-tab-item> 
                </v-tabs-items>
            </v-card-text>
            
        </v-card>
    </Layout>
</template>
<script>
import FiltrosCompetencias from '../../../components/elementos/FiltrosCompetencias'
import store from 'store'
import EscritosTipos from './EscritosTipos'
import EscritosTiposIngresos from './EscritosTiposIngresos'
import { mapState, mapMutations } from 'vuex'
import { quantum } from '../../../config/quantum'
import Layout from '../../../components/competencias/laboral/Layout'


export default {
    name: 'EscritosMain',
    data () {
        return {
            tab: null
            ,urlquauntum: quantum + '/laboral_controller/totalesCorte/'+ store.get('cod_corte')
        }
    },
    components: {
        Layout,
        FiltrosCompetencias,
        EscritosTipos,
        EscritosTiposIngresos
    }
} 
</script>