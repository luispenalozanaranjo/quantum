<template>
    <v-card class="pdfi">
        <v-card>
            <v-card-title>
                Escritos Tipos Ingresos
                <v-spacer></v-spacer>
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <v-icon
                            color="orange"
                            dark
                            large
                            v-bind="attrs"
                            v-on="on"
                        >
                            mdi-information-outline
                        </v-icon>
                        </template>
                        <h4 class="orange--text">Criterios</h4>
                        Los siguientes tipos de escritos no son considerados:<br/>
                        <ul>
                            <li>Ingreso Demanda</li>
                            <li>Ingreso medida prejudicial</li>
                            <li>Ingreso denuncia</li>
                            <li>Notificacion</li>
                            <li>Devolución Cobranza</li>
                        </ul>
                </v-tooltip>
            </v-card-title>
            <v-card-subtitle>
                {{fechas.periodo}}
            </v-card-subtitle>
            <v-card-text>
                <!-- INI DETALLE INGRESOS -->
                <ModalDetalle :tipoModal="this.tipoModal" />
                <!-- FIN DETALLE INGRESOS -->
                <apexchart height="400" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico2"></apexchart>

                <vue-excel-xlsx class="btn text-center mt-5"
                    :data="Query_Escritos"
                    :columns="excelHead"
                    :filename="'Escritos_tipos_ingresos'"
                    :sheetname="'Hoja1'"
                >
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs" v-on="on"
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>
                            </v-btn>
                        </template>
                        <span>Exportar a excel</span>
                    </v-tooltip>
                </vue-excel-xlsx>
                <v-data-table 
                        :headers="headers"
                        :items="Query_Escritos"
                        :sort-by="['cantidad']"
                        :sort-desc="[true]"
                        dense
                        class="mt-1"
                        >
                        <template v-slot:[`body`]="{ items }">
                            <tbody>
                            <tr v-for="item in items " :key="item.increment">
                                <td class="text-center">{{ item.increment }}</td>
                                <td class="text-center">{{ item.tipo_ingreso_causa }}</td>
                                <td class="text-center"><countTo class="count" :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo></td>
                            </tr>
                            </tbody>
                            <tfoot>
                                <tr class="pjud white--text">
                                    <th></th>
                                    <th class="text-center  subtitle-2">Total</th>
                                    <th class="text-center  subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                                </tr>
                            </tfoot>
                        </template>
                </v-data-table>

            </v-card-text>
        </v-card>
        <ModalLoading/>
    </v-card>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { urlApi } from '../../../config/api'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import ModalDetalle from '../ModalDetalles.vue'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"

export default {
    name: 'EscritosTiposIngresos',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            Query_Escritos: [],        
            headers: [
                { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text subtitle-2'},
                { text: 'Tipo Ingreso',  align: 'center', value: 'tipo_ingreso_causa', class : 'pjud white--text subtitle-2'},
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text subtitle-2'}
            ],
            excelHead : [{label: "#",               field: "increment"},
                        {label: "Tipo Ingreso",     field:  "tipo_ingreso_causa"},
                        {label: "Cantidad",         field:  "cantidad"}
            ],
            total : 0 , 
            tipoModal: "escritosTipos",
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    height: 400,
                    type: 'pie',
                    id: 'pieGrafico2',
                },
                dataLabels: {
                    enabled: true,
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                }
			}, 
        }
    },
    created(){
        try {
            this.setModal(true);
            this.$gtag.event('laboral_escritos_tipos_ingresos', { method: 'Google' });
            this.getEscritosTiposIngresos();
        } catch (error) {
            console.log(error);
        }finally{
            this.setModal(false);
        }

    },
    components: {
        ModalLoading,
        ModalDetalle,
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        //  downloadPDF(){
        //     window.scrollTo(0,0) // Desplaza hacia arriba
                
        //     html2canvas(document.querySelector('.pdfi')).then(canvas => {
        //         let image = canvas.toDataURL('image/png')
                
        //         let doc = new jsPDF('p', 'pt', 'a1');
        //         doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
        //         doc.save('DashboardTerminos.pdf')
        //     })
        // },  
        async getEscritosTiposIngresos() {
            const axios = require('axios');
            const req1 = urlApi + '/laboral/escritos_tipos_ingresos';
            this.Query_Escritos = [];
            this.total = 0;
            let dataLabelsAux = [];
            let dataSeriesAux = [];
           
            const get = async req1 => {
                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user[0].cod_corte || this.$route.params.cod_corte,
                            cod_tribunal: this.user[0].cod_tribunal || this.$route.params.cod_tribunal,
                            anoInicio:  this.fechas.anoInicio || this.$route.params.ano,
                            mesInicio: this.fechas.mesInicio || this.$route.params.mes,
                            anoFin: this.fechas.anoFin || this.$route.params.ano,
                            mesFin: this.fechas.mesFin || this.$route.params.mes,
                            flg_exhorto: this.fechas.exhortos || 0
                        }
                    });
                        
                    const data = response.data;
                    let contador = 1;

                    Object.values(data.recordset).map((type) => {

                        dataLabelsAux.push(type.tipo_ingreso_causa);
                        dataSeriesAux.push(type.cantidad);

                        this.Query_Escritos.push({
                            increment: contador,
                            cod_tribunal: type.cod_tribunal,
                            tipo_ingreso_causa: type.tipo_ingreso_causa,
                            cantidad: type.cantidad
                        });

                        this.total += type.cantidad;

                        contador+= 1;

                    });

                    //Series
                    this.pieSeries = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico2', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);


                } 
                catch (error) {
                    console.log(error);
                }
            }

            get(req1);  
           
        },
    },

    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.getEscritosTiposIngresos()
        }
    }
} 
</script>