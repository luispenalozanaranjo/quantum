<template>
    <v-card class="pdfi" id="pdfi">
        <v-card-title>
            Ingresos por causa
            <v-spacer></v-spacer>
            <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                    <v-icon
                        color="orange"
                        dark
                        large
                        v-bind="attrs"
                        v-on="on"
                    >
                        mdi-information-outline
                    </v-icon>
                </template>
                <h4 class="orange--text">Criterios</h4>
                Los siguientes tipos de solicitudes son considerados:<br/>
                <ul>
                    <li>• Ingreso demanda</li>
                    <li>• Ingreso medida prejudicial</li>
                    <li>• Ingreso denuncia</li>
                </ul>
            </v-tooltip>
        </v-card-title>
        <v-card-subtitle>
            {{fechas.periodo}}
        </v-card-subtitle>
        <v-card-text>
            <v-row>
                <v-col sm="12">
                    <ModalDetalleIngresos/> 
                    <v-spacer></v-spacer>
                </v-col> 
            </v-row>
            <v-row>
                <v-col sm="12">
                    <!--<apexchart height="400" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico"></apexchart>-->
                    <ShareDataset :series="pieData" />
                </v-col>
            </v-row>
            <v-row>
                <v-col sm="12">        
                    <vue-excel-xlsx class="btn text-center"
                        :data="Query_Ingreso"
                        :columns="excelHead"
                        :filename="'Ingreso Causa'"
                        :sheetname="'Hoja1'"
                    >
                        <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn
                                    class="mx-2"
                                    fab
                                    dark
                                    small
                                    color="success"
                                    v-bind="attrs" v-on="on"
                                >
                                    <v-icon >mdi-microsoft-excel</v-icon>
                                </v-btn>
                            </template>
                            <span>Exportar a excel</span>
                        </v-tooltip>
                    </vue-excel-xlsx>
                    <v-btn   small  class="pjud white--text" @click="downloadPDF()" >PDF</v-btn>
                </v-col>
            </v-row>
            <v-row>

                <v-col sm="12">
                    <Tabla :total="total" :sort_desc="sort_desc" :pieData="Query_Ingreso" :headers="headers" :sort-desc="true" />
                </v-col> 

            </v-row>
                
        </v-card-text>   
    </v-card>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { urlApi } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import ModalDetalleIngresos from './ModalDetallesIngresosCausas'
import es from "apexcharts/dist/locales/es.json";
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"
import ShareDataset from '../../../components/elementos/grafico/ShareDataset.vue'
import Tabla from '../../../components/elementos/tablas/tabla.vue'


export default {
    name: 'Ingresos',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            sort_desc: "",
            pieSeries: [],
            pieData: [],
            pieChartOptions: {
                chart: {
                    id: 'pieGrafico',
                    height: 400,
                    type: 'pie',
                    locales: [es],
                    defaultLocale: "es",   
                },
                noData: {
                    text: 'Visualizando'
                },  
                dataLabels: {
                    enabled: true,
                    formatter: function (val) {
                        return val.toFixed(2).toString().replace('.',',') + '%'
                    }  
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                    horizontalAlign: 'center',
                    onItemHover: {
                        highlightDataSeries: true
                    },
                    onItemClick: {
                        toggleDataSeries: true
                    },
                    // floating: true,
                },
			}, 
            Query_Ingreso: [],        
            headers: [
                { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text'},
                { text: 'Tipo Causa',  align: 'center', value: 'tip_causa', class : 'pjud white--text'},
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text'},
              ],
            excelHead : [
                {
                    label: "#",
                    field: "increment",

                },

                {
                
                    label: "Tipo Causa",
                    field:  "tip_causa",
  
                },


                {
                
                    label: "Cantidad",
                    field:  "cantidad",
  
                },

                 {
                    label: "Total",
                    field: "totales",
                }

                                                                                                                                                                                               
            ],
            excelHead2 : [
                {
                    label: "#",
                    field: "increment",

                },

                {
                
                    label: "Tipo Materia",
                    field:  "gls_materia",
  
                },


                {
                
                    label: "Cantidad",
                    field:  "cantidad",
  
                }


                                                                                                                                                                                               
            ],
            total : 0 ,
        }
    },
    created(){
        this.$gtag.event('laboral_ingresos_causas', { method: 'Google' });
        this.consulta_ingreso();
    },
    components: {
        ModalLoading,
        ModalDetalleIngresos,
        countTo,
        ShareDataset,
        Tabla
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
                
            html2canvas(document.querySelector('.pdfi')).then(canvas => {
                let image = canvas.toDataURL('image/png')
                
                let doc = new jsPDF('p', 'pt', 'a1');
                doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
                doc.save('DashboardIngresos.pdf')
            })    
            

            // html2canvas(document.querySelector('.pdfi'), {imageTimeout: 5000, useCORS: true}).then(canvas => {
            //     document.getElementById('pdfi').appendChild(canvas)

            //     let img = canvas.toDataURL('image/png')
            //     let pdf = new jsPDF('p', 'pt', 'a1');
            //     pdf.addImage(img, 'JPEG', 5, 5, 200, 287)
            //     pdf.save('relatorio-remoto.pdf')
            //     document.getElementById('pdf').innerHTML = ''

            // })
            

        },
 
        consulta_ingreso() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/laboral/ingresos_causa' 
            this.Query_Ingreso = []
            this.total = 0
            let dataLabelsAux = [];
            let dataSeriesAux = [];

            axios.all([
                    axios.get(req1, {
                    params: {
                        cod_corte: this.user[0].cod_corte,
                        cod_tribunal: this.user[0].cod_tribunal,
                        anoInicio: this.fechas.anoInicio,
                        mesInicio: this.fechas.mesInicio,
                        anoFin: this.fechas.anoFin,
                        mesFin: this.fechas.mesFin,
                        flg_exhorto: this.fechas.exhorto
                    }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objIngreso;
                    let increment = 1
                   
                    Object.values(data1.recordset).map((type) => {

                        objIngreso = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                        objIngreso.cod_corte = type.cod_corte
                        objIngreso.cod_tribunal = type.cod_tribunal
                        objIngreso.ano = type.ano
                        objIngreso.mes = type.mes
                        objIngreso.increment = increment
                        objIngreso.tip_causa = type.tip_causa
                        objIngreso.cantidad = type.cantidad
                        this.total= this.total + type.cantidad
                        
                        dataLabelsAux.push(type.tip_causa);
                        dataSeriesAux.push(type.cantidad);

                        this.Query_Ingreso.push(objIngreso) // push para la tabla 
                        increment ++ 
                       
                    });

                    this.headers =[
                        { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text'},
                        { text: 'Tipo Causa',  align: 'center', value: 'tip_causa', class : 'pjud white--text'},
                        { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text'},
                    ];
            
                    this.sort_desc = "";
                    this.sort_desc = "[true]";
                    //Series
                    this.pieSeries = dataSeriesAux;

                    this.pieData = [];
                    this.pieData = data1.recordset;

                    this.setModal(false) // Aqui Manipulamos el modal                     

            })).catch(errors => {
                console.log(errors)
            })
            
        }  
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.consulta_ingreso()
        }
    }
} 
</script>