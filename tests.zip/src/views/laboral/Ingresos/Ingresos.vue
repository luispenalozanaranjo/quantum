<template>
  <v-container fluid>
    <v-row>
      <v-col cols="9">
        <!-- Botón para fusionar las dos primeras filas -->
        <v-btn color="primary" @click="mergeFirstTwoRows">
          Fusionar las dos primeras filas
        </v-btn>
        <draggable
          v-model="sections"
          class="drag-container"
          :options="{ group: 'sections', animation: 200 }"
        >
          <v-row
            v-for="(sectionRow, rowIndex) in sectionRows"
            :key="rowIndex"
            class="section-row"
            :class="{
              'combined-1-2': isCombined1and2 && rowIndex === 0,
              'combined-1-3': isCombined1and3 && rowIndex === 0,
            }"
          >
            <v-col
              v-for="(section, colIndex) in sectionRow"
              :key="colIndex"
              :cols="getColSpan(rowIndex, colIndex)"
              :class="[
                'section-col',
                getItemClass(rowIndex, colIndex),
              ]"
              @mousedown="handleMouseOver(rowIndex, colIndex)"
              
            >
              <draggable
                v-model="section.items"
                class="drag-container"
                :options="{ group: 'components', animation: 200 }"
                @add="componenteAgregado(rowIndex, colIndex, $event)"
                @remove="componenteQuitado(rowIndex, colIndex, $event)"
              >
                <v-row>
                  <v-col
                    v-for="(item, idx) in section.items"
                    :key="idx"
                    :cols="item.cols"
                    class="component-col"
                  >
                    <component
                      :is="item.component"
                      :series="pieData"
                      :total="total"
                      :sort_desc="sort_desc"
                      :pieData="Query_Ingreso"
                      :headers="headers"
                      :sort-desc="true"
                    />
                  </v-col>
                </v-row>
              </draggable>
            </v-col>
          </v-row>
        </draggable>
      </v-col>
      <v-col cols="3">
        <v-card class="component-selection">
          <v-card-title>Seleccionar Componentes</v-card-title>
          <v-card-text>
            <draggable
              v-model="availableComponents"
              class="drag-container"
              :options="{ group: 'components', animation: 200 }"
            >
              <v-list-item
                v-for="(component, index) in availableComponents"
                :key="index"
                class="component-item"
              >
                <v-list-item-title>{{ component.name }}</v-list-item-title>
              </v-list-item>
            </draggable>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>


<script>
import draggable from "vuedraggable";
import ModalLoading from "../../../components/elementos/ModalLoading";
import store from "store";
import { urlApi } from "../../../config/api";
import { mapState, mapMutations } from 'vuex'
import countTo from "vue-count-to";
import ModalDetalleIngresos from "./ModalDetallesIngresosCausas";
import es from "apexcharts/dist/locales/es.json";
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"
import ShareDataset from "../../../components/elementos/grafico/ShareDataset.vue";
import Tabla from "../../../components/elementos/tablas/tabla.vue";

export default {
  name: "Ingresos",

  data() {
    return {
      isCombined1and2: false,
      isCombined1and3: false,
      sections: [
        { type: "row", items: [] },
        { type: "row", items: [] },
        { type: "row", items: [] },
        { type: "row", items: [] }
      ],
      availableComponents: [
        {
          name: "Tabla de Datos Tipo Causa",
          component: "Tabla",
          cols: 12
        },
        {
          name: "Grafico Tipo Causa",
          component: "ShareDataset",
          cols: 12
        },
        {
          name: "Detalle Ingresos",
          component: "ModalDetalleIngresos",
          cols: 12
        }
      ],
      user: [{
              usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
              cod_corte : store.get('cod_corte'),
              cod_tribunal : store.get('cod_tribunal'),
              ano : store.get('ano'),
              mes : store.get('mes')
          }],
          sort_desc: "",
          pieSeries: [],
          pieData: [],
          pieChartOptions: {
              chart: {
                  id: 'pieGrafico',
                  height: 400,
                  type: 'pie',
                  locales: [es],
                  defaultLocale: "es",   
              },
              noData: {
                  text: 'Visualizando'
              },  
              dataLabels: {
                  enabled: true,
                  formatter: function (val) {
                      return val.toFixed(2).toString().replace('.',',') + '%'
                  }  
              },
      labels: [],
              legend: {
                  show: true,
                  position: 'bottom',
                  horizontalAlign: 'center',
                  onItemHover: {
                      highlightDataSeries: true
                  },
                  onItemClick: {
                      toggleDataSeries: true
                  },
                  // floating: true,
              },
    }, 
          Query_Ingreso: [],        
          headers: [
              { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text'},
              { text: 'Tipo Causa',  align: 'center', value: 'tip_causa', class : 'pjud white--text'},
              { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text'},
            ],
          excelHead : [
              {
                  label: "#",
                  field: "increment",

              },

              {
              
                  label: "Tipo Causa",
                  field:  "tip_causa",

              },


              {
              
                  label: "Cantidad",
                  field:  "cantidad",

              },

               {
                  label: "Total",
                  field: "totales",
              }

                                                                                                                                                                                             
          ],
          excelHead2 : [
              {
                  label: "#",
                  field: "increment",

              },

              {
              
                  label: "Tipo Materia",
                  field:  "gls_materia",

              },


              {
              
                  label: "Cantidad",
                  field:  "cantidad",

              }


                                                                                                                                                                                             
          ],
          total : 0
    };
  },
  created(){
      this.$gtag.event('laboral_ingresos_causas', { method: 'Google' });
      this.consulta_ingreso();
  },
  components: {
    draggable,
    ModalLoading,
    ModalDetalleIngresos,
    countTo,
    ShareDataset,
    Tabla
  },

  methods: {
    ...mapMutations(['setModal']), // Mutations no Borrar
        // Método para fusionar las dos primeras filas
        mergeFirstTwoRows() {
          alert('bbbb')
        // Combinar las dos primeras filas en una
        this.sections[0].cols = 12; // La primera celda abarca toda la fila
        this.sections[1] = { type: "row", items: [] }; // Eliminar la segunda fila para combinar
       
        // También puedes eliminar el objeto de la segunda fila si no se va a utilizar
        this.sections.splice(1, 1);
    },
    toggleGrid(combination, state = null) {

      if (combination === 'combine1and2') {
        if (state !== null) {

          this.isCombined1and2 = !this.isCombined1and2;
        } else {
          this.isCombined1and2 = state;
        }
        if (this.isCombined1and2) {
          this.isCombined1and3 = false;
        }
      } else if (combination === 'combine1and3') {

        if (state !== null) {
          this.isCombined1and3 = !this.isCombined1and3;
        } else {
          this.isCombined1and3 = state;
        }
        if (this.isCombined1and3) {
          this.isCombined1and2 = false;
        }
      }
    },
    getColSpan(rowIndex, colIndex) {
      console.log(this.isCombined1and2+' '+rowIndex+' '+colIndex);
      console.log(this.isCombined1and2 && rowIndex === 0 && colIndex === 0);
      if (this.isCombined1and2 && rowIndex === 0 && colIndex === 0) {
          console.log('forgi');
        return 12;
      }
      return 6;
    },
    getItemClass(rowIndex, colIndex) {
      var item='';
      if (colIndex === 0 && rowIndex === 0) item="item-1";
      if (colIndex === 1 && rowIndex === 0) item="item-2";
      if (colIndex === 0 && rowIndex === 1) item="item-3";
      if (colIndex === 1 && rowIndex === 1) item="item-4";
      return item;
    },
    handleMouseOver(rowIndex, colIndex) {

      if (rowIndex === 0 && colIndex === 0) {
        this.toggleGrid("combine1and2", true);
      } else if (rowIndex === 1 && colIndex === 0) {
        this.toggleGrid("combine1and3", true);
      }
    },
    handleMouseLeave(rowIndex, colIndex) {
      if (rowIndex === 0 && colIndex === 0) {
        this.toggleGrid("combine1and2", false);
      } else if (rowIndex === 1 && colIndex === 0) {
        this.toggleGrid("combine1and3", false);
      }
    },
downloadPDF(){
  window.scrollTo(0,0) // Desplaza hacia arriba
      
  html2canvas(document.querySelector('.pdfi')).then(canvas => {
      let image = canvas.toDataURL('image/png')
      
      let doc = new jsPDF('p', 'pt', 'a1');
      doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
      doc.save('DashboardIngresos.pdf')
  })    
  

  // html2canvas(document.querySelector('.pdfi'), {imageTimeout: 5000, useCORS: true}).then(canvas => {
  //     document.getElementById('pdfi').appendChild(canvas)

  //     let img = canvas.toDataURL('image/png')
  //     let pdf = new jsPDF('p', 'pt', 'a1');
  //     pdf.addImage(img, 'JPEG', 5, 5, 200, 287)
  //     pdf.save('relatorio-remoto.pdf')
  //     document.getElementById('pdf').innerHTML = ''

  // })
  

},

consulta_ingreso() {
  this.setModal(true) // Aqui Manipulamos el modal
  const axios = require('axios')
  const req1 = urlApi + '/laboral/ingresos_causa' 
  this.Query_Ingreso = []
  this.total = 0
  let dataLabelsAux = [];
  let dataSeriesAux = [];

  axios.all([
          axios.get(req1, {
          params: {
              cod_corte: this.user[0].cod_corte,
              cod_tribunal: this.user[0].cod_tribunal,
              anoInicio: this.fechas.anoInicio,
              mesInicio: this.fechas.mesInicio,
              anoFin: this.fechas.anoFin,
              mesFin: this.fechas.mesFin,
              flg_exhorto: this.fechas.exhorto
          }
          })

      ]).then(axios.spread((...responses) => {

          const data1 = responses[0].data
          let objIngreso;
          let increment = 1
         
          Object.values(data1.recordset).map((type) => {

              objIngreso = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
              objIngreso.cod_corte = type.cod_corte
              objIngreso.cod_tribunal = type.cod_tribunal
              objIngreso.ano = type.ano
              objIngreso.mes = type.mes
              objIngreso.increment = increment
              objIngreso.tip_causa = type.tip_causa
              objIngreso.cantidad = type.cantidad
              this.total= this.total + type.cantidad
              
              dataLabelsAux.push(type.tip_causa);
              dataSeriesAux.push(type.cantidad);

              this.Query_Ingreso.push(objIngreso) // push para la tabla 
              increment ++ 
             
          });

          this.headers =[
              { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text'},
              { text: 'Tipo Causa',  align: 'center', value: 'tip_causa', class : 'pjud white--text'},
              { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text'},
          ];
  
          this.sort_desc = "";
          this.sort_desc = "[true]";
          //Series
          this.pieSeries = dataSeriesAux;

          this.pieData = [];
          this.pieData = data1.recordset;

          this.setModal(false) // Aqui Manipulamos el modal                     

   })).catch(errors => {
      console.log(errors)
   })
  
    },
   componenteAgregado(rowIndex, colIndex, event) {

  const section = this.sections[rowIndex * 2 + colIndex];
  console.log(this.availableComponents);
  console.log(section.items[0]);
  console.log(section.items[0].cols);
if (section.items.length > 1) {
  // Ya existe un componente en la celda, elimina el componente que se acaba de agregar
  console.log(`No se puede agregar otro componente en la fila ${rowIndex + 1}, columna ${colIndex + 1}.`);
  console.log(section.items);
  this.availableComponents.push(section.items[1]);
  // Elimina el componente recién agregado para mantener solo uno
  section.items.pop();
} else {
  console.log(`Componente agregado en la fila ${rowIndex + 1}, columna ${colIndex + 1}`);
}
      },

      componenteQuitado(rowIndex, colIndex, event) {
          const section = this.sections[rowIndex * 2 + colIndex];
  const fromSectionIndex = this.sections.findIndex(
      sec => sec.items === event.from
  );

  // Verifica si el componente removido proviene de otra celda
  if (fromSectionIndex !== (rowIndex * 2 + colIndex)) {
      console.log(`El componente fue movido de la fila ${Math.floor(fromSectionIndex / 2) + 1}, columna ${(fromSectionIndex % 2) + 1} a la fila ${rowIndex + 1}, columna ${colIndex + 1}`);
  } else {
      console.log(`El componente fue eliminado de la fila ${rowIndex + 1}, columna ${colIndex + 1}`);
  }
      },
              // Método para fusionar las dos columnas superiores en una sola
      mergeColumns(rowIndex) {
      
          this.sections[0].cols = 12; // La primera celda abarca ambas columnas
          this.sections.splice(1, 1);
          //this.sections.splice(0, 1);
          //this.sections.splice(1, 1); // Elimina la segunda celda
      },

      // Método para fusionar las dos filas a la derecha en una sola
      mergeRows(colIndex) {

          this.sections[0].cols = 12; // La celda inferior derecha abarca ambas filas
          this.sections.splice(2, 1); // Elimina la celda derecha
      },
  },

  computed: {
    ...mapState(["fechas"]),
    sectionRows() {
      return [this.sections.slice(0, 2), this.sections.slice(2, 4)];
    }
  },

  watch: {
    fechas() {
      this.consulta_ingreso();
    }
  }
};
</script>


<style scoped>
.drag-container {
  border: 1px dashed #ccc;
  padding: 10px;
  min-height: 200px;
}

.section-row {
  margin-bottom: 20px;
}

.section-col {
  margin-bottom: 10px;
}

.component-col {
  border: 1px solid #ddd;
  padding: 10px;
  background-color: #f9f9f9;
}

.component-selection {
  max-height: 600px;
  overflow-y: auto;
}

.component-item {
  cursor: grab;
  margin-bottom: 10px;
  padding: 10px;
  background-color: #e3e3e3;
  border: 1px solid #ccc;
}

/* Combina item 1 y item 2 */
.combined-1-2 .item-1 {
  grid-column: span 2;
  grid-row: span 1;
}
.combined-1-2 .item-2 {
  display: none;
}

/* Combina item 1 y item 3 */
.combined-1-3 .item-1 {
  grid-row: span 2;
  grid-column: span 1;
}
.combined-1-3 .item-3 {
  display: none;
}
</style>