<template>
    <v-card class="pdfi">
        <v-card>
            <v-card-title>
                Tipos Términos
                <v-spacer></v-spacer>
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <v-icon
                            color="orange"
                            dark
                            large
                            v-bind="attrs"
                            v-on="on"
                        >
                            mdi-information-outline
                        </v-icon>
                    </template>
                    <h4 class="orange--text">Criterios</h4>
                    Estados de los tramites:<br/>
                    <ul>
                        <li>• Firmados</li>
                        <li>• Pregrabados</li>
                    </ul>
                </v-tooltip>
            </v-card-title>
            <v-card-subtitle>
                {{fechas.periodo}}
            </v-card-subtitle>
            <v-card-text>
                <!-- INI DETALLE INGRESOS -->
                <ModalDetalle :tipoModal="this.tipoModal" />
                <!-- FIN DETALLE INGRESOS -->
                <apexchart  height="400" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico"></apexchart>

                <vue-excel-xlsx class="btn text-center mt-5"
                    :data="Query_Ingreso"
                    :columns="excelHead"
                    :filename="'Tipo_Terminos'"
                    :sheetname="'Hoja1'"
                >
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs" v-on="on"
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>
                            </v-btn>
                        </template>
                        <span>Exportar a excel</span>
                    </v-tooltip>
                </vue-excel-xlsx>
                <v-data-table 
                        :headers="headers"
                        :items="Query_Ingreso"
                        :sort-by="['cantidad']"
                        :sort-desc="[true]"
                        :items-per-page="itemsPerPage"
                        hide-default-footer
                        disable-sort
                        dense
                        class="mt-1"
                        >
                        <template v-slot:[`body`]="{ items }">
                            <tbody>
                            <tr v-for="item in items " :key="item.increment">
                                <td class="text-center">{{ item.increment }}</td>
                                <td class="text-center">{{ item.gls_tipfallada }}</td>
                                <td class="text-center"><countTo class="count" :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo></td>
                            </tr>
                            </tbody>
                            <tfoot>
                                <tr class="pjud white--text">
                                    <th></th>
                                    <th class="text-center  subtitle-2">Total</th>
                                    <th class="text-center  subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                                </tr>
                            </tfoot>
                        </template>
                </v-data-table>

            </v-card-text>
        </v-card>
        <ModalLoading/>
    </v-card>
</template>
<script>

import ModalLoading from '../../../components/elementos/ModalLoading'
import store from 'store'
import { urlApi } from '../../../config/api'
import { Chart } from 'highcharts-vue'
import { mapState, mapMutations } from 'vuex'
import countTo from 'vue-count-to'
import ModalDetalle from '../ModalDetalles.vue'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"


export default {
    name: 'TerminosTipos',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            Query_Ingreso: [],
            itemsPerPage: 30,       
            headers: [
                { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text  subtitle-2'},
                { text: 'Tipo Término',  align: 'center', value: 'gls_tipfallada', class : 'pjud white--text  subtitle-2'},
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text  subtitle-2'}
            ],
            excelHead : [{label: "#",               field: "increment"},
                        {label: "Tipo Término",     field:  "gls_tipfallada"},
                        {label: "Cantidad",         field:  "cantidad"}
            ],
            total : 0 , 
            tipoModal: "terminosTipos",
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    height: 400,
                    type: 'pie',
                    id: 'pieGrafico',
                },
                dataLabels: {
                    enabled: true,
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                }
			}, 
        }
    },
    created(){
        this.$gtag.event('laboral_terminos_tipos', { method: 'Google' });
        this.consulta_ingreso();
    },
    components: {
        ModalLoading,
        ModalDetalle,
        countTo
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
                
            html2canvas(document.querySelector('.pdfi')).then(canvas => {
                let image = canvas.toDataURL('image/png')
                
                let doc = new jsPDF('p', 'pt', 'a1');
                doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
                doc.save('DashboardTerminos.pdf')
            })
        }, 
         
        consulta_ingreso() {
            this.setModal(true) // Aqui Manipulamos el modal
            const axios = require('axios')
            const req1 = urlApi + '/laboral/terminos_tipos' 
            this.Query_Ingreso = []
            this.total = 0
            let archivoEspecialParam = ''
            let dataLabelsAux = [];
            let dataSeriesAux = [];

            if(this.archivoEspecial){
                archivoEspecialParam = 't'
            }else {
                archivoEspecialParam = 'f'
            }
              
            axios.all([
                    axios.get(req1, {
                    params: {
                        cod_corte: this.user[0].cod_corte,
                        cod_tribunal: this.user[0].cod_tribunal,
                        anoInicio: this.fechas.anoInicio,
                        mesInicio: this.fechas.mesInicio,
                        anoFin: this.fechas.anoFin,
                        mesFin: this.fechas.mesFin,
                        archivoEspecial: archivoEspecialParam,
                        flg_exhorto: this.fechas.exhorto
                    }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objTermino;
                    let increment = 1
                   
                    Object.values(data1.recordset).map((type) => {

                        objTermino = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                        objTermino.increment = increment
                        objTermino.gls_tipfallada = type.gls_tipfallada
                        objTermino.cantidad = type.cantidad
                        this.total = this.total + type.cantidad

                        this.Query_Ingreso.push(objTermino)

                        dataLabelsAux.push(type.gls_tipfallada);
                        dataSeriesAux.push(type.cantidad);


                        increment ++ 
                    });

                    //Series
                    this.pieSeries = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);


                    this.setModal(false) // Aqui Manipulamos el modal                     

            })).catch(errors => {
                console.log(errors);
                 this.setModal(false);
            })
            
        }  
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.consulta_ingreso()
        },
        archivoEspecial(){
            this.consulta_ingreso()
        }
    },
    props: {
        archivoEspecial: {
            type: Boolean,
            required: false,
            default: true
        },
    }
} 
</script>