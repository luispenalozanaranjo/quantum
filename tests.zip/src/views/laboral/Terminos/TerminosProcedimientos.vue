<template>
    <v-card class="pdfi">
        <v-card>
            <v-card-title>
                Términos Procedimientos
                <v-spacer></v-spacer>
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <v-icon
                            color="orange"
                            dark
                            large
                            v-bind="attrs"
                            v-on="on"
                        >
                            mdi-information-outline
                        </v-icon>
                    </template>
                    <h4 class="orange--text">Criterios</h4>
                    Estados de los tramites:<br/>
                    <ul>
                        <li>• Firmados</li>
                        <li>• Pregrabados</li>
                    </ul>
                </v-tooltip>
            </v-card-title>
            <v-card-subtitle>
                {{fechas.periodo}}
            </v-card-subtitle>
            <v-card-text>
                <!-- INI DETALLE INGRESOS -->
                <ModalDetalle :tipoModal="this.tipoModal" />
                <!-- FIN DETALLE INGRESOS -->
                <apexchart  height="400" :options="pieChartOptions" :series="pieSeries" ref="pieGrafico3"></apexchart>

                <vue-excel-xlsx class="btn text-center mt-5"
                    :data="Query_Ingreso"
                    :columns="excelHead"
                    :filename="'Tipo_Procedimientos'"
                    :sheetname="'Hoja1'"
                >
                    <v-tooltip top>
                        <template v-slot:activator="{ on, attrs }">
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs" v-on="on"
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>
                            </v-btn>
                        </template>
                        <span>Exportar a excel</span>
                    </v-tooltip>
                </vue-excel-xlsx>
                <v-data-table 
                        :headers="headers"
                        :items="Query_Ingreso"
                        :sort-by="['cantidad']"
                        :sort-desc="[true]"
                        dense
                        class="mt-1"
                        >
                        <template v-slot:[`body`]="{ items }">
                            <tbody>
                            <tr v-for="item in items " :key="item.increment">
                                <td class="text-center">{{ item.increment }}</td>
                                <td class="text-center">{{ item.gls_procedimiento }}</td>
                                <td class="text-center"><countTo class="count" :startVal="0" :endVal="item.cantidad" separator="." :duration="1000"></countTo></td>
                            </tr>
                            </tbody>
                            <tfoot>
                                <tr class="pjud white--text">
                                    <th></th>
                                    <th class="text-center  subtitle-2">Total</th>
                                    <th class="text-center  subtitle-2"><countTo class="count" :startVal="0" :endVal="total" separator="." :duration="1000"></countTo></th>
                                </tr>
                            </tfoot>
                        </template>
                </v-data-table>

            </v-card-text>
        </v-card>
    </v-card>
</template>

<script>

import store from 'store'
import { urlApi } from '../../../config/api'
import countTo from 'vue-count-to'
import { mapState, mapMutations } from 'vuex'
import ModalDetalle from '../ModalDetalles.vue'
import html2canvas from 'html2canvas'
import jsPDF  from "jspdf"


export default {
    name: 'TerminosProcedimientos',
    data () {
        return {
            user: [{
                usuario_id : store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte : store.get('cod_corte'),
                cod_tribunal : store.get('cod_tribunal'),
                ano : store.get('ano'),
                mes : store.get('mes')
            }],
            Query_Ingreso: [],        
            headers: [
                { text: '#',  align: 'center', value: 'increment', class : 'pjud white--text subtitle-2'},
                { text: 'Tipo Procedimiento',  align: 'center', value: 'gls_procedimiento', class : 'pjud white--text subtitle-2'},
                { text: 'Cantidad', align: 'center', value: 'cantidad', class : 'pjud white--text subtitle-2'}
            ],
            excelHead : [{label: "#",               field: "increment"},
                        {label: "Tipo Procedimiento",     field:  "gls_procedimiento"},
                        {label: "Cantidad",         field:  "cantidad"}
            ],
            total : 0 , 
            tipoModal: "terminosProcedimientos",
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    height: 400,
                    type: 'pie',
                    id: 'pieGrafico3',
                },
                dataLabels: {
                    enabled: true,
                },
				labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                }
			}, 

        }
    },
    created(){
        try {
            this.$gtag.event('laboral_terminos_procedimientos', { method: 'Google' });
            this.consulta_ingreso();      
        } catch (error) {
            console.log(error.message);
        }

    },
    components: {
        ModalDetalle,
        countTo,
    },  
    methods: { 
        ...mapMutations(['setModal']), // Mutations no Borrar

        downloadPDF(){
            window.scrollTo(0,0) // Desplaza hacia arriba
                
            html2canvas(document.querySelector('.pdfi')).then(canvas => {
                let image = canvas.toDataURL('image/png')
                
                let doc = new jsPDF('p', 'pt', 'a1');
                doc.addImage(image, 'PNG', 10, 10, 1500, 1000)
                doc.save('DashboardTerminos.pdf')
            })    

        },
         
        consulta_ingreso() {
            const axios = require('axios')
            const req1 = urlApi + '/laboral/terminos_procedimientos' 
            this.Query_Ingreso = []
            this.total = 0
            let dataLabelsAux = [];
            let dataSeriesAux = [];
           
              
            axios.all([
                    axios.get(req1, {
                    params: {
                        cod_corte: this.user[0].cod_corte,
                        cod_tribunal: this.user[0].cod_tribunal,
                        anoInicio: this.fechas.anoInicio,
                        mesInicio: this.fechas.mesInicio,
                        anoFin: this.fechas.anoFin,
                        mesFin: this.fechas.mesFin,
                        flg_exhorto: this.fechas.exhorto
                    }
                    })

                ]).then(axios.spread((...responses) => {

                    const data1 = responses[0].data
                    let objTermino;
                    let increment = 1

                    Object.values(data1.recordset).map((type) => {

                        objTermino = new Object();// creamos el objeto para asignarle cada elemento del result de consulta
                        objTermino.increment = increment
                        objTermino.gls_procedimiento = type.gls_procedimiento
                        objTermino.cantidad = type.cantidad
                        this.total = this.total + type.cantidad

                        this.Query_Ingreso.push(objTermino)

                        dataLabelsAux.push(type.gls_procedimiento);
                        dataSeriesAux.push(type.cantidad);

                        increment ++ 
                    });

                    
                    //Series
                    this.pieSeries = dataSeriesAux;
                    //Labels
                    ApexCharts.exec('pieGrafico3', 'updateOptions', {
                        labels: dataLabelsAux
                    }, false, true);         

                })).catch(errors => {
                    console.log(errors.message)
                })
            
        }  
    },
    computed: {
        ...mapState(['fechas'])
    },
    watch: {
        fechas () {
            this.consulta_ingreso()
        }
    }
} 
</script>