<template>
    <v-row>
        <v-col>
            <TotalPresupuestos :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" :cod_corte="cod_corte" v-if="modelList == 0" />
            <v-row>
                <v-col sm="12" md="12">
                    <GraficosPresupuestos :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" :cod_corte="cod_corte" v-if="modelList == 0"/>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <Observacion    
                        :id_competencia=0
                        :anoInforme="anoInforme" 
                        :cod_corte="cod_corte" 
                        :cod_tribunal="cod_tribunal" 
                        :formulario_id="6" 
                    />
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>

<script>
import store from 'store'
import TotalPresupuestos from '../../../components/competencias/jurisdiccional/Presupuestos/TotalPresupuestos'
import GraficosPresupuestos from '../../../components/competencias/jurisdiccional/Presupuestos/GraficosPresupuestos'
import Observacion from '../../../components/competencias/jurisdiccional/ObservacionesSC.vue'
import { mapState } from 'vuex'

export default {
    name: 'JurisdiccionalPresupuestaria',
    data() {
        return {
            modelList: 0,
        }
    },
    components: {
        TotalPresupuestos,
        GraficosPresupuestos,
        Observacion
    },
    props:{
        anoInforme: {
            type: Number,
            required: true
        },
        cod_corte: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        }
    },
    methods:{

    }
}
</script>

<style scoped>
    .border {
    border: 2px dashed purple;
    }
</style>