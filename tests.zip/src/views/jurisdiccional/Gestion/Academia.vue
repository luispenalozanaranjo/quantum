<template>
        <LayoutJurisdiccional>
                <TotalAcademia :anoInforme="anoInforme" :cod_tribunal="user.cod_tribunal" :cod_corte="user.cod_corte" v-if="modelList == 0" />
                <v-row>
                    <v-col sm="12" md="12">
                        <GraficosAcademia :anoInforme="anoInforme" :cod_tribunal="user.cod_tribunal" :cod_corte="user.cod_corte" v-if="modelList == 0"/>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col sm="12" md="12">
                        <TablasAcademia :anoInforme="anoInforme" :cod_tribunal="user.cod_tribunal" :cod_corte="user.cod_corte" v-if="modelList == 0"/>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col md="12">
                        <Observacion    
                            :id_competencia=0
                            :anoInforme="anoInforme" 
                            :cod_corte="user.cod_corte" 
                            :cod_tribunal="user.cod_tribunal" 
                            :formulario_id="10" 
                            :key="this.key"
                            v-if="modelList == 0"
                        />
                    </v-col>
                </v-row>
        </LayoutJurisdiccional>
</template>

<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'
import TotalAcademia from '../../../components/competencias/jurisdiccional/Academia/TotalAcademia'
import GraficosAcademia from '../../../components/competencias/jurisdiccional/Academia/GraficosAcademia'
import TablasAcademia from '../../../components/competencias/jurisdiccional/Academia/TablasAcademia'
import Observacion from '../../../components/competencias/jurisdiccional/ObservacionesSC'

export default {
    name: 'JurisdiccionalAcademia',
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            modelList: 0,
            anoInforme: 0,
            key: 0,
            resumenesIndicadores: [],
            tab: null,
        }
    },
    created() {
        try {
            this.$gtag.event('IGJAcademia', { method: 'Google' });
            this.anoInforme = this.yearInformeJurisdiccional();
            this.getResumenes(this.user.cod_corte, this.user.cod_tribunal, this.anoInforme);
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['yearInformeJurisdiccional']), // Valores Guardados

        async getResumenes(cod_corte, cod_tribunal, ano) {
            try {
                this.key++
                const req = urlJurisdiccional + '/observaciones_ica'

                const getResumenes = await axios.get(req, {
                    params: {
                        formulario_id: 10,
                        cod_corte: cod_corte,
                        cod_tribunal: cod_tribunal,
                        ano: ano,
                    },
                })

                if (getResumenes.status == 200) {
                    this.resumenesIndicadores = getResumenes.data.data;
                } else {
                    console.log(getResumenes.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
        LayoutJurisdiccional,
        TotalAcademia,
        GraficosAcademia,
        TablasAcademia,
        Observacion
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional();
                this.getResumenes(this.user.cod_corte, this.user.cod_tribunal, this.anoInforme);
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}
</script>