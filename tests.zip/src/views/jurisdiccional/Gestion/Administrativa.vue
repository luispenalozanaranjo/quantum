<template>
    <LayoutJurisdiccional>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    1. Información sobre las necesidades y estado de la Infraestructura del juzgado, así como también las mejoras desarrolladas
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion1"
                    v-model="textData1"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:3"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    2. Información sobre las necesidades y estado en el ámbito Informático, así como también las mejoras desarrolladas
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion2"
                    v-model="textData2"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:7"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    3. Acuerdos tomados por los Jueces que ilustren las gestiones y mejoras que ha implementado el propio tribunal
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion3"
                    v-model="textData3"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:5"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    4. Informes solicitados por la Corte de Apelaciones o por el Consejo de Coordinación zonal y los tiempos de respuesta involucrados.
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion4"
                    v-model="textData4"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:3"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    5. Requerimientos formulados por la CAPJ que fueron atendidos y aquellos que se encuentran pendientes respecto de los que se dio una respuesta negativa.
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion5"
                    v-model="textData5"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:3"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    6. Informe sobre las iniciativas de coordinación conducente a optimizar la gestión administrativa y presupuestaria del juzgado.
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion6"
                    v-model="textData6"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:5"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    7. Desafíos futuros del Tribunal en materia administrativa y de gestión.
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion7"
                    v-model="textData7"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:7"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <p class="font-weight-medium">
                    8. General.
                </p>
                <v-textarea
                    outlined
                    name="txtObservacion8"
                    v-model="textData8"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    auto-grow
                    :rows="validaEstado != 1?1:3"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col md="12">
                <v-btn
                    outlined
                    rounded
                    :class="validaEstado != 1 ? '' : 'green white--text'"
                    :disabled="validaEstado != 1"
                    @click="guardarObservacion()"
                    >
                        <v-icon>
                            mdi-content-save-outline
                        </v-icon>
                        Guardar
                </v-btn>
            </v-col>
        </v-row>
        <v-row>
            <v-col md="12">
                    <v-alert
                        dense
                        :type="typeAlert"
                        dismissible
                        v-model="alert"
                    >
                        {{ alertText }}
                    </v-alert>
                </v-col>
        </v-row>
    </LayoutJurisdiccional>
</template>
<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'

export default {
    name: "JurisdiccionalAdministrativa",
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            validaEstado: 1,
            textData1: "",
            textData2: "",
            textData3: "",
            textData4: "",
            textData5: "",
            textData6: "",
            textData7: "",
            textData8: "",
            typeAlert: 'success',
            alertText: '',
            alert: false,
        }
    },
    created() {
        try {
            this.$gtag.event('IGJAdministrativa', { method: 'Google' });
            this.getObservacion();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{
        
        async guardarObservacion(){
            try {
                const req = urlJurisdiccional + '/obsingresos';

                const postObservacion = await axios.post(req, {
                    formulario_id: 9,
                    competencia_id: 0,
                    cod_corte: this.user.cod_corte,
                    cod_tribunal: this.user.cod_tribunal,
                    ano: this.yearInformeJurisdiccional,
                    observacion: [
                        {
                            id: 1,
                            descripcion: this.textData1,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 2,
                            descripcion: this.textData2,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 3,
                            descripcion: this.textData3,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 4,
                            descripcion: this.textData4,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 5,
                            descripcion: this.textData5,
                            estado_observacion_id: 1,
                        },
                                                {
                            id: 6,
                            descripcion: this.textData6,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 7,
                            descripcion: this.textData7,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 8,
                            descripcion: this.textData8,
                            estado_observacion_id: 1,
                        },
                    ],
                });

                if (postObservacion.status == 200) {
                    this.typeAlert = 'success'
                    this.alertText = 'Observaciones guardadas correctamente'
                    this.alert = true
                } else {
                    this.typeAlert = 'error'
                    this.alertText = postObservacion.data.observacion
                    this.alert = true
                }

                setTimeout(() => (this.alert = false), 5000);


            } catch (error) {
                console.log(error.message);
            }
        },

        async getObservacion() {
            try {
                this.validaEstado = 1
                this.textData1 = ""
                this.textData2 = ""
                this.textData3 = ""
                this.textData4 = ""
                this.textData5 = ""
                this.textData6 = ""
                this.textData7 = ""
                this.textData8 = ""
                const req = urlJurisdiccional + '/observaciones_ica';

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 9,
                        //competencia_id: 0,
                        cod_corte: this.user.cod_corte,
                        cod_tribunal: this.user.cod_tribunal,
                        ano: this.yearInformeJurisdiccional,
                    },
                });

                if (getObservacion.status == 200) {

                    if(getObservacion.data.data.observaciones.length > 0 && this.yearInformeJurisdiccional > 2020){

                        getObservacion.data.data.observaciones[0].observacion.forEach(obs => {

                            switch (obs.id) {
                                case 1:
                                    this.textData1 = obs.descripcion;
                                    break;
                                case 2:
                                    this.textData2 = obs.descripcion;
                                    break;
                                case 3:
                                    this.textData3 = obs.descripcion;
                                    break;
                                case 4:
                                    this.textData4 = obs.descripcion;
                                    break;
                                case 5:
                                    this.textData5 = obs.descripcion;
                                    break;
                                case 6:
                                    this.textData6 = obs.descripcion;
                                    break;
                                case 7:
                                    this.textData7 = obs.descripcion;
                                    break;
                                case 8:
                                    this.textData8 = obs.descripcion;
                                    break;
                
                                default:
                                    break;
                            }

                            this.validaEstado =  obs.estado_observacion_id;

                        });

                    } else if (this.yearInformeJurisdiccional <= 2020){

                        getObservacion.data.data.observaciones[0].observacion.forEach((obs, index) => {

                            switch (index) {
                                case 0:
                                    this.textData1 = obs.descripcion;
                                    break;
                                case 1:
                                    this.textData2 = obs.descripcion;
                                    break;
                                case 2:
                                    this.textData3 = obs.descripcion;
                                    break;
                                case 3:
                                    this.textData4 = obs.descripcion;
                                    break;
                                case 4:
                                    this.textData5 = obs.descripcion;
                                    break;
                                case 5:
                                    this.textData6 = obs.descripcion;
                                    break;
                                case 6:
                                    this.textData7 = obs.descripcion;
                                    break;
                                case 7:
                                    this.textData8 = obs.descripcion;
                                    break;
                
                                default:
                                    break;
                            }

                            this.validaEstado =  obs.estado_observacion_id;

                        });
                    }


                } else {
                    console.log(getObservacion.data.observacion);
                }
                this.validaEstado = this.validaEnvioICA;
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    computed:{
        ...mapState(['yearInformeJurisdiccional','validaEnvioICA']),
    },
    components: {
        countTo,
        LayoutJurisdiccional
    },
    watch: {
        yearInformeJurisdiccional() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional;
                this.getObservacion();
            } catch (error) {
                console.log(error.message);
            }
        },
    },
}

</script>

<style scoped>
.whiteBox{
    background: #fff;
}
</style>