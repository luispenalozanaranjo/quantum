<template>
        <LayoutJurisdiccional>
            <v-row>
                <PresupuestariaMain :anoInforme="anoInforme" :cod_corte="user.cod_corte" :cod_tribunal="user.cod_tribunal" :key="this.key"/>
            </v-row>
        </LayoutJurisdiccional>
</template>

<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'
import PresupuestariaMain from './PresupuestariaMain'


export default {
    name: 'JurisdiccionalIngresos',
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            anoInforme: 0,
            key: 0,
            resumenesIndicadores: [],
            tab: null,
        }
    },
    created() {
        try {
            this.$gtag.event('IGJPresupuestaria', { method: 'Google' });
            this.anoInforme = this.yearInformeJurisdiccional();
            this.getResumenes(this.user.cod_corte, this.user.cod_tribunal,this.anoInforme);
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['yearInformeJurisdiccional']), // Valores Guardados

        async getResumenes(cod_corte, cod_tribunal, ano) {
            try {
                this.key++
                const req = urlJurisdiccional + '/presupuestos'

                const getResumenes = await axios.get(req, {
                    params: {
                        cod_corte: cod_corte,
                        cod_tribunal: cod_tribunal,
                        ano: ano,
                    },
                })

                if (getResumenes.status == 200) {
                    this.resumenesIndicadores = getResumenes.data.data;
                } else {
                    console.log(getResumenes.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
        LayoutJurisdiccional,
        PresupuestariaMain,
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional();
                this.getResumenes(this.user.cod_corte, this.user.cod_tribunal,this.anoInforme);
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}
</script>