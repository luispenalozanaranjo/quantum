<template>
    <LayoutJurisdiccional>
        <v-card-text>
            <v-row v-for="index in 30" :key="index">
                <v-col md="3">
                    <v-text-field
                        label="CARGO"
                        v-model="funcionario[index - 1].cargo"
                        outlined
                        :readonly="validaEstado != 1"
                    ></v-text-field>
                </v-col>
                <v-col md="2">
                    <v-menu
                        v-model="menu[index - 1]"
                        :close-on-content-click="false"
                        transition="scale-transition"
                        offset-y
                        min-width="auto"
                        :readonly="validaEstado != 1"
                    >
                        <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                            v-model="funcionario[index - 1].publicacion"
                            label="FECHA PUBLICACIÓN"
                            prepend-icon="mdi-calendar"
                            v-bind="attrs"
                            v-on="on"
                            hint="YYYY/MM/DD"
                            persistent-hint
                            outlined
                            :readonly="validaEstado != 1"
                        ></v-text-field>
                        </template>
                        <v-date-picker
                            v-model="funcionario[index - 1].publicacion"
                            no-title
                            scrollable
                            :readonly="validaEstado != 1"
                            @change = "calculaDias(index - 1)"
                            @input="menu[index - 1] = false"
                        >
                        </v-date-picker>
                    </v-menu>
                </v-col>
                <v-col md="3">
                    <v-select
                        :items="itemsSelect"
                        v-model="funcionario[index - 1].resultado"
                        label="RESULTADO"
                        outlined
                        :readonly="validaEstado != 1"
                    ></v-select>
                </v-col>
                <v-col md="2">
                    <v-menu
                        v-model="menu2[index - 1]"
                        :close-on-content-click="false"
                        transition="scale-transition"
                        offset-y
                        min-width="auto"
                        :readonly="validaEstado != 1"
                    >
                        <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                            v-model="funcionario[index - 1].asunsion"
                            label="FECHA ASUNCIÓN"
                            prepend-icon="mdi-calendar"
                            v-bind="attrs"
                            v-on="on"
                            hint="YYYY/MM/DD"
                            persistent-hint
                            outlined
                            :readonly="validaEstado != 1"
                        ></v-text-field>
                        </template>
                        <v-date-picker
                            v-model="funcionario[index - 1].asunsion"
                            no-title
                            scrollable
                            :readonly="validaEstado != 1"
                            @change = "calculaDias(index - 1)"
                            @input="menu2[index - 1] = false"
                        >
                        </v-date-picker>
                    </v-menu>
                </v-col>
                <v-col md="2">
                    <v-text-field
                        label="DEMORA EN ASUNCIÓN"
                        v-model="funcionario[index - 1].demora"
                        outlined
                        readonly
                    ></v-text-field>
                </v-col>
            <v-row>
                <v-col md="12">
                        <v-alert
                            dense
                            :type="typeAlert"
                            dismissible
                            v-model="alertas[index - 1]"
                        >
                            {{ alertText }}
                        </v-alert>
                    </v-col>
            </v-row> 
            </v-row>
             
        </v-card-text>
        <v-row>
            <v-col md="12">
                <v-btn
                    outlined
                    rounded
                    :class="validaEstado != 1 ? '' : 'green white--text'"
                    :disabled="validaEstado != 1"
                    @click="guardarObservacion()"
                    >
                        <v-icon>
                            mdi-content-save-outline
                        </v-icon>
                        Guardar
                </v-btn>
            </v-col>
        </v-row>
        <v-row>
            <v-col md="12">
                    <v-alert
                        dense
                        :type="typeAlert"
                        dismissible
                        v-model="alert"
                    >
                        {{ alertText }}
                    </v-alert>
                </v-col>
        </v-row>        
    </LayoutJurisdiccional>
</template>
<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'

export default {
    name: "JurisdiccionalConsursos",
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            funcionario: Array(30).fill().map(u => ({
                cargo: '',
                publicacion: '',
                resultado: '',
                asunsion: '',
                demora: 0,
                estado_observacion_id: 1
            })),
            validaEstado: 1,
            validated: 0,
            chkSinObs: false,
            chkSinObsGeneral: false,
            textData: "",
            textDataGeneral: "",
            typeAlert: 'success',
            alertText: '',
            alert: false,
            alertas: [],
            date: [],
            date2: [],
            menu: [],
            menu2: [],
            itemsSelect: ['Resuelto', 'Pendiente', 'Declaracion Desierto', 'Concurso Anulado'],
        }
    },
    created() {
        try {
            this.$gtag.event('IGJConcursos', { method: 'Google' })
            for (let index = 0; index < 30; index++) { this.alertas[index] = false }
            this.getConcursos();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{
        ...mapState(['yearInformeJurisdiccional']),

        async guardarObservacion(){
            try {
                var observacion = []
                let compr = 0
                const req = urlJurisdiccional + '/obsingresos';

                this.funcionario.map((type, index) => {
                    observacion.push(type)
                    if (type.demora < 0)
                        compr = 1
                })

                if (compr == 0){
                    const postObservacion = await axios.post(req, {
                        formulario_id: 14,
                        competencia_id: 0,
                        cod_corte: this.user.cod_corte,
                        cod_tribunal: this.user.cod_tribunal,
                        ano: this.yearInformeJurisdiccional(),
                        observacion: observacion,
                    });

                    if (postObservacion.status == 200) {
                        this.typeAlert = 'success'
                        this.alertText = 'Observaciones guardadas correctamente'
                        this.alert = true
                    } else {
                        this.typeAlert = 'error'
                        this.alertText = postObservacion.data.observacion
                        this.alert = true
                    }
                } else {
                    this.typeAlert = 'error'
                    this.alertText = "La fecha de Asunción no puede ser menor que la fecha de Publicación"
                    this.alert = true
                }
                setTimeout(() => (this.alert = false), 5000);
            } catch (error) {
                console.log(error.message);
            }
        },

        async getConcursos() {
            try {
                const req = urlJurisdiccional + '/observaciones_ica';
                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 14,
                        cod_corte: this.user.cod_corte, // 11, 
                        cod_tribunal: this.user.cod_tribunal, // 6,
                        ano: this.yearInformeJurisdiccional(), // 2020,
                    },
                });

                if (getObservacion.status == 200) {
                    for(let i=0; i < 30; i++) {
                        this.funcionario[i].cargo = ""
                        this.funcionario[i].publicacion = ""
                        this.funcionario[i].resultado = ""
                        this.funcionario[i].asunsion = ""
                        this.funcionario[i].demora = ""
                    }

                    if(getObservacion.data.data.observaciones.length > 0){
                        Object.values(getObservacion.data.data.observaciones).map((type) => {
                            this.validaEstado = type.observacion[0].estado_observacion_id;
                            Object.values(type.observacion).map((element, index) => {
                                this.validated = element.estado_observacion_id
                                this.funcionario[index].cargo = element.cargo
                                this.funcionario[index].publicacion = (element.demora != 0)?element.publicacion.substring(0, 10):""
                                this.funcionario[index].resultado = element.resultado
                                this.funcionario[index].asunsion = (element.demora != 0)?element.asunsion.substring(0, 10):""
                                this.funcionario[index].demora = element.demora
                            })
                        })
                    }


                } else {
                    console.log(getObservacion.data.observacion);
                }

            } catch (error) {
                console.log(error.message);
            }
        },

        calculaDias (index) {
            let asunsion = new Date(this.funcionario[index].asunsion)
            let publicacion = new Date(this.funcionario[index].publicacion)

            if (asunsion < publicacion){
                this.typeAlert = 'error'
                this.alertText = "La fecha de Asunción no puede ser menor que la fecha de Publicación"
                this.alertas[index] = true
                var diff = asunsion.getTime() - publicacion.getTime()
                var diffDays = Math.ceil(diff / (1000 * 3600 * 24))
                return this.funcionario[index].demora = diffDays
            } else {
                var diff = asunsion.getTime() - publicacion.getTime()
                var diffDays = Math.ceil(diff / (1000 * 3600 * 24))
                this.alertas[index] = false
                return this.funcionario[index].demora = diffDays
            }
        }
    },
    components: {
        countTo,
        LayoutJurisdiccional
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional();
                this.getConcursos()
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}

</script>