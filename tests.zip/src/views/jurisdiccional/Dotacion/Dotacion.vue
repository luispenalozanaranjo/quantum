<template>
        <LayoutJurisdiccional>
            <GraficoBarraDotacion :anoInforme="anoInforme" :cod_corte="user.cod_corte" :cod_tribunal="user.cod_tribunal" />
            <GraficoTortaDotacion :anoInforme="anoInforme" :cod_corte="user.cod_corte" :cod_tribunal="user.cod_tribunal" />
            <Observacion    
                    :id_competencia="0" 
                    :anoInforme="anoInforme" 
                    :cod_corte="user.cod_corte" 
                    :cod_tribunal="user.cod_tribunal" 
                    :formulario_id="8" 
                    :key="this.key"
            />
        </LayoutJurisdiccional>
</template>

<script>
import store from 'store'
import { mapState } from 'vuex'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'
import GraficoBarraDotacion from '../../../components/competencias/jurisdiccional/Dotacion/GraficoBarraDotacion.vue'
import GraficoTortaDotacion from '../../../components/competencias/jurisdiccional/Dotacion/GraficoTortaDotacion.vue'
import Observacion from '../../../components/competencias/jurisdiccional/ObservacionesSC.vue'


export default {
    name: 'JurisdiccionalDotacion',
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            anoInforme: 0,
            key: 0,
            tab: null,
        }
    },
    created() {
        try {
            this.$gtag.event('IGJDotacion', { method: 'Google' })
            this.key++
            this.anoInforme = this.yearInformeJurisdiccional();
            this.getResumenes();
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['yearInformeJurisdiccional']), // Valores Guardados

        async getResumenes() {
            try {
                this.key++
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
        LayoutJurisdiccional,
        GraficoBarraDotacion,
        GraficoTortaDotacion,
        Observacion
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional();
                this.getResumenes();
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}
</script>