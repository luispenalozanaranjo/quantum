<template>
        <LayoutJurisdiccional>
            <v-row v-for="indicador in resumenesIndicadores"
                    v-bind:key="indicador._id"
            >
                <v-col class="ribbon-wrapper">
                    <span  class="ribbon ribbon-bookmark ribbon-info white--text headline">{{indicador.gls_competencia}}</span>
                    <TerminosMain :id_competencia="indicador._id" :anoInforme="anoInforme" :cod_corte="user.cod_corte" :cod_tribunal="user.cod_tribunal" />
                </v-col>
            </v-row>
        </LayoutJurisdiccional>
</template>

<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../../components/competencias/jurisdiccional/Layout.vue'
import TerminosMain from '../Terminos/TerminosMain.vue'


export default {
    name: 'JurisdiccionalTerminos',
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            anoInforme: 0,
            resumenesIndicadores: [],
            tab: null,
        }
    },
    created() {
        try {
            this.$gtag.event('IGJTerminos', { method: 'Google' });
            this.anoInforme = this.yearInformeJurisdiccional();
            this.getResumenes(this.user.cod_tribunal,this.anoInforme);
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['yearInformeJurisdiccional']), // Valores Guardados

        async getResumenes(cod_tribunal, ano) {
            try {

                const req = urlJurisdiccional + '/resumenAnualIndicadores'

                const getResumenes = await axios.get(req, {
                    params: {
                        cod_tribunal: cod_tribunal,
                        ano: ano,
                    },
                })

                if (getResumenes.status == 200) {
                    this.resumenesIndicadores = getResumenes.data.data;
                } else {
                    console.log(getResumenes.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
        LayoutJurisdiccional,
        TerminosMain,
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional();
                this.getResumenes(this.user.cod_tribunal,this.anoInforme);
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}
</script>

<style scoped>
	.ribbon {
		padding: 0 20px;
		height: 30px;
		line-height: 30px;
		clear: left;
		position: absolute;
		top: 12px;
		left: -2px;
		color: #fff;
	}

	.ribbon-bookmark.ribbon-info:before {
		border-color: #5461a9 transparent #5461a9 #5461a9;
	}

	.ribbon-bookmark:before {
		position: absolute;
		top: 0;
		left: 95%;
		display: block;
		width: 0;
		height: 0;
		content: '';
		border: 15px solid #2b2b2b;
		border-right: 10px solid transparent;
	}

	.ribbon-info {
		background: #5461a9;
	}

	.ribbon-wrapper,
	.ribbon-wrapper-bottom,
	.ribbon-wrapper-reverse,
	.ribbon-wrapper-right-bottom {
		position: relative;
		background: #f4f8f9;
		padding: 50px 15px 15px 50px;
	}
</style>
