<template>
    <v-row>
        <v-col>
            <TotalIngresos :id_competencia="id_competencia" :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" v-if="modelList == 0" />
            <TotalIngresosMaterias :id_competencia="id_competencia" :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" :cod_materia="cod_materia" v-if="modelList == 1"/>
            <v-row>
                <v-col sm="12" md="9">
                    <GraficoIngresos :id_competencia="id_competencia" :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" v-if="modelList == 0"/>
                    <GraficoIngresosMaterias :id_competencia="id_competencia" :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" @seleccionMateria="seleccionMateria" v-if="modelList == 1"/>
                </v-col>
                <v-col sm="12" md="3">
                    <v-card class="mx-auto" max-width="350">
                        <v-card-title class="justify-center">
                            Nivel de Visualización
                        </v-card-title>
                        <v-card-text>
                            <v-list>
                                <v-list-item-group v-model="modelList" mandatory active-class="border" color="indigo">
                                    <v-list-item>
                                        <v-list-item-content>
                                            <v-list-item-title class="justify-center">Ingresos</v-list-item-title>
                                        </v-list-item-content>
                                    </v-list-item>
                                    <v-list-item v-if="id_competencia != 2 &&  id_competencia != 4">
                                        <v-list-item-content>
                                            <v-list-item-title class="justify-center">Ingresos Materia</v-list-item-title>
                                        </v-list-item-content>
                                    </v-list-item>
                                </v-list-item-group>
                            </v-list>
                        </v-card-text>
                    </v-card>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <Observacion    
                        :id_competencia="id_competencia" 
                        :anoInforme="anoInforme" 
                        :cod_corte="cod_corte" 
                        :cod_tribunal="cod_tribunal" 
                        :formulario_id="1" 
                    />
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>

<script>
import store from 'store'
import TotalIngresos from '../../../../components/competencias/jurisdiccional/Ingresos/TotalIngresos.vue'
import TotalIngresosMaterias from '../../../../components/competencias/jurisdiccional/Ingresos/TotalIngresosMaterias.vue'
import GraficoIngresos from '../../../../components/competencias/jurisdiccional/Ingresos/GraficosIngresos.vue'
import GraficoIngresosMaterias from '../../../../components/competencias/jurisdiccional/Ingresos/GraficoIngresosMaterias.vue'
import Observacion from '../../../../components/competencias/jurisdiccional/Observaciones.vue'
import { mapState } from 'vuex'

export default {
    name: 'JurisdiccionalIngresosMain',
    data() {
        return {
            modelList: 0,
            cod_materia: '',
        }
    },
    components: {
        TotalIngresos,
        GraficoIngresos,
        TotalIngresosMaterias,
        GraficoIngresosMaterias,
        Observacion
    },
    props:{
        id_competencia: {
            type: Number,
            required: true
        },
        anoInforme: {
            type: Number,
            required: true
        },
        cod_corte: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        }
    },
    methods:{
        seleccionMateria(newMateria){
            this.cod_materia = newMateria;
        }
    }
}
</script>

<style scoped>
    .border {
    border: 2px dashed purple;
    }
</style>