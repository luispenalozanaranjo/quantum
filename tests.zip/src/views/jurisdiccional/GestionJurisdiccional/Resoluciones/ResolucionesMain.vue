<template>
    <v-row>
        <v-col>
            <TotalResoluciones :id_competencia="id_competencia" :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" />
            <v-row>
                <v-col sm="12" md="12">
                    <GraficoResoluciones :id_competencia="id_competencia" :anoInforme="anoInforme" :cod_tribunal="cod_tribunal" />
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <Observacion    
                        :id_competencia="id_competencia" 
                        :anoInforme="anoInforme" 
                        :cod_corte="cod_corte" 
                        :cod_tribunal="cod_tribunal" 
                        :formulario_id="3" 
                    />
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>

<script>
import store from 'store'
import TotalResoluciones from '../../../../components/competencias/jurisdiccional/Resoluciones/TotalResoluciones.vue'
import GraficoResoluciones from '../../../../components/competencias/jurisdiccional/Resoluciones/GraficoResoluciones.vue'
import Observacion from '../../../../components/competencias/jurisdiccional/Observaciones.vue'

export default {
    name: 'JurisdiccionalResolucionesMain',
    data() {
        return {
            modelList: 0,
        }
    },
    components: {
        TotalResoluciones,
        GraficoResoluciones,
        Observacion
    },
    props:{
        id_competencia: {
            type: Number,
            required: true
        },
        anoInforme: {
            type: Number,
            required: true
        },
        cod_corte: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        }
    },
}
</script>

<style scoped>
    .border {
    border: 2px dashed purple;
    }
</style>