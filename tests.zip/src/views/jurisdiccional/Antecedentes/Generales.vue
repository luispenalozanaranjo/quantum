<template>
        <LayoutJurisdiccional>
            <v-card outlined class="ribbon-wrapper">
                <v-card-subtitle
                    class="ribbon ribbon-bookmark ribbon-info white--text"
                >
                    Antecedentes
                </v-card-subtitle>
                <v-card-text>
                    En cumplimiento con los establecido en el artículo 24 letra d,
                    del Código de Tribunales, se presenta a continuación la cuenta
                    anual de la gestión jurisdiccional y administrativa del
                    Tribunal, para el periodo comprendido entre 01 de enero y el 31
                    de diciembre de 2023
                </v-card-text>
            </v-card>

            <v-card
                flat
                class="ribbon-wrapper"
                v-for="indicador in resumenesIndicadores"
                v-bind:key="indicador._id"
            >
                <v-card-subtitle class="ribbon ribbon-bookmark ribbon-info white--text">
                    {{ indicador.gls_competencia }}
                </v-card-subtitle>
                <v-card-text>
                    <v-row>
                        <v-col md="3">
                            <v-hover v-slot:default="{ hover }">
                                <v-card 
                                    hover
                                    :elevation="hover ? 12 : 2"
                                    :class="{ 'on-hover': hover }"
                                    color="#00bbd9"
                                    @click="goIndicadores('JurisdiccionalIngresos')"
                                    
                                >
                                    <v-card-title class="white--text">Ingresos</v-card-title>
                                    <v-card-text>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.ingresos"
                                            separator="."
                                            :duration="1000"
                                            v-if="incluirExhortoJurisdiccional()"
                                        ></countTo>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.ingresos_se"
                                            separator="."
                                            :duration="1000"
                                            v-if="!incluirExhortoJurisdiccional()"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-col>
                        <v-col md="3">
                            <v-hover v-slot:default="{ hover }">
                                <v-card 
                                    hover
                                    :elevation="hover ? 12 : 2"
                                    :class="{ 'on-hover': hover }"
                                    color="#2ecc71"
                                    @click="goIndicadores('JurisdiccionalResoluciones')"
                                >
                                    <v-card-title class="white--text">Resoluciones</v-card-title>
                                    <v-card-text>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.resoluciones"
                                            separator="."
                                            :duration="1000"
                                            v-if="incluirExhortoJurisdiccional()"
                                        ></countTo>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.resoluciones_se"
                                            separator="."
                                            :duration="1000"
                                            v-if="!incluirExhortoJurisdiccional()"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-col>
                        <v-col md="3">
                            <v-hover v-slot:default="{ hover }">
                                <v-card 
                                    hover
                                    :elevation="hover ? 12 : 2"
                                    :class="{ 'on-hover': hover }"
                                    color="#e74a25"
                                    @click="goIndicadores('JurisdiccionalTerminos')"
                                >
                                    <v-card-title class="white--text">Términos</v-card-title>
                                    <v-card-text>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.terminos"
                                            separator="."
                                            :duration="1000"
                                            v-if="incluirExhortoJurisdiccional()"
                                        ></countTo>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.terminos_se"
                                            separator="."
                                            :duration="1000"
                                            v-if="!incluirExhortoJurisdiccional()"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-col>
                        <v-col md="3">
                            <v-hover v-slot:default="{ hover }">
                                <v-card 
                                    hover
                                    :elevation="hover ? 12 : 2"
                                    :class="{ 'on-hover': hover }"
                                    color="#ffb136" 
                                    v-show="indicador._id != 2"
                                    @click="goIndicadores('JurisdiccionalAudiencias')"
                                >
                                    <v-card-title class="white--text">Audiencias</v-card-title>
                                    <v-card-text>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.audiencias"
                                            separator="."
                                            :duration="1000"
                                            v-if="incluirExhortoJurisdiccional()"
                                        ></countTo>
                                        <countTo
                                            class="count headline white--text"
                                            :startVal="0"
                                            :endVal="indicador.audiencias_se"
                                            separator="."
                                            :duration="1000"
                                            v-if="!incluirExhortoJurisdiccional()"
                                        ></countTo>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </v-col>
                    </v-row>
                </v-card-text>
            </v-card>
        </LayoutJurisdiccional>
</template>

<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'


export default {
    name: 'JurisdiccionalGenerales',
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            resumenesIndicadores: [],
        }
    },
    created() {
        try {
            this.$gtag.event('IGJGenerales', { method: 'Google' })
            this.getResumenes(this.user.cod_tribunal, this.yearInformeJurisdiccional());
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['yearInformeJurisdiccional', 'incluirExhortoJurisdiccional']), // Valores Guardados

        async getResumenes(cod_tribunal, ano) {
            try {

                const req = urlJurisdiccional + '/resumenAnualIndicadores'

                const getResumenes = await axios.get(req, {
                    params: {
                        cod_tribunal: cod_tribunal,
                        ano: ano,
                    },
                });

                if (getResumenes.status == 200 || getResumenes.status == 304) {
                    this.resumenesIndicadores = getResumenes.data.data;
                } else {
                    console.log(getResumenes.data.observacion);
                }
            } catch (error) {
                console.log(error.message);
            }
        },
        goIndicadores(paramRoute) {
            try {
                this.$router.push({ name: paramRoute });
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.getResumenes(this.user.cod_tribunal, this.yearInformeJurisdiccional());
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    components: {
        countTo,
        LayoutJurisdiccional
    },
}
</script>

<style scoped>
	.ribbon {
		padding: 0 20px;
		height: 30px;
		line-height: 30px;
		clear: left;
		position: absolute;
		top: 12px;
		left: -2px;
		color: #fff;
	}

	.ribbon-bookmark.ribbon-info:before {
		border-color: #5461a9 transparent #5461a9 #5461a9;
	}

	.ribbon-bookmark:before {
		position: absolute;
		top: 0;
		left: 95%;
		display: block;
		width: 0;
		height: 0;
		content: '';
		border: 15px solid #2b2b2b;
		border-right: 10px solid transparent;
	}

	.ribbon-info {
		background: #5461a9;
	}

	.ribbon-wrapper,
	.ribbon-wrapper-bottom,
	.ribbon-wrapper-reverse,
	.ribbon-wrapper-right-bottom {
		position: relative;
		background: #f4f8f9;
		padding: 50px 15px 15px 50px;
	}
</style>
