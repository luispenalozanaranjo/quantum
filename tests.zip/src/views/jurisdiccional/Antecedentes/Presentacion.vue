<template>
    <LayoutJurisdiccional>
        <v-row>
            <v-col md="4">
                <h2>Palabras de Juez Presidente (Periodo {{yearInformeJurisdiccional()}})</h2>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <v-checkbox
                    v-model="chkSinObs"
                    label="Sin observación"
                    color="indigo darken-3"
                    @change="chkSinObs == true
                                ? (textData = 'Sin observación')
                                : (textData = '')
                        "
                ></v-checkbox>
                <v-textarea
                    outlined
                    name="txtObservacion"
                    v-model="textData"
                    label="Observación"
                    clearable
                    clear-icon="mdi-close-circle"
                    rows="20"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <v-checkbox
                    v-model="chkSinObsGeneral"
                    label="Sin observación"
                    color="indigo darken-3"
                    @change="chkSinObsGeneral == true
                                ? (textDataGeneral = 'Sin observación')
                                : (textDataGeneral = '')
                        "
                ></v-checkbox>
                <v-textarea
                    outlined
                    name="txtObservacionGeneral"
                    v-model="textDataGeneral"
                    label="Presentación Administración"
                    clearable
                    clear-icon="mdi-close-circle"
                    rows="2"
                    :readonly="validaEstado != 1"
                ></v-textarea>
            </v-col>
        </v-row>
        <v-row>
            <v-col md="12">
                <v-btn
                    outlined
                    rounded
                    :class="validaEstado != 1 ? '' : 'green white--text'"
                    :disabled="validaEstado != 1"
                    @click="guardarObservacion()"
                    >
                        <v-icon>
                            mdi-content-save-outline
                        </v-icon>
                        Guardar
                </v-btn>
            </v-col>
        </v-row>
        <v-row>
            <v-col md="12">
                    <v-alert
                        dense
                        :type="typeAlert"
                        dismissible
                        v-model="alert"
                    >
                        {{ alertText }}
                    </v-alert>
                </v-col>
        </v-row>
    </LayoutJurisdiccional>
</template>
<script>
import axios from 'axios'
import store from 'store'
import { mapState } from 'vuex'
import { urlJurisdiccional } from '../../../config/api'
import countTo from 'vue-count-to'
import LayoutJurisdiccional from '../../../components/competencias/jurisdiccional/Layout.vue'

export default {
    name: "JurisdiccionalPresentacion",
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            validaEstado: 1,
            chkSinObs: false,
            chkSinObsGeneral: false,
            textData: "",
            textDataGeneral: "",
            typeAlert: 'success',
            alertText: '',
            alert: false,
        }
    },
    created() {
        try {
            this.$gtag.event('IGJPresentacion', { method: 'Google' })
            this.getObservacion();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{
        ...mapState(['yearInformeJurisdiccional','validaEnvioICA']),

        async guardarObservacion(){
            try {
                const req = urlJurisdiccional + '/obsingresos';

                const postObservacion = await axios.post(req, {
                    formulario_id: 7,
                    competencia_id: 0,
                    cod_corte: this.user.cod_corte,
                    cod_tribunal: this.user.cod_tribunal,
                    ano: this.yearInformeJurisdiccional(),
                    observacion: [
                        {
                            id: 1,
                            descripcion: this.textData,
                            estado_observacion_id: 1,
                        },
                        {
                            id: 2,
                            descripcion: this.textDataGeneral,
                            estado_observacion_id: 1,
                        },
                    ],
                });

                if (postObservacion.status == 200) {
                    this.typeAlert = 'success'
                    this.alertText = 'Observaciones guardadas correctamente'
                    this.alert = true
                } else {
                    this.typeAlert = 'error'
                    this.alertText = postObservacion.data.observacion
                    this.alert = true
                }

                setTimeout(() => (this.alert = false), 5000);


            } catch (error) {
                console.log(error.message);
            }
        },

        async getObservacion() {
            try {
                const req = urlJurisdiccional + '/observaciones_ica';

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 7,
                        //competencia_id: 0,
                        cod_corte: this.user.cod_corte,
                        cod_tribunal: this.user.cod_tribunal,
                        ano: this.yearInformeJurisdiccional(),
                    },
                });

                if (getObservacion.status == 200) {

                    if(getObservacion.data.data.observaciones.length > 0){
                        this.textData = getObservacion.data.data.observaciones[0].observacion[0].descripcion;
                        this.validaEstado =  getObservacion.data.data.observaciones[0].observacion[0].estado_observacion_id;

                        this.textDataGeneral =  getObservacion.data.data.observaciones[0].observacion[1].descripcion;
                        this.validaEstado =  getObservacion.data.data.observaciones[0].observacion[1].estado_observacion_id;
                    } else {
                        this.textData = ""
                        this.validaEstado = ""
                        this.textDataGeneral = ""
                    }

                } else {
                    console.log(getObservacion.data.observacion);
                }
                this.validaEstado = this.validaEnvioICA();
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    components: {
        countTo,
        LayoutJurisdiccional
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.anoInforme = this.yearInformeJurisdiccional();
                this.getObservacion()
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}

</script>