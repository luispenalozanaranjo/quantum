<template>
    
</template>
<script>
export default {
  name: 'Jurisdiccional',
  data () {
    return {
    }
  },
  created () {
  }
}
</script>
