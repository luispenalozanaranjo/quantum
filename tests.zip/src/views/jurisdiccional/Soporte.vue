<template>
        <LayoutJurisdiccional>
            <v-row>
                <v-col md="12">
                <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                        <vue-excel-xlsx
                            :data="reportsState"
                            :columns="excelHead"
                            :filename="'EstadoReporte'"
                            :sheetname="'Hoja1'"
                        >  
                            <v-btn
                                class="mx-2"
                                fab
                                dark
                                small
                                color="success"
                                v-bind="attrs"
                                v-on="on"                                          
                            >
                                <v-icon >mdi-microsoft-excel</v-icon>  
                            </v-btn>
                        </vue-excel-xlsx>
                    </template>
                    <span>Exportar Excel</span>
                </v-tooltip>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <v-text-field
                        v-model="search"
                        append-icon="mdi-magnify"
                        label="Buscar"
                        single-line
                        hide-details
                    ></v-text-field>    
                    <v-data-table
                        :headers="headers"
                        :items="reportsState"
                        :search="search"
                        dense
                    >
                    </v-data-table>
                </v-col>
            </v-row>

        </LayoutJurisdiccional>
</template>

<script>
import axios from 'axios'
import { urlJurisdiccional } from '../../config/api'
import LayoutJurisdiccional from '../../components/competencias/jurisdiccional/Layout.vue'
import { mapState } from 'vuex'

export default {
    name: 'JurisdiccionalSoporte',
    data() {
        return {
            headers: [
                { text: 'CD', align: 'left', value: 'cod_corte', class : 'pjud white--text' },
                { text: 'Corte', align: 'left', value: 'gls_corte', class : 'pjud white--text' },
                { text: 'CT', align: 'left', value: 'cod_tribunal', class : 'pjud white--text' },
                { text: 'Tribunal', align: 'left', value: 'gls_tribunal', class : 'pjud white--text' },
                { text: 'Completados', align: 'left', value: 'cantidad', class : 'pjud white--text' },
                { text: 'Detalles', align: 'left', value: 'glsDetalle', class : 'pjud white--text' },
                { text: 'Estado Adm.Tribunal', align: 'left', value: 'estado', class : 'pjud white--text' },
                { text: 'Estado Adm.Corte', align: 'left', value: 'estadoCorte', class : 'pjud white--text' },
            ],
            reportsState: [],
            formulario: {
                1: 'Ingresos',
                3: 'Resoluciones',
                5: 'Terminos',
                6: 'Presupuestos',
                7: 'Presentaciones',
                8: 'Dotaciones',
                9: 'Administrativa',
                10: 'Academia',
                15: 'Corte Apelaciones',
                14: 'Concursos',
                20: 'Audiencias'
            },
            search: '',
            excelHead : [
                { label: "CD",field:  "cod_corte" },
                { label: "Corte",field:  "gls_corte" },
                { label: "CT",field:  "cod_tribunal" },
                { label: "Tribunal",field:  "gls_tribunal" },
                { label: "Completados",field:  "cantidad" },
                { label: "Detalles",field:  "glsDetalle" },
                { label: "Estado Adm.Tribunal",field:  "estado" },
                { label: "Estado Adm.Corte",field:  "estadoCorte" },
            ],
            hide: false,

        }
    },
    created(){
        try {
            this.$gtag.event('IGJSoporte', { method: 'Google' });
            this.getReports(this.yearInformeJurisdiccional());
        } catch (error) {
            console.log(error.message);
        }
    },
    methods: {
        ...mapState(['yearInformeJurisdiccional']), // Valores Guardados

        async getReports(ano){
            try {

                const req = urlJurisdiccional + '/reportes'
                this.reportsState = [];
                let estadoCorte = '';

                const getReports = await axios.get(req, {
                    params: {
                        ano: ano
                    },
                });

                if (getReports.status == 200 || getReports.status == 304) {
                    
                    getReports.data.data.reportes.forEach(report => {
                        
                        let cod_corte    = report.Cortes[0].cod_corte;
                        let gls_corte    = report.Cortes[0].gls_corte;
                        let gls_tribunal = report.gls_tribunal;
                        let cod_tribunal = report.cod_tribunal;     
                        let cantidad = String(report.Observacion.length);
                        let estado = 'Pendiente';
                        let gls = '';

                        if(report.Observacion.length >= 1){
                            estado = (report.Observacion[0].observacion[0].estado_obervacion_id == 2 || report.Observacion[0].observacion[0].estado_observacion_id == 2) ? 'Enviado':'Pendiente';
                        }

                        //Estado corte
                        estadoCorte = 'Pendiente';

                        report.Observacion.forEach(obs => {
                            gls += ' ' + this.formulario[obs.formulario_id] + ','

                            if(obs.formulario_id == 15){
                                estadoCorte = (obs.estado_observacion_id == 2) ? 'Enviado':'Pendiente';
                            }

                        });

                     

                        this.reportsState.push({
                            cod_corte: cod_corte,
                            gls_corte: gls_corte,
                            cod_tribunal: cod_tribunal,
                            gls_tribunal: gls_tribunal,
                            cantidad: cantidad,
                            glsDetalle: gls,
                            estado: estado,
                            estadoCorte: estadoCorte
                        });

                    });

                }else {
                    console.log(getReports);
                }

                
            } catch (error) {
                console.log(error.message);
            }
        }
    },
    watch: {
        '$store.state.yearInformeJurisdiccional'() {
            try {
                this.getReports(this.yearInformeJurisdiccional());
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    components:{
        LayoutJurisdiccional,
    }
}
</script>