<template>
    <Layout :glsCorte="nombreCorte" :cod_corte="cod_corte" :switchResfrescar="switchResfrescar">
        <v-row>
            <v-col md="12">
                <v-card>
                    <v-card-title class="justify-center">{{nombreTribunalIGJ}}</v-card-title>
                    <v-card-text>
                        <v-expansion-panels focusable v-model="panelModel">
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Palabras de Juez Presidente
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 0">
                                    <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" 
                                        :formulario_id="7"
                                        /> 
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Ingresos
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 1">
                                    <v-row>
                                        <v-col md="12">
                                            <TotalesIngresos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListIngresos == 0"/>
                                            <TotalesIngresosMaterias :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListIngresos == 1"/>
                                        </v-col>
                                    </v-row>
                                    <v-row>
                                        <v-col sm="12" md="9">
                                            <GraficoIngresos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListIngresos == 0"/>
                                            <GraficoIngresosMaterias :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListIngresos == 1"/>        
                                        </v-col>
                                        <v-col sm="12" md="3">
                                            <v-card class="mx-auto" max-width="350">
                                                <v-card-title class="justify-center">
                                                    Nivel de Visualización
                                                </v-card-title>
                                                <v-card-text>
                                                    <v-list>
                                                        <v-list-item-group v-model="modelListIngresos" mandatory active-class="border" color="indigo">
                                                            <v-list-item>
                                                                <v-list-item-content>
                                                                    <v-list-item-title class="justify-center">Ingresos</v-list-item-title>
                                                                </v-list-item-content>
                                                            </v-list-item>
                                                            <v-list-item>
                                                                <v-list-item-content>
                                                                    <v-list-item-title class="justify-center">Ingresos Materia</v-list-item-title>
                                                                </v-list-item-content>
                                                            </v-list-item>
                                                        </v-list-item-group>
                                                    </v-list>
                                                </v-card-text>
                                            </v-card>
                                        </v-col>
                                    </v-row>
                                    <v-row>
                                        <v-col md="12">
                                            <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="1" />
                                        </v-col>
                                    </v-row>
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Términos
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 2">
                                    <v-row>
                                        <v-col md="12">
                                            <TotalesTerminos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListTerminos == 0"/>
                                            <TotalesTerminosMaterias :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListTerminos == 1"/>
                                        </v-col>
                                    </v-row>
                                    <v-row>
                                        <v-col sm="12" md="9">
                                            <GraficoTerminos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListTerminos == 0" />
                                            <GraficoTerminosMaterias :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListTerminos == 1" />
                                        </v-col>
                                        <v-col sm="12" md="3">
                                            <v-card class="mx-auto" max-width="350">
                                                <v-card-title class="justify-center">
                                                    Nivel de Visualización
                                                </v-card-title>
                                                <v-card-text>
                                                    <v-list>
                                                        <v-list-item-group v-model="modelListTerminos" mandatory active-class="border" color="indigo">
                                                            <v-list-item>
                                                                <v-list-item-content>
                                                                    <v-list-item-title class="justify-center">Términos</v-list-item-title>
                                                                </v-list-item-content>
                                                            </v-list-item>
                                                            <v-list-item>
                                                                <v-list-item-content>
                                                                    <v-list-item-title class="justify-center">Términos Materia</v-list-item-title>
                                                                </v-list-item-content>
                                                            </v-list-item>
                                                        </v-list-item-group>
                                                    </v-list>
                                                </v-card-text>
                                            </v-card>
                                        </v-col>
                                    </v-row>
                                    <v-row>
                                        <v-col md="12">
                                            <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="5" />
                                        </v-col>
                                    </v-row>
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Resoluciones
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 3">
                                    <TotalesResoluciones :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                                    <GraficoResoluciones :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                                    <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="3" />
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Audiencias Realizadas
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 4">
                                    <TotalesAudiencias :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                                    <GraficoAudienciasRealizadas :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                                    <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="20" />
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Administrativa
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 5">
                                    <Administrativa :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" />
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Presupuesto
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 6">
                                    <TotalPresupuestos :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                                    <GraficosPresupuestos :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                                    <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="6" />
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Dotación
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 7">
                                    <GraficoBarraDotacion :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                                    <GraficoTortaDotacion :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                                    <ObservacionesTribunales :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="8" />
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                            <v-expansion-panel>
                                <v-expansion-panel-header>
                                    <span class="ribbon ribbon-bookmark ribbon-info white--text">
                                        Concursos
                                    </span>
                                </v-expansion-panel-header>
                                <v-expansion-panel-content v-if="panelModel == 8">
                                    <Concursos :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                                </v-expansion-panel-content>
                            </v-expansion-panel>
                        </v-expansion-panels>
                        <v-row>
                            <v-col md="12">
                                <ObservacionCorte 
                                    :anoInforme="yearInformeJurisdiccional" 
                                    :cod_corte="cod_corte" 
                                    :cod_tribunal="codTribunalIGJ" 
                                    :formulario_id="15" 
                                    :id_competencia="0"
                                    :switchResfrescar="switchResfrescar"
                                    class="mt-2"
                                    v-on:getObservacionSC="onObservacionCorte"
                                />
                            </v-col>
                        </v-row>

                    </v-card-text>
                    <v-card-actions>
                        <v-alert
                            dense
                            :type="typeAlert"
                            dismissible
                            v-model="alert"
                        >
                            {{ alertText }}
                        </v-alert>
                        <v-spacer></v-spacer>
                        <v-dialog 
                            v-model="dialogFinalizar"
                            persistent
                            max-width="290"
                        >
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn 
                                class="success white--text"
                                outlined
                                rounded
                                v-bind="attrs"
                                v-on="on"
                                :disabled="validaEstado != 1"
                                >
                                    <v-icon>
                                        mdi-lock-check-outline 
                                    </v-icon>
                                    Finalizar
                                </v-btn>
                            </template>
                            <v-card>
                                <v-card-title class="text-h5">¿Está Seguro?</v-card-title>
                                <v-card-text>
                                    Compruebe que haya guardado una observación. Esta acción impedirá futuras modificaciones al informe<br>
                                </v-card-text>
                                <v-card-actions>
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        color="red darken-1"
                                        text
                                        @click="dialogFinalizar = false"
                                    >
                                        Cancelar
                                    </v-btn>
                                    <v-btn
                                        color="green darken-1"
                                        text
                                        @click="finalizarInformeIGJ()"
                                    >
                                        Finalizar
                                    </v-btn>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                        <v-btn
                            outlined
                            rounded
                            class="error white--text ml-2"
                            @click="generarPDF()"
                        >
                            <v-icon>
                                mdi-file-pdf-box   
                            </v-icon>
                            PDF
                        </v-btn>
                        <!-- <v-dialog 
                            v-model="dialogObservar"
                            persistent
                            max-width="290"
                        >
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn 
                                outlined
                                rounded
                                class="error white--text ml-2"
                                v-bind="attrs"
                                v-on="on"
                                :disabled="validaEstado != 1"
                                >
                                    <v-icon>
                                       mdi-eye-settings-outline  
                                    </v-icon>
                                    Observar
                                </v-btn>
                            </template>
                            <v-card>
                                <v-card-title class="text-h5">¿Está Seguro?</v-card-title>
                                <v-card-text>
                                    Esta acción devolverá el informe al administrador de tribunal informando lo guardado en el campo observación<br>
                                </v-card-text>
                                <v-card-actions>
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        color="red darken-1"
                                        text
                                        @click="dialogObservar = false"
                                    >
                                        Cancelar
                                    </v-btn>
                                    <v-btn
                                        color="green darken-1"
                                        text
                                        @click="observarInformeIGJ()"
                                    >
                                        Enviar a Tribunal
                                    </v-btn>
                                </v-card-actions>
                            </v-card>
                        </v-dialog> -->
                    </v-card-actions>
                </v-card>           
            </v-col>
        </v-row>
        <v-row v-if="putPDF">
            <v-col cols="12">
                <v-card id="imprimirJuezPDF">
                    <v-card-title class="white headline">
                        Palabras del Juez Presidente
                    </v-card-title>
                    <v-card-text class="white">
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="7" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirIngresosPDF">
                    <v-card-title class="white headline">
                        Ingresos de Causas
                    </v-card-title>
                    <v-card-text class="white">
                        <TotalesIngresos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                        <GraficoIngresos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="1" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirTerminosPDF">
                    <v-card-title class="white headline">
                        Términos de Causas
                    </v-card-title>
                    <v-card-text class="white">
                        <TotalesTerminos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListTerminos == 0"/>
                        <GraficoTerminos :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" v-if="modelListTerminos == 0" />
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="5" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirResolucinesPDF">
                    <v-card-title class="white headline">
                        Resoluciones
                    </v-card-title>
                    <v-card-text class="white">
                        <TotalesResoluciones :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                        <GraficoResoluciones :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="3" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirAudienciasRealizadasPDF">
                    <v-card-title class="white headline">
                        Audiencias Realizadas
                    </v-card-title>
                    <v-card-text class="white">
                        <TotalesAudiencias :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                        <GraficoAudienciasRealizadas :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" :id_competencia="0" />
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="20" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirAdministrativaPDF">
                    <v-card-title class="white headline">
                        Administrativa
                    </v-card-title>
                    <v-card-text class="white">
                        <AdministrativaPDF :anoInforme="yearInformeJurisdiccional" :cod_tribunal="codTribunalIGJ" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirPresupuestoPDF">
                    <v-card-title class="white headline">
                        Presupuesto
                    </v-card-title>
                    <v-card-text class="white">
                        <TotalPresupuestos :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                        <GraficosPresupuestos :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="6" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirDotacionPDF">
                    <v-card-title class="white headline">
                        Dotación
                    </v-card-title>
                    <v-card-text class="white">
                        <TablaDotacion  :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ"/>
                        <GraficoTortaDotacion :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                        <ObservacionesTribunalesPDF :id_competencia="0" :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" :formulario_id="8" />
                    </v-card-text>
                </v-card>
                <v-card  id="imprimirConcursosPDF">
                    <v-card-title class="white headline">
                        Concursos
                    </v-card-title>
                    <v-card-text class="white">
                        <Concursos :anoInforme="yearInformeJurisdiccional" :cod_corte="cod_corte" :cod_tribunal="codTribunalIGJ" />
                    </v-card-text>
                </v-card>    
            </v-col>
        </v-row>
        <ModalLoading />
    </Layout>
</template>
<script>
import store from 'store'
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import { urlJurisdiccional } from '../../../config/api'
import { mapState, mapMutations } from 'vuex'
import jsPDF  from "jspdf"
import  "jspdf-autotable"
import html2canvas from 'html2canvas'
import Layout from '../../../components/competencias/jurisdiccional/Cortes/Layout.vue'
import GraficoIngresos from '../../../components/competencias/jurisdiccional/Cortes/Ingresos/GraficoIngresos.vue'
import GraficoIngresosMaterias from '../../../components/competencias/jurisdiccional/Cortes/Ingresos/GraficoIngresosMaterias.vue'
import TotalesIngresos from '../../../components/competencias/jurisdiccional/Cortes/Ingresos/TotalesIngresos.vue'
import TotalesIngresosMaterias from '../../../components/competencias/jurisdiccional/Cortes/Ingresos/TotalesIngresosMaterias.vue'
import ObservacionesTribunales from '../../../components/competencias/jurisdiccional/Cortes/ObservacionesTribunales.vue'
import GraficoTerminos from '../../../components/competencias/jurisdiccional/Cortes/Terminos/GraficoTerminos.vue'
import GraficoTerminosMaterias from '../../../components/competencias/jurisdiccional/Cortes/Terminos/GraficoTerminosMaterias.vue'
import TotalesTerminos from '../../../components/competencias/jurisdiccional/Cortes/Terminos/TotalesTerminos.vue'
import TotalesTerminosMaterias from '../../../components/competencias/jurisdiccional/Cortes/Terminos/TotalesTerminosMaterias.vue'
import TotalesResoluciones from '../../../components/competencias/jurisdiccional/Cortes/Resoluciones/TotalesResoluciones.vue'
import GraficoResoluciones from '../../../components/competencias/jurisdiccional/Cortes/Resoluciones/GraficoResoluciones.vue'
import TotalesAudiencias from '../../../components/competencias/jurisdiccional/Cortes/Audiencias/TotalesAudiencias.vue'
import GraficoAudienciasRealizadas from '../../../components/competencias/jurisdiccional/Cortes/Audiencias/GraficoAudienciasRealizadas.vue'
import Administrativa from '../../../components/competencias/jurisdiccional/Cortes/Administrativa.vue'
import AdministrativaPDF from '../../../components/competencias/jurisdiccional/Cortes/AdministrativaPDF.vue'
import GraficoBarraDotacion from '../../../components/competencias/jurisdiccional/Dotacion/GraficoBarraDotacion.vue'
import GraficoTortaDotacion from '../../../components/competencias/jurisdiccional/Dotacion/GraficoTortaDotacion.vue'
import TablaDotacion from '../../../components/competencias/jurisdiccional/Dotacion/TablaDotacion.vue'
import TotalPresupuestos from '../../../components/competencias/jurisdiccional/Presupuestos/TotalPresupuestos.vue'
import GraficosPresupuestos from '../../../components/competencias/jurisdiccional/Presupuestos/GraficosPresupuestos.vue'
import Concursos from '../../../components/competencias/jurisdiccional/Cortes/Concursos.vue'
import ObservacionCorte from '../../../components/competencias/jurisdiccional/ObservacionesSC.vue'
import ObservacionesTribunalesPDF from '../../../components/competencias/jurisdiccional/Cortes/ObservacionesTribuanlesPDF.vue'
import ModalLoading from '../../../components/ModalLoading.vue'



export default {
    name: 'JurisdiccionalCortes',
    data() {
        return{
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                email: store.get('email')
            },
            cod_corte: 0,
            nombreCorte: '',
            indicadores: [
                {id: 0, nombre: 'Ingresos'},
                {id: 1, nombre: 'Términos'},
                {id: 2, nombre: 'Resoluciones'},
                {id: 3, nombre: 'Audiencias'},
            ],
            panelModel: null,
            dialogFinalizar: false,
            dialogObservar: false,
            validaEstado: 1,
            alert: false,
            typeAlert: 'success',
            alertText: '',
            switchResfrescar: false,
            modelListIngresos: 0,
            modelListTerminos: 0,
            putPDF: false,
            strObservacionCorte: "",
            strJuezPresidente: "",
            textData1: '',
            textData2: '',
            textData3: '',
            textData4: '',
            textData5: '',
            textData6: '',
            textData7: '',
            textData8: '',
            obsJuezPresidente: [],
        }    
    },
    created(){
        try {
            
            this.putPDF = false;
            this.$gtag.event('JurisdiccionalCortes', { method: 'Google' })
            this.getCorteTribunal();
            this.getObservacionAdministrativa();
            this.getObservacionJuezPresidente();

            if(this.codTribunalIGJ != 0){
                this.getEstadoCorteTribunal();
            }
            
        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{

        async generarPDF(){
            try {
                window.scrollTo(0,0);
                this.putPDF = true;
                this.panelModel = null;
                this.setModal(true);
                setTimeout(() => (this.generarDoc()), 1000);
                
            } catch (error) {
                console.log(error.message);
                this.setModal(false);
            }
        },

        async generarDoc(){
            try { 
                let doc = new jsPDF({
                    orientation: 'p',
                    unit: 'in',
                    format: 'a4',   
                    putOnlyUsedFonts:true
                });

                doc.setFont('Arial');
                doc.setFontSize(18);
                doc.text((8.27 / 2), 0.5, 'INFORME DE GESTIÓN JURISDICCIONAL' , { align: 'center' });
                doc.setFontSize(12);
                doc.text((8.27 / 2), 1, this.nombreTribunalIGJ + ' '+ this.yearInformeJurisdiccional , { align: 'center' });

                    let textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('Juez Presidente', 7.25)
                                        
                    let verticalOffSet=0.5;
                    doc.text(0.5, 2, textlines);

                    let tamañoLetra = "12"
                    if (this.obsJuezPresidente[0].texto.length > 4300){
                        tamañoLetra = "11"
                    }

                    textlines = doc.setFont("Arial")
                    .setFontSize(tamañoLetra)
                    .splitTextToSize(this.obsJuezPresidente[0].texto, 7.25)
                    doc.text(0.5, 2.5 , textlines);                  
                    

                    doc.addPage();                    
                    doc.setFont("Arial")
                    doc.setFontSize("15")
                    doc.text('Administrativa',0.5,0.5)


                     textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('1. Información sobre las necesidades y estado de la Infraestructura del juzgado, así como también las mejoras desarrolladas', 7.25)
                    
                    
                    verticalOffSet=1;
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 0.7) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData1, 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;
                    
                    textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('2. Información sobre las necesidades y estado en el ámbito Informático, así como también las mejoras desarrolladas', 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;
                    
                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData2, 7.25)
                    doc.text(0.5, verticalOffSet + 12/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 12 / 72;

                    if(verticalOffSet > 5.5){
                        doc.addPage();
                        verticalOffSet = 0.5;
                    }

                    textlines = doc.setFont("Arial")
                        .setFontSize("15")
                        .splitTextToSize('3. Acuerdos tomados por los Jueces que ilustren las gestiones y mejoras que ha implementado el propio tribunal', 7.25)
                        doc.text(0.5, verticalOffSet + 15/72 , textlines);
                        verticalOffSet += (textlines.length + 1) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData3, 7.25)
                    doc.text(0.5, verticalOffSet + 13/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 13 / 72;


                    textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('4. Informes solicitados por la Corte de Apelaciones o por el Consejo de Coordinación zonal y los tiempos de respuesta involucrados.', 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData4, 7.25)
                    doc.text(0.5, verticalOffSet + 12/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 12 / 72;

                    
                    if(verticalOffSet > 6){
                        doc.addPage();
                        verticalOffSet = 0.5;
                    }

                    textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('5. Requerimientos formulados por la CAPJ que fueron atendidos y aquellos que se encuentran pendientes respecto de los que se dio una respuesta negativa.', 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData5, 7.25)
                    doc.text(0.5, verticalOffSet + 12/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 12 / 72;

                    if(verticalOffSet > 6){
                        doc.addPage();
                        verticalOffSet = 0.5;
                    }

                    textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('6. Informe sobre las iniciativas de coordinación conducente a optimizar la gestión administrativa y presupuestaria del juzgado', 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData6, 7.25)
                    doc.text(0.5, verticalOffSet + 12/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 12 / 72;

                    if(verticalOffSet > 6){
                        doc.addPage();
                        verticalOffSet = 0.5;
                    }

                    textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('7. Desafíos futuros del Tribunal en materia administrativa y de gestión.', 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData7, 7.25)
                    doc.text(0.5, verticalOffSet + 12/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 12 / 72;

                    if(verticalOffSet > 6){
                        doc.addPage();
                        verticalOffSet = 0.5;
                    }


                    textlines = doc.setFont("Arial")
                    .setFontSize("15")
                    .splitTextToSize('8. General.', 7.25)
                    doc.text(0.5, verticalOffSet + 15/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 15 / 72;

                    textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize('Respuesta: ' + this.textData8, 7.25)
                    doc.text(0.5, verticalOffSet + 12/72 , textlines);
                    verticalOffSet += (textlines.length + 1) * 12 / 72;
                


                html2canvas(document.querySelector('#imprimirConcursosPDF')).then(canvas => { 
                    doc.addPage();
                    let img = canvas.toDataURL('image/png' , 7.25 , 2.5);
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 2.5);
                })

                html2canvas(document.querySelector('#imprimirIngresosPDF')).then(canvas => {
                    let img = canvas.toDataURL('image/png' , 7.25 , 8);
                    doc.addPage();
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 8);
                })

                html2canvas(document.querySelector('#imprimirTerminosPDF')).then(canvas => {
                    let img = canvas.toDataURL('image/png' , 7.25 , 8);
                    doc.addPage();
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 8);
                    // doc.save('Informe Gestion Jurisdiccional.pdf');
                    // this.putPDF = false;
                })

                html2canvas(document.querySelector('#imprimirResolucinesPDF')).then(canvas => {
                    let img = canvas.toDataURL('image/png' , 7.25 , 8);
                    doc.addPage();
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 8);
                    // doc.save('Informe Gestion Jurisdiccional.pdf');
                    // this.putPDF = false;
                })

                html2canvas(document.querySelector('#imprimirAudienciasRealizadasPDF')).then(canvas => {
                    let img = canvas.toDataURL('image/png' , 7.25 , 8);
                    doc.addPage();
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 8);
                    // doc.save('Informe Gestion Jurisdiccional.pdf');
                    // this.putPDF = false;
                })

                html2canvas(document.querySelector('#imprimirPresupuestoPDF')).then(canvas => {
                    let img = canvas.toDataURL('image/png' , 7.25 , 5);
                    doc.addPage();
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 5);
                })


                html2canvas(document.querySelector('#imprimirDotacionPDF')).then(canvas => {
                    let img = canvas.toDataURL('image/png' , 7.25 , 8);
                    doc.addPage();
                    doc.addImage(img, 'png', 0.5, 0.5,  7.25, 8);
                    
                    doc.addPage();
                    doc.setFont("Arial")
                    doc.setFontSize("15")
                    doc.text('Observación de la corte', 0.5, 0.5)

                    let textlines = doc.setFont("Arial")
                    .setFontSize("12")
                    .splitTextToSize(this.strObservacionCorte, 7.25)    
                    doc.text(0.5, 1, textlines);

                    doc.save('Informe Gestion Jurisdiccional.pdf');
                    this.putPDF = false;
                    this.setModal(false);
                }); 



            } catch (error) {
                console.log(error);
                this.setModal(false);
            }
        },

        async getEstadoCorteTribunal(){
            try {
                const req = urlJurisdiccional + '/observaciones';

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 15,
                        competencia_id: 0,
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.codTribunalIGJ,
                        ano: this.yearInformeJurisdiccional,
                    },
                });

                if (getObservacion.status == 200 || getObservacion.status == 304) {
                    if(getObservacion.data.data.observaciones.length > 0){
                        this.validaEstado =  getObservacion.data.data.observaciones[0].estado_observacion_id;
                    }else{
                        this.validaEstado = 1;
                    }
                   

                } else {
                    console.log(getObservacion.data.observacion);
                }

            } catch (error) {
                console.log(error.message);
            }
        },
        async getCorteTribunal(){
            try {

                const req = url + '/user/getUser/' + this.user.usuario_id;
                const getUserConf = await axios.get(req);

                if(getUserConf.status == 200 || getUserConf.status == 304){
                
                    store.set('cod_tribunal', getUserConf.data.cod_tribunal_origen.cod_tribunal);
		            store.set('cod_corte', getUserConf.data.cod_tribunal_origen.corte.cod_corte);
                    this.nombreCorte = getUserConf.data.cod_tribunal_origen.corte.descripcion;
                    this.cod_corte = getUserConf.data.cod_tribunal_origen.corte.cod_corte;
                    
                }

            } catch (error) {
                console.log(error.message);
            }
        },
        async finalizarInformeIGJ(){
            try {
                const req1 = urlJurisdiccional + '/finalizarIGJCorte'
                const req2 = url + '/email/emailIGJCortes'

                if(this.codTribunalIGJ == 0){
                    this.alertText = 'Debe seleccionar un tribunal';
                    this.typeAlert = 'error';
                    this.alert = true;
                    this.dialogFinalizar = false;
                    setTimeout(() => (this.alert = false), 5000)
                    return;
                }

                const response = await axios.post(req1, {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.codTribunalIGJ,
                        ano: this.yearInformeJurisdiccional,
                        usuario: this.user.usuario_id,
                    });

                if(response.status == 200 || response.status == 304){
                    this.typeAlert = 'success';
                    this.alertText = 'Informe finalizado correctamente';
                    this.alert = true;
                    this.getEstadoCorteTribunal();
                    this.switchResfrescar = !this.switchResfrescar;

                }else {
                    this.typeAlert = 'error';
                    this.alertText = 'Error al intentar finalizar el informe. Comuniquese a jurisdiccional@pjud.cl';
                    this.alert = true;
                }

                this.dialogFinalizar = false;

                //envio email
                const response2 = await axios.post(req2, {
                            email: this.user.email,
                            gls_tribunal: this.nombreTribunalIGJ,
                            gls_corte: this.nombreCorte
                })

                setTimeout(() => (this.alert = false), 3000);



            } catch (error) {
                console.log(error.message);
            }
        },
        async observarInformeIGJ(){
            try {
                const req1 = urlJurisdiccional + '/observarIGJCorte'
                const req2 = url + '/email/emailIGJCorteObserva'
                const req3 = urlJurisdiccional + '/observaciones_ica'
                const req4 = urlJurisdiccional + '/estados'

                let emailAdmTribunal = '';
                let observacionCorte = '';
                let admTribunal = '';

                //valido tribunal
                if(this.codTribunalIGJ == 0){
                    this.alertText = 'Debe seleccionar un tribunal';
                    this.typeAlert = 'error';
                    this.alert = true;
                    this.dialogObservar = false;
                    setTimeout(() => (this.alert = false), 3000)
                    return;
                }

                //Necesito que el administrador de tribunal haya finalizado el informe para saber a que usuario informar las observaciones
                const responseEstado = await axios.get(req4, {
                    params: {
                            cod_corte: this.cod_corte,
                            cod_tribunal: this.codTribunalIGJ,
                            ano: this.yearInformeJurisdiccional
                    }
                });

                //valido el informe observado
                if(responseEstado.data.data.estados.estado_observacion_id != undefined){
                    if(responseEstado.data.data.estados.estado_observacion_id == 1){
                        this.typeAlert = 'error';
                        this.alertText = 'No podemos informar las observaciones debido a que el tribunal no ha finalizado el informe jurisdiccional';
                        this.alert = true;
                        this.getEstadoCorteTribunal();
                        this.switchResfrescar = !this.switchResfrescar;
                        return;
                    }
                    //Administrador de tribunal que realizo el informe
                    admTribunal = responseEstado.data.data.estados.guardado.usuario;

                    //voy a buscar el correo del usuario
                    const req5 = url + '/user/getUser/' + admTribunal;
                    const getUserConf = await axios.get(req5);

                    if(getUserConf.status == 200 || getUserConf.status == 304){
                        emailAdmTribunal = getUserConf.data.email;
                    }


                    //Obtengo la observación guardada por la corte
                    const getObservacion = await axios.get(req3, {
                        params: {
                            formulario_id: 15,
                            cod_corte: this.cod_corte,
                            cod_tribunal: this.codTribunalIGJ,
                            ano: this.yearInformeJurisdiccional,
                        },
                    });

                    if(getObservacion.status == 200 || getObservacion.status  == 304){
                        //si no han guardado ninguna observación no es posible devolver el informe al tribunal
                        if (getObservacion.data.data.observaciones.length == 0) {
                            this.typeAlert = 'error';
                            this.alertText = 'Debe guardar una observación para informar al tribunal';
                            this.alert = true;
                            this.getEstadoCorteTribunal();
                            this.switchResfrescar = !this.switchResfrescar;
                            return;
                        }

                        getObservacion.data.data.observaciones.forEach(obs => {
                            observacionCorte = obs.observacion[0].descripcion;
                        });
                        //si la observación no contiene nada no podemos informar al tribunal
                        if (observacionCorte.trim == '') {
                            this.typeAlert = 'error';
                            this.alertText = 'La observación de la corte no puede estar vacia';
                            this.alert = true;
                            this.getEstadoCorteTribunal();
                            this.switchResfrescar = !this.switchResfrescar;
                            return;
                        }

                    }

                    //Procedemos a devolver el estado del informe IGJ de los tribunales para que puedan editarlo.
                    const response = await axios.post(req1, {
                            cod_corte: this.cod_corte,
                            cod_tribunal: this.codTribunalIGJ,
                            ano: this.yearInformeJurisdiccional,
                            usuario: this.user.usuario_id,
                    });

                    if(response.status == 200 || response.status == 304){
                        this.typeAlert = 'success';
                        this.alertText = 'Se ha informado al tribunal de sus observaciones';
                        this.alert = true;
                        this.getEstadoCorteTribunal();
                        this.switchResfrescar = !this.switchResfrescar;

                    }else {
                        this.typeAlert = 'error';
                        this.alertText = 'Error al habilitar el informe. Comuniquese a jurisdiccional@pjud.cl';
                        this.alert = true;
                        return;
                    }

                    this.dialogObservar = false;
                    setTimeout(() => (this.alert = false), 4000);

                    // envio email al usuario que realizo el informe en los tribunales.
                    const responseEmail = await axios.post(req2, {
                                email: emailAdmTribunal,
                                gls_tribunal: this.nombreTribunalIGJ,
                                gls_corte: this.nombreCorte,
                                observacion: observacionCorte,
                                cc: this.user.email
                    });

                }else{
                        this.typeAlert = 'error';
                        this.alertText = 'No podemos informar las observaciones debido a que el tribunal no ha finalizado el informe jurisdiccional';
                        this.alert = true;
                        this.getEstadoCorteTribunal();
                        this.switchResfrescar = !this.switchResfrescar;
                        return; 
                }


            } catch (error) {
                console.log(error.message);
            }
        },
        async onObservacionCorte(paramObs){
            try {
                this.strObservacionCorte = paramObs;
            } catch (error) {
                console.log(error.message);
            }
        },
        async getObservacionAdministrativa() {
            try {
                this.textData1 = ''
                this.textData2 = ''
                this.textData3 = ''
                this.textData4 = ''
                this.textData5 = ''
                this.textData6 = ''
                this.textData7 = ''
                this.textData8 = ''
                const req = urlJurisdiccional + '/observaciones_ica'

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 9,
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.codTribunalIGJ,
                        ano: this.yearInformeJurisdiccional,
                    },
                })

                if (getObservacion.status == 200) {
                    if (getObservacion.data.data.observaciones.length > 0 && this.yearInformeJurisdiccional > 2020) {
                        getObservacion.data.data.observaciones[0].observacion.forEach(
                            obs => {
                                switch (obs.id) {
                                    case 1:
                                        this.textData1 = obs.descripcion
                                        break
                                    case 2:
                                        this.textData2 = obs.descripcion
                                        break
                                    case 3:
                                        this.textData3 = obs.descripcion
                                        break
                                    case 4:
                                        this.textData4 = obs.descripcion
                                        break
                                    case 5:
                                        this.textData5 = obs.descripcion
                                        break
                                    case 6:
                                        this.textData6 = obs.descripcion
                                        break
                                    case 7:
                                        this.textData7 = obs.descripcion
                                        break
                                    case 8:
                                        this.textData8 = obs.descripcion
                                        break

                                    default:
                                        break
                                }
                            }
                        )
                    } else if (this.yearInformeJurisdiccional <= 2020) {
                        getObservacion.data.data.observaciones[0].observacion.forEach((obs, index) => {
                                switch (index) {
                                    case 0:
                                        this.textData1 = obs.descripcion
                                        break
                                    case 1:
                                        this.textData2 = obs.descripcion
                                        break
                                    case 2:
                                        this.textData3 = obs.descripcion
                                        break
                                    case 3:
                                        this.textData4 = obs.descripcion
                                        break
                                    case 4:
                                        this.textData5 = obs.descripcion
                                        break
                                    case 5:
                                        this.textData6 = obs.descripcion
                                        break
                                    case 6:
                                        this.textData7 = obs.descripcion
                                        break
                                    case 7:
                                        this.textData8 = obs.descripcion
                                        break

                                    default:
                                        break
                                }
                            }
                        )
                    }
                } else {
                    console.log(getObservacion.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
        async getObservacionJuezPresidente() {
            try {
                const req = urlJurisdiccional + '/observaciones';
                this.obsJuezPresidente = [];
                let contador = 0;

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 7,
                        competencia_id: 0,
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.codTribunalIGJ,
                        ano: this.yearInformeJurisdiccional,
                    },
                });

                if (getObservacion.status == 200 || getObservacion.status == 304) {

                    getObservacion.data.data.observaciones.forEach(obs => {

                        obs.observacion.forEach(obsDet => {

                            this.obsJuezPresidente.push({
                                id:contador,
                                competencia: '',
                                texto:  obsDet.descripcion,
                            });     

                            contador++;

                        });

                    });


                } else {
                    console.log(getObservacion.data.observacion);
                }


            } catch (error) {
                console.log(error.message);
            }
        },
        ...mapMutations(['setModal']),

    },
    components:{
        Layout,
        GraficoIngresos,
        TotalesIngresos,
        ObservacionesTribunales,
        GraficoTerminos,
        TotalesTerminos,
        TotalesResoluciones,
        GraficoResoluciones,
        TotalesAudiencias,
        GraficoAudienciasRealizadas,
        Administrativa,
        GraficoBarraDotacion,
        GraficoTortaDotacion,
        TotalPresupuestos,
        GraficosPresupuestos,
        Concursos,
        ObservacionCorte,
        TotalesIngresosMaterias,
        GraficoIngresosMaterias,
        GraficoTerminosMaterias,
        TotalesTerminosMaterias,
        ObservacionesTribunalesPDF,
        AdministrativaPDF,
        ModalLoading,
        TablaDotacion
    },
    computed: {
        ...mapState(['codTribunalIGJ', 'yearInformeJurisdiccional','nombreTribunalIGJ'])
    },
    watch:{
        codTribunalIGJ(){
            try {
                if(this.codTribunalIGJ != 0){
                    this.getEstadoCorteTribunal();
                    this.getObservacionAdministrativa();
                    this.getObservacionJuezPresidente();
                }
                
            } catch (error) {
                console.log(error.message);
            }
        },
        yearInformeJurisdiccional(){
            try {
                if(this.codTribunalIGJ != 0){
                    this.getEstadoCorteTribunal();
                    this.getObservacionAdministrativa()
                    this.getObservacionJuezPresidente();
                }

            } catch (error) {
                console.log(error.message);
            }
        },
    }
}
</script>
<style scoped>
	.ribbon {
		padding: 0 20px;
		height: 30px;
		line-height: 30px;
		clear: left;
		position: absolute;
		top: 12px;
		left: -2px;
		color: #fff;
	}

	.ribbon-bookmark.ribbon-info:before {
		border-color: #5461a9 transparent #5461a9 #5461a9;
	}

	.ribbon-bookmark:before {
		position: absolute;
		top: 0;
		left: 95%;
		display: block;
		width: 0;
		height: 0;
		content: '';
		border: 15px solid #2b2b2b;
		border-right: 10px solid transparent;
	}

	.ribbon-info {
		background: #5461a9;
	}

	.ribbon-wrapper,
	.ribbon-wrapper-bottom,
	.ribbon-wrapper-reverse,
	.ribbon-wrapper-right-bottom {
		position: relative;
		background: #f4f8f9;
		padding: 50px 15px 15px 50px;
	}
</style>
