import Vue from 'vue'
import App from './App.vue'
import './registerServiceWorker'
import router from './router'
import store from './store'
import VueExcelXlsx from "vue-excel-xlsx";
// import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'
import vuetify from '@/plugins/vuetify' // path to vuetify export
import 'roboto-fontface-material/fonts/roboto-fontface-material.css'
import '@mdi/font/css/materialdesignicons.css'
// import 'bootstrap/dist/css/bootstrap.css'
// import 'bootstrap-vue/dist/bootstrap-vue.css'
// import 'bootstrap-vue/dist/bootstrap-vue-icons.min.css'
import './assets/css/bigToolTip.css'
import './assets/css/custom.css'
//import './icon.js' //FontAwesome ICONS
import VueMoment from 'vue-moment'
import moment from 'moment-timezone'
import { ValidationProvider } from 'vee-validate';

import * as Sentry from "@sentry/vue";
import { Integrations } from "@sentry/tracing";
import VueGtag from "vue-gtag";
import VueGoogleCharts from 'vue-google-charts'
import VueApexCharts from 'vue-apexcharts'



// Vue.use(BootstrapVue)
// Vue.use(IconsPlugin)
Vue.use(VueGoogleCharts)
Vue.component('apexchart', VueApexCharts)
Vue.use(VueApexCharts)
Vue.use(VueExcelXlsx)
Vue.use(VueMoment, {
  moment,
})
Vue.component('ValidationProvider', ValidationProvider);

Vue.prototype.$thousandSeparator = function(value){
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}
Vue.prototype.$settingDate = function(date){
  return moment(date).format('YYYY/MM/DD')
}

Vue.prototype.$setDate = function(option){
  let fechas = [{
    anoInicio: 0,
    anoFin: 0,
    mesInicio: 0,
    mesFin: 0,
    calendario: [],
    fechaInicioCompleta: '',
    fechaFinalCompleta: '',
  }]    

  moment.locale('es');

  let calendario = []
  switch (option) {
      case 1:
              fechas.mesInicio = Number(moment().add(-1,'M').format("M"))  // Menos un mes.
              fechas.anoInicio = Number(moment().add(-1,'M').format("YYYY"))
              fechas.mesFin = Number(moment().add(-1,'M').format("M")) // Menos un mes.
              fechas.anoFin = Number(moment().add(-1,'M').format("YYYY"))
              calendario.push(moment().month(fechas.mesFin -1).format('MMMM'));
              fechas.fechaInicioCompleta = moment(fechas.anoInicio + '/' + fechas.mesInicio + '/01').format('YYYY/MM');
              fechas.fechaFinalCompleta = moment(fechas.anoFin + '/' + fechas.mesFin + '/01').format('YYYY/MM');
              fechas.calendario = calendario;
             
          break;
      case 2:
              fechas.mesInicio = Number(moment().add(-3,'M').format("M")) // Menos tres meses.
              fechas.anoInicio = Number(moment().add(-3,'M').format("YYYY"))
              fechas.mesFin = Number(moment().add(-1,'M').format("M")) // Menos un mes.
              fechas.anoFin = Number(moment().add(-1,'M').format("YYYY"))
              fechas.fechaInicioCompleta = moment(fechas.anoInicio + '/' + fechas.mesInicio + '/01').format('YYYY/MM');
              fechas.fechaFinalCompleta = moment(fechas.anoFin + '/' + fechas.mesFin + '/01').format('YYYY/MM');

              

              for (let index = (fechas.mesInicio - 1); index <= (fechas.mesFin - 1); index++) {
                calendario.push(moment().month(index).format('MMMM'))
              }
              fechas.calendario = calendario
              
          break;
      case 3:
              fechas.mesInicio = Number(moment().add(-12,'M').format("M")) // Menos tres meses.
              fechas.anoInicio = Number(moment().add(-12,'M').format("YYYY"))
              fechas.mesFin = Number(moment().add(-1,'M').format("M")) // Menos un mes.
              fechas.anoFin = Number(moment().add(-1,'M').format("YYYY"))
              fechas.fechaInicioCompleta = moment(fechas.anoInicio + '/' + fechas.mesInicio + '/01').format('YYYY/MM');
              fechas.fechaFinalCompleta = moment(fechas.anoFin + '/' + fechas.mesFin + '/01').format('YYYY/MM');

              for (let index = (fechas.mesInicio - 1); index <= 11; index++) {
                calendario.push(moment().month(index).format('MMMM'))
              }

              for (let index = (fechas.mesFin -1); index >= 0; index--) {
                calendario.push(moment().month(((fechas.mesFin -1) - index)).format('MMMM'))
              } 

              fechas.calendario = calendario

          break;                                         

      default:
          break;
  }
  return fechas
}

Vue.prototype.$setDateConecta = function(ano, mes, opcion){
  
  moment.locale('es');
  let startDate = ''
  let endDate   = ''
  switch (opcion) {
      case 0:
        startDate = moment([ano, mes - 1])
        endDate = moment(startDate).endOf('month');
        return [startDate.toDate(), endDate.toDate()]                                       
      default:
        startDate = moment([ano, 0])
        endDate = moment(startDate).endOf('year');
        return [startDate.toDate(), endDate.toDate()]  
  }
}



Vue.prototype.$goDetallesIndicadores = function(paramRoute, paramCod_corte, paramCod_tribunal){
	try {

		store.set('cod_tribunal', paramCod_tribunal);
		store.set('cod_corte', paramCod_corte);
		this.$router.push({ name: paramRoute });

	} catch (error) {
		throw new Error(error.message);
	}
}



Vue.prototype.$setDateIntervalConecta = function(startDate, endDate){
  
  moment.locale('es');
  let dates = []
  startDate = moment(startDate)

  while(moment(startDate).format('YYYY-MM-DD') !== moment(endDate).format('YYYY-MM-DD')) {
    dates.push(moment(startDate).format('YYYY-MM-DD'))
    startDate = moment(startDate).add(1, 'days')
  }

  dates.push(moment(startDate).format('YYYY-MM-DD'))

  return dates
}

Vue.filter('capitalize', function (value) {
  if (!value) return ''
  value = value.toString().toLowerCase()
  return value.charAt(0).toUpperCase() + value.slice(1)
})

Vue.prototype.$interval = async function interval(id, stateFunction) {
  return new Promise(async function(resolve, reject) {
      try {
          let stateJob = 'Running'
          let loop = undefined
          loop = setInterval(async function() {
              stateJob =  await stateFunction(id)
              if(stateJob !== 'Running'){
                  clearInterval(loop)
                  resolve(stateJob)
              }
          }, 2000)
      } catch (error) {
         reject(error) 
      }
  })
},

Vue.config.productionTip = false

Sentry.init({
  Vue,
  dsn: "https://d83534e6be4a48fb8e2a018a16957a54@o170794.ingest.sentry.io/5880280",
  integrations: [
    new Integrations.BrowserTracing({
      routingInstrumentation: Sentry.vueRouterInstrumentation(router),
      tracingOrigins: ["localhost", "my-site-url.com", /^\//],
    }),
  ],
  // Set tracesSampleRate to 1.0 to capture 100%
  // of transactions for performance monitoring.
  // We recommend adjusting this value in production
  tracesSampleRate: 1.0
});

Vue.use(VueGtag, {
  config: { id: "G-Q53EJ298H2" }
});


new Vue({
  vuetify,
  router,
  store,
  render: h => h(App)
}).$mount('#app')