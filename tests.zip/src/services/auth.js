import axios from 'axios'
import store from 'store'
import { url } from '../config/apiConfig'

export default class AuthService {
	static login(usuario, contrasena) {
		return new Promise(async (resolve, reject) => {
		try {
			let response = await axios.post(`${url}/authorization/login`, {
			usuario,
			contrasena,
			});

			store.set("usuario", response.data.data.usuario);

			store.set("nombre_completo", response.data.data.nombre_completo);

			store.set("email", response.data.data.email);

        	store.set('cod_corte', response.data.data.cod_corte)

			store.set('token', response.data.data.token)

			store.set('cod_tribunal', response.data.data.cod_tribunal);

			store.set('perfil_corte', response.data.data.perfil_corte)

			resolve(response)
		} catch (error) {
			resolve(error.response)
		}
    })
  }

  	static async recuperarConstrasena(email){
    	return new Promise(async (resolve , reject) => {
			try {
		  		let response = await axios.post(`${url}/authorization/recuperarContrasena`,{email});
				resolve(response);

			} catch (error) {
				resolve(error.response);
			}
		});

  	}

	static async changePassword(usuario, newPassword){
		try {
			let response = await axios.patch(`${url}/authorization/changePassword`,{
												usuario: usuario,
												password: newPassword,
											});

			return(response);

		} catch (error) {
			return(error);
		}

  	}




}
