<template>
  <v-container fluid>
    <v-row>
      <v-col cols="6" md="12">
        <v-data-table
          :headers="headers"
          :items="filteredItems"
          :sort-by="computedSortBy"
          :sort-desc="computedSortDesc"
          item-key="increment"
          class="elevation-1"
          :search="search"
          :custom-filter="filterOnlyCapsText"
          no-results-text="Sin Resultado"
          dense
          style="max-height: 400px; overflow-x: auto;"
          :footer-props="{
        'items-per-page-text':'Cantidad de Registro(s) por pagina',
        'items-per-page-options': [10, 20, 30, 40, 50,-1],
        pageText: '{0}-{1} de {2}'
      }"
        >
        <template v-slot:top>
            <v-text-field
              v-model="search"
              label="Busqueda"
              class="mx-4"
            ></v-text-field>
          </template>

          <template v-slot:no-data>
          Sin Registros
      </template>
      <!-- eslint-disable-next-line vue/valid-v-slot -->
      <template v-slot:body.append> 
        <tr class="pjud white--text">
          <td></td>
          <td v-text="'Total'" style="text-align: center;" class="v-data-table__mobile-row__header"></td>
          <td style="text-align: center;" class="v-data-table__mobile-row__header"><countTo
                                            class="count"
                                            :startVal="0"
                                            :endVal="total"
                                            separator="."
                                            :duration="1000"
                                        ></countTo></td>
        </tr>
      </template>

        </v-data-table>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import countTo from 'vue-count-to';

export default {
  name: 'ComponenteTabla',
  props: {
    pieData: { type: Array, default: () => [] },
    headers: { type: Array, default: () => [] },
    sort_desc: { type: [Boolean, Array, String], default: () => [] },
    sort_by: { type: Array, default: () => [] },
    total: { type: Number, default: () => 0 },
  },
  data() {
    return {
      search: '',
      filteredItems: this.pieData
    };
  },
  computed: {
    computedSortBy() {
      return [...this.sort_by];
    },
    computedSortDesc() {
      return Array.isArray(this.sort_desc) ? this.sort_desc : Boolean(this.sort_desc);
    },
    totalCantidad(){
      return this.pieData.reduce((acc, item) => acc + item.cantidad,0);
    }
  },
  watch: {
    pieData: {
      handler(newPieData, oldPieData) {
        if (JSON.stringify(newPieData) !== JSON.stringify(oldPieData)) {
          this.fetchData();
        }
      },
      deep: true,
    },
    search(newSearch){
      this.updateSearch(newSearch);
    }
  },
  created() {
    this.fetchData();
  },
  methods: {
    fetchData() {
      try {
        console.log("En fetchData");   
        console.log(this.pieData);
        const cabecera = this.headers.map((a) => a.value);
        console.log(cabecera);
        this.$emit('update:sort_by', cabecera);
        this.updateTableData();
      } catch (error) {
        console.error('Error al obtener los datos:', error);
      }
    },
    updateTableData() {
      this.filteredItems = this.pieData;
    },
    updateSearch(search) {    

        var upperCaseSearch = [];

        upperCaseSearch = this.pieData.filter(item => item.tip_causa.toString().toUpperCase().includes(search.toString().toUpperCase()) || item.increment.toString() === search.toString() || item.cantidad.toString() === search.toString());

        if (upperCaseSearch===undefined) 
        { 
          this.filteredItems = this.pieData; // Resetea los items si no hay búsqueda 
        } 
        else 
        { 
          this.filteredItems = this.filterOnlyCapsText(upperCaseSearch); 
        } 
      },
      filterOnlyCapsText(items) 
      { 
        return items;
      }   
  },
  components: {
    countTo,
  },
};
</script>