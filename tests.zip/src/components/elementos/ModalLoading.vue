<template>
    <v-dialog
        v-model="$store.state.dialog"    
        persistent max-width="600px"
        >
        <v-card
            color="#5461a9"
            dark
        >
            <v-card-text class="white--text">
            Obteniendo Información
            <v-progress-linear
                indeterminate
                color="#5461a9"
                class="mb-0"
            ></v-progress-linear>
            </v-card-text>
        </v-card>
    </v-dialog>   
</template>

<script>
export default {
    name: 'ModalLoading',
    data (){
        return {
           
        }
    }
}
</script>