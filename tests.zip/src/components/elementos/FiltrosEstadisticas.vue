<template>
    <v-card outlined class="mx-auto">
        <v-row align="center" class="px-4" dense>
            <v-col class="mt-3" cols="1" sm="1">
                <v-select
                    :items="anios"
                    v-model="aniosSelected"
                    :label="labelAnoInicio"
                    dense
                    
                ></v-select>                 
            </v-col>
            <v-col class="mt-3" cols="2" sm="2">
                <v-select
                    item-value="value"
                    item-text="name"
                    :items="meses"
                    v-model="mesesSelected"
                    :label="labelMesInicio"
                    dense
                ></v-select>                 
            </v-col>
            <v-col class="mt-4" cols="3" sm="3">
                <v-select @change="getTribunales($event)"
                    item-value="cod_corte"
                    item-text="corte"
                    :items="listCortes"
                    v-model="corteSelected"
                    :label="labelCorte"
                    dense
                ></v-select>
            </v-col>
            <v-col class="mt-3" cols="3" sm="3">
                <v-select
                    item-value="cod_tribunal"
                    item-text="tribunal"
                    :items="listTribunales"
                    v-model="tribunalSelected"
                    :label="labelTribunal"
                    dense
                ></v-select>
            </v-col>
            <v-col class="mt-3 px-0 ml-3" cols="2" sm="2">
                <v-btn color="pjud text-white" style="margin-top: -25px" @click="buscar">Buscar</v-btn>      
            </v-col>
        </v-row>
    </v-card>
</template>
<script>
import Vue from 'vue'
import store from 'store'
import { urlApi } from '../../config/api'
import { mapMutations } from 'vuex' // Esto interpreta el archivo index.js de la carpeta store
import moment from 'moment-timezone'
moment.locale('es');

export default {
    name: 'FiltrosEstadisticas',
    data () {
        return {       
            anios: [2024,2023,2022,2021,2020,2019],
            aniosSelected: store.get('ano'),
            aniosSelectedFin: store.get('ano'),
            meses: [ { value: 1, name: 'Enero' },
                     { value: 2, name: 'Febrero' },
                     { value: 3, name: 'Marzo' },
                     { value: 4, name: 'Abril' },
                     { value: 5, name: 'Mayo' },
                     { value: 6, name: 'Junio' },
                     { value: 7, name: 'Julio' },
                     { value: 8, name: 'Agosto' },
                     { value: 9, name: 'Septiembre' },
                     { value: 10, name: 'Octubre' },
                     { value: 11, name: 'Noviembre' },
                     { value: 12, name: 'Diciembre' }
            ],
            mesesSelected: store.get('mes'),
            labelAnoInicio: 'Año',
            labelMesInicio: 'Mes',
            labelCorte: 'Corte',
            labelTribunal: 'Tribunal',
            corteSelected: store.get('cod_corte'),
            tribunalSelected: store.get('cod_tribunal'),
            listCortes: [],
            listTribunales: [],
            competencia: this.$route.path.split('/')
        }
    },
    created(){
        const objFechas = store.get('fechas');

        this.mesesSelected = (objFechas.mesFin == 1)?12:objFechas.mesFin - 1;
        this.aniosSelected = (objFechas.mesFin == 1)?objFechas.anoFin - 1:objFechas.anoFin;
        this.competencia = this.competencia[2]
        //this.anios = [(objFechas.mesFin == 1)?objFechas.anoFin - 1:objFechas.anoFin];
        this.inicia()
    },
    methods: {
        ...mapMutations(['setFechas']), // Mutations no Borrar
        buscar() {
            let fechas = {
            }

            fechas.corte = Number(this.corteSelected)  // Menos un mes.
            fechas.tribunal = Number(this.tribunalSelected)
            fechas.ano = Number(this.aniosSelected)
            fechas.mes = Number(this.mesesSelected)
            fechas.mesEst = Number(this.mesesSelected)
            this.setFechas(fechas)

            this.$emit("buscar")
        },
        inicia(){ 
            const axios = require('axios')
            let req1 = urlApi + '/generales/tribunal-detalle'
            axios.all([
                    axios.get(req1, {
                        params: {
                            competencia: this.competencia
                        }
                    }),
                    axios.get(req1, {
                        params: {
                            cod_tribunal: this.tribunalSelected,
                            competencia: this.competencia
                        }
                    })
                ]).then(axios.spread((...responses) => {
                    const data = responses[0].data
                    const data1 = responses[1].data
                    this.corteSelected = (data1.recordset.length > 0)?data1.recordset[0].cod_corte:0
                    this.getTribunales(this.corteSelected)
                    this.listCortes = []
                    this.listCortes.push({cod_corte:0, corte:'TODAS'})
                    Object.values(data.recordset).map((type) => {
                        this.listCortes.push({cod_corte:type.cod_corte, corte:type.gls_corte})
                    })
                    this.listCortes = Object.values(this.listCortes.reduce((acc,cur)=>Object.assign(acc,{[cur.cod_corte]:cur}),{}))

                })).catch(errors => {
            //  this.setModal(false) // Aqui Manipulamos el modal
            })

            let fechas = {
            }
            fechas.corte = Number(this.corteSelected)  // Menos un mes.
            fechas.tribunal = Number(this.tribunalSelected)
            fechas.ano = Number(this.aniosSelected)
            fechas.mes = Number(this.mesesSelected)
            this.setFechas(fechas)

        },
        getTribunales(event){
            const axios = require('axios')
            let req1 = urlApi + '/generales/tribunal-detalle'
            axios.all([
                    axios.get(req1, {
                        params: {
                            cod_corte: event,
                            competencia: this.competencia
                        }
                    })
                ]).then(axios.spread((...responses) => {
                    const data = responses[0].data
                    let cont = 0
                    this.listTribunales = []
                    this.listTribunales.push({cod_tribunal:0, tribunal:'TODOS'})
                    Object.values(data.recordset).map((type) => {
                        if (this.tribunalSelected === type.cod_tribunal){
                            cont = 1
                        }
                        this.listTribunales.push({cod_tribunal:type.cod_tribunal, tribunal:type.gls_tribunal})
                    })
                    if (cont == 0){
                        this.tribunalSelected = 0
                    }
                    let fechas = {
                    }
                    fechas.corte = Number(this.corteSelected)  // Menos un mes.
                    fechas.tribunal = Number(this.tribunalSelected)
                    fechas.ano = Number(this.aniosSelected)
                    fechas.mes = Number(this.mesesSelected)
                    fechas.mesEst = Number(this.mesesSelected)
                    this.setFechas(fechas)
                })).catch(errors => {
            //  this.setModal(false) // Aqui Manipulamos el modal
            })
        }
    } 
}
</script>