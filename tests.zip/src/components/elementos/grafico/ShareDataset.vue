<template>
    <v-col sm="12" cols="12">
      <div id="main" ref="chart" class="chart-container"></div>
    </v-col>
  </template>
  
  <script>
  import * as echarts from 'echarts';
  
  export default {
    name: 'BarChart',
    props: {
    series: { type: Array, default: () => [] }
  },
    data() {
      return {
        dataValues: [],
        dataLabels: [],
        dataArray:[],
        chart: null,
        hasData: true
      };
    },
    watch: {
    series: {
      handler(newSeries, oldSeries) {
        if (JSON.stringify(newSeries) !== JSON.stringify(oldSeries)) {
          this.fetchData();
        }
      },
      deep: true // Para observar cambios en objetos o arrays profundamente anidados
    }
  },
  created() {
    this.fetchData();
  },
  mounted() {
    this.initializeChart();
    window.addEventListener('resize', this.updateChartOptions);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.updateChartOptions);
    if (this.chart) {
      this.chart.dispose(); // Liberar recursos del gráfico al destruir el componente
    }
  },
    methods: {
        initializeChart() {
      const chartDom = this.$refs.chart;
      if (!chartDom) {
        console.error('Elemento del gráfico no encontrado.');
        return;
      }
      this.chart = echarts.init(chartDom, null, {
        renderer: 'canvas'
      });
      this.updateChartOptions();
      this.updateChartData();
    },
    fetchData() {
      try {
        /*Se declaran variables */
        const dataLabels = [];
        const dataValues = [];
        const Array = [];

        /*Se recorre arreglo y se deja en las constantes de tipo array guardada de mayor a menor*/  
        this.series
          .sort((a, b) => b.cantidad - a.cantidad)
          .forEach((item) => {
            dataLabels.push(item.tip_causa.trim());
            dataValues.push(item.cantidad);
            Array.push({ x:item.tip_causa.trim(), y:item.cantidad });
          });
        /*Se realiza reversa a arrays dataLabels y dataValues al momento de mostrar valores en grafico, los muestre de mayor a menor y Otros a la ultima barra */
        this.dataLabels = dataLabels;
        this.dataValues = dataValues;
        this.Array = Array;

        this.hasData = true;
        this.updateChartData();
      } catch (error) {
        console.error('Error al obtener los datos:', error);
        this.hasData = false;
      }
    },
    updateChartOptions() {
      if (this.chart) {
        const isMobile = window.innerWidth < 768;
        this.chart.setOption({
          legend: {
            orient: isMobile ? 'horizontal' : 'vertical',
            right: isMobile ? 'auto' : 20,
            left: isMobile ? 'center' : 'auto',
            top: isMobile ? 'bottom' : 'left',
            data: this.dataLabels
          }
        });
      }
    },
    updateChartData() {
        const chartDom = this.$refs.chart;
        if (!chartDom) {
          console.error('Elemento del gráfico no encontrado.');
          return;
        }
        this.chart = echarts.init(chartDom, null, {
          renderer: 'canvas'
        });    
        
        const inputArray = this.Array;

const labels = inputArray.map(item => item.x);
const result = [];

// Add the first row with labels
result.push(['product', ...labels]);

// Generate the matrix
labels.forEach((label, rowIndex) => {
  const row = [label];
  labels.forEach((_, colIndex) => {
    if (rowIndex === colIndex) {
      row.push(inputArray[rowIndex].y);
    } else {
      row.push(0);
    }
  });
  result.push(row);
});


const array = new Array(this.dataLabels.length).fill({
                type: 'line',
                smooth: true,
                seriesLayoutBy: 'row',
                emphasis: { focus: 'series' }
              }); 
              
        setTimeout(() => {

          let option = {
            legend: {},
            tooltip: {
              trigger: 'axis',
              showContent: false
            },
            dataset: {
              source: result
            },
            xAxis: { type: 'category' },
            yAxis: { gridIndex: 0 },
            grid: { top: '55%' },
            series: [
            ...array,
              {
                type: 'pie',
                id: 'pie',
                radius: '30%',
                center: ['50%', '25%'],
                emphasis: {
                  focus: 'self'
                },
                data: this.dataLabels.map((label, index) => ({
                value: this.dataValues[index],
                name: label
              })),
                label: {
                  formatter: '{b}: {@2012} ({d}%)'
                },
                encode: {
                  itemName: 'product',
                  value: '2012',
                  tooltip: '2012'
                }
              }
            ]
          };
  
          this.chart.on('updateAxisPointer', (event) => {
            const xAxisInfo = event.axesInfo[0];
            if (xAxisInfo) {
              const dimension = xAxisInfo.value + 1;
              this.chart.setOption({
                series: [{
                  id: 'pie',
                  label: {
                    formatter: `{b}: {@[${dimension}]} ({d}%)`
                  },
                  encode: {
                    value: dimension,
                    tooltip: dimension
                  }
                }]
              });
            }
          });
  
          this.chart.setOption(option);
        }, 0);
      }
    }
  };
  </script>
  
  <style scoped>
  .chart-container {
    position: relative;
    height: 100vh;
    overflow: hidden;
  }
  
  @media (max-width: 768px) {
    .chart-container {
      height: 60vh;
    }
  }
  
  @media (max-width: 480px) {
    .chart-container {
      height: 50vh;
    }
  }
  </style>