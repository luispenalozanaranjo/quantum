<template>
  <v-col cols="12">
    <div id="main" ref="chart" class="chart-container"></div>
  </v-col>
</template>

<script>
import * as echarts from 'echarts';

export default {
  name: 'PieChart',
  props: {
    series: { type: Array, default: () => [] },
    labels: { type: Array, default: () => [] },
    tribunal: { type: String, default: () => '' }
  },
  data() {
    return {
      dataLabels: [],
      dataValues: [],
      chart: null,
      hasData: true,
      windowWidth: window.innerWidth
    };
  },
  watch: {
    series: 'fetchData',
    labels: 'fetchData',
    tribunal: 'fetchData'
  },
  async created() {
    this.fetchData();
    window.addEventListener('resize', this.handleResize);
  },
  destroyed() {
    window.removeEventListener('resize', this.handleResize);
  },
  mounted() {
    this.initializeChart();
    window.addEventListener('resize', this.updateChartOptions);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.updateChartOptions);
  },
  methods: {
    initializeChart() {
      const chartDom = this.$refs.chart;
      if (!chartDom) {
        console.error('Elemento del gráfico no encontrado.');
        return;
      }
      this.chart = echarts.init(chartDom);
      this.updateChartOptions();
    },
    async fetchData() {

      try {
        this.dataValues = this.series;
        this.dataLabels = this.labels;
        this.hasData = true;
        this.updateChartData();
      } catch (error) {
        console.error('Error al obtener los datos:', error);
        this.hasData = false;
      }
    },
    updateChartOptions() {
      if (this.chart) {
        const isMobile = window.innerWidth < 768;
        this.chart.setOption({
          legend: {
            orient: isMobile ? 'horizontal' : 'vertical',
            right: isMobile ? 'auto' : 20,
            left: isMobile ? 'center' : 'auto',
            top: isMobile ? 'bottom' : 'left',
            data: this.dataLabels
          }
        });
      }
    },
    updateChartData() {
      if (this.chart) {
        const option = {
          title: {
            text: `Total ${this.getTotales().toLocaleString()}`,
            left: '26%',
            top: '38%',
            verticalAlign: 'middle'
          },
          legend: {
            orient: window.innerWidth < 768 ? 'horizontal' : 'vertical',
            right: window.innerWidth < 768 ? 'auto' : '10%',
            left: window.innerWidth < 768 ? 'center' : 'auto',
            top: window.innerWidth < 768 ? 'bottom' : 'left',
            data: this.dataLabels
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
          },
          series: [
            {
              name: this.tribunal,
              type: 'pie',
              radius: ['40%', '70%'],
              center: ['30%', '40%'],
              avoidLabelOverlap: true,
              label: {
                show: true,
                position: 'inner',
                formatter: params => `${params.percent}%`
              },
              labelLine: {
                show: true
              },
              data: this.dataLabels.map((label, index) => ({
                value: this.dataValues[index],
                name: label
              }))
            }
          ]
        };

        this.chart.setOption(option);
        this.chart.on('mouseup', params => this.updateTitle(params.value));
        this.chart.on('click', event => this.updateTitle(event.data.value));
        this.chart.on('legendselectchanged', params => this.updateLegend(params.selected));
      }
    },
    updateTitle(value) {
      if (this.chart) {
        const option = this.chart.getOption();
        option.title[0].text = `Total ${value.toLocaleString()}`;
        option.title[0].left = '26%'; // Move the title to the left
        option.title[0].top = '38%'; 
        option.title[0].verticalAlign = 'middle'; 
        this.chart.setOption(option);
      }
    },
    updateLegend(selected) {
      const selectedLabels = Object.keys(selected).filter(key => selected[key]);
      const selectedValues = selectedLabels.map(label => this.dataValues[this.dataLabels.indexOf(label)]);
      const total = selectedValues.reduce((a, b) => a + b, 0);

      const option = this.chart.getOption();
      option.title[0].text = `Total ${total.toLocaleString()}`;
      option.title[0].left = '26%'; // Move the title to the left
      option.title[0].top = '38%'; 
      option.title[0].verticalAlign = 'middle'; 
      option.series[0].data = this.dataLabels.map((label, index) => ({
        value: this.dataValues[index],
        name: label
      }));
      this.chart.setOption(option);
    },
    getTotales() {
      return this.dataValues.reduce((a, b) => a + b, 0);
    },
    handleResize() {
      this.windowWidth = window.innerWidth;
      this.updateChartData();
    }
  }
};
</script>

<style scoped>
.chart-container {
  width: 100%;
  height: 500px;
  position: relative;
}

.chart {
  width: 100%;
  height: 100%;
}

.no-data-container {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 1.2rem;
  color: #999;
}

@media (max-width: 767px) {
  .chart-container {
    height: 400px;
  }
}
</style>
