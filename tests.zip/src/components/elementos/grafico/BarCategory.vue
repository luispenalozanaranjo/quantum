<template>
  <v-col cols="12">
    <div id="main" ref="chart" class="chart-container"></div>
  </v-col>
</template>

<script>
import * as echarts from 'echarts';

export default {
  name: 'BarChart',
  props: {
    series: { type: Array, default: () => [] },
    val: { type: Number, default: 0 }
  },
  data() {
    return {
      dataValues: [],
      dataLabels: [],
      valor: 0,
      chart: null,
      hasData: true
    };
  },
  watch: {
    series: {
      handler(newSeries, oldSeries) {
        if (JSON.stringify(newSeries) !== JSON.stringify(oldSeries)) {
          this.fetchData();
        }
      },
      deep: true // Para observar cambios en objetos o arrays profundamente anidados
    },
    val(newVal, oldVal) {
      if (newVal !== oldVal) {
        this.fetchData();
      }
    }
  },
  created() {
    this.fetchData();
  },
  mounted() {
    this.initializeChart();
    window.addEventListener('resize', this.updateChartOptions);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.updateChartOptions);
    if (this.chart) {
      this.chart.dispose(); // Liberar recursos del gráfico al destruir el componente
    }
  },
  methods: {
    initializeChart() {
      const chartDom = this.$refs.chart;
      if (!chartDom) {
        console.error('Elemento del gráfico no encontrado.');
        return;
      }
      this.chart = echarts.init(chartDom, null, {
        renderer: 'canvas'
      });
      this.updateChartOptions();
      this.updateChartData();
    },
    fetchData() {
      try {
        /*Se declaran variables */
        const dataLabels = [];
        const dataValues = [];
			  var sum = 0;
        /*Se recorre arreglo y se deja en las constantes de tipo array guardada de mayor a menor*/  
        this.series
          .sort((a, b) => b.value - a.value)
          .forEach((item) => {
            dataLabels.push(item.name.trim());
            dataValues.push(item.value);
          });
        /*If que da la opcion para generar un Otros en Labels o eje x*/   
        if (dataLabels.length >= 11) {
          dataLabels[10] = 'OTROS';
          dataLabels.length = 11;
        }
        /*If que da la opcion para generar un Otros mas un valor a mostrar en la barra y a marcar en eje x*/        
        if (dataValues.length >= 11){ 
            dataValues[10] = dataValues[0]-1;
            sum += dataValues.slice(10).reduce((acumulador, valorActual) => acumulador + valorActual, 0);
            dataValues.length = 11; 
        }
        /*Se realiza reversa a arrays dataLabels y dataValues al momento de mostrar valores en grafico, los muestre de mayor a menor y Otros a la ultima barra */
        this.dataLabels = dataLabels.reverse();
        this.dataValues = dataValues.reverse();
        this.valor = sum;
        this.hasData = true;
        this.updateChartData();
      } catch (error) {
        console.error('Error al obtener los datos:', error);
        this.hasData = false;
      }
    },
    updateChartOptions() {
      if (this.chart) {
        const isMobile = window.innerWidth < 768;
        this.chart.setOption({
          legend: {
            orient: isMobile ? 'horizontal' : 'vertical',
            right: isMobile ? 'auto' : 20,
            left: isMobile ? 'center' : 'auto',
            top: isMobile ? 'bottom' : 'left',
            data: this.dataLabels
          }
        });
      }
    },
    updateChartData() {
      if (this.chart) {

        const option = {
          title: {
            left: 'center'
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'shadow'
            },
            backgroundColor: 'rgba(50, 50, 50, 0.8)',
            borderColor: 'rgba(100, 100, 100, 0.8)',
            borderWidth: 1,
            padding: [10, 15, 10, 15],
            textStyle: {
              color: '#fff',
              fontSize: 14
            },
            formatter: params => {
              let html = `<div>${params[0].name}</div>`;
              params.forEach((item, index) => {
                html += `
                  <div style="display: flex; justify-content: space-between;">
                    <span>series-${index + 1}: ${item.value}</span>
                  </div>
                `;
              });
              return html;
            }
          },
          legend: {
            data: this.dataLabels
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'value',
            name: 'Cantidad',
            nameLocation: 'middle',
            nameGap: 30
          },
          yAxis: {
            type: 'category',
            data: this.dataLabels,
            name: 'Materia',
            nameLocation: 'end',
            nameGap: 30
          },
          series: [
            {
              type: 'bar',
              barWidth: '60%',
              data: this.dataValues,
              label: {
                show: true,
                position: 'inside',
                formatter: params => {
                  if ((params.dataIndex === 0)&&(this.valor!==0)) return this.valor;
                  return params.value;
                }
              }
            }
          ]
        };

        this.chart.setOption(option);
      }
    }
  }
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
}
.chart-container {
  position: relative;
  height: 100vh;
  overflow: hidden;
}

@media (max-width: 768px) {
  .chart-container {
    height: 60vh;
  }
}

@media (max-width: 480px) {
  .chart-container {
    height: 50vh;
  }
}

@media (max-width: 180px) {
  .chart-container {
    height: 40vh;
  }
}
</style>