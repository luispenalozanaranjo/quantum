<template>
    <div>
        <!-- NAVBAR -->
        <v-app-bar 
            app
            hide-on-scroll short flat 
            class="pjud">
            <v-app-bar-nav-icon color="white" @click="drawer = !drawer">
                <!-- <font-awesome-icon  icon="align-justify" size="2x" class="white--text"/> -->
            </v-app-bar-nav-icon>
           <v-spacer></v-spacer>
            <v-menu offset-y>
                <template v-slot:activator="{ on, attrs }">
                        <v-btn color="#5461a9" dark icon v-bind="attrs" v-on="on">
                            <font-awesome-icon icon="ellipsis-v" size="1x" class="white--text"/> 
                        </v-btn>
                </template>
                <v-list>
                    <v-list-item>
                        <v-list-item-title>
                            <v-btn color="white" :href="this.logout" style="text-decoration:none">Salir</v-btn>    
                        </v-list-item-title>
                    </v-list-item>
                </v-list>
            </v-menu>
        </v-app-bar>
        
        <!-- SIDEBAR -->
        <v-navigation-drawer 
            app
            left
            v-bind:style="sidebar"
            v-model="drawer"     
            >
               <v-layout>
                      <v-flex>
                           <img src="../../public/img/Poder Judicial.png" alt="Poder Judicial" class="mt-4 ml-16"/>
                      </v-flex>
                </v-layout>
                <v-divider></v-divider>
                <v-list subheader>
                        <v-list-item-title class="text-h6 white--text ml-6 mt-2" >QUANTUM TABLERO</v-list-item-title>
                        <v-list-group prepend-icon="" v-for="list in li" :key="list.nombre" no-action class="borderli">
                            <template v-slot:activator>
                                <v-list-item-icon class="mr-1">
                                    <v-icon  color="white" large>{{list.icono}}</v-icon>
                                </v-list-item-icon>
                                <v-list-item-title class="white--text ml-4">{{list.nombre}}</v-list-item-title>
                            </template>
                            <v-list-item class="pl-6" v-for="menu in menus[list.id]" :key="menu.nombre" link>
                                    <v-list-item-icon class="mr-2">
                                        <font-awesome-icon  :icon="menu.icono" size="1x" class="dotcolor"/>
                                    </v-list-item-icon>
                                    <v-list-item-content>
                                        <router-link class="white--text" style="text-decoration:none;" :to="menu.link" >{{menu.nombre}}</router-link>
                                    </v-list-item-content>
                            </v-list-item>
                        </v-list-group>
                </v-list>
        </v-navigation-drawer>
    </div>
</template>

<script>
import Vue from 'vue'
import AppVue from '../App_old.vue'
import store from 'store'
import { url } from '../config/api'
import { quantum } from '../config/quantum'

export default {
    name: "Sidebar",
    data(){
        return{
            login:  store.get('user_login'),
            drawer: true,
            active: true,
            li: [],
            menus: [],
            logout: ''
        };
    },
    created () {
        this.logout = quantum + '/home/logout' 
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        this.setActive(this.active())
        }
    },
    methods: {
        salir: function(){
            window.location.href= this.logout;
        }
    },
    watch: 
    {
        $route (to, from) 
        {
            let llave = to.fullPath.substring(1)
            llave = llave.substring(0, llave.indexOf('/'))
            if (this.li.length === 0) {
                const axios = require('axios')
                const urlpermissions = url + '/configuraciones/permisos'
                const get = async urlpermissions => {
                try {
                    const response = await axios.get(urlpermissions, {
                        params: {
                            llave: llave
                        }
                    })

                    const data = response.data
                    let obj = data.recordset.filter(element => element.id_permiso === data.recordset[0].id &&  element.llave == '')
                    
                    obj.forEach(type => {
                        this.li.push({ id: type.id, nombre: type.nombre, icono: type.icono }) // Creo el primer nivel del menu
                        this.menus[type.id] = [] // Inserto el arreglo y la posición
                        let opc = data.recordset.filter(element => element.id_permiso === type.id)
                        opc.forEach(typeTwo => {
                            this.menus[type.id].push({ nombre: typeTwo.nombre, link: typeTwo.llave, icono: typeTwo.icono })
                        })
                    })
                } catch (error) {
                    console.log(error)
                }
                }
                get(urlpermissions)
            }
        }
    },
    computed: {
        sidebar() {
            return {
              'backgroundImage': `url(${require('../../public/img/Sidebar/sidebar-04.jpg')})`,
              'background-color': '#fff',
              'background-size': '260px 100vh'              
            };
        }
    }    
}
</script>
<style>
.white{
    color: #fff;
}

.user_avatar{
    width:65px;
    border:1px solid #eee;
    background:#fff;
    padding:5px;
    border-radius:50%;
   
}

.amarillo{
    color: #F4F000;
}

.dotcolor{
    color: #E8E7E7;
}

.MenuIconColor{
    color: #007bff;
}

.borderli{
    border-bottom: 1px solid #f8f8f8;
    border-bottom-width: 1px;
    border-bottom-style: solid;
    border-bottom-color: #EFEFEF;
}
</style>