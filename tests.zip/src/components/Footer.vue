<template>
    <footer class="" style="position: relative;
                   bottom: 0;
                   width: 100%;
                   height: 40px;
                   line-height: 40px;
                   background: #fff;
                   border-top: 1px solid #D9DEE4;">
        <p>Poder Judicial</p>
    </footer>
</template>
<script>
import Vue from 'vue'
export default {
  name: 'Footer',
  data () {
    return {

    }
  }
}
</script>
