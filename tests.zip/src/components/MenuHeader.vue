<template>
	<div>
		<v-app-bar
			app
			hide-on-scroll short flat
			class="pjud"
			>
			<v-app-bar-nav-icon color="white" @click="drawer = !drawer">
			</v-app-bar-nav-icon>
			<v-spacer></v-spacer>
			<v-menu
				left
				bottom
				>
				<template v-slot:activator="{ on, attrs }">
					<v-btn
						icon
						v-bind="attrs"
						v-on="on"
						>
						<v-icon color="white">mdi-dots-vertical</v-icon>
					</v-btn>
				</template>
				<v-list dense>
					<!-- <v-list-item
						v-for="n in 5"
						:key="n"
						@click="() => {}"
						>
						<v-list-item-title>Opciones {{ n }}</v-list-item-title>
					</v-list-item> -->
						<v-list-item to="/CambiarContrasena" link>
							<v-list-item-content>
								<v-list-item-title>Cambiar contraseña</v-list-item-title>
							</v-list-item-content>
						</v-list-item>
						<v-list-item to="/Login" link>
							<v-list-item-content>
								<v-list-item-title>Salir</v-list-item-title>
							</v-list-item-content>
						</v-list-item>
				</v-list>
			</v-menu>
		</v-app-bar>
		<v-navigation-drawer
			app
			left
			v-bind:style="sidebar"
			v-model="drawer"
			>
			<v-layout>
				<v-flex>
					<img src="../../public/img/Poder Judicial.png" alt="Poder Judicial" class="mt-4 ml-16"/>
				</v-flex>
			</v-layout>
			<v-list>
				<v-list-item link>
					<v-list-item-content>
						<v-list-item-title class="text-h6 white--text ml-8" >
							{{ usuario.nombre_completo }}
						</v-list-item-title>
						<v-list-item-subtitle class="white--text ml-14">{{ usuario.email }}</v-list-item-subtitle>
					</v-list-item-content>
				</v-list-item>
			</v-list>
			<v-divider></v-divider>
			<v-list
				nav
				dense
				class="white--text" 
				>
				<div>
					<v-list-item  link :to="{ name: 'Home' }" >
						<v-list-item-icon>
							<v-icon color="white">mdi-home</v-icon>
						</v-list-item-icon>
						<v-list-item-title class="white--text">
							Inicio
						</v-list-item-title>
					</v-list-item>					
				</div>
				<div v-for="(item) in rolesList" link :key="item._id">
					<v-list-group v-if="!item.enlace">
						<template #appendIcon >
							<v-icon color="white">mdi-chevron-down</v-icon>
						</template>								
						<template v-slot:activator>
							<v-list-item-icon>
								<v-icon :color="item.color">{{ item.icon }}</v-icon>
							</v-list-item-icon>
							<v-list-item-title class="white--text">
								{{ item.descripcion }}
							</v-list-item-title>
						</template>
						<v-list-item v-for="(itemTwo) in item.accesos" :key="itemTwo._id" :to="{ name: itemTwo.enlace }">
							<v-list-item-icon>
								<v-icon :color="itemTwo.color">{{ itemTwo.icon }}</v-icon>
							</v-list-item-icon>
							<v-list-item-title class="white--text">
								{{ itemTwo.descripcion }}
							</v-list-item-title>
						</v-list-item>			
					</v-list-group>
					<v-list-item v-else link :key="item._id" :to="{ name: item.enlace }">
						<v-list-item-icon>
							<v-icon :color="item.color">{{ item.icon }}</v-icon>
						</v-list-item-icon>
						<v-list-item-title class="white--text">
							{{ item.descripcion }}
						</v-list-item-title>
					</v-list-item>
				</div>
			</v-list>
		</v-navigation-drawer>
	</div>
</template>
<script>
import axios from 'axios'
import { url } from '../config/apiConfig'
import store from 'store'
export default {
  	name: 'MenuHeader',
    props: { 
        path: {
            Object,
            default: () => {}
        }
    },	  
	data: () => ({
	mini: true,
		usuario: {
			usuario: store.get('usuario'),
			nombre_completo: store.get('nombre_completo'),
			email: store.get('email')
		},
		drawer: true,
		clipped: true,
		navDraw: true,
		rolesList: [
			{
				Object,
				default: () => {}
			}
		]
	}),
    watch: {
        path: async function () {
            this.rolesList =  await this.getPermissionUser(this.usuario.usuario, this.path)
        }
    },	
	methods: {
		async getPermissionUser (usuario, path) {
			return new Promise(async function(resolve, reject) {
				try {
					let response = await  axios({
						method: 'POST',
						url: url+'/permit/getPermissionUser',
						headers: {},
						data:{
							usuario: usuario,
							path: path
						}
					})
					resolve(response.data.permitUser)
				} catch (err) {
					reject(err)
				}
			})
		},
		goViews(nombreView){
			try {
				this.$router.push(nombreView);
			} catch (error) {
				console.log(error);
			}
		},
  	},	  
	components: {
	// MenuLeft
	},
	computed: {
		sidebar() {
			return {
				'backgroundImage': `url(${require('../../public/img/Sidebar/sidebar-04.jpg')})`,
				'background-color': '#fff',
				'background-size': '260px 100vh',
				'box-shadow': '2px 10px 30px 0 rgba(0,0,0,.42),0 4px 25px 0 rgba(0,0,0,.12),0 8px 10px -5px rgba(0,0,0,.2)'           
			};
		}
	}    
};
</script>