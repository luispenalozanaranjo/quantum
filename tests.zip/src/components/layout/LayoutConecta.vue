<template>
    <v-row dense>
        <v-col xs12 cols="12"> 
            <v-banner
                single-line
            >
                {{gls_tribunal}}
                <template v-slot:actions>
                        <!-- <v-btn
                            class="mx-2"
                            fab
                            dark
                            small
                            color="red"
                        >
                            <v-icon >mdi-file-pdf-box</v-icon>
                        </v-btn> -->
                        <v-btn
                            class="mx-2"
                            fab
                            dark
                            small
                            color="success"
                            @click="getJob"
                        >
                            <v-icon >mdi-microsoft-excel</v-icon>
                        </v-btn>                        
                    <date-picker 
                        v-model="dateRange"  
                        range
                        :format="DatePickerFormat"
                        :shortcuts="shortcuts"
                        placeholder="Fecha de Atenciones"
                    >
                    <!-- :disabled-date="(date) => date <= new Date(new Date().setDate(new Date().getDate() - 1))" -->
                    </date-picker>                 
                    <v-btn  color="success" href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                </template>
            </v-banner>       
        </v-col>
        <ModalLoading />
    </v-row>
</template>

<script>
import { url } from '../../config/api'
import store from 'store'
import axios from 'axios'
import DatePicker from 'vue2-datepicker'
import 'vue2-datepicker/index.css'
import 'vue2-datepicker/locale/es'
import ModalLoading from '../../components/elementos/ModalLoading'
import moment from 'moment-timezone'
import { mapState, mapMutations } from 'vuex'
export default {
    name: "LayoutConecta",
    data(){
        return{
            dateRange: this.$attrs.dateRange,
            mensaje: '',
            DatePickerFormat: 'DD/MM/YYYY',            
            shortcuts: [
                {
                    text: 'Hoy',
                    onClick() {
                        const date = new Date();
                        // return a Date
                        return date;
                    }
                },
                {
                    text: 'Ayer',
                    onClick() {
                        const date = new Date();
                        date.setTime(date.getTime() - 3600 * 1000 * 24);
                        return date;
                    }
                },
                {
                    text: '7 atras',
                    onClick() {
                        const date = new Date();
                        date.setTime(date.getTime() - 3600 * 1000 * 24);
                        return date;
                    }
                },
                {
                    text: '30 atras',
                    onClick() {
                        const date = new Date();
                        date.setTime(date.getTime() - 3600 * 1000 * 24);
                        return date;
                    }                             
                }
            ],
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto')
            },
            gls_tribunal: ''
        }
    },
    watch: {
        dateRange:{
            handler: function (val, oldVal) {
                this.$emit('clicked', this.dateRange)
            }
        }
    },    
    created(){
        this.getTribunal() // Consulta Tribunal 
    },
    methods:{
        ...mapMutations(['setModal']), // Mutations para Visualizar el modal de obteniendo Informacion
        getTribunal(){
            try {
                const axios = require('axios')
                const req1 = url + '/configuraciones/getTribunal'

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal
                            }
                                        
                        })
                        
                        const data = response.data
                        this.gls_tribunal = ''

                        Object.values(data.recordset).map((type) => {
                            this.gls_tribunal = type.gls_tribunal
                        })


                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

            } catch (error) {
                console.log(error)
            }
        },
        async getJob(){
            this.setModal(true) // Aqui Manipulamos el modal
            let parseString = require('xml2js').parseString;
            let username = 'admin';
            let password = 'password';
            let credentials = btoa(username + ':' + password)
            const response = await axios({
                    method: 'GET',
                    url: 'http://vmetlbi.cadm.pjud:9081/pentaho/kettle/executeJob/?job=/Sebastian/Jobs/Conecta/Familia_Excel_Comunicaciones',
                    headers: {
                        'Authorization': 'Basic '+credentials,
                        'Accept': 'application/xml'
                    },
                    params:{
                        rep:'pentaho_docker',
                        user:'admin',
                        pass:'admin',
                        cod_corte: this.user.cod_corte,
                        cod_tribunal: this.user.cod_tribunal,
                        fecha_inicio: moment(this.dateRange[0]).format('YYYY-MM-DD'),
                        fecha_termino: moment(this.dateRange[1]).format('YYYY-MM-DD'),
                        usuario_id: this.user.usuario_id
                    }
                })
            parseString(response.data, async (err, result) => {

                let stateJobs = await this.$interval(result.webresult.id[0], this.state)
                if(stateJobs === 'Finished'){
                    this.download()
                }else{
                    this.setModal(false) // Cerrando Modal
                    console.log(err)
                }
            })                             
        },
        async download(){
            const req1 = url + '/familia/familiaConectaAtencionesDescargar'
            await  axios({
                method: 'GET',
                url: req1,
                params:{
                    usuario_id: this.user.usuario_id,
                    fechaInicio: moment(this.dateRange[0]).format('YYYY-MM-DD'),
                    fechaTermino: moment(this.dateRange[1]).format('YYYY-MM-DD'),
                },
                responseType: 'arraybuffer'   
            }).then((response) => {
                let blob = new Blob([response.data], { 
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                }),
                url = window.URL.createObjectURL(blob)
                this.setModal(false) // Cerrando Modal
                window.open(url);                 
            })
        },
        async state (id) {
            return new Promise(async function(resolve, reject) {
                try {
                    let parseString = require('xml2js').parseString;            
                    let username = 'admin';
                    let password = 'password';
                    let credentials = btoa(username + ':' + password)

                    let response = await  axios({
                            method: 'GET',
                            url: 'http://vmetlbi.cadm.pjud:9081/pentaho/kettle/jobStatus?name=Familia_Excel_Comunicaciones',
                            headers: {
                                'Authorization': 'Basic '+credentials,
                                'Accept': 'application/xml'
                            },
                            params:{
                                xml: 'y',
                                id: id
                            }      
                    })
                    parseString(response.data, (err, result) => {
                        resolve(result.jobstatus.status_desc[0])
                    })                    
                } catch (error) {
                   this.setModal(false) // Cerrando Modal
                   reject(error) 
                }
            })
        }
    },
    components:{
        DatePicker,
        ModalLoading
    }
}

</script>