<template>
    <v-row>
        <v-col xs="12" sm="12" md="4" xl="4" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="2">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-checkbox-marked-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="10">
                    <countTo
                        class="count headline"
                        :startVal="0"
                        :endVal="totalResoluciones"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>TOTAL RESOLUCIONES {{ anoInforme}}</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col  xs="12" sm="12" md="4" xl="4" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="2">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-checkbox-marked-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="10">
                    <countTo
                        class="count headline"
                        :startVal="0"
                        :endVal="totalResolucionesAnterior"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>TOTAL RESOLUCIONES {{ anoInforme - 1}}</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col  xs="12" sm="12" md="4" xl="4" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="2">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-chart-timeline-variant
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="10">
                    <countTo
                        class="count headline"
                        :startVal="0"
                        :endVal="crecimiento"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <span class="headline">%</span>
                    <br/>
                    <span>% CRECIMIENTO</span>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es');

export default {
    name: 'totalResolucionesJurisdiccional',
    data() {
        return {
            totalResoluciones: 0,
            totalResolucionesAnterior: 0,
            crecimiento: 0,
        }
    },
    created() {
        try {
            this.getTotales();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getTotales(){
            try {
                
                const req = urlJurisdiccional + '/resoluciones_anual_competencia';

                const getResoluciones = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia
                    },
                });

                if (getResoluciones.status == 200) {

                    if(this.incluirExhortoJurisdiccional()){
                        this.totalResoluciones = getResoluciones.data.data.resoluciones[0].cantidad; 
                        this.totalResolucionesAnterior = getResoluciones.data.data.resoluciones_ant[0].cantidad; 
                    }else {
                        this.totalResoluciones = getResoluciones.data.data.resoluciones[0].cantidad_se; 
                        this.totalResolucionesAnterior = getResoluciones.data.data.resoluciones_ant[0].cantidad_se; 
                    }

                    this.crecimiento = Math.round((((this.totalResoluciones - this.totalResolucionesAnterior)*100)/ this.totalResolucionesAnterior),2);


                } else {
                    console.log(getResoluciones.data.observacion);
                }

            } catch (error) {
                console.log(error.message);
            }
        }

    },
    components:{
        countTo,
    },
    props:{
        id_competencia: {
            type: Number,
            required: true
        },
        anoInforme: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        }
    },
    watch:{
        'anoInforme'(){
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message)
            }
        },
        '$store.state.incluirExhortoJurisdiccional'() {
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message);
            }
        },
    }
}
</script>
<style scoped>

    .info-box {
        background: #fff;
        padding: 30px 30px 30px 20px;
        border-right: 1px solid #e5ebec;
        border-bottom: 1px solid #e5ebec;
    }

    .info-box .icoleaf {
        display: inline-block;
        width: 55px;
        height: 55px;
        padding: 9px 8px;
        font-size: 28px;
        border-top-left-radius: 50%;
        border-bottom-left-radius: 50%;
        border-bottom-right-radius: 50%;
    }
</style>
