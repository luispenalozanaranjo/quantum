<template>
    <v-row align="center">
        <v-col class="info-box">
            <apexchart
                type="line"
                height="350"
                :options="pieChartOptionsLine"
                :series="pieSeriesLine"
                :ref="idGrafico"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoResolucionesJurisdiccional',
    data() {
        return {
            totalresoluciones: 0,
            totalresolucionesAnterior: 0,
            idGrafico: 'lineChartresoluciones' + this.id_competencia.toString(),
            window: 0,
            length: 2,
            pieSeriesLine: [],
            pieChartOptionsLine: {
                chart: {
                    id: 'lineChartresoluciones'+ this.id_competencia.toString(),
                    height: 350,
                    type: 'line',
                    // group: 'resoluciones',
                    zoom: {
                        enabled: false,
                    },
                },
                title: {
                    text: 'resoluciones',
                    align: 'left',
                },
                colors: ['#2E93fA', '#E91E63', '#546E7A', '#FF9800','#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff', '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080', '#330e0e', '#000000'],
                noData: {
                    text: 'Visualizando'
                },   
                dataLabels: {
                    enabled: false,
                },
                stroke: {
                    width: [5, 5,],
                    curve: 'smooth',
                },
                legend: {
                    position: 'right',
                    offsetY: 50, 
                },
                markers: {
                    size: 3,
                    hover: {
                        sizeOffset: 6,
                    },
                },
                grid: {
                    borderColor: '#f1f1f1',
                },
                xaxis: {
                    categories: [
                        'Ene',
                        'Feb',
                        'Mar',
                        'Abr',
                        'May',
                        'Jun',
                        'Jul',
                        'Ago',
                        'Sep',
                        'Oct',
                        'Nov',
                        'Dic',
                    ],
                },
                yaxis: {
                    labels: {
                        minWidth: 34
                    }
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            this.getResoluciones()
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getResoluciones() {
            try {
                const req = urlJurisdiccional + '/resoluciones_mensuales_competencia'
                const req2 = urlJurisdiccional + '/resoluciones_mensuales_jueces'

                let seriesAux = [];
                let seriesAuxSE = [];

                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return

                const getResoluciones = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia,
                    },
                })

                const getResolucionesJueces = await axios.get(req2, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia,
                    },
                })

                //RESOLUCIONES ANUALES
                if (getResoluciones.status == 200) {
                    //con exhortos
                    seriesAux = [
                        {
                            name: getResoluciones.data.data.resoluciones[0]._id.ano.toString(),
                            data: [
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 1) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 1).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 2) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 2).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 3) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 3).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 4) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 4).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 5) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 5).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 6) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 6).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 7) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 7).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 8) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 8).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 9) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 9).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 10) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 10).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 11) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 11).cantidad,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 12) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 12).cantidad,
                            ],
                        },
                        {
                            name: getResoluciones.data.data.resoluciones_ant[0]._id.ano.toString(),
                            data: [
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 1) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 1).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 2) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 2).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 3) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 3).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 4) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 4).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 5) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 5).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 6) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 6).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 7) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 7).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 8) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 8).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 9) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 9).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 10) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 10).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 11) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 11).cantidad,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 12) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 12).cantidad,
                            ],
                        },
                    ];
                    //sin exhortos
                    seriesAuxSE = [
                        {
                            name: getResoluciones.data.data.resoluciones[0]._id.ano.toString(),
                            data: [
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 1) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 1).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 2) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 2).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 3) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 3).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 4) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 4).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 5) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 5).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 6) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 6).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 7) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 7).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 8) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 8).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 9) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 9).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 10) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 10).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 11) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 11).cantidad_se,
                                getResoluciones.data.data.resoluciones.find(element => element._id.mes == 12) == undefined ? 0 : getResoluciones.data.data.resoluciones.find(element => element._id.mes == 12).cantidad_se,
                            ],
                        },
                        {
                            name: getResoluciones.data.data.resoluciones_ant[0]._id.ano.toString(),
                            data: [
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 1) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 1).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 2) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 2).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 3) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 3).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 4) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 4).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 5) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 5).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 6) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 6).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 7) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 7).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 8) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 8).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 9) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 9).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 10) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 10).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 11) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 11).cantidad_se,
                                getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 12) == undefined ? 0 : getResoluciones.data.data.resoluciones_ant.find(element => element._id.mes == 12).cantidad_se,
                            ],
                        },
                    ];


                } else {
                    console.log(getResoluciones.data.observacion)
                }

                //RESOLUCIONES JUECES
                if(getResolucionesJueces.status == 200){
                    //con exhortos
                    getResolucionesJueces.data.resolucionesJueces.forEach(resJuez => {
                        seriesAux.push(resJuez);
                    });

                    //sin exhortos
                    getResolucionesJueces.data.resolucionesJuecesSE.forEach(resJuez => {
                        seriesAuxSE.push(resJuez);
                    });

                }else {
                    console.log(getResolucionesJueces.data.observacion)
                }

                //UPDATE DATA AL GRAFICO
                ApexCharts.exec(this.idGrafico, "updateOptions", {
                    yaxis: {
                        labels: {
                            formatter: function(value) {
                                if (value >= 1000){
                                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return value;
                                }
                            }
                        }
                    },
                    dataLabels: {
                        formatter: function(value) {
                            if (value >= 1000){
                                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                            } else {
                                return value;
                            }
                        }
                    }
                });

                if(this.incluirExhortoJurisdiccional()){
              
                    ApexCharts.exec(
                        this.idGrafico,
                        'updateSeries',
                        seriesAux,
                        true
                    );


                }else {

                    ApexCharts.exec(
                        this.idGrafico,
                        'updateSeries',
                        seriesAuxSE,
                        true
                    );

                }



            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getResoluciones()
            } catch (error) {
                console.log(error.message)
            }
        },
        '$store.state.incluirExhortoJurisdiccional'() {
            try {
                this.getResoluciones();
            } catch (error) {
                console.log(error.message);
            }
        },
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
