<template>
    <v-row align="center">
        <v-col class="info-box">
            <apexchart
                type="bar"
                height="350"
                :options="pieChartOptionsBar"
                :series="pieSeriesBar"
                :ref="idGrafico"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoPresupuestos',
    data() {
        return {
            totalIngresos: 0,
            totalIngresosAnterior: 0,
            idGrafico: 'barChartPresupuestos',
            window: 0,
            length: 2,
            pieSeriesBar: [],
            pieChartOptionsBar: {
                chart: {
                    id: 'barChartPresupuestos',
                    height: 500,
                    type: 'bar',
                    stacked: false,
                    toolbar:{
                        show: false
                    }
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        dataLabels: {
                            position: 'top', // top, center, bottom
                        },
                    }
                },
                dataLabels: {
                    enabled: true,
                    offsetY: -20,
                    style: {
                        fontSize: '12px',
                        colors: ["#304758"]
                    }
                },
                yaxis: {
                    title: {
                        text: "Millones",
                    }
                },
                fill: {
                    opacity: 1
                },
                title: {
                    text: 'Presupuesto Asignado Ultimos años',
                    align: 'center',
                },
                legend: {
                    show: true,
                    showForSingleSeries: true,
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            this.getIngresos()
        } catch (error) {
            console.log(error)
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getIngresos() {
            try {
                let seriesBar = [];
                let anios = []
                const req = urlJurisdiccional + '/presupuestos';

                const response  = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                if (response.status == 200) {
                    seriesBar.push({
                        name: "Montos Asignados por Año",
                        data:[]
                    });

                    seriesBar.forEach(serie => {
                        response.data.data.presupuestos.forEach(type => {
                            serie.data.push({
                                x: 'type.ano',
                                y: (type.monto_asignado > 0) ? type.monto_asignado : type.monto_utilizado,
                            });
                            anios.push(type.ano);
                        });

                    });

                    ApexCharts.exec('barChartPresupuestos', "updateOptions", {
                        legend:{
                            customLegendItems: ["Montos Asignados por Año"]
                        },
                        yaxis: {
                            title: {
                                text: "Millones",
                            },
                            labels: {
                                formatter: function(value) {
                                    if (value >= 1000){
                                        return '$' + value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                    } else {
                                        return '$' + value;
                                    }
                                }
                            }
                        },
                        dataLabels: {
                            formatter: function(value) {
                                if (value >= 1000){
                                    return '$' + value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return '$' + value;
                                }
                            }
                        },
                        xaxis: {
                            categories: anios,
                            type: 'category',
                            labels: {
                                showDuplicates: false,
                            }
                        }
                    });

                    //UPDATE GRAFICO
                    ApexCharts.exec(
                        'barChartPresupuestos',
                        'updateSeries',
                        seriesBar,
                        true
                    );

                } else {
                    console.log(response.data)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true
        }
    },
    watch: {
        anoInforme() {
            try {
                this.getIngresos();
            } catch (error) {
                console.log(error.message)
            }
        },
        cod_tribunal() {
            try {
                this.getIngresos();
            } catch (error) {
                console.log(error.message)
            }
        }
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
