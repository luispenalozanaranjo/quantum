<template>
    <v-row>
        <v-col xs="12" sm="12" md="3" xl="3" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-currency-usd-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="monto_asignado"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>Presupuesto Asignado</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col xs="12" sm="12" md="3" xl="3" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-currency-usd-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="monto_utilizado"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>Presupuesto Utilizado</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col xs="12" sm="12" md="3" xl="3" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-chart-timeline-variant
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="utilizado"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>% Utilizado</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col xs="12" sm="12" md="3" xl="3" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-currency-usd-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="crecimiento"
                        separator="."
                        :duration="1000"
                         :decimals="2"
                    ></countTo>%
                    <br/>
                    <span>% Crecimiento {{this.anoInforme}}</span>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es');

export default {
    name: 'TotalPresupuestos',
    data() {
        return {
            totalIngresos: 0,
            totalIngresosAnterior: 0,
            competencia_id: 0,
            monto_asignado: 0,
            monto_asignado_ant: 0,
            monto_utilizado: 0,
            crecimiento: 0,
            utilizado: 0,
        }
    },
    created() {
        try {
            this.getTotales();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getTotales(){
            try {
                
                const req = urlJurisdiccional + '/presupuestos';

                const response  = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                if (response.status == 200) {
                    const arreglo = []
                        Object.values(response.data.data.presupuestos).map((type) => {
                            if (type.ano == (this.anoInforme) -1 ) {
                                this.monto_asignado_ant = type.monto_asignado
                            }

                            // this.monto_asignado = type.monto_asignado
                            this.monto_utilizado = type.monto_utilizado
                            this.monto_asignado = (type.monto_asignado > 0) ? type.monto_asignado : type.monto_utilizado    

                            this.calcularPromedio(type.monto_utilizado, this.monto_asignado)
                        })

                        this.calcularCrecimiento(this.monto_asignado, this.monto_asignado_ant)

                } else {
                    console.log(response.data);
                }

            } catch (error) {
                console.log(error.message);
            }
        },
        calcularCrecimiento (monto_asignado, monto_asignado_ant) {
            this.crecimiento = (((monto_asignado - monto_asignado_ant) * 100) / monto_asignado_ant) 
            return this.crecimiento
        },
        calcularPromedio (monto_utilizado, monto_asignado) {
            this.utilizado = ((monto_utilizado * 100) / monto_asignado)
            return this.utilizado
        },
        

    },
    components:{
        countTo,
    },
    props:{
        anoInforme: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        },
        cod_corte: {
            type: Number,
            required: true
        }
    },
    watch:{
        anoInforme(){
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message)
            }
        },
        cod_tribunal(){
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message)
            }
        }
    }
}
</script>
<style scoped>

    .info-box {
        background: #fff;
        padding: 30px 30px 30px 20px;
        border-right: 1px solid #e5ebec;
        border-bottom: 1px solid #e5ebec;
    }

    .info-box .icoleaf {
        display: inline-block;
        width: 55px;
        height: 55px;
        padding: 9px 8px;
        font-size: 28px;
        border-top-left-radius: 50%;
        border-bottom-left-radius: 50%;
        border-bottom-right-radius: 50%;
    }
</style>
