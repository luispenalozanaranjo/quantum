<template>
    <v-row>
        <v-col md="12" class="whiteBox">
            <v-row>
                <v-col md="12">
                    <v-textarea
                        outlined
                        name="txtObservacion"
                        v-model="txtValue"
                        label="Observación"
                        :clearable="validaEstado == 1"
                        clear-icon="mdi-close-circle"
                        :readonly="validaEstado != 1"
                    ></v-textarea>

                    <v-checkbox
                        v-model="chkSinObs"
                        :disabled="validaEstado != 1"
                        label="Sin observación"
                        color="indigo darken-3"
                        class="mt-0"
                        @change="
                            chkSinObs == true
                                ? (txtValue = 'Sin observación')
                                : (txtValue = textData)
                        "
                    ></v-checkbox>
                </v-col>
            </v-row>
            <v-row>
                <v-col>
                    <v-card flat>
                        <v-card-actions>
                            <v-btn
                                outlined
                                rounded
                                :class="
                                    validaEstado != 1
                                        ? 'mt-0'
                                        : 'green white--text mt-0'
                                "
                                :disabled="validaEstado != 1"
                                @click="guardarObservacion()"
                            >
                                <v-icon>
                                    mdi-content-save-outline
                                </v-icon>
                                Guardar
                            </v-btn>
                            <v-spacer></v-spacer>
                            <v-icon 
                                large
                                dark
                                color="orange"
                                class="mr-1"
                                >
                                    mdi-information-outline
                            </v-icon>
                            <b>{{ fromInfoText }}</b>
                        </v-card-actions>
                    </v-card>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <v-alert
                        dense
                        :type="typeAlert"
                        dismissible
                        v-model="alert"
                    >
                        {{ alertText }}
                    </v-alert>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import moment from 'moment-timezone'
import { urlJurisdiccional } from '../../../config/api'
import axios from 'axios'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'ObservacionesJurisdiccional',
    data() {
        return {
            txtValue: '',
            textData: '',
            typeAlert: 'success',
            fromInfoText: '',
            alertText: '',
            alert: false,
            validaEstado: 1,
            chkSinObs: false,
        }
    },
    created() {
        try {
            this.getObservacion();
            switch (this.formulario_id) {
                case 8:
                    this.fromInfoText = 'Información proveniente desde SIGPER'
                    break;
                case 6:
                    this.fromInfoText = 'Información proveniente desde Dpto. Finanzas CAPJ'
                    break;
                case 10:
                    this.fromInfoText = 'Información proveniente desde SIGPER'
                    break;
                default:
                    break;
            }
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['validaEnvioICA']),

        async guardarObservacion() {
            try {
                const req = urlJurisdiccional + '/obsingresos'

                if(this.cod_tribunal == 0){
                    this.alertText = 'Debe seleccionar un tribunal';
                    this.typeAlert = 'error';
                    this.alert = true;
                    setTimeout(() => (this.alert = false), 5000)
                    return;
                }

                const postObservacion = await axios.post(req, {
                    formulario_id: this.formulario_id,
                    competencia_id: this.id_competencia,
                    cod_corte: this.cod_corte,
                    cod_tribunal: this.cod_tribunal,
                    ano: this.anoInforme,
                    observacion: [
                        {
                            id: 1,
                            descripcion: this.txtValue,
                            estado_observacion_id: 1,
                        },
                    ],
                });

                if (postObservacion.status == 200) {
                    this.typeAlert = 'success'
                    this.alertText = 'Observación guardada correctamente'
                    this.alert = true
                } else {
                    this.typeAlert = 'error'
                    this.alertText = postObservacion.data.observacion
                    this.alert = true
                }

                setTimeout(() => (this.alert = false), 3000)
            } catch (error) {
                console.log(error.message)
            }
        },
        async getObservacion() {
            try {
                const req = urlJurisdiccional + '/observaciones_ica'

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: this.formulario_id,
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                    },
                });

                if (getObservacion.status == 200 || getObservacion.status == 304) {
                    getObservacion.data.data.observaciones.forEach(obs => {
                        this.textData = obs.observacion[0].descripcion
                        this.txtValue = this.textData
                        this.validaEstado =
                            obs.observacion[0].estado_observacion_id
                    });

                    if (getObservacion.data.data.observaciones.length == 0) {
                        this.textData = ''
                        this.txtValue = ''
                        this.validaEstado = 1
                    }

                    this.$emit('getObservacionSC', this.textData);


                } else {
                    console.log(getObservacion.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    props: {
        id_competencia: {
            type: Number,
            required: false,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
        formulario_id: {
            type: Number,
            required: true,
        },
        switchResfrescar: {
            type: Boolean,
            required: false,
            default: false
        },
    },
    watch: {
        cod_tribunal() {
            try {
                if(this.cod_tribunal != 0){
                    this.getObservacion()
                }
            } catch (error) {
                console.log(error.message)
            }
        },
        anoInforme() {
            try {
                if(this.cod_tribunal != 0){
                    this.getObservacion()
                }
            } catch (error) {
                console.log(error.message)
            }
        },
        switchResfrescar() {
            try {
                this.getObservacion()
            } catch (error) {
                console.log(error.message)
            }
        },
    },
}
</script>
<style scoped>
.info-box {
    background: #fff;
    padding: 10px 10px 10px 5px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}

.whiteBox {
    background: #fff;
}
</style>
