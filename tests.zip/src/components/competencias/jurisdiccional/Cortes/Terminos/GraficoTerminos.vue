<template>
    <v-row align="center">
        <v-col class="info-box">
            <apexchart
                type="line"
                height="350"
                :options="pieChartOptionsLine"
                :series="pieSeriesLine"
                :ref="idGrafico"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import { urlJurisdiccional } from '../../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoTerminosCorteIGJ',
    data() {
        return {
            totalterminos: 0,
            totalterminosAnterior: 0,
            idGrafico: 'lineChartTerminosCorte',
            window: 0,
            length: 2,
            pieSeriesLine: [],
            pieChartOptionsLine: {
                chart: {
                    id: 'lineChartTerminosCorte',
                    height: 350,
                    type: 'line',
                    zoom: {
                        enabled: false,
                    },
                },
                title: {
                    text: 'Terminos de Causas',
                    align: 'left',
                },
                colors: ['#2E93fA', '#E91E63', '#546E7A', '#FF9800','#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff', '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080', '#330e0e', '#000000'],
                noData: {
                    text: 'Visualizando'
                },   
                dataLabels: {
                    enabled: false,
                },
                stroke: {
                     width: [5, 5, 5, 5, 5, 5, 5, 5, 5],
                    curve: 'smooth',
                },
                legend: {
                    position: 'right',
                    offsetY: 100, 
                },
                markers: {
                    size: 3,
                    hover: {
                        sizeOffset: 6,
                    },
                },
                grid: {
                    borderColor: '#f1f1f1',
                },
                xaxis: {
                    categories: [
                        'Ene',
                        'Feb',
                        'Mar',
                        'Abr',
                        'May',
                        'Jun',
                        'Jul',
                        'Ago',
                        'Sep',
                        'Oct',
                        'Nov',
                        'Dic',
                    ],
                },
                yaxis: {
                    labels: {
                        minWidth: 34
                    }
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            if(this.cod_tribunal != 0){
                this.getTerminos()
            }
        } catch (error) {
            console.log(error)
        }
    },
    methods: {

        async getTerminos() {
            try {
                const req =
                    urlJurisdiccional + '/terminos_mensuales_competencia';
                let seriesAux = [];
                let seriesAuxSE = [];

                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return;

                const getTerminos = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia,
                    },
                });

                if (getTerminos.status == 200 || getTerminos.status == 304) {

                    //recorro competencias para cargar la data del ano actual
                    this.competencias.forEach(competencia => {
                        //compruebo si el tribunal posee dicha competencia
                        if(getTerminos.data.data.terminos.find(element => element._id.competencia_id == competencia.id) != undefined){
                            //agrego data
                            seriesAux.push(
                                {
                                    name: getTerminos.data.data.terminos[0]._id.ano.toString() + "("+competencia.competencia+")",
                                    data: [
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id).cantidad,
                                    ],
                                },      
                            );

                            seriesAuxSE.push(
                                {
                                    name: getTerminos.data.data.terminos[0]._id.ano.toString() + "("+competencia.competencia+")",
                                    data: [
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id).cantidad_se,
                                    ],
                                }, 
                            );
                        }
                    });

                    //recorro competencias para cargar la data del ano anterior
                     this.competencias.forEach(competencia => {
                        //compruebo si el tribunal posee dicha competencia
                        if(getTerminos.data.data.terminos_ant.find(element => element._id.competencia_id == competencia.id) != undefined){

                            seriesAux.push(
                                {
                                    name: getTerminos.data.data.terminos_ant[0]._id.ano.toString() + "("+competencia.competencia+")",
                                    data: [
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id).cantidad,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id).cantidad,
                                    ],
                                },      
                            );
                            
                            seriesAuxSE.push(
                                {
                                    name: getTerminos.data.data.terminos_ant[0]._id.ano.toString() + "("+competencia.competencia+")",
                                    data: [
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 1 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 2 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 3 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 4 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 5 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 6 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 7 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 8 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 9 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 10 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 11 && element._id.competencia_id == competencia.id).cantidad_se,
                                        getTerminos.data.data.terminos_ant.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id) == undefined ? 0 : getTerminos.data.data.terminos_ant.find(element => element._id.mes == 12 && element._id.competencia_id == competencia.id).cantidad_se,
                                    ],
                                },
                            );
                        }
                     });

                    //UPDATE GRAFICO
                    ApexCharts.exec(this.idGrafico, "updateOptions", {
                        yaxis: {
                            labels: {
                                formatter: function(value) {
                                    if (value >= 1000){
                                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                    } else {
                                        return value;
                                    }
                                }
                            }
                        },
                        dataLabels: {
                            formatter: function(value) {
                                if (value >= 1000){
                                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return value;
                                }
                            }
                        }
                    });
                    
                    if(this.incluirExhortoJurisdiccional){
                        ApexCharts.exec(
                            this.idGrafico,
                            'updateSeries',
                            seriesAux,
                            true
                        );
                    }else{
                        ApexCharts.exec(
                            this.idGrafico,
                            'updateSeries',
                            seriesAuxSE,
                            true
                        );
                    }



                } else {
                    console.log(getTerminos.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    computed:{
        ...mapState(['incluirExhortoJurisdiccional','competencias']),
    },
    watch: {
        anoInforme() {
            try {
                this.getTerminos();
            } catch (error) {
                console.log(error.message)
            }
        },
        incluirExhortoJurisdiccional() {
            try {
                this.getTerminos();
            } catch (error) {
                console.log(error.message);
            }
        },
        cod_tribunal(){
            try {
                this.getTerminos();
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
