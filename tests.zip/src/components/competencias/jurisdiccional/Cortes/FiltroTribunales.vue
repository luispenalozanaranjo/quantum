<template>
    <v-col md="4">
        <v-autocomplete
            v-model="tribunal"
            :items="tribunales"
            chips
            label="Selecciona un Tribunal"
            item-text="gls_tribunal"
            item-value="cod_tribunal"
            prepend-icon="mdi-city"
            background-color="#FFFFFF"
            color="#FFFFFF"
            rounded
            full-width
            dense
            no-data-text="Sin datos"
            @change="setCodTribunal(tribunal)"
        >
            <template v-slot:selection="data">
                <v-chip v-bind="data.attrs" :input-value="data.selected">
                    {{ data.item.gls_tribunal }}
                </v-chip>
            </template>
            <template v-slot:item="data">
                <template>
                    <v-list-item-content>
                        <v-list-item-title
                            v-html="data.item.gls_tribunal"
                        ></v-list-item-title>
                        <v-list-item-subtitle
                            v-html="data.item.competencias"
                        ></v-list-item-subtitle>
                    </v-list-item-content>
                    <v-list-item-avatar right>
                        <v-tooltip bottom :color="data.item.color">
                        <template v-slot:activator="{ on, attrs }">
                            <v-icon :color="data.item.color"           
                                    v-bind="attrs"
                                    v-on="on">
                                {{ data.item.avatar }}
                            </v-icon>
                        </template>
                        <span> {{ data.item.estado }}</span>
                        </v-tooltip>
                    </v-list-item-avatar>
                    <v-list-item-avatar right>
                        <v-tooltip bottom :color="data.item.colorCorte">
                        <template v-slot:activator="{ on, attrs }">
                            <v-icon :color="data.item.colorCorte"           
                                    v-bind="attrs"
                                    v-on="on">
                                {{ data.item.avatarCorte }}
                            </v-icon>
                        </template>
                        <span> {{ data.item.estadoCorte }}</span>
                        </v-tooltip>
                    </v-list-item-avatar>
                </template>
            </template>
        </v-autocomplete>
    </v-col>
</template>
<script>
import moment from 'moment-timezone'
import axios from 'axios'
import { mapMutations, mapState } from 'vuex'
import { url } from '../../../../config/apiConfig'
import { urlJurisdiccional } from '../../../../config/api'
import store from 'store'

moment.locale('es')

export default {
    name: 'FiltroTribunalesCortes',
    data() {
        return {
            switch1: true,
            tribunal: null,
            tribunales: [
                {
                    gls_tribunal: 'Corte de Apelaciones de Puerto Montt',
                    cod_tribunal: 90,
                    competencias: 'competencia',
                    avatar: 'mdi-microsoft-excel',
                    color: 'success'
                },
                {
                    gls_tribunal: 'gls_tribunal2',
                    cod_tribunal: 50,
                    competencias: 'competencia',
                    avatar: 'mdi-microsoft-excel',
                    color: 'success'
                },
            ],
        }
    },
    created() {
        try {
            if(this.cod_corte != 0 && this.yearInformeJurisdiccional != 0){
                //obtengo tribunales
                this.getTribunales();
                //seteo el tribunal seleccionado
                if(this.codTribunalIGJ != 0){
                    this.tribunal = this.codTribunalIGJ;
                }
            }
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapMutations(['setcodTribunalIGJ','setnombreTribunalIGJ']),

        async getTribunales() {
            try {
                this.tribunales = [];
                const req = url + '/tribunal/getCorteTribunales';
                const reqEstado = urlJurisdiccional + '/observacionesCorte';

                
                //requests
                const getUserConf = await axios.get(req, {  
                                                        params: {cod_corte: this.cod_corte}
                });

                const getEstado = await axios.get(reqEstado, {
                                                        params: {
                                                            ano: this.yearInformeJurisdiccional,
                                                            cod_corte: this.cod_corte
                                                        }
                });

                if ((getUserConf.status == 200 || getUserConf.status == 304) && (getEstado.status == 200 || getEstado.status == 304)) {

                    //Recorro tribunales
                    getUserConf.data.forEach(tribunal => {
                        let strCompetencias = '';
                        let strAuxCompetencias = '';
                        let strEstado = '';
                        let strEstadoCorte = '';
                        let paramsIcon = '';
                        let paramsIconCorte = '';
                        let color= '';
                        let colorCorte= '';
                        //Obtengo las competencias del tribunal
                        tribunal.competencia_data.forEach(competencia => {
                            if(competencia.descripcion != 'Civil'){
                                strAuxCompetencias += competencia.descripcion + ', ';
                            }
                            strCompetencias += competencia.descripcion + ', ';
                        });

                        //Quito ultima coma
                        strCompetencias = strCompetencias.substring(0,strCompetencias.length-2);
                        strAuxCompetencias = strAuxCompetencias.substring(0,strAuxCompetencias.length-2);

                        //Estado del tribunal que estoy cargando
                        let rowEstadoTribunal = getEstado.data.data.find(r => r.cod_tribunal == tribunal.cod_tribunal);

                        //Compruebo si el informe esta finalizado para marcarlo OK
                        if(rowEstadoTribunal != undefined){
                            if(rowEstadoTribunal.observacion.length > 0){

                                switch (rowEstadoTribunal.observacion[0].estado_observacion_id) {
                                    case 1:
                                        strEstado = 'Pendiente Adm. Tribunal';
                                        color = 'error';
                                        paramsIcon = 'mdi-circle-edit-outline';
                                        break;
                                    case 2:
                                        strEstado = 'Ok Adm. Tribunal';
                                        color = 'success';
                                        paramsIcon = 'mdi-checkbox-marked-circle-outline';
                                        break;
                                    case 3:
                                        strEstado = 'Pendiente Adm. Tribunal - Bloqueado';
                                        color = 'warning';
                                        paramsIcon = 'mdi-circle-edit-outline';
                                        break;
                                    default:
                                        strEstado = 'Pendiente Adm. Tribunal';
                                        color = 'error';
                                        paramsIcon = 'mdi-circle-edit-outline';
                                        break;
                                }

                                //Compruebo si la corte finalizo el informe
                                let estadoCorte = getEstado.data.data.find(r => r.cod_tribunal == tribunal.cod_tribunal && r.formulario_id == 15);

                                if(estadoCorte != undefined){
                                    
                                    switch (estadoCorte.estado_observacion_id) {
                                        case 1:
                                            strEstadoCorte = 'Pendiente Adm. Corte'
                                            paramsIconCorte = 'mdi-circle-edit-outline';
                                            colorCorte = 'error';  
                                            break;
                                        case 2:
                                            strEstadoCorte = 'Ok Adm. Corte';
                                            colorCorte = 'success';
                                            paramsIconCorte = 'mdi-checkbox-marked-circle-outline';
                                            break;
                                        case 3:
                                            strEstadoCorte = 'Pendiente Adm. Corte - Bloqueado';
                                            colorCorte = 'warning';
                                            paramsIconCorte = 'mdi-circle-edit-outline';
                                            break;
                                        default:
                                            strEstadoCorte = 'Pendiente Adm. Tribunal';
                                            colorCorte = 'error';
                                            paramsIconCorte = 'mdi-circle-edit-outline';
                                            break;
                                    }


                                }else{
                                    strEstadoCorte = 'Pendiente Adm. Corte'
                                    paramsIconCorte = 'mdi-circle-edit-outline';
                                    colorCorte = 'error';
                                    strEstadoCorte = 'Pendiente Adm. Corte';
                                    paramsIconCorte = 'mdi-circle-edit-outline';
                                    colorCorte = 'error';  
                                }
                                

                                
                            }else {
                                strEstado = 'Pendiente Adm. Tribunal';
                                color = 'error';
                                paramsIcon = 'mdi-circle-edit-outline';
                                strEstadoCorte = 'Pendiente Adm. Corte';
                                paramsIconCorte = 'mdi-circle-edit-outline';
                                colorCorte = 'error';  
                            }                           
                        }else{
                                strEstado = 'Pendiente Adm. Tribunal';
                                color = 'error';
                                paramsIcon = 'mdi-circle-edit-outline';
                                strEstadoCorte = 'Pendiente Adm. Corte'
                                paramsIconCorte = 'mdi-circle-edit-outline';
                                colorCorte = 'error';  
                        } 


                        //Agrego al array del componente excluyendo los tribunales que solo tienen de competencia CIVIL
                        if(strCompetencias != 'Civil')
                        {
                            this.tribunales.push({
                                gls_tribunal: tribunal.descripcion,
                                cod_tribunal: tribunal.cod_tribunal,
                                competencias: strAuxCompetencias,
                                avatar: paramsIcon,
                                color: color,
                                estado: strEstado,
                                estadoCorte: strEstadoCorte,
                                avatarCorte: paramsIconCorte,
                                colorCorte: colorCorte

                            });

                        }

                    });

                }
            } catch (error) {
                console.log(error.message)
            }
        },
        setCodTribunal(cod_tribunal){
            try {
                let gls_tribunal = this.tribunales.find(tri => tri.cod_tribunal == cod_tribunal).gls_tribunal;
                this.setcodTribunalIGJ(cod_tribunal);
                this.setnombreTribunalIGJ(gls_tribunal);
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    computed:{
        ...mapState(['yearInformeJurisdiccional','codTribunalIGJ'])
    },
    props: {
        cod_corte: {
            type: Number,
            required: true,

        },
        switchResfrescar: {
            type: Boolean,
            required: false,
            default: false
        },
    },
    watch:{
        cod_corte() {
            try {
                if(this.cod_corte != 0){
                    this.getTribunales();
                }
               
                if(this.codTribunalIGJ != 0){
                    this.tribunal = this.codTribunalIGJ;
                }
            } catch (error) {
                console.log(error.message);
            }
        },
        yearInformeJurisdiccional(){
            try {
                if(this.cod_corte != 0){
                    this.getTribunales();
                }

                if(this.codTribunalIGJ != 0){
                    this.tribunal = this.codTribunalIGJ;
                }
            } catch (error) {
                console.log(error.message);
            }     
        },
        codTribunalIGJ(){
            try { 
                if(this.codTribunalIGJ != 0){
                    this.tribunal = this.codTribunalIGJ;
                }

            } catch (error) {
                console.log(error.message);
            }
        },
        switchResfrescar(){
            try { 
                this.getTribunales();

                if(this.codTribunalIGJ != 0){
                    this.tribunal = this.codTribunalIGJ;
                }

            } catch (error) {
                console.log(error.message);
            }
        }

    }
}
</script>
