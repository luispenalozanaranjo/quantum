<template>
    <v-row dense  justify="center">
        <v-col xs12 cols="12"> 
            <v-card class="mx-auto">
                <v-toolbar flat class="pjud">
                    <v-toolbar-title>
                        <h2 class="white--text">{{glsCorte}}</h2>
                    </v-toolbar-title>
                    <v-spacer></v-spacer>
                    <filtroTribunales :cod_corte="cod_corte" :switchResfrescar="switchResfrescar" class="mt-4"/>    
                    <filtroExhortos />
                    <filtroJurisdiccional />
                    <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none;" class="ml-13" >Volver</v-btn>
                </v-toolbar>
                <v-card-text class="fondoColor">
                    <slot> 
                    </slot>
                </v-card-text>
            </v-card>
        </v-col>
    </v-row>
</template>



<script>
import filtroJurisdiccional from '../FiltroInforme.vue'
import filtroTribunales from './FiltroTribunales.vue'
import filtroExhortos from '../FiltroExhortos.vue'

export default {
    name: "LayoutJurisdiccionalCortes",
    data(){
        return{
            validated: 2,
            formulario: {
                1: 'Ingresos',
                3: 'Resoluciones',
                5: 'Terminos',
                6: 'Presupuestos',
                7: 'Presentaciones',
                8: 'Dotaciones',
                9: 'Administrativa',
                10: 'Academia',
                14: 'Concursos',
                20: 'Audiencias'        
            },
            cod_corte_param: 0
        }
    },
    components:{
        filtroJurisdiccional,
        filtroTribunales,
        filtroExhortos
    },
    props: {
        glsCorte: {
            type: String,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        switchResfrescar: {
            type: Boolean,
            required: false,
            default: false
        },
    }
    
}

</script>


<style lang="css" scoped>

.fondoColor {
    background-color: #f4f8f9;
}

</style>