<template>
    <v-row class="white">
        <v-col md="12">
            <v-row>
                <v-col
                    v-for="item in totalizados"
                    :key="item.competencia_id"
                    :md="12 / totalizados.length"
                    align="center"
                >
                    <v-card width="70%" class="borderCard">
                        <v-card-title class="white">
                            Total Ingresos
                        </v-card-title>
                        <v-card-subtitle align="left" class="white">{{item.competencia}}</v-card-subtitle>
                        <v-card-text class="white">
                            <v-row justify="center">
                                <v-avatar size="80">
                                    <v-img
                                        :src="item.src"
                                        :alt="item.competencia"
                                    />
                                </v-avatar>
                            </v-row>
                            <v-row justify="center">
                                <v-icon color="#5461a9">mdi-folder-multiple-plus-outline</v-icon>
                                <countTo
                                    class="count display-1 black--text font-weight-bold ml-2"
                                    :startVal="0"
                                    :endVal="item.ingresos"
                                    separator="."
                                    :duration="1000"
                                ></countTo>
                                <v-tooltip bottom class="pjud">
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-chip
                                            class="ma-2"
                                            :color="item.color"
                                            outlined
                                            v-bind="attrs"
                                            v-on="on"
                                        >
                                        <v-icon left>
                                            {{item.icon}}
                                        </v-icon>
                                            {{item.porcentaje}}%
                                        </v-chip>
                                    </template>
                                    <span>Total Ingresos {{item.year_ant}}:</span>
                                    <countTo
                                        class="count"
                                        :startVal="0"
                                        :endVal="item.ingresos_ant"
                                        separator="."
                                        :duration="1000"
                                    ></countTo>
                                </v-tooltip>
                            </v-row>
                            <v-row justify="center">
                                <p class="font-weight-medium">
                                    {{item.year}}
                                </p>
                            </v-row>
                        </v-card-text>
                    </v-card>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import { urlJurisdiccional } from '../../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'TotalIngresosCorte',
    data() {
        return {
            totalIngresos: 0,
            totalIngresosAnterior: 0,
            totalizados: [],
        }
    },
    created() {
        try {
            this.getTotales()
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        async getTotales() {
            try {
                const req = urlJurisdiccional + '/ingresos_anual_competencia'
                this.totalizados = []
                let totalizadosCompetencias = []

                const getIngresos = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia,
                    },
                })

                if (getIngresos.status == 200) {
                    getIngresos.data.data.ingresos.forEach(ing => {
                        
                        let ingAnt = 0;
                        let ingSE = 0;
                        let porcentaje = 0.0;

                        if (this.incluirExhortoJurisdiccional) {
                            
                            ingAnt = getIngresos.data.data.ingresos_ant.find(ing_ant =>ing_ant._id.competencia_id ==ing._id.competencia_id).cantidad;

                            if(ing.cantidad == ingAnt){
                                porcentaje = 0;
                            }else{
                                porcentaje = Math.round((((ing.cantidad - ingAnt) * 100)/ingAnt),1);
                            }

                            totalizadosCompetencias.push({
                                year: this.anoInforme,
                                year_ant: this.anoInforme - 1,
                                competencia_id: ing._id.competencia_id,
                                competencia: this.competencias.find(c => c.id == ing._id.competencia_id).competencia,
                                ingresos: ing.cantidad,
                                ingresos_materias: ing.cantidad_materias,
                                ingresos_ant: ingAnt,
                                ingresos_materias_ant: getIngresos.data.data.ingresos_ant.find(ing_ant =>ing_ant._id.competencia_id ==ing._id.competencia_id).cantidad_materias,
                                src: this.competencias.find(c => c.id == ing._id.competencia_id).src,
                                porcentaje: porcentaje,
                                icon: porcentaje >= 0 ? 'mdi-trending-up':'mdi-trending-down',
                                color: porcentaje >= 0 ? 'success':'error',
                            });

                        } else {

                            ingAnt = getIngresos.data.data.ingresos_ant_se.find(ing_ant_se =>ing_ant_se._id.competencia_id ==ing._id.competencia_id).cantidad;
                            ingSE = getIngresos.data.data.ingresos_se.find(ing_se =>ing_se._id.competencia_id ==ing._id.competencia_id).cantidad;

                            if(ingSE == ingAnt){
                                porcentaje = 0;
                            }else{
                                porcentaje = Math.round((((ingSE - ingAnt) * 100)/ingAnt),1);
                            }

                            totalizadosCompetencias.push({
                                year: this.anoInforme,
                                year_ant: this.anoInforme - 1,
                                competencia_id: ing._id.competencia_id,
                                competencia: this.competencias.find(c => c.id == ing._id.competencia_id).competencia,
                                ingresos: ingSE,
                                ingresos_materias: getIngresos.data.data.ingresos_se.find(ing_se =>ing_se._id.competencia_id ==ing._id.competencia_id).cantidad_materias,
                                ingresos_ant: ingAnt,
                                ingresos_materias_ant: getIngresos.data.data.ingresos_ant_se.find(ing_ant_se =>ing_ant_se._id.competencia_id ==ing._id.competencia_id).cantidad_materias,
                                src: this.competencias.find(c => c.id == ing._id.competencia_id).src,
                                porcentaje: porcentaje,
                                icon: porcentaje >= 0 ? 'mdi-trending-up':'mdi-trending-down',
                                color: porcentaje >= 0 ? 'success':'error',
                            })
                        }
                    })

                    this.totalizados = totalizadosCompetencias
                } else {
                    console.log(getIngresos.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    computed: {
        ...mapState(['incluirExhortoJurisdiccional', 'competencias']),
    },
    watch: {
        anoInforme() {
            try {
                this.getTotales()
            } catch (error) {
                console.log(error.message)
            }
        },
        cod_tribunal() {
            try {
                this.getTotales()
            } catch (error) {
                console.log(error.message)
            }
        },
        incluirExhortoJurisdiccional() {
            try {
                this.getTotales()
            } catch (error) {
                console.log(error.message)
            }
        },
    },
}
</script>
<style scoped>
.borderCard{
    border: 1px solid #5461a9
}
</style>