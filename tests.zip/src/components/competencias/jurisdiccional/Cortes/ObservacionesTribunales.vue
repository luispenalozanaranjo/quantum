<template>
    <v-row>
        <v-col md="12" class="info-box">
            <v-row v-for="obs in observaciones" :key="obs.id">
                <v-col md="12">
                    <v-textarea
                        outlined
                        :name="obs.competencia + 'txtObservacion' + formulario_id"
                        v-model="obs.texto"
                        readonly
                        rows="1"
                        auto-grow
                    ></v-textarea>

                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import moment from 'moment-timezone'
import { urlJurisdiccional } from '../../../../config/api'
import axios from 'axios'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'ObservacionesTribunales',
    data() {
        return {
            txtValue: '',
            typeAlert: 'success',
            alertText: '',
            alert: false,
            validaEstado: 1,
            chkSinObs: false,
            observaciones: [],
        }
    },
    created() {
        try {
            if(this.cod_tribunal != 0){
                this.getObservacion();
            }
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        async getObservacion() {
            try {
                const req = urlJurisdiccional + '/observaciones';
                this.observaciones = [];
                let contador = 0;

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: this.formulario_id,
                        competencia_id: this.id_competencia,
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                    },
                });

                if (getObservacion.status == 200 || getObservacion.status == 304) {

                    getObservacion.data.data.observaciones.forEach(obs => {

                        obs.observacion.forEach(obsDet => {

                            if(this.formulario_id == 1 || this.formulario_id == 5 || this.formulario_id == 3 || this.formulario_id == 20){
                                this.observaciones.push({
                                    id: this.competencias.find(c => c.id == obs.competencia_id).id,
                                    competencia: this.competencias.find(c => c.id == obs.competencia_id).competencia,
                                    texto:  this.competencias.find(c => c.id == obs.competencia_id).competencia + ': ' + obsDet.descripcion,
                                });
                            }else{
                                this.observaciones.push({
                                    id:contador,
                                    competencia: '',
                                    texto:  obsDet.descripcion,
                                });     
                            }

                            contador++;

                        });

                    });


                } else {
                    console.log(getObservacion.data.observacion);
                }


            } catch (error) {
                console.log(error.message);
            }
        },
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
        formulario_id: {
            type: Number,
            required: true,
        },
    },
    computed:{
        ...mapState(['competencias']),
    },
    watch:{
        cod_tribunal(){
            try {
                if(this.cod_tribunal != 0){
                    this.getObservacion();
                }
            } catch (error) {
                console.log(error.message)
            }
        },
        anoInforme(){
            try {
                if(this.anoInforme != 0){
                    this.getObservacion();
                }
            } catch (error) {
                console.log(error.message)
            }
        }
    },
}
</script>
<style scoped>
.info-box {
    background: #fff;
    padding: 10px 10px 10px 5px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
