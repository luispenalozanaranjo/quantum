<template>
<v-row class="white">
    <v-col md="12">
        <v-data-table
            :headers="headers"
            :items="concursos"
            :items-per-page="30"
            class="elevation-1 mt-2"
            hide-default-footer
            no-data-text="Sin concursos"
        >
            <template v-slot:item="{ item }">
                <tr>
                    <td class="white">{{ item.cargo }}</td>
                    <td class="white">{{ item.publicacion }}</td>
                    <td class="white">{{ item.resultado }}</td>
                    <td class="white">{{ item.asunsion }}</td>
                    <td class="white">{{ item.demora }}</td>
                </tr>
            </template>
        </v-data-table>
    </v-col>
</v-row>

</template>
<script>
import axios from 'axios'
import store from 'store'
import { urlJurisdiccional } from '../../../../config/api'
import countTo from 'vue-count-to'

export default {
    name: "JurisdiccionalConsursosCorte",
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            concursos: [{
                cargo: '',
                publicacion: '',
                resultado: '',
                asunsion: '',
                demora: 0,
            }],
            headers: [{text: 'Cargo',align: 'start',sortable: false, value: 'cargo', class: 'pjud white--text subtitle-2'},
                    { text: 'Fec. Publicación',align: 'start',sortable: false, value: 'publicacion', class: 'pjud white--text subtitle-2' },
                    { text: 'Resultado', value: 'resultado',align: 'start',sortable: false, class: 'pjud white--text subtitle-2' },
                    { text: 'Fec. Asunción', value: 'asunsion',align: 'start',sortable: false, class: 'pjud white--text subtitle-2' },
                    { text: 'Demora en Asunción', value: 'demora',align: 'start',sortable: false, class: 'pjud white--text subtitle-2' },
            ],
        }
    },
    created() {
        try {
            if(this.cod_tribunal != 0){
                this.getConcursos();
            }
            
        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{
        async getConcursos() {
            try {
                const req = urlJurisdiccional + '/observaciones';
                this.concursos = [];

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: 14,
                        competencia_id:0,
                        cod_corte: this.cod_corte, // 11, 
                        cod_tribunal: this.cod_tribunal, // 6,
                        ano: this.anoInforme, // 2020,
                    },
                });

                if (getObservacion.status == 200 || getObservacion.status == 304) {

                    if(getObservacion.data.data.observaciones.length > 0){
                        getObservacion.data.data.observaciones[0].observacion.forEach(concurso => {

                            if(concurso.cargo != ""){
                                this.concursos.push({
                                            cargo:  concurso.cargo,
                                            publicacion: (concurso.demora != 0)?concurso.publicacion.substring(0, 10):"",
                                            resultado: concurso.resultado,
                                            asunsion:  (concurso.demora != 0)?concurso.asunsion.substring(0, 10):"",
                                            demora:  concurso.demora
                                });
                            }

                        });
                    }

                } else {
                    console.log(getObservacion.data.observacion);
                }

            } catch (error) {
                console.log(error.message);
            }
        },
    },
    components: {
        countTo
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getConcursos()
            } catch (error) {
                console.log(error.message);
            }
        },
        cod_tribunal() {
            try {
                this.getConcursos()
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}

</script>
