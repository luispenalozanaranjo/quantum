<template>
    <v-row dense>
        <v-col xs12 cols="12"> 
            <v-card class="mx-auto">
                <v-toolbar flat class="pjud">
                    <v-toolbar-title>
                        <h2 class="white--text">{{nombreTribunal}}</h2>
                    </v-toolbar-title>
                    <v-spacer></v-spacer>
                    <filtroExhortos />
                    <filtroJurisdiccional />
                    <v-menu offset-y transition="slide-x-transition" bottom right>
                        <template v-slot:activator="{ on: menu, attrs }">
                            <v-tooltip bottom>
                                <template v-slot:activator="{ on: tooltip }">
                                    <v-btn icon color="white" class="ml-10" @click="muestraAvance()" v-bind="attrs" v-on="{ ...tooltip, ...menu }">
                                        <v-icon>
                                            mdi-format-list-bulleted-square
                                        </v-icon>
                                    </v-btn>
                                </template>
                                <span>Ver progreso</span>
                            </v-tooltip>
                        </template>
                        <v-card>
                            <v-list>
                                <v-list-item v-for="form in complete" :key="form.index">
                                    <v-list-item-title>
                                            <p>
                                                <strong>{{form.descript}}</strong>
                                                <span class="pull-right text-muted">{{form.completed}}% Completado</span>
                                            </p>
                                            <div class="progress progress-striped active">
                                                <div v-bind:class="form.completed == 100 ? 'progress-bar progress-bar-success':'' "  role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100">
                                                    <span style="opacity: 0;" class="sr-only">{{form.completed}}</span>
                                                </div>
                                            </div>
                                    </v-list-item-title>
                                </v-list-item>
                            </v-list>
                        </v-card>
                    </v-menu>
                    <v-btn v-if="this.validated != 1" color="error" disabled style="text-decoration:none;" class="ml-10" >{{ text }}</v-btn>

                    <v-dialog v-else
                        v-model="dialog"
                        persistent
                        max-width="290"
                    >
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn 
                        color="success"
                        style="text-decoration:none;"
                        class="ml-10"
                        dark
                        v-bind="attrs"
                        v-on="on"
                        >
                        {{ text }}
                        </v-btn>
                    </template>
                    <v-card>
                        <v-card-title class="text-h5">
                        Está Seguro?
                        </v-card-title>
                            <v-card-text>
                                Esta acción enviará todos los datos ingresados a su respectiva Corte de Apelaciones, no pudiendo realizar nuevas modificaciones.<br>
                                Desea Continuar?
                            </v-card-text>
                            <v-card-actions>
                                <v-spacer></v-spacer>
                                <v-btn
                                    color="green darken-1"
                                    text
                                    @click="dialog = false"
                                >
                                    No enviar
                                </v-btn>
                                <v-btn
                                    color="green darken-1"
                                    text
                                    @click="enviaAICA"
                                >
                                    Enviar a ICA
                                </v-btn>
                            </v-card-actions>
                        </v-card>
                    </v-dialog>
                    
                    <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none;" class="ml-10" >Volver</v-btn>
                </v-toolbar>
                <v-card-text class="fondoColor">
                    <slot>
                    </slot>
                </v-card-text>
            </v-card>
        </v-col>
    </v-row>
</template>



<script>
import axios from 'axios'
import { mapState } from 'vuex'
import { mapMutations } from 'vuex'
import { urlApi } from '../../../config/api'
import { url } from '../../../config/apiConfig'
import store from 'store'
import filtroJurisdiccional from './FiltroInforme.vue'
import filtroExhortos from './FiltroExhortos.vue'

export default {
    name: "LayoutJurisdiccional",
    data(){
        return{
            user: {
                usuario_id: store.get('usuario'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                email: store.get('email'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto')
            },
            nombreTribunal: '',
            validated: 2,
            text: 'Enviar a ICA',
            colorBtn: 'success',
            habilitadoBtn: '',
            dialog: false,
            complete: [],
            formulario: {
                1: 'Ingresos',
                3: 'Resoluciones',
                5: 'Terminos',
                6: 'Presupuestos',
                7: 'Presentaciones',
                8: 'Dotaciones',
                9: 'Administrativa',
                10: 'Academia',
                14: 'Concursos',
                20: 'Audiencias'        
            },
        }
    },
    created(){
        try {
            this.getTribunal();

        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{
        ...mapState(['yearInformeJurisdiccional'], ['validaEnvioICA']), // Valores Guardados
        ...mapMutations(['setValidaEnvioICA']),

        async getTribunal(){
            try {
                const req = url + '/user/getUser/' + this.user.usuario_id;
                const getUserConf = await axios.get(req);

                if(getUserConf.status == 200){
                    let user = getUserConf.data;
                    this.nombreTribunal = user.cod_tribunal_origen.descripcion;

                    store.set('cod_tribunal', getUserConf.data.cod_tribunal_origen.cod_tribunal);
		            store.set('cod_corte', getUserConf.data.cod_tribunal_origen.corte.cod_corte);

                    this.getEstadoICA(getUserConf.data.cod_tribunal_origen.corte.cod_corte, getUserConf.data.cod_tribunal_origen.cod_tribunal);
                }

            } catch (error) {
                console.log(error.message);
            }
        },

        getTribunalData(){
            try {
                const axios = require('axios')
                const req1 = urlApi + '/laboral/tribunal_detalle' 

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal
                            }
                                        
                        })
                        
                        const data = response.data
                        this.nombreTribunal = ''

                        Object.values(data.recordset).map((type) => {
                            this.nombreTribunal = type.gls_tribunal
                        })

                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

            } catch (error) {
                console.log(error)
            }
        },

        async getEstadoICA(cod_corte, cod_tribunal){
            try {
                const axios = require('axios')
                const req1 = urlApi + '/jurisdiccional/estados'

                try{
                    const response = await axios.get(req1, {
                        params: {
                                cod_corte: cod_corte,
                                cod_tribunal: cod_tribunal,
                                ano: this.yearInformeJurisdiccional()
                        }
                                    
                    })
                    const data = response.data
                    
                    if (Object.keys(response.data.data).length === 1) {
                        const data = response.data
                        Object.values(data.data).map((type) => {
                            if(type !== null){
                                this.validated = type.estado_observacion_id
                                if (type.estado_observacion_id != 1){
                                    this.text = 'Enviado a ICA'
                                    this.colorBtn = 'error'
                                    this.habilitadoBtn = 'disabled'
                                    this.validated = 2
                                    this.setValidaEnvioICA(type.estado_observacion_id)
                                } else {
                                    this.text = 'Enviar a ICA'
                                    this.colorBtn = 'success'
                                    this.habilitadoBtn = ''
                                    this.validated = 1
                                    this.setValidaEnvioICA(type.estado_observacion_id)
                                }
                            }
                        })
                    } else {
                        this.validated = 1;
                        this.text = 'Enviar a ICA'
                    }

                } 
                catch (error) {
                }
                

            } catch (error) {
                console.log(error.message);
            }
        },

        async enviaAICA(){
            try {
                const axios = require('axios')
                const req1 = urlApi + '/jurisdiccional/finalizar'
                const req2 = urlApi + '/jurisdiccional/sendemail'

                try{
                    const response = axios.post(req1, {
                        cod_corte: this.user.cod_corte,
                        cod_tribunal: this.user.cod_tribunal,
                        ano: this.yearInformeJurisdiccional(),
                        usuario: this.user.usuario_id
                    })

                    this.validated = 2
                    this.text= 'Enviado a ICA'
                    this.dialog = false

                } 
                catch (error) {
                    console.log(error)
                }

                try{
                    const response2 = await axios.get(req2, {
                        params: {
                            gls_tribunal: this.nombreTribunal,
                            email: this.user.email,
                        }
                    })
                } 
                catch (error) {
                    console.log(error)
                }
                
            } catch (error) {
                console.log(error.message);
            }
        },

        async muestraAvance(){
            try {
                this.complete = [];
                // this.dialog = true
                const axios = require('axios')
                const req1 = urlApi + '/jurisdiccional/formularios'

                try{
                    const response = await axios.get(req1, {
                        params: {
                            cod_corte: this.user.cod_corte,
                            cod_tribunal: this.user.cod_tribunal,
                            ano: this.yearInformeJurisdiccional()
                        }
                    })

                    const data = response.data
        
                    Object.values(data.data.data).map((type) => {
                        var descript = type.descripcion;
                        var completed = (type.Observacion.length >= 1) ? 100 : 0;
                        var aux = {descript,completed}
                        this.complete.push(aux)
                    })

                } 
                catch (error) {
                    console.log(error)
                }
                
            } catch (error) {
                console.log(error.message);
            }
        },

    },
    components:{
        filtroJurisdiccional,
        filtroExhortos
    },
    watch: {
        '$store.state.validaEnvioICA'() {
            try {
                this.validaEstado = this.validaEnvioICA();
            } catch (error) {
                console.log(error.message);
            }
        }
    },
    
}

</script>


<style lang="css" scoped>

.fondoColor {
    background-color: #f4f8f9;
}

</style>