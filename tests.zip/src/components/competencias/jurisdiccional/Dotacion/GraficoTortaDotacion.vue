<template>
    <v-row align="center">
        <v-col class="whiteBox">
            <apexchart
                height="400"
                :options="pieChartOptions"
                :series="pieSeries"
                ref="pieGrafico"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'

moment.locale('es')

export default {
    name: 'GraficoTortaDotacionJurisdiccional',
    data() {
        return {
            pieSeries: [],
            pieChartOptions: {
                chart: {
                    id: 'pieGrafico',
                    height: 400,
                    type: 'pie',
                    locales: [es],
                    defaultLocale: 'es',
                },
                title: {
                    text: 'Dotación Vigente',
                    align: 'center',
                },
                noData: {
                    text: 'Visualizando',
                },
                colors: ['#2E93fA', '#E91E63', '#546E7A', '#FF9800','#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff', '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080', '#330e0e', '#000000'],
                dataLabels: {
                    enabled: true,
                    // formatter: function(val) {
                    //     return (
                    //         val
                    //             .toFixed(0)
                    //             .toString()
                    //             .replace('.', ',') + '%'
                    //     )
                    // },
                },
                labels: [],
                legend: {
                    show: true,
                    position: 'bottom',
                    horizontalAlign: 'center',
                    onItemHover: {
                        highlightDataSeries: true,
                    },
                    onItemClick: {
                        toggleDataSeries: true,
                    },
                },
            },
        }
    },
    created() {
        try {
            this.getDotacion()
        } catch (error) {
            console.log(error)
        }
    },
    methods: {

        async getDotacion() {
            try {
                const req = urlJurisdiccional + '/dotaciones';
                let dataLabelsAux = [];
                let dataSeriesAux = [];

                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return;

                const getDotacion = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                if (getDotacion.status == 200) {
                    this.pieSeries = []
                    
                    getDotacion.data.data.count.forEach(dotacion => {
                            
                        dataLabelsAux.push(dotacion._id);
                        this.pieSeries.push(dotacion.count);

                    });


                    ApexCharts.exec('pieGrafico', "updateOptions", {
                        labels: dataLabelsAux,
                    });

                    //UPDATE GRAFICO
                    ApexCharts.exec(
                        'pieGrafico',
                        'updateSeries',
                        dataSeriesAux,
                        true
                    );


                } else {
                    console.log(getDotacion.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getDotacion();
            } catch (error) {
                console.log(error.message)
            }
        },
        cod_tribunal() {
            try {
                this.getDotacion();
            } catch (error) {
                console.log(error.message)
            }
        },
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
.whiteBox{
    background: #fff;
}
</style>
