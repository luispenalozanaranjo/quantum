<template>
<v-row class="white">
    <v-col md="12">
        <v-data-table
            :headers="headers"
            :items="dotacion"
            :items-per-page="30"
            class="elevation-1 mt-2"
            hide-default-footer
            no-data-text="Sin dotacion"
        >
            <template v-slot:item="{ item }">
                <tr>
                    <td class="white" style="text-align: center;">{{ item.cargo }}</td>
                    <td class="white" style="text-align: center;">{{ item.cantidad }}</td>
                </tr>
            </template>
        </v-data-table>
    </v-col>
</v-row>

</template>
<script>
import axios from 'axios'
import store from 'store'
import { urlJurisdiccional } from '../../../../config/api'
import countTo from 'vue-count-to'

export default {
    name: "JurisdiccionalDotacionTableCorte",
    data() {
        return {
            user: {
                usuario_id: store.get('usuario'),
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
            },
            dotacion: [{
                cargo: '',
                cantidad: 0,
            }],
            headers: [{text: 'Cargo',align: 'center',sortable: false, value: 'cargo', class: 'pjud white--text subtitle-2'},
                    { text: 'Cantidad',align: 'center',sortable: false, value: 'cantidad', class: 'pjud white--text subtitle-2' },
            ],
        }
    },
    created() {
        try {
            if(this.cod_tribunal != 0){
                this.getdotacion();
            }
            
        } catch (error) {
            console.log(error.message);
        }
    },
    methods:{
        async getdotacion() {
            try {
                const req = urlJurisdiccional + '/dotaciones';
                const anoInforme_ant = this.anoInforme - 1
                this.dotacion = [];
                let totalizado = 0;

                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return;

                const getDotacion = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });


                // const getDotacion_ant = await axios.get(req, {
                //     params: {
                //         cod_corte: this.cod_corte,
                //         cod_tribunal: this.cod_tribunal,
                //         ano: anoInforme_ant
                //     },
                // });

                if (getDotacion.status == 200 || getDotacion.status == 304) {
                    getDotacion.data.data.count.forEach(dotacion => {
                        this.dotacion.push({
                            cargo: dotacion._id,
                            cantidad: dotacion.count
                        });

                        totalizado += dotacion.count;

                    });

                    this.dotacion.push({
                        cargo: 'TOTAL',
                        cantidad: totalizado
                    });


                }


            } catch (error) {
                console.log(error.message);
            }
        },
    },
    components: {
        countTo
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getdotacion()
            } catch (error) {
                console.log(error.message);
            }
        },
        cod_tribunal() {
            try {
                this.getdotacion()
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}

</script>
