<template>
    <v-row align="center">
        <v-col class="white">
            <apexchart
                type="bar"
                height="500"
                :options="pieChartOptionsBar"
                :series="pieSeriesBar"
                ref="barChartDotacion"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'

moment.locale('es')

export default {
    name: 'GraficoBarraDotacionJurisdiccional',
    data() {
        return {
            pieSeriesBar: [],
            pieChartOptionsBar: {
                chart: {
                    id: 'barChartDotacion',
                    height: 500,
                    type: 'bar',
                    stacked: false,
                },
                plotOptions: {
                    bar: {
                        horizontal: true,
                    }
                },
                yaxis: {
                    labels: {
                        align: 'left',
                        maxWidth: 300,
                    }
                },
                fill: {
                    opacity: 1
                },
                colors: ['#5461a9','#E91E63'],
                noData: {
                    text: 'Visualizando',
                },
                title: {
                    text: 'Dotación Vigente',
                    align: 'center',
                },
                legend: {
                    show: true,
                    showForSingleSeries: true,
                    customLegendItems: ['Actual', 'Expected'],
                    markers: {
                        fillColors: ['#5461a9', '#E91E63']
                    }
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            this.getDotacion()
        } catch (error) {
            console.log(error)
        }
    },
    methods: {

        async getDotacion() {
            try {
                const req = urlJurisdiccional + '/dotaciones';
                const anoInforme_ant = this.anoInforme - 1
                let seriesBar = [];

                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return;

                const getDotacion = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                const getDotacion_ant = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: anoInforme_ant
                    },
                });

                if (getDotacion.status == 200) {

                    seriesBar.push({
                        name: this.anoInforme,
                        data:[]
                    });

                    seriesBar.forEach(serie => {

                        getDotacion.data.data.count.forEach(dotacion => {

                            let values_dotAnt = getDotacion_ant.data.data.count.find(dotAnt => dotAnt._id == dotacion._id) == undefined ? 0 : getDotacion_ant.data.data.count.find(dotAnt => dotAnt._id == dotacion._id).count
                            
                            serie.data.push({
                                x: dotacion._id,
                                y: dotacion.count,
                                goals:[{
                                    name: anoInforme_ant,
                                    value: values_dotAnt,//getDotacion_ant.data.data.count.find(dotAnt => dotAnt._id == dotacion._id).count,
                                    strokeWidth: 5,
                                    strokeHeight: 10,
                                    strokeColor: '#E91E63',
                                }],
                            });
                        });

                    });

                    ApexCharts.exec('barChartDotacion', "updateOptions", {
                        legend:{
                            customLegendItems: [this.anoInforme.toString(), anoInforme_ant.toString()]
                        }
                    });

                    //UPDATE GRAFICO
                    ApexCharts.exec(
                        'barChartDotacion',
                        'updateSeries',
                        seriesBar,
                        true
                    );


                } else {
                    console.log(getDotacion.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getDotacion();
            } catch (error) {
                console.log(error.message)
            }
        },
        cod_tribunal() {
            try {
                this.getDotacion();
            } catch (error) {
                console.log(error.message)
            }
        },
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
