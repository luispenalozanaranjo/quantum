<template>
    <v-row align="center">
        <v-col class="info-box">
            <v-card-text>
                <v-data-table 
                    :headers="headers"
                    :items="detalleIngresos"
                    :page.sync="page"
                    :items-per-page="itemsPerPage"
                    dense
                    hide-default-footer
                    @page-count="pageCount = $event"                                
                    class="mt-10">
                </v-data-table>
                <v-row justify="center"> 
                    <v-col cols="6">
                        <v-pagination v-model="page" :length="pageCount"></v-pagination>
                    </v-col>
                </v-row>
            </v-card-text>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoAcademia',
    data() {
        return {
            dialog: false
            ,detalleIngresos: []
            ,search: ''
            ,page: 1
            ,pageCount: 0
            ,itemsPerPage: 10
            ,headers: [
                {text: 'Nombres', align: 'center', value: 'nombres', class : 'pjud white--text', width: '15%'},
                {text: 'Cargo', align: 'center', value: 'cargo', class : 'pjud white--text', width: '15%'},
                {text: 'Curso', align: 'center', value: 'curso', class : 'pjud white--text', width: '25%'},
                {text: 'Evaluación', align: 'center', value: 'evaluacion', class : 'pjud white--text', width: '15%'},
                {text: 'Horas', align: 'center', value: 'horas', class : 'pjud white--text', width: '5%'},
                {text: 'Fecha Termino', align: 'center', value: 'fec_termino', class : 'pjud white--text', width: '10%'}
            ]
            ,excelHead :[
                 { label: "#",field: "increment" }
                ,{ label: "RIT",field: "rit" }
                ,{ label: "Litigante",field: "litigante" }
                ,{ label: "Litigante",field: "litigante2" }
                ,{ label: "Procedimiento",field: "procedimiento" }
                ,{ label: "Materia",field: "materia" }
                ,{ label: "Fecha Ingreso",field: "fecha_ingreso" }
            ]
        }
    },
    created() {
        try {
            this.getIngresos()
        } catch (error) {
            console.log(error)
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getIngresos() {
            try {
                this.detalleIngresos = [];
                                
                const req = urlJurisdiccional + '/capacitaciones';

                const response  = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                if (response.status == 200) {
                    const arreglo = []
                    let increment = 1
                
                    Object.values(response.data.data.count).map((type) => {
                        this.detalleIngresos.push(type)
                        increment ++
                    })

                } else {
                    console.log(response.data)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true
        }
    },
    watch: {
        anoInforme() {
            try {
                this.getIngresos();
            } catch (error) {
                console.log(error.message)
            }
        }
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
