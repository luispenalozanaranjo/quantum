<template>
    <v-row>
        <v-col xs="12" sm="12" md="4" xl="4" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-checkbox-marked-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="totalh[1]"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>Total HRS Cursos Asignados {{this.anoInforme}}</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col xs="12" sm="12" md="4" xl="4" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-checkbox-marked-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="totalh[0]"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>Total HRS Cursos Asignados {{this.anoInforme - 1}}</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col xs="12" sm="12" md="4" xl="4" class="info-box">
            <v-row>
                <v-col sm="6" md="3" xl="3">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-chart-timeline-variant
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="9" xl="9">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="prom"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>Promedio HRS Funcionario {{this.anoInforme}}</span>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es');

export default {
    name: 'TotalPresupuestos',
    data() {
        return {
            totalIngresos: 0,
            totalIngresosAnterior: 0,
            competencia_id: 0,
            monto_asignado: 0,
            monto_asignado_ant: 0,
            monto_utilizado: 0,
            crecimiento: 0,
            utilizado: 0,
            totalh: [],
            prom: 0, 
        }
    },
    created() {
        try {
            this.getTotales();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getTotales(){
            try {
                
                const req = urlJurisdiccional + '/capacitaciones';

                const response  = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                if (response.status == 200) {
                    const arreglo = []
                    let graf = []
                    let cantf = 0
                    this.totalh = []
                
                    Object.values(response.data.data.count).map((type) => {
                        cantf += type.horas
                        let aux =  graf.findIndex(i => i.label === type.cargo)
                        aux === -1 ? graf.push({ label: type.cargo, value: type.horas }) : graf[aux].value = graf[aux].value + type.horas
                    })

                    Object.values(response.data.data.total).map((type) => {
                        this.totalh.push(type.count)
                    })

                    this.prom = Math.round(cantf / graf.length)

                } else {
                    console.log(response.data);
                }

            } catch (error) {
                console.log(error.message);
            }
        },        

    },
    components:{
        countTo,
    },
    props:{
        anoInforme: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        },
        cod_corte: {
            type: Number,
            required: true
        }
    },
    watch:{
        'anoInforme'(){
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message)
            }
        }
    }
}
</script>
<style scoped>

    .info-box {
        background: #fff;
        padding: 30px 30px 30px 20px;
        border-right: 1px solid #e5ebec;
        border-bottom: 1px solid #e5ebec;
    }

    .info-box .icoleaf {
        display: inline-block;
        width: 55px;
        height: 55px;
        padding: 9px 8px;
        font-size: 28px;
        border-top-left-radius: 50%;
        border-bottom-left-radius: 50%;
        border-bottom-right-radius: 50%;
    }
</style>
