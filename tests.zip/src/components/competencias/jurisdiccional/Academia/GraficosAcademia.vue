<template>
    <v-row align="center">
        <v-col class="info-box">
            <apexchart
                type="donut"
                height="350"
                :options="pieChartOptionsDonut"
                :series="pieSeriesDonut"
                :ref="idGrafico"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoAcademia',
    data() {
        return {
            totalIngresos: 0,
            totalIngresosAnterior: 0,
            idGrafico: 'donutChartAcademia',
            window: 0,
            length: 2,
            pieSeriesDonut: [],
            pieChartOptionsDonut: {
                chart: {
                    id: 'donutChartAcademia',
                    height: 500,
                    type: 'donut',
                    toolbar:{
                        show: false
                    }
                },
                theme: {
                    monochrome: {
                        enabled: true
                    }                    
                },
                plotOptions: {
                    pie: {
                        donut: {
                            labels: {
                                show: true,
                                name: {
                                    show: true,
                                    fontSize: '22px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    fontWeight: 600,
                                    color: '#373d3f',
                                    offsetY: -10,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                total: {
                                    show: true,
                                    showAlways: false,
                                    label: 'Total',
                                    fontSize: '22px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    fontWeight: 600,
                                    color: '#373d3f',
                                    formatter: function (w) {
                                        return w.globals.seriesTotals.reduce((a, b) => {
                                        return a + b
                                        }, 0)
                                    }
                                }
                            },
                        }
                    }
                },
                dataLabels: {
                    enabled: false,
                    offsetY: -20,
                    style: {
                        fontSize: '12px',
                    }
                },
                fill: {
                    opacity: 1
                },
                title: {
                    text: 'Funcionarios Capacitados',
                    align: 'center',
                },
                legend: {
                    show: true,
                    showForSingleSeries: true,
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            this.getIngresos()
        } catch (error) {
            console.log(error)
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getIngresos() {
            try {
                let seriesBar = [];
                let anios = []
                const req = urlJurisdiccional + '/capacitaciones';

                const response  = await axios.get(req, {
                    params: {
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme
                    },
                });

                if (response.status == 200) {
                    const arreglo = []
                    let graf = []
                    let label = []
                    let serie = []
                    let cantf = 0
                    this.totalh = []
                
                    Object.values(response.data.data.count).map((type) => {
                        cantf += type.horas
                        let aux =  graf.findIndex(i => i.label === type.cargo)
			            aux === -1 ? graf.push({ label: type.cargo, value: type.horas }) : graf[aux].value = graf[aux].value + type.horas
                    })
                    Object.values(graf).map((type) => {
                        serie.push( type.value )
                        label.push( type.label )
                    })

                    ApexCharts.exec('donutChartAcademia', "updateOptions", {
                        labels: label
                    });

                    //UPDATE GRAFICO
                    ApexCharts.exec(
                        'donutChartAcademia',
                        'updateSeries',
                        serie,
                        true
                    );

                } else {
                    console.log(response.data)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true
        }
    },
    watch: {
        anoInforme() {
            try {
                this.getIngresos();
            } catch (error) {
                console.log(error.message)
            }
        }
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
