<template>
    <v-row>
        <v-col xs="12" sm="12" md="6" xl="6" class="info-box">
            <v-row>
                <v-col sm="6" md="2" xl="1">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-checkbox-marked-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="10" xl="11">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="totalTerminos"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>TOTAL TÉRMINOS MATERIAS {{ anoInforme}}</span>
                </v-col>
            </v-row>
        </v-col>
        <v-col  xs="12" sm="12" md="6" xl="6" class="info-box">
            <v-row>
                <v-col sm="6" md="2" xl="1">
                    <span class="icoleaf white--text pjud">
                        <v-icon color="white" large> 
                            mdi-checkbox-marked-circle-outline
                        </v-icon>
                    </span>
                </v-col>
                <v-col sm="6" md="10" xl="11">
                    <countTo
                        class="count headline pjud--text"
                        :startVal="0"
                        :endVal="totalTerminosAnterior"
                        separator="."
                        :duration="1000"
                    ></countTo>
                    <br/>
                    <span>TOTAL TÉRMINOS MATERIAS {{ anoInforme - 1}}</span>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es');

export default {
    name: 'TotalTerminosMateriasJurisdiccional',
    data() {
        return {
            totalTerminos: 0,
            totalTerminosAnterior: 0,
        }
    },
    created() {
        try {
            this.getTotales();
        } catch (error) {
            console.log(error.message);
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getTotales(){
            try {
                
                const req = urlJurisdiccional + '/resumen_anual_materias';

                const getTerminos = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia
                    },
                });

                if (getTerminos.status == 200) {


                    let accMateria = 0
                    let accMateriaAnt = 0
                    let accMateriaSE = 0
                    let accMateriaAntSE = 0

                    let arrayMateria = getTerminos.data.indicadorMaterias.filter(element => element.cod_materia == this.cod_materia)
                    let arrayMateriaAnt = getTerminos.data.indicadorMaterias_ant.filter(element => element.cod_materia == this.cod_materia)

                    arrayMateria.forEach(element => {
                        if (element.terminos){
                            accMateria += element.terminos
                        }
                        if (element.terminos_se){
                            accMateriaSE += element.terminos_se
                        }
                    });

                    arrayMateriaAnt.forEach(element => {
                        if (element.terminos){
                            accMateriaAnt += element.terminos
                        }
                        if (element.terminos_se){
                            accMateriaAntSE += element.terminos_se
                        }
                    });

                    if(this.incluirExhortoJurisdiccional()){
                        this.totalTerminos = accMateria; 
                        this.totalTerminosAnterior = accMateriaAnt; 
                    }else {
                        this.totalTerminos = accMateriaSE; 
                        this.totalTerminosAnterior = accMateriaAntSE; 
                    }

                } else {
                    console.log(getTerminos.data.observacion);
                }

            } catch (error) {
                console.log(error.message);
            }
        }

    },
    components:{
        countTo,
    },
    props:{
        id_competencia: {
            type: Number,
            required: true
        },
        anoInforme: {
            type: Number,
            required: true
        },
        cod_tribunal: {
            type: Number,
            required: true
        },
        cod_materia: {
            type: String,
            required: true
        }
    },
    watch:{
        'anoInforme'(){
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message)
            }
        },
        '$store.state.incluirExhortoJurisdiccional'() {
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message);
            }
        },
        cod_materia(){
            try {
                this.getTotales();
            } catch (error) {
                console.log(error.message)
            }
        }
    }
}
</script>
<style scoped>

    .info-box {
        background: #fff;
        padding: 30px 30px 30px 20px;
        border-right: 1px solid #e5ebec;
        border-bottom: 1px solid #e5ebec;
    }

    .info-box .icoleaf {
        display: inline-block;
        width: 55px;
        height: 55px;
        padding: 9px 8px;
        font-size: 28px;
        border-top-left-radius: 50%;
        border-bottom-left-radius: 50%;
        border-bottom-right-radius: 50%;
    }
</style>
