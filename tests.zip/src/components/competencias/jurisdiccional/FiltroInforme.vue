<template>
    <v-menu
        v-model="menu"
        transition="slide-x-transition"
        bottom
        right
    >
        <template v-slot:activator="{ on, attrs }">
            <v-badge
                :content="selectedValue"
                :value="selectedValue"
                color="red"
                overlap
                
            >
                <v-icon v-bind="attrs" v-on="on" large color="white"> 
                    mdi-calendar
                </v-icon>
            </v-badge>
        </template>

        <v-list dense>
            <v-list-item-group
                v-model="selectedYear"
                color="primary"
                @change="setYear(selectedYear)"
            >
                <v-list-item v-for="(year, i) in years" :key="i">
                    <v-list-item-title>{{ year }}</v-list-item-title>
                </v-list-item>
            </v-list-item-group>
        </v-list>
    </v-menu>
</template>
<script>
import Vue from 'vue'
import store from 'store'
import moment from 'moment-timezone'
import { mapMutations } from 'vuex'

moment.locale('es')

export default {
    name: 'FiltroInforme',
    data() {
        return {
            menu: false,
            modal: false,
            years: [],
            messages: 0,
            selectedYear: 0,
            selectedValue: 0,
        }
    },
    created() {
        try {
            this.getYears();
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapMutations(['setYearInformeJurisdiccional']),

        buscar() {
            try {
            } catch (error) {
                console.log(error.message)
            }
        },
        getYears() {
            try {
                let yearNow = moment().year()

                for (let index = yearNow - 3; index < yearNow; index++) {
                    this.years.unshift(index)
                }
                this.selectedYear = yearNow - 1;
                this.selectedValue = yearNow - 1;
                this.setYearInformeJurisdiccional(yearNow - 1);
            } catch (error) {
                console.log(error.message)
            }
        },
        setYear(yearIndex){
            try {
                
                this.selectedValue = this.years[yearIndex];
                this.setYearInformeJurisdiccional(this.years[yearIndex]);

            } catch (error) {
                console.log(error.message);
            }

        },
    },
}
</script>
