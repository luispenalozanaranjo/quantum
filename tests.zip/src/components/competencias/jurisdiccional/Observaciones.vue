<template>
    <v-row>
        <v-col md="12" class="info-box">
            <v-row>
                <v-col md="12">
                    <v-textarea
                        outlined
                        name="txtObservacion"
                        v-model="txtValue"
                        label="Observación"
                        :clearable="validaEstado == 1"
                        clear-icon="mdi-close-circle"
                        :readonly="validaEstado != 1"
                    ></v-textarea>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="3">
                    <v-checkbox
                        v-model="chkSinObs"
                        label="Sin observación"
                        color="indigo darken-3"
                        :disabled="validaEstado != 1"
                        @change="
                            chkSinObs == true
                                ? (txtValue = 'Sin observación')
                                : (txtValue = textData)
                        "
                    ></v-checkbox>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <v-card-actions>
                        <v-btn
                            outlined
                            rounded
                            :class="validaEstado != 1 ? '' : 'green white--text'"
                            :disabled="validaEstado != 1"
                            @click="guardarObservacion()"
                        >
                            <v-icon>
                                mdi-content-save-outline
                            </v-icon>
                            Guardar
                        </v-btn>
                        <v-spacer></v-spacer>
                        <v-icon 
                            large
                            dark
                            color="orange"
                            class="mr-1"
                        >
                            mdi-information-outline
                        </v-icon>
                        <b>Información proveniente desde QUANTUM</b>
                    </v-card-actions>
                </v-col>
            </v-row>
            <v-row>
                <v-col md="12">
                    <v-alert
                        dense
                        :type="typeAlert"
                        dismissible
                        v-model="alert"
                    >
                        {{ alertText }}
                    </v-alert>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>
<script>
import moment from 'moment-timezone'
import { urlJurisdiccional } from '../../../config/api'
import axios from 'axios'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'ObservacionesJurisdiccional',
    data() {
        return {
            txtValue: '',
            textData: '',
            typeAlert: 'success',
            alertText: '',
            alert: false,
            validaEstado: 1,
            chkSinObs: false,
        }
    },
    created() {
        try {
            this.getObservacion()
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {

        async guardarObservacion() {
            try {
                const req = urlJurisdiccional + '/obsingresos';

                const postObservacion = await axios.post(req, {
                    formulario_id: this.formulario_id,
                    competencia_id: this.id_competencia,
                    cod_corte: this.cod_corte,
                    cod_tribunal: this.cod_tribunal,
                    ano: this.anoInforme,
                    observacion: [
                        {
                            id: 1,
                            descripcion: this.txtValue,
                            estado_observacion_id: 1,
                        },
                    ],
                });

                if (postObservacion.status == 200) {
                    this.typeAlert = 'success';
                    this.alertText = 'Observación guardada correctamente';
                    this.alert = true;
                } else {
                    this.typeAlert = 'error';
                    this.alertText = postObservacion.data.observacion;
                    this.alert = true;
                }

                setTimeout(() => (this.alert = false), 5000);

            } catch (error) {
                console.log(error.message);
            }
        },
        async getObservacion() {
            try {
                const req = urlJurisdiccional + '/observaciones';

                const getObservacion = await axios.get(req, {
                    params: {
                        formulario_id: this.formulario_id,
                        competencia_id: this.id_competencia,
                        cod_corte: this.cod_corte,
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                    },
                });

                if (getObservacion.status == 200) {
                    getObservacion.data.data.observaciones.forEach(obs => {
                        this.textData = obs.observacion[0].descripcion;
                        this.txtValue = this.textData;
                        this.validaEstado = obs.observacion[0].estado_observacion_id;
                    });

                } else {
                    console.log(getObservacion.data.observacion);
                }
                
                this.validaEstado = this.validaEnvioICA;
            } catch (error) {
                console.log(error.message);
            }
        },
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_corte: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
        formulario_id: {
            type: Number,
            required: true,
        },
    },
    computed:{
        ...mapState(['validaEnvioICA']),
    },
}
</script>
<style scoped>
.info-box {
    background: #fff;
    padding: 10px 10px 10px 5px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
