<template>
    <v-container>
        <v-row align="center">
            <v-col class="info-box">
                <apexchart
                    type="line"
                    height="350"
                    :options="pieChartOptionsLine"
                    :series="pieSeriesLine"
                    :ref="idGrafico"
                ></apexchart>
            </v-col>
        </v-row>
        <v-row>
            <v-col>
                <v-chip v-for="materia in arrayMaterias " :key="materia.cod_materia" class="ma-2" @click="loadDataMateria(materia.cod_materia)" :color="(materiaSeleccionada == materia.cod_materia) ?  'success' : ''">{{materia.gls_materia}}</v-chip>
            </v-col>
        </v-row>
    </v-container>

</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoIngresosMateriasJurisdiccional',
    data() {
        return {
            totalIngresos: 0,
            totalIngresosAnterior: 0,
            idGrafico: 'lineChartIngresosMaterias' + this.id_competencia.toString(),
            window: 0,
            length: 2,
            arrayMaterias: [],
            arrayIndicadoresMaterias: [],
            arrayIndicadoresMateriasAnt: [],
            pieSeriesLine: [],
            materiaSeleccionada: '',
            pieChartOptionsLine: {
                chart: {
                    id: 'lineChartIngresosMaterias'+ this.id_competencia.toString(),
                    height: 350,
                    type: 'line',
                    // group: 'ingresos',
                    zoom: {
                        enabled: false,
                    },
                },
                title: {
                    text: 'Ingresos Materias',
                    align: 'left',
                },
                colors: ['#2E93fA', '#E91E63', '#546E7A', '', '#FF9800'],
                noData: {
                    text: 'Visualizando'
                },   
                dataLabels: {
                    enabled: false,
                },
                stroke: {
                    width: [5, 5],
                    curve: 'smooth',
                },
                legend: {
                    position: 'right',
                    offsetY: 100, 
                },
                markers: {
                    size: 3,
                    hover: {
                        sizeOffset: 6,
                    },
                },
                grid: {
                    borderColor: '#f1f1f1',
                },
                xaxis: {
                    categories: [
                        'Ene',
                        'Feb',
                        'Mar',
                        'Abr',
                        'May',
                        'Jun',
                        'Jul',
                        'Ago',
                        'Sep',
                        'Oct',
                        'Nov',
                        'Dic',
                    ],
                },
                yaxis: {
                    labels: {
                        minWidth: 34
                    }
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            this.getDataMaterias();
        } catch (error) {
            console.log(error)
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        loadDataMateria(cod_materia){

            let seriesAux = [];
            let seriesAuxSE = [];

            try {

                
                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return;
                
                seriesAux = [
                        {
                            name: this.arrayIndicadoresMaterias[0].ano.toString(),//getIngresos.data.data.ingresos[0]._id.ano.toString(),
                            data: [
                                this.arrayIndicadoresMaterias.find(element => element.mes == 1 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 1 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 2 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 2 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 3 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 3 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 4 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 4 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 5 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 5 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 6 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 6 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 7 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 7 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 8 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 8 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 9 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 9 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 10 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 10 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 11 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 11 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 12 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 12 && element.cod_materia == cod_materia).ingresos,
                            ],
                        },
                        {
                            name: this.arrayIndicadoresMateriasAnt[0].ano.toString(),
                            data: [
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 1 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 1 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 2 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 2 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 3 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 3 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 4 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 4 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 5 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 5 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 6 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 6 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 7 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 7 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 8 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 8 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 9 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 9 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 10 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 10 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 11 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 11 && element.cod_materia == cod_materia).ingresos,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 12 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 12 && element.cod_materia == cod_materia).ingresos,
                            ],
                        },
                ]


                seriesAuxSE = [
                        {
                            name: this.arrayIndicadoresMaterias[0].ano.toString(),//getIngresos.data.data.ingresos[0]._id.ano.toString(),
                            data: [
                                this.arrayIndicadoresMaterias.find(element => element.mes == 1 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 1 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 2 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 2 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 3 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 3 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 4 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 4 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 5 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 5 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 6 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 6 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 7 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 7 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 8 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 8 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 9 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 9 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 10 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 10 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 11 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 11 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMaterias.find(element => element.mes == 12 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMaterias.find(element => element.mes == 12 && element.cod_materia == cod_materia).ingresos_se,
                            ],
                        },
                        {
                            name: this.arrayIndicadoresMateriasAnt[0].ano.toString(),
                            data: [
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 1 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 1 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 2 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 2 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 3 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 3 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 4 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 4 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 5 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 5 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 6 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 6 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 7 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 7 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 8 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 8 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 9 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 9 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 10 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 10 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 11 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 11 && element.cod_materia == cod_materia).ingresos_se,
                                this.arrayIndicadoresMateriasAnt.find(element => element.mes == 12 && element.cod_materia == cod_materia) == undefined ? 0 : this.arrayIndicadoresMateriasAnt.find(element => element.mes == 12 && element.cod_materia == cod_materia).ingresos_se,
                            ],
                        },
                ]


                if(this.incluirExhortoJurisdiccional()){

                    ApexCharts.exec(
                            this.idGrafico,
                            'updateSeries',
                            seriesAux,
                            true
                        );
                    }else{

                        ApexCharts.exec(
                            this.idGrafico,
                            'updateSeries',
                            seriesAuxSE,
                            true
                        );
                }

                ApexCharts.exec(this.idGrafico, "updateOptions", {
                        yaxis: {
                            labels: {
                                formatter: function(value) {
                                    if (value >= 1000){
                                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                    } else {
                                        return value;
                                    }
                                }
                            }
                        },
                        dataLabels: {
                            formatter: function(value) {
                                if (value >= 1000){
                                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return value;
                                }
                            }
                        },
                        title:{
                            text: 'Ingresos Materias: ' + this.arrayMaterias.find(element => element.cod_materia == cod_materia).gls_materia
                        }
                });

                this.materiaSeleccionada = cod_materia;
                this.$emit("seleccionMateria", this.materiaSeleccionada);


            } catch (error) {
                console.log(error.message)
            }
        },
        
        async getDataMaterias(){
            try {
    
                const req = urlJurisdiccional + '/resumen_anual_materias';
                
                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return;

                const getIngresosMaterias = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia,
                    },
                });

                if (getIngresosMaterias.status == 200) {

                    this.arrayMaterias = getIngresosMaterias.data.Materias;
                    this.arrayIndicadoresMaterias = getIngresosMaterias.data.indicadorMaterias;
                    this.arrayIndicadoresMateriasAnt = getIngresosMaterias.data.indicadorMaterias_ant;
                }

            } catch (error) {
                console.log(error.message);
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getDataMaterias();
            } catch (error) {
                console.log(error.message)
            }
        },
        '$store.state.incluirExhortoJurisdiccional'() {
            try {
                this.loadDataMateria(this.materiaSeleccionada);
            } catch (error) {
                console.log(error.message);
            }
        },
        arrayMaterias(){
            try {
                this.loadDataMateria(this.arrayMaterias[0].cod_materia);
            } catch (error) {
                console.log(error.message);
            }
        }
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
