<template>
    <v-tooltip bottom>
        <template v-slot:activator="{ on, attrs }">
            <div v-on="on" v-bind="attrs">
                <v-switch
                    v-model="switch1"
                    class="mt-5 mr-2"
                    dense
                    dark
                    label="¿Incluir Exhortos?"
                ></v-switch>
            </div>
        </template>
        <span>¿Incluir Exhortos?</span>
    </v-tooltip>
</template>
<script>
import moment from 'moment-timezone'
import { mapMutations } from 'vuex'

moment.locale('es')

export default {
    name: 'FiltroExhortoJurisdiccional',
    data() {
        return {
            switch1: true,
        }
    },
    created() {
        try {
            this.switch1 = true //this.incluirExhortoJurisdiccional;
            this.setExhortosJurisdiccional(this.switch1)
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapMutations(['setExhortosJurisdiccional']),
    },
    watch: {
        switch1() {
            try {
                this.setExhortosJurisdiccional(this.switch1)
            } catch (error) {
                console.log(error.message)
            }
        },
    },
}
</script>
