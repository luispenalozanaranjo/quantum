<template>
    <v-row align="center">
        <v-col class="info-box">
            <apexchart
                type="line"
                height="350"
                :options="pieChartOptionsLine"
                :series="pieSeriesLine"
                :ref="idGrafico"
            ></apexchart>
        </v-col>
    </v-row>
</template>
<script>
import axios from 'axios'
import moment from 'moment-timezone'
import countTo from 'vue-count-to'
import es from 'apexcharts/dist/locales/es.json'
import { urlJurisdiccional } from '../../../../config/api'
import { mapState } from 'vuex'

moment.locale('es')

export default {
    name: 'GraficoAudienciasJurisdiccional',
    data() {
        return {
            totalaudiencias: 0,
            totalaudienciasAnterior: 0,
            idGrafico: 'lineChartAudiencias' + this.id_competencia.toString(),
            window: 0,
            length: 2,
            pieSeriesLine: [],
            pieChartOptionsLine: {
                chart: {
                    id: 'lineChartAudiencias'+ this.id_competencia.toString(),
                    height: 350,
                    type: 'line',
                    // group: 'audiencias',
                    zoom: {
                        enabled: false,
                    },
                },
                title: {
                    text: 'audiencias realizadas',
                    align: 'left',
                },
                colors: ['#2E93fA', '#E91E63', '#546E7A', '', '#FF9800'],
                noData: {
                    text: 'Visualizando'
                },   
                dataLabels: {
                    enabled: false,
                },
                stroke: {
                    width: [5, 5],
                    curve: 'smooth',
                },
                legend: {
                    tooltipHoverFormatter: function(val, opts) {
                        return (
                            val +
                            ' - ' +
                            opts.w.globals.series[opts.seriesIndex][
                                opts.dataPointIndex
                            ] +
                            ''
                        )
                    },
                },
                markers: {
                    size: 3,
                    hover: {
                        sizeOffset: 6,
                    },
                },
                grid: {
                    borderColor: '#f1f1f1',
                },
                xaxis: {
                    categories: [
                        'Ene',
                        'Feb',
                        'Mar',
                        'Abr',
                        'May',
                        'Jun',
                        'Jul',
                        'Ago',
                        'Sep',
                        'Oct',
                        'Nov',
                        'Dic',
                    ],
                },
                yaxis: {
                    labels: {
                        minWidth: 34
                    }
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                },
            },
        }
    },
    created() {
        try {
            this.getAudiencias()
        } catch (error) {
            console.log(error.message)
        }
    },
    methods: {
        ...mapState(['incluirExhortoJurisdiccional']),

        async getAudiencias() {
            try {
                const req = urlJurisdiccional + '/audiencias_realizadas_mensuales_competencia';
                let seriesAux = [];
                let seriesAuxSE = [];

                //valida fecha evita error al recargar
                if (this.anoInforme == 0) return

                const getAudiencias = await axios.get(req, {
                    params: {
                        cod_tribunal: this.cod_tribunal,
                        ano: this.anoInforme,
                        id_competencia: this.id_competencia,
                    },
                })

                if (getAudiencias.status == 200) {
                    seriesAux = [
                        {
                            name: getAudiencias.data.data.audiencias[0]._id.ano.toString(),
                            data: [
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 1) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 1).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 2) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 2).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 3) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 3).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 4) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 4).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 5) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 5).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 6) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 6).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 7) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 7).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 8) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 8).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 9) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 9).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 10) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 10).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 11) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 11).cantidad,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 12) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 12).cantidad,
                            ],
                        },
                        {
                            name: getAudiencias.data.data.audiencias_ant[0]._id.ano.toString(),
                            data: [
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 1) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 1).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 2) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 2).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 3) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 3).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 4) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 4).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 5) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 5).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 6) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 6).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 7) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 7).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 8) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 8).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 9) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 9).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 10) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 10).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 11) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 11).cantidad,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 12) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 12).cantidad,
                            ],
                        },
                    ];


                    seriesAuxSE = [
                        {
                            name: getAudiencias.data.data.audiencias[0]._id.ano.toString(),
                            data: [
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 1) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 1).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 2) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 2).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 3) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 3).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 4) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 4).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 5) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 5).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 6) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 6).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 7) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 7).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 8) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 8).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 9) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 9).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 10) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 10).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 11) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 11).cantidad_se,
                                getAudiencias.data.data.audiencias.find(element => element._id.mes == 12) == undefined ? 0 : getAudiencias.data.data.audiencias.find(element => element._id.mes == 12).cantidad_se,
                            ],
                        },
                        {
                            name: getAudiencias.data.data.audiencias_ant[0]._id.ano.toString(),
                            data: [
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 1) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 1).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 2) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 2).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 3) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 3).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 4) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 4).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 5) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 5).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 6) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 6).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 7) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 7).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 8) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 8).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 9) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 9).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 10) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 10).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 11) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 11).cantidad_se,
                                getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 12) == undefined ? 0 : getAudiencias.data.data.audiencias_ant.find(element => element._id.mes == 12).cantidad_se,
                            ],
                        },
                    ];

                    //UPDATE GRAFICO
                    ApexCharts.exec(this.idGrafico, "updateOptions", {
                        yaxis: {
                            labels: {
                                formatter: function(value) {
                                    if (value >= 1000){
                                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                    } else {
                                        return value;
                                    }
                                }
                            }
                        },
                        dataLabels: {
                            formatter: function(value) {
                                if (value >= 1000){
                                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                } else {
                                    return value;
                                }
                            }
                        }
                    });
                    
                    if(this.incluirExhortoJurisdiccional()){
                        ApexCharts.exec(
                            this.idGrafico,
                            'updateSeries',
                            seriesAux,
                            true
                        );
                    }else{
                        ApexCharts.exec(
                            this.idGrafico,
                            'updateSeries',
                            seriesAuxSE,
                            true
                        );
                    }



                } else {
                    console.log(getAudiencias.data.observacion)
                }
            } catch (error) {
                console.log(error.message)
            }
        },
    },
    components: {
        countTo,
    },
    props: {
        id_competencia: {
            type: Number,
            required: true,
        },
        anoInforme: {
            type: Number,
            required: true,
        },
        cod_tribunal: {
            type: Number,
            required: true,
        },
    },
    watch: {
        anoInforme() {
            try {
                this.getAudiencias()
            } catch (error) {
                console.log(error.message)
            }
        },
        '$store.state.incluirExhortoJurisdiccional'() {
            try {
                this.getAudiencias()
            } catch (error) {
                console.log(error.message);
            }
        },
    },
}
</script>

<style scoped>
.info-box {
    background: #fff;
    padding: 30px 30px 30px 20px;
    border-right: 1px solid #e5ebec;
    border-bottom: 1px solid #e5ebec;
}
</style>
