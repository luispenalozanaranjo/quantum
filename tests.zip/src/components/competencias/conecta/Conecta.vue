<template>
  <v-container fluid>
    <v-row dense>
      <v-col xs12 cols="12">
        <router-view > 
        </router-view>        
      </v-col>
    </v-row>
  </v-container>
</template>
<script>
export default {
  name: 'Conecta',
  data () {
    return {
    }
  },
  created () {
  }    
}
</script>
