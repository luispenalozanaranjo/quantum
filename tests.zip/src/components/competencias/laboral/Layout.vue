<template>
    <v-row dense>
        <v-col xs12 cols="12"> 
            <v-card class="mx-auto" width="95%">
                <v-toolbar flat class="pjud">
                    <v-toolbar-title>
                        <h2 class="white--text">{{nombreTribunal}}</h2>
                    </v-toolbar-title>
                    <v-spacer></v-spacer>
                    <v-btn  color="success"  href="javascript:history.back()" style="text-decoration:none">Volver</v-btn>
                </v-toolbar>
                <v-card-text class="pjud">
                    <slot>
                    </slot>
                </v-card-text>
            </v-card>
        </v-col>
    </v-row>
</template>



<script>
import { urlApi } from '../../../config/api'
import store from 'store'

export default {
    name: "LayoutPenal",
    data(){
        return{
            user: {
                usuario_id: store.get('user_usuario_id'), // Los parametros que obtenemos de la url
                cod_corte: store.get('cod_corte'),
                cod_tribunal: store.get('cod_tribunal'),
                ano: store.get('ano'),
                mes: store.get('mes'),
                rango: store.get('rango'),
                exhorto: store.get('exhorto')
            },
            nombreTribunal: ''
        }
    },
    created(){
        this.getTribunal();
    },
    methods:{
        getTribunal(){
            try {
                const axios = require('axios')
                const req1 = urlApi + '/laboral/tribunal_detalle' 

                const get = async req1 => {
                    try{
                        const response = await axios.get(req1, {
                            params: {
                                    cod_corte: this.user.cod_corte,
                                    cod_tribunal: this.user.cod_tribunal
                            }
                                        
                        })
                        
                        const data = response.data
                        this.nombreTribunal = ''

                        Object.values(data.recordset).map((type) => {
                            this.nombreTribunal = type.gls_tribunal
                        })


                    } 
                    catch (error) {
                        console.log(error)
                    }
                }

                get(req1)

            } catch (error) {
                console.log(error)
            }
        }
    },
    components:{
    }
}

</script>


<style lang="css" scoped>

.fondoColor {
    background-color: #DCDCDC;
}

</style>