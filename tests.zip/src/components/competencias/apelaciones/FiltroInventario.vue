<template>
    <v-card outlined class="mx-auto">
        <v-row align="center" class="px-4" dense>
            <v-col class="mt-3" cols="2" sm="2">
                <v-menu
                    v-model="menu"
                    :close-on-content-click="false"
                    :nudge-right="40"
                    transition="scale-transition"
                    offset-y
                    min-width="auto"
                >
                    <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                        v-model="date"
                        label="Fecha de Inventario"
                        prepend-icon="mdi-calendar"
                        readonly
                        v-bind="attrs"
                        v-on="on"
                    ></v-text-field>
                    </template>
                    <v-date-picker
                    v-model="date"
                    locale="es-419"
                    @input="menu = false"
                    :min="dateMin"
                    :max="dateMax"
                    ></v-date-picker>
                </v-menu>

            </v-col>  
            <v-col>
                <v-btn color="pjud white--text" @click="buscar">Buscar</v-btn>      
            </v-col>
        </v-row>
    </v-card>
</template>
<script>

import Vue from 'vue'
import store from 'store'
import moment from 'moment-timezone'
import { mapState,mapMutations } from 'vuex'

moment.locale('es');

export default {

    name: 'FiltroInventario',
    data () {
        return {
            date: 0,
            dateMax: 0,
            dateMin: "",
            menu: false,
            modal: false
        }
    },
    created(){
        try {
            const paramFecha = store.get('fechas')
            this.date = paramFecha.dateNow;
            this.date = moment(this.date).subtract(1, 'days');
            this.date = moment(this.date,'DD/MM/YYYY').format('YYYY-MM-DD');
            this.dateMax = this.date;
            
            let dateMoment = moment(this.date).subtract(90, 'days').calendar();
            dateMoment =  moment(dateMoment,'DD/MM/YYYY').format('YYYY-MM-DD');
            this.dateMin = dateMoment;
            this.buscar();
        } catch (error) {
            console.log(error.message)
        }
    },
    methods:{

        ...mapMutations(['setFechas']),

        buscar(){
            try {
				let fechas = {};
				let calendario = [];
                let fechaConsulta =  moment(this.date, 'YYYY-MM-DD');

				fechas.diaInicio = fechaConsulta.format('D');
				fechas.anoInicio = fechaConsulta.format('YYYY');
				fechas.mesInicio = fechaConsulta.format('M');
                fechas.diaFin = fechaConsulta.format('D');
				fechas.mesFin = fechaConsulta.format('M');
				fechas.anoFin = fechaConsulta.format('YYYY');
				fechas.exhorto = 1;
				fechas.nombreMesInicio = moment.months()[(fechas.mesInicio-1)];
                fechas.nombreMesFin = moment.months()[(fechas.mesFin-1)];
                fechas.periodo = "De " + fechas.nombreMesInicio + " " + fechas.anoInicio + " - Hasta " +  fechas.nombreMesFin + " " + fechas.anoFin;
                fechas.TipoBusqueda = 'Mensual';
                fechas.PeriodoAntanoInicio = Number(moment(new Date(fechas.mesInicio+'/01/'+fechas.anoInicio)).format('YYYY'));
                fechas.PeriodoAntanoFin = Number(moment(new Date(fechas.mesFin+'/01/'+fechas.anoFin)).format('YYYY'));
                fechas.PeriodoAntmesInicio = Number(moment(new Date(fechas.mesInicio+'/01/'+fechas.anoInicio)).format('M'));
                fechas.PeriodoAntmesFin = Number(moment(new Date(fechas.mesFin+'/01/'+fechas.anoFin)).format('M'));
                calendario.push(moment().month(fechas.mesFin-1).format('MMMM'));
                fechas.calendario = calendario;
				fechas.rangoSelected = 1; //mensual
				fechas.dateNow = (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10);

                this.setFechas(fechas);

            } catch (error) {
                console.log(error.message);
            }
        },
    },
    computed: {
        ...mapState(['fechas'])
    },
}

</script>