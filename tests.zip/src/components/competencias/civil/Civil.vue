<template>
	<v-container fluid>		
        <v-row>
            <v-expand-transition appear  v-for="(item) in cortes" :key="item.descripcion">
                <v-col cols="4">
                    <v-card
                        v-show="true"
                    >
                        <router-link  style="text-decoration: none;" :to="{ name: 'CivilIndicadores', params:{ cod_corte: item.cod_corte } }" >
                            <v-alert
                                prominent
                                outlined
                                color="info"
                                class="text-center"
                            >
                                <strong>{{ item.descripcion}}</strong>
                            </v-alert>
                        </router-link>
                    </v-card>     
                </v-col>
            </v-expand-transition>   
        </v-row>
	</v-container>
</template>

<script>
import axios from 'axios'
import { url } from '../../../config/apiConfig'
import store from 'store'
export default {
	name: 'Civil',
	data: () => ({
        usuario: {
            usuario: store.get('usuario'),
            nombre_completo: store.get('nombre_completo'),
            email: store.get('email')
        },
        cortes:[
            {
                Object,
                default: () => {}
            }
	    ]
	}),
	async created () {
        let objects  = []
        let response =  await this.getUserCortes(this.usuario.usuario, 'Civil')

		if(response.length == 1 && response[0].cantidad == 1){
			this.$router.push({ path: `/Home/Civil/Indicadores` }) // -> /user/123
		}
        response.map(function (object){
            objects.push({
                cod_corte: object.cod_corte,
                descripcion: object.descripcion
            })
        })

		this.cortes = objects.sort(function(a,b){return a.cod_corte - b.cod_corte})

	},
    methods: {
        async getUserCortes (usuario, competencia) {
            return new Promise(async function(resolve, reject) {
                try {
                    let response = await  axios({
                        method: 'GET',
                        url: url+'/user/getUserCortes',
                        headers: {},
                        params:{
                            usuario: usuario,
							competencia: competencia
                        }
                    })
                    resolve(response.data.cortesUser)
                } catch (err) {
                    reject(err)
                }
            })
        }
    },	
}
</script>
